import { CommonModule, HashLocationStrategy, LocationStrategy } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CoreModule } from './modules/core/core-module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { OktaInterceptor } from './utilities/oktainterceptor';
import { SharedModule } from './shared/shared.module';
import {  AsrDetailLinkPipe, DynamicPipe, RiskScorePipe, YesNoPipe } from './shared/custom-pipes';

const COMMON_MODULES = [BrowserModule, CommonModule, AppRoutingModule, CoreModule, SharedModule];

const COMMON_COMPONENT = [AppComponent];

const PIPES = [RiskScorePipe, YesNoPipe, DynamicPipe, AsrDetailLinkPipe]

@NgModule({
  declarations: [...COMMON_COMPONENT],
  imports: [...COMMON_MODULES, BrowserAnimationsModule, DynamicPipe],
  exports: [],
  bootstrap: [AppComponent],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: OktaInterceptor,
      multi: true,
    },
    PIPES
  ],
})
export class AppModule {}
