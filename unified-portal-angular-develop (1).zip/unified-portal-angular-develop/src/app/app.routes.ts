import { Routes } from '@angular/router';
import { LandingComponent } from './modules/core/landing/landing';
import { AuthGuard } from './auth.guard';
import { LayoutComponent } from './modules/core/layout/layout';

export const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: '',
        pathMatch: 'full',
        component: LandingComponent,
        data: {
          hideMenu: true,
        },
      },
      {
        path: 'Investigative',
        pathMatch: 'full',
        loadChildren: () => import('./modules/home/home-module').then((m) => m.HomeModule),
        data: {
          activeLink: true,
        },
      },
      {
        path: 'Investigative/Triage',
        loadChildren: () => import('./modules/summary/summary-module').then((m) => m.SummaryModule),
      },
      {
        path: 'Investigative/Details',
        loadChildren: () =>
          import('./modules/asr-detail/asr-detail-module').then((m) => m.AsrDetailModule),
      },

      {
        path: 'IPHome',
        pathMatch: 'full',
        redirectTo: 'Investigative',
      },
      {
        path: '**',
        pathMatch: 'full',
        redirectTo: '',
      },
    ],
  },
  {
    path: '**',
    redirectTo: '',
  },
];
