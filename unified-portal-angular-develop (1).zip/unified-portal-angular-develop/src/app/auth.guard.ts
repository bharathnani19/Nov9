import { Injectable } from '@angular/core';

import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';

import { OktaService } from './services/okta';

import { SessionService } from './services/session-timeout-service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  private loginRedirectInProgress = false;

  constructor(
    private readonly okta: OktaService,
    private readonly sessionService: SessionService,
  ) {}

  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> {
   
    if (this.okta.oktaAuth.isLoginRedirect()) {
      return false;
    }

    const authenticated = await this.okta.oktaAuth.isAuthenticated();

    if (!authenticated) {
      this.sessionService.stopSessionTimeout();

     
      if (this.loginRedirectInProgress) {
        return false;
      }

      this.loginRedirectInProgress = true;

      try {
        this.okta.oktaAuth.setOriginalUri(state.url);

        await this.okta.oktaAuth.signInWithRedirect();
      } finally {
        
        this.loginRedirectInProgress = false;
      }

      return false;
    }

   
    this.sessionService.startSessionTimeout();

    try {
      await this.okta.loadUser();
    } catch (error) {
      
      console.error('Unable to load user profile:', error);

      return false;
    }

    return true;
  }
}
