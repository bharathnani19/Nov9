export const ws_host =
  'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/fps';
export const app_url = 'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com';

export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'dev',
  appBaseHref: '/',
  okta: {
    issuer: 'https://test.idp.idm.cms.gov/oauth2/ausbbjql1yRIpm9yt297',
    clientId: '0oabbjqacsMm5sZO2297',
    redirectUri:
      'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/FPS2UnifiedPortal/',
    postLogoutRedirectUri:
      'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/FPS2UnifiedPortal/',
    scopes: ['openid', 'email', 'profile', 'offline_access'],
    tokenManager: {
      autoRenew: true,
      autoRemove: true,
    },
    state: 'fps-auth-state',
    devMode: true,
  },
  trainingUrls: {
    lms: 'https://idm.cms.gov/home/cms_cpiifislearningeps_1/0oa12gpibetx6igio298/aln12gpmwlz9Yx8Gm298',
  },
  tableauBase: 'http://dtab1.awscloud.cms.local:8000/#/',
  tableauProviderEduAttr:
    'http://dtab1.awscloud.cms.local:8000/#/views/ProviderEducation/ProviderEducationandModelAttributeReport?NPI=',
  tableauModelAttr:
    'http://dtab1.awscloud.cms.local:8000/#/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=',
  slaLoggingEnabled: false,
  splunkUrl: '',
  splunkToken: '',
};
