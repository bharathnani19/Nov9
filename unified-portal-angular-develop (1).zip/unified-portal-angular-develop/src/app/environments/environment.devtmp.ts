export const ws_host =
  'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/fps';

export const app_url = 'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com';

export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'dev',
  appBaseHref: '.',
  okta: {
    issuer: 'https://test.idp.idm.cms.gov/oauth2/ausbbjql1yRIpm9yt297',
    clientId: '0oabbjqacsMm5sZO2297',
    //redirectUri:
    //  'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/FPS2UnifiedPortal/',
    //postLogoutRedirectUri:
    //  'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/FPS2UnifiedPortal/',
    redirectUri:
      'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/unified-portal/',
    postLogoutRedirectUri:
      'https://nlb-portal-dev-fps-2-3357e18bb32e8b3b.elb.us-east-1.amazonaws.com/unified-portal/',
    scopes: ['openid', 'email', 'profile', 'offline_access'],
    state: 'fps-auth-state',
    devMode: true,
  },
  trainingUrls: { lms: 'https://impl.idp.idm.cms.gov/app/cms-impl_cpiifislearningeps_1/exk12kj4ft0stuiZp298/sso/saml' },
  tableauBase: 'http://dtab1.awscloud.cms.local:8000/#/',
  tableauProviderEduAttr : "http://dtab1.awscloud.cms.local:8000/#/views/ProviderEducation/ProviderEducationandModelAttributeReport?NPI=",
  tableauModelAttr :  "http://dtab1.awscloud.cms.local:8000/#/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=",
  slaLoggingEnabled: false,
  splunkUrl:'',
  splunkToken: ''
};
