export const ws_host = 'https://cloud.fpsportalmte.cms.cmsval/fps';
export const app_url = 'https://cloud.fpsportalmte.cms.cmsval';
export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'mte',
  appBaseHref: '/',
  okta: {
    pkce: true,
    issuer: 'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
    clientId: '0oac24ih3eJjmcmlk297',
    redirectUri: 'https://cloud.fpsportalmte.cms.cmsval/FPS2UnifiedPortal/',
    postLogoutRedirectUri: 'https://cloud.fpsportalmte.cms.cmsval/FPS2UnifiedPortal/',

    scopes: ['openid', 'email', 'profile', 'offline_access'],
    tokenManager: {
      autoRenew: true,
      autoRemove: true,
    },
  },
  trainingUrls: { lms: 'https://idm.cms.gov/home/cms_cpiifislearningeps_1/0oa12gpibetx6igio298/aln12gpmwlz9Yx8Gm298' },
  tableauBase: 'https://cloud.fpsreportsmte.cms.cmsval/t/MTE',
  tableauProviderEduAttr : "https://cloud.fpsreportsmte.cms.cmsval/t/MTE/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=",
  tableauModelAttr :  "https://cloud.fpsreportsmte.cms.cmsval/t/MTE/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=",
  slaLoggingEnabled: true,
  splunkUrl: 'https://cloud.fpsportalmte.cms.cmsval:8443/services/collector/event',
  splunkToken: '8d6687c6-f26c-42a0-93b5-93179d4adaac'
};
