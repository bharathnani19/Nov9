export const ws_host = 'https://cloud.fpsportal.cmsnet/fps';
export const app_url = 'https://cloud.fpsportal.cmsnet';
export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'prod',
  appBaseHref: '/',
  okta: {
    pkce: true,
    issuer: 'https://idm.cms.gov/oauth2/auscoyy5hpZupmXGB297',
    clientId: '0oacoyv2pq9YMwnYe297',
    redirectUri: 'https://cloud.fpsportal.cmsnet/FPS2UnifiedPortal/',
    postLogoutRedirectUri: 'https://cloud.fpsportal.cmsnet/FPS2UnifiedPortal/',

    scopes: ['openid', 'email', 'profile', 'offline_access'],
    tokenManager: {
      autoRenew: true,
      autoRemove: true,
    },
  },
  trainingUrls: { lms: 'https://idm.cms.gov/home/cms_cpiifislearningeps_1/0oa12gpibetx6igio298/aln12gpmwlz9Yx8Gm298' },
  tableauBase: 'https://cloud.fpsreports.cmsnet',
  tableauProviderEduAttr : "https://cloud.fpsreports.cmsnet/t/Prod/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=",
  tableauModelAttr :  "https://cloud.fpsreports.cmsnet/t/Prod/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=",
  slaLoggingEnabled: true,
  splunkUrl:'https://cloud.fpsportal.cmsnet:8443/services/collector/event',
  splunkToken: '53010c4b-d798-485e-9d2e-7a379cf93271'
};
