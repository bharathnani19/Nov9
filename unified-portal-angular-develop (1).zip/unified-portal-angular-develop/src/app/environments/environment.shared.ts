import { app_url, environmentExtended } from './environment';

const portalBaseUrl = environmentExtended.appUrl + '/FPS2UnifiedPortal';

export const environment = {
  extended: environmentExtended,
  wsUrls: {
    homePageTileService: environmentExtended.wsHost + '/rest/home/',
    homePageToolbarService: environmentExtended.wsHost + '/rest/landingpage/messages',
    navbarData: environmentExtended.wsHost + '/rest/landingpage/header/{userId}/{zoneId}',
    fileDownload: environmentExtended.wsHost + '/rest/modeldocs/{fileName}?userId={userId}',
    documentServlet: 'LoadDocumentServlet?fileName={fileName}&userId={userId}',
    drillReportcardlink:
      environmentExtended.wsHost +
      '/rest/asr/rptcard/{modelId}/{npi}/{type}/{attrNum}/csv?userId={userId}',

    getLandingPageData: environmentExtended.wsHost + '/rest/landingpage/{userId}/{zoneId}',
    saveUserPrefs: environmentExtended.wsHost + '/rest/preferences',
    editSearchCriteria:
      environmentExtended.wsHost + '/rest/savedsearch/{searchId}/?userId={userId}',
    workbenchItems: environmentExtended.wsHost + '/rest/provider/lists/user/{userId}',
    workbenchItemSearch:
      environmentExtended.wsHost + '/rest/provider/lists/search/{workItemId}?userId={userId}',
    workbenchListById:
      environmentExtended.wsHost + '/rest/provider/{asrType}lists/{workItemId}?userId={userId}',
    watchlistData: environmentExtended.wsHost + '/rest/landingpage/watchlist/{userId}/{zoneId}',
    reportsData: environmentExtended.wsHost + '/rest/landingpage/reportsdata/{userId}/{zoneId}',
    checkExistName:
      environmentExtended.wsHost + '/rest/provider/{asrType}lists/user/{userId}/{workbenchType}',
    renameWorkbench: environmentExtended.wsHost + '/rest/provider/{workbenchType}/{listId}',
    deleteWorkbench:
      environmentExtended.wsHost + '/rest/provider/{workbenchType}/{listId}?userId={userId}',
    sharableUsers:
      environmentExtended.wsHost + '/rest/provider/{asrType}groups/{groupId}?userId={userId}',
    shareToGroup: environmentExtended.wsHost + '/rest/provider/groups?userId={userId}',
    availableReports: environmentExtended.wsHost + '/rest/landingpage/reports/{userId}/{zoneId}',
    archive: environmentExtended.wsHost + '/rest/provider/lists/{groupId}/archive/{userId}',
    updatepubpriaction:
      environmentExtended.wsHost + '/rest/provider/exclusions/{userId}/visible/{actionBool}',
    getCriminalDetails:
      environmentExtended.wsHost + '/rest/asr/detail/{asrId}/{searchType}?userId={userId}',
    getAsrDetails:
      environmentExtended.wsHost + '/rest/asr/detail/{asrId}/{searchType}?userId={userId}',
    getMdcdAsrDetails:
      environmentExtended.wsHost + '/rest/mdcd/asr/detail/{asrId}/{searchType}?userId={userId}',
    watchlistSubscribe: environmentExtended.wsHost + '/rest/service/subscribe',
    editInfo: environmentExtended.wsHost + '/rest/landing/editinfo?userId={userId}',
    editClaimsDenied:
      environmentExtended.wsHost + '/rest/editinfo/claims/{npi}/{editName}?userId={userId}',
    asrDetailEditInfo: environmentExtended.wsHost + '/rest/editinfo?userId={userId}',
    getAsrSearchRefdata: environmentExtended.wsHost + '/rest/refdata/ASRLEVEL?userId={userId}',
    getSavedSearchRefdata: environmentExtended.wsHost + '/rest/provider/lists/user/{userId}/search',
    verifyAsrs: environmentExtended.wsHost + '/rest/{asrType}asr/search/verify',
    asrSearch: environmentExtended.wsHost + '/rest/asr/search',
    infoModel:
      environmentExtended.wsHost +
      '/rest{type}/asr/search/latest/{modelId}/{modelDate}?userId={userId}',
    //Triage
    retrieveUserPrefs: environmentExtended.wsHost + '/rest/preferences/{userId}/{type}',
    getAddToExistInputVals:
      environmentExtended.wsHost + '/rest/provider/{searchType}lists/user/{userId}/asr',
    createWorkingSet: environmentExtended.wsHost + '/rest/provider/lists',
    addToExistingWorkingSet:
      environmentExtended.wsHost + '/rest/provider/lists/{workItemId}/items?userId={userId}',
    removeFromWorkingSet:
      environmentExtended.wsHost + '/rest/provider/lists/{workItemId}/items?userId={userId}',
    getP1costDeails:
      environmentExtended.wsHost + '/rest/asr/detail/{asrId}/P1TOTALZNCOST?userId={userId}',
    getPrioritizeForUCMTableData:
      environmentExtended.wsHost + '/rest/{searchType}asr/availablemodels',
    getPriorUcmZones: environmentExtended.wsHost + '/rest/refdata/PRIORITIZE',
    prioritizeASRsForUCM: environmentExtended.wsHost + '/rest/asr/priority',
    googleMaps:
      environmentExtended.wsHost + '/rest/asr/detail/{asrptId}/MAPS/{resultsIndex}?userId={userId}',
    modelGoogleMaps: environmentExtended.wsHost + '/rest/asr/{asrptId}/alert/{modelId}/benes',
    //Details
    asrDetails:
      environmentExtended.wsHost + '/rest/{searchType}asr/detail/{asrId}/{asrType}?userId={userId}',
    asrFieldExport: environmentExtended.wsHost + '/rest/asrexport/{asrptId}?userId={userId}',
    mdcdAsrFieldExport:
      environmentExtended.wsHost + '/rest/mdcd/asrexport/{asrptId}?userId={userId}',
    ucmLeadData: environmentExtended.wsHost + '/rest/asr/investigation/{leadId}',
    reportCards: environmentExtended.wsHost + '/rest/asr/rptcard/{modelId}/{npi}',
    mdcdReportCards: environmentExtended.wsHost + '/rest/mdcd/asr/rptcard/{modelId}/{npi}/{state}',
    claimsExport: environmentExtended.wsHost + '/rest',
    viz: environmentExtended.wsHost + '/rest/asr/{vizType}/{asrID}{modelId}?userId={userId}',
    vizExport:
      environmentExtended.wsHost + '/rest/asr/{vizExportType}/{asrID}{modelId}?userId={userId}',
    vizReportCard: environmentExtended.wsHost + '/rest/{asrType}asr/rptcard/{modelId}/{npi}',
  },
  upHome: environmentExtended.appUrl + '/FPS2UnifiedPortal',
  umLink: environmentExtended.appUrl + '/UserManagement',
  vulMgmt: environmentExtended.appUrl + '/VulnerabilityManagement',
  editInq: environmentExtended.appUrl + '/ProblemReportingTool',
  emlLink: environmentExtended.appUrl + '/eml/',
  admin: environmentExtended.appUrl + '/unified-portal/#/Administration',
  newUserRoleRequestUrl: environmentExtended.appUrl + '/UserManagement/#/userprofile',
  wsHost: environmentExtended.wsHost,
  appUrl: environmentExtended.appUrl,
  tableauProviderProfile:
    environmentExtended.tableauBase + '/views/ProviderProfile/ProviderInfo?ASRPTID=',
  tableauEditTrend:
    environmentExtended.tableauBase + '/views/EditsTrendReport/EditsTrendReport?NPI=',
  tableauProviderEduAttr:
    environmentExtended.tableauBase +
    '/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=',
  tableauModelAttr: environmentExtended.tableauModelAttr,
  tableauProviderEducation:
    environmentExtended.tableauBase +
    '/views/ProviderEducationandModelAttribute/ProviderEducationReport?NPI=',
  tableauChow:
    environmentExtended.tableauBase + '/views/ChangeinOwnershipCHOWReport/ChangeinOwnership?NPI=',
  tableauRiskScoreTrending2:
    environmentExtended.tableauBase + '/views/RiskScoreTrendingReport/RiskScoreTrendChart',
  tableauRiskScoreTrending:
    environmentExtended.tableauBase +
    '/views/RiskScoreTrendingReport/RiskScoreTrendChart?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no&:jsdebug=n',
};
