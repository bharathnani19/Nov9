export const ws_host = 'https://cloud.fpsportal.cms.cmsval/fps';
export const app_url = 'https://cloud.fpsportal.cms.cmsval';
export const environmentExtended = {
  wsHost: ws_host,
  appUrl: app_url,
  production: false,
  env: 'val',
  appBaseHref: '/',
  okta: {
    pkce: true,
    issuer: 'https://impl.idp.idm.cms.gov/oauth2/ausc24l2w5nTQczdY297',
    clientId: '0oac24ih3eJjmcmlk297',
    redirectUri: 'https://cloud.fpsportal.cms.cmsval/unified-portak/',
    postLogoutRedirectUri: 'https://cloud.fpsportal.cms.cmsval/unified-portal/',

    scopes: ['openid', 'email', 'profile', 'offline_access'],
    tokenManager: {
      autoRenew: true,
      autoRemove: true,
    },
  },
  trainingUrls: { lms: 'https://impl.idp.idm.cms.gov/app/cms-impl_cpiifislearningeps_1/exk12kj4ft0stuiZp298/sso/saml' },
  tableauBase: 'https://cloud.fpsreports.cms.cmsval/t/Val',
  tableauProviderEduAttr : "https://cloud.fpsreports.cms.cmsval/t/Val/views/ProviderEducationandModelAttribute/ProviderEducationandModelAttributeReport?NPI=",
  tableauModelAttr :  "https://cloud.fpsreports.cms.cmsval/t/Val/views/ModelAttributeComparisonReport/ModelAttributeComparisonReport-TabularList?NPI=",
  slaLoggingEnabled: true,
  splunkUrl:'https://cloud.fpsportal.cms.cmsval:8443/services/collector/event',
  splunkToken: '8d6687c6-f26c-42a0-93b5-93179d4adaac'
};
