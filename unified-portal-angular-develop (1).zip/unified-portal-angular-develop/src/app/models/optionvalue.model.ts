export class OptionValue{
    displayVal?:string;
    optionVal?:string;
    hideable:boolean=false;
}