import { Component, inject, OnDestroy } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Card } from '../../shared/interface';
import { OktaService } from '../../services/okta';
import { AsrDetailsService } from '../../services/asr-details.service';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AsrDetails } from './model';
import { ToastService } from '../../services/toaster.service';
import { LoaderService } from '../../services/loader.service';
import { MatDialog } from '@angular/material/dialog';
import { CommonDialogComponent } from '../../shared/dialog/common-dialog/common-dialog';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { Subject, takeUntil } from 'rxjs';
import { FileUploadService } from '../../services/file-upload.service';
import { GoogleMapsLoaderService } from '../../services/google-maps-loader.service';
import { AsrGoogleMapApiService } from '../../services/asr-google-map-api.service';

@Component({
  selector: 'app-asr-detail',
  templateUrl: './asr-detail.html',
  styleUrl: './asr-detail.scss',
  standalone: false,
})
export class AsrDetailComponent implements OnDestroy {
  private _asrDetailsService = inject(AsrDetailsService);
  private _fileService = inject(FileUploadService);
  private _route = inject(ActivatedRoute);

  isLoading: boolean = false;
  selectedTabIndex: number = 0;

  private destory$ = new Subject<void>();
  constructor(
    private title: Title,
    public okta: OktaService,
    private _toaster: ToastService,
    private _loader: LoaderService,
    public dialog: MatDialog,
  ) {
    this.title.setTitle('ASR Details');
    this._initData();
  }

  ngOnDestroy(): void {
    this.destory$.next();
    this.destory$.complete();
  }

  get asrDetails(): AsrDetails | null {
    return this._asrDetailsService.asrDetails();
  }

  private _initData() {
    this._loader.show();
    this._route.queryParamMap.pipe(takeUntil(this.destory$)).subscribe(({ params }: any) => {
      const { viewParam: searchType, asrId } = params;
      this.selectedTabIndex = searchType === 'medicaid' ? 1 : 0;
      this._fetchDetails(searchType, 'init', asrId);
    });
  }

  private _fetchDetails(searchType: string, type: string, asrId: string | number) {
    this._loader.show();
    this._asrDetailsService
      .getAsrDetails(searchType, 'init', asrId)
      .pipe(takeUntil(this.destory$))
      .subscribe({
        next: (res: any) => {
          this._loader.hide();
        },
        error: (error: HttpErrorResponse) => {
          this._loader.hide();
          this._toaster.error('ASR Details failed due to ' + error.status);
        },
      });
  }

  detailsCard: Card = {
    title: 'ASR Details',
    hoverText:
      'The ASR Details page displays information related the ASR alerted provider, their alerts, edits and the leads and investigations tied to them.',
  };

  onTabChange(e: MatTabChangeEvent) {
    const searchType = e.index ? 'medicaid' : 'medicare';
    const asrId =
      searchType === 'medicare' ? this.asrDetails?.asrDbId : this.asrDetails?.mdcdAsrDbId;
    if (asrId) this._fetchDetails(searchType, 'init', asrId);
  }

  downloadExport(): void {
    const programType = this.selectedTabIndex === 0 ? 'medicare' : 'medicaid';
    const asrptId = this.asrDetails?.provider?.npi;
    if (!asrptId) {
      this._toaster.error(`Unable to download ${programType} field export. Missing ASR ID.`);
      return;
    }

    this._loader.show();
    this._fileService
      .downloadAsrFieldExport(asrptId, programType)
      .pipe(takeUntil(this.destory$))
      .subscribe({
        next: (downloaded) => {
          this._loader.hide();

          if (!downloaded) {
            this._toaster.error(`Unable to download ${programType} field export.`);
          }
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Unable to download ${programType} field export due to ${err.status}.`,
          );
        },
      });
  }

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }
}
