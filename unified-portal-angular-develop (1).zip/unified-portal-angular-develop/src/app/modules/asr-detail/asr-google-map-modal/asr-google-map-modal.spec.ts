import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsrGoogleMapModalComponent } from './asr-google-map-modal';

describe('AsrGoogleMapModalComponent', () => {
  let component: AsrGoogleMapModalComponent;
  let fixture: ComponentFixture<AsrGoogleMapModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AsrGoogleMapModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AsrGoogleMapModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
