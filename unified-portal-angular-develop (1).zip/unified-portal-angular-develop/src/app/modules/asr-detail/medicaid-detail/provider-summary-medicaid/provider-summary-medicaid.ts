import { Component, Input } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AsrDetails } from '../../model';
import { OktaService } from '../../../../services/okta';
import { ToastService } from '../../../../services/toaster.service';
import { allRoleTypes, allOrgTypes } from '../../../../utilities/constants';
import { TriageService } from '../../../../services/triage.service';
import { LoaderService } from '../../../../services/loader.service';
import { MatDialog } from '@angular/material/dialog';
import { PrioritizeUcmTableComponent } from '../../../../shared//prioritize-ucm/prioritize-ucm.component';
import { CommonDialogComponent } from '../../../../shared/dialog/common-dialog/common-dialog';
import { AsrDetailsService } from '../../../../services/asr-details.service';
import { ASRDetailsTableComponent } from '../../asr-detail-table/asr-detail-table';
import { ASR_MEDICAID_MODEL_COLUMNS, Prioritize_MDCD_Columns } from '../.././column-config';

@Component({
  selector: 'provider-summary-medicaid',
  templateUrl: './provider-summary-medicaid.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class ProviderSummaryMedicaidComponent {
  @Input() asrDetails!: AsrDetails | null;
  canPrioritize: boolean = false;

  constructor(
    public okta: OktaService,
    public dialog: MatDialog,
    private _loader: LoaderService,
    private _toaster: ToastService,
    private _triageService: TriageService,
    private _detailsService: AsrDetailsService,
  ) {
    this.canPrioritize = !!this.okta.user()?.groups?.includes(allRoleTypes.ROLE_PRIORITY_SUP);
  }

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }

  viewTotalPaymentModal() {
    const data = this.asrDetails?.mdcdTotalPayments || [];
    this.openTableDialog(
      {
        title: 'Medicaid Alerted Total Payment',
        info: 'This table displays the total amount paid to the ASR alerted provider based on alerted claims at risk from the last model run. Medicaid data displayed in the Total Payment table does not include all claims and only displays information related to the Alerting Model/Alerting Claims. Provider Roles are displayed per the claim header and/or claim line that the model alerted on.',
        warningMessage:
          "In the Medicaid Alerted Total Payment table if a provider has an alert in a state outside of the end-user's jurisdiction all information except financials displays. N/A is displayed in columns with amounts outside of the end-user's jurisdiction and for columns in which there is no data to display. The end-user will not be able to export any claims for financial information for a Medicaid Alerted State outside of the end-user's jurisdiction.",
       dialogId:'totalPaymentMDCDModal',
          componentData: {
          rowData: data,
          columns: ASR_MEDICAID_MODEL_COLUMNS,
          tableName: 'Medicaid Alerted Total Payment Table',
          tableId: 'totalPaymentMDCDTable',
          tableHeight: '40vh',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true
      },
      '80%',
    );
  }

  openPrioritizeDialog() {
      const selectedRows = this.asrDetails?.mdcdAsrDbId ? [{ asrDbid: this.asrDetails.mdcdAsrDbId }] : [];
      if (
        this.okta.user()?.groups?.includes(allOrgTypes.MEDIC) &&
        this.asrDetails?.hasPartD === 'N'
      ) {
        this._toaster.error(
          'The prioritization of this ASR is not permitted because the ASR is not associated with Part D claims.',
        );
        return;
      }
  
      this._triageService.getPriorUcmZones().subscribe({
        next: (res: any) => {
          const zones = res?.responseData || [];
        },
      });
      this._loader.show();
      const asrType = 'medicaid';
      this._triageService.getPrioritizeForUCMTableData(asrType, selectedRows).subscribe({
        next: (res: any) => {
          this._loader.hide();
          const rowData = Array.isArray(res) ? res : res?.responseData || [];
          this.openTableDialog(
            {
              title: 'Prioritize for UCM',
              info: 'Indicate Model and State and Confirm to Prioritize ASR.',
              warningMessage:
                'By prioritizing ASRs, they will be sent to the UCM FPS queue for processing. Complete the fields below, then click Prioritize. Prioritization can only be applied to models that have triggered alerts in states within your jurisdiction.',
               dialogId:'prioritizeMdcdModal',
                componentData: {
                rowData,
                columns:  Prioritize_MDCD_Columns,
                tableName: 'Prioritize Table',
                tableId: 'prioritizeMdcdTable',
                programType: asrType,
              },
              panelClass: 'ip-dialog-panel',
              component: PrioritizeUcmTableComponent,
            },
            '90%',
          );
        },
        error: () => {
          this._loader.hide();
        },
      });
    }
}
