import { Component, Inject, Input, OnInit } from '@angular/core';
import {
  LEADS_ACTIVITY_COLUMNS,
  LEADS_RULING_COLUMNS,
  LEADS_ACTIONS_COLUMNS,
  LEADS_RATE_COLUMNS,
  LEADS_BACTIONS_COLUMNS,
} from '../../../../column-config';
import { AsrDetailsService } from '../../../../../../services/asr-details.service';
import { LoaderService } from '../../../../../../services/loader.service';
import { ToastService } from '../../../../../../services/toaster.service';

@Component({
  selector: 'lead-detail',
  templateUrl: './lead-detail.component.html',
  standalone: false,
})
export class LeadDetailComponent implements OnInit {
  rowData: any[];
  showMppINV: boolean = true;
  ucmData: any;

  constructor(
    @Inject('componentData') public data: any,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
  ) {
    this.rowData = this.data?.rowData || [];
  }
  LEADS_ACTIVITY_COLUMNS = LEADS_ACTIVITY_COLUMNS;
  LEADS_RULING_COLUMNS = LEADS_RULING_COLUMNS;
  LEADS_ACTIONS_COLUMNS = LEADS_ACTIONS_COLUMNS;
  LEADS_BACTIONS_COLUMNS = LEADS_BACTIONS_COLUMNS;
  LEADS_RATE_COLUMNS = LEADS_RATE_COLUMNS;
  selectedTabIndex: any;

  ngOnInit() {
    const ucmId = this.data?.rowData?.ucmId || '';
    this.showMppINV = !ucmId.includes('MPP');
    this._loader.show();
    this._detailsService.ucmLeadData(this.data?.rowData?.id).subscribe({
      next: (res: any) => {
        this.ucmData = res.responseData?.leads[0];
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this._toaster.error('Cannot retrieve lead information due to ' + err.status);
      },
    });
  }
//   trackUserActivity('HLEADS', null);
}
