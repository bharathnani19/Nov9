import { Component, effect, Input, OnChanges, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import {
  ASR_HISTORY_COLUMNS,
  NOTES_COLUMNS,
  ALERTS_HISTORY_COLUMNS,
  PHASE1_ALERTS_HISTORY_COLUMNS,
  LEADS_HISTORY_COLUMNS,
  MODEL_GUIDANCE_COLUMNS,
  PHASE1_ALERT_DLG_COLUMNS,
  ALERT_DLG_COLUMNS,
} from '../../column-config';
import { AsrDetails } from '../../model';
import { MatDialog } from '@angular/material/dialog';
import { AsrDetailsService } from '../../../../services/asr-details.service';
import { LoaderService } from '../../../../services/loader.service';
import { ToastService } from '../../../../services/toaster.service';
import { HomePageService } from '../../../../services/homepage.service';
import { OktaService } from '../../../../services/okta';
import { CommonDialogComponent } from '../../../../shared/dialog/common-dialog/common-dialog';
import { ASRDetailsTableComponent } from '../../asr-detail-table/asr-detail-table';
import { LeadDetailComponent } from '../current-records/Leads/lead-detail/lead-detail.component';

@Component({
  selector: 'medicare-history',
  templateUrl: './medicare-history.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class MedicareHistoryComponent implements OnInit , OnChanges{
  @Input() asrDetails: AsrDetails | null = null;
  selectedTabIndex: any;
  asrHistoryColumns = ASR_HISTORY_COLUMNS;
  notesColumns = NOTES_COLUMNS;
  historyAlertsColumns = ALERTS_HISTORY_COLUMNS;
  historyP1AlertsColumns = PHASE1_ALERTS_HISTORY_COLUMNS;
  historyLeadsColumns = LEADS_HISTORY_COLUMNS;
  notesData: any[] = [];
  historyAlertsData: any[] = [];
  historyP1AlertsData: any[] = [];
  historyLeadsData: any[] = [];

  constructor(
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    public okta: OktaService,
  ) { }
  
  ngOnChanges(){
    this.setDefaultTab();
  }
  setDefaultTab() {
    this.selectedTabIndex = 0;
  }

  ngOnInit() {}
  onTabChange(event: MatTabChangeEvent): void {
    const index = event.index;

    switch (index) {
      case 1:
        this.loadNotes();
        break;

      case 2:
        this.loadHistoryAlerts();

        break;
      case 3:
        this.loadHistoryP1Alerts();
        break;

      case 4:
        this.loadAsrHistoryLeads();
        break;
    }
  }
  loadHistoryP1Alerts() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'P1HALERTS', String(this.asrDetails?.asrDbId ?? '0'))
      .subscribe({
        next: (res: any) => {
          this.historyP1AlertsData = res?.responseData?.historyP1Alert || [];
          this._loader.hide();
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Error loading Phase 1 Alerts data to ${err?.status || 'error'}`);
        },
      });
  }
  loadHistoryAlerts() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'HALERTS', String(this.asrDetails?.asrDbId ?? '0'))
      .subscribe({
        next: (res: any) => {
          this.historyAlertsData = res?.responseData?.oldAlert || [];
          this._loader.hide();
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Error loading Alerts data to ${err?.status || 'error'}`);
        },
      });
  }
  loadNotes() {
    throw new Error('Method not implemented.');
  }
  loadAsrHistoryLeads() {
     this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'HLEADS', String(this.asrDetails?.asrDbId ?? '0'))
      .subscribe({
        next: (res: any) => {
          this.historyLeadsData = res?.responseData?.leads || [];
          this._loader.hide();
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Error loading Alerts data to ${err?.status || 'error'}`);
        },
      });
  }
  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }
  openModels(row: any) {
    this.openTableDialog(
      {
        title: 'Models',
        info: "This table displays the selected model's details. To obtain an available Model Guidance document, select the model name hyperlink.",
        dialogId: 'modalsModal',
        componentData: {
          rowData: [{ ...row?.models, modelSchemes: row?.modelSchemes ?? '' }],
          columns: MODEL_GUIDANCE_COLUMNS,
          tableName: 'Models Table',
          tableId: 'ModalsTable',
          componentId: 'Modals',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true,
      },
      '80%',
    );
  }

  onViewAlerts(row: any, alertType: 'alerts' | 'p1Alerts') {
    row.alerts = row.alerts?.map((alert: any) => ({
      ...alert,
      asrDbId: row.asrptId,
      modelId: row?.models?.modelId,
    }));
    const columns = alertType === 'p1Alerts' ? PHASE1_ALERT_DLG_COLUMNS : ALERT_DLG_COLUMNS;
    const title = 'Alerts Model – ' + row.modelBusnsId;
    this.openTableDialog(
      {
        title: title,
        info: 'The table below provides the details associated with each alert, or each time the ASR ID was identified during a model run. To learn about the information contained within the table below, hover over the information indicators.',
        dialogId: 'alertsModal',
        componentData: {
          rowData: row?.alerts,
          columns,
          asrDetails: this.asrDetails,
          tableName: 'Alerts Table',
          tableId: 'AlertsTable',
          componentId: 'Alerts',
        },
        panelClass: 'ip-dialog-panel',
        component: ASRDetailsTableComponent,
        enableClose: true,
      },
      '80%',
    );
  }
  getHistoryLeadId(row: any): string {
      return  row?.id || '';
    }
  
    shouldShowHistoryLeadLink(row: any): boolean {
      const macUser = this.okta.user().macUser;
  
      return !macUser;
    }
  
    viewHistoryLead(row: any): void {
      const leadId = this.getHistoryLeadId(row);
  
      if (!leadId) {
        return;
      }
  
      this.dialog.open(CommonDialogComponent, {
        width: '60%',
        data: {
          title: 'Legacy FPS2 Record Information',
          info: 'The tabs below display the details logged for the category specified in the selected FPS2 Legacy Lead or Investigation.',
          dialogId: 'Leads Detail Model',
          componentData: {
            rowData: row,
          },
          panelClass: 'ip-dialog-panel',
          component: LeadDetailComponent,
          enableClose: true,
        },
      });
    }
}
