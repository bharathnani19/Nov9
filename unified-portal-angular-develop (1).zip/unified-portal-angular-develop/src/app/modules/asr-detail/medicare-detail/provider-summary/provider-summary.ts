import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AsrDetails } from '../../model';
import { OktaService } from '../../../../services/okta';
import { ToastService } from '../../../../services/toaster.service';
import { allRoleTypes, allOrgTypes } from '../../../../utilities/constants';
import { TriageService } from '../../../../services/triage.service';
import { LoaderService } from '../../../../services/loader.service';
import { MatDialog } from '@angular/material/dialog';
import { environment } from '../../../../environments/environment.shared';
import {
  ASR_COST_COLUMNS,
  ASR_JURISDICTION_COLUMNS,
  ASR_PHASE1_JURISDICTION_COLUMNS,
  Prioritize_Columns,
} from '../.././column-config';
import { PrioritizeUcmTableComponent } from '../../../../shared//prioritize-ucm/prioritize-ucm.component';
import { CommonDialogComponent } from '../../../../shared/dialog/common-dialog/common-dialog';
import { AsrDetailsService } from '../../../../services/asr-details.service';
import { ASRDetailsTableComponent } from '../../asr-detail-table/asr-detail-table';
import { AsrGoogleMapModalComponent } from '../../asr-google-map-modal/asr-google-map-modal';
import { VisualizationDialogComponent } from '../../visualization/visualization';

@Component({
  selector: 'provider-summary',
  templateUrl: './provider-summary.html',
  styleUrls: ['../../asr-detail.scss'],
  standalone: false,
})
export class ProviderSummaryComponent {
  @Input() asrDetails: AsrDetails | null = null;
  canPrioritize: boolean = false;

  constructor(
    public okta: OktaService,
    public dialog: MatDialog,
    private _loader: LoaderService,
    private _toaster: ToastService,
    private _triageService: TriageService,
    private _detailsService: AsrDetailsService,
  ) {
    this.canPrioritize = !!this.okta.user()?.groups?.includes(allRoleTypes.ROLE_PRIORITY_SUP);
  }

  openTableDialog(data: any, width: string = '80%') {
    this.dialog.open(CommonDialogComponent, {
      width,
      data: {
        ...data,
      },
      panelClass: 'ip-dialog-panel',
    });
  }

  openPrioritizeDialog() {
    const selectedRows = this.asrDetails?.asrDbId ? [{ asrDbid: this.asrDetails.asrDbId }] : [];
    if (
      this.okta.user()?.groups?.includes(allOrgTypes.MEDIC) &&
      this.asrDetails?.hasPartD === 'N'
    ) {
      this._toaster.error(
        'The prioritization of this ASR is not permitted because the ASR is not associated with Part D claims.',
      );
      return;
    }

    this._triageService.getPriorUcmZones().subscribe({
      next: (res: any) => {
        const zones = res?.responseData || [];
      },
    });
    this._loader.show();
    const asrType = 'medicare';
    this._triageService.getPrioritizeForUCMTableData(asrType, selectedRows).subscribe({
      next: (res: any) => {
        this._loader.hide();
        const rowData = Array.isArray(res) ? res : res?.responseData || [];
        this.openTableDialog(
          {
            title: 'Prioritize for UCM',
            info: 'Indicate Model and Confirm to Prioritize ASR.',
            dialogId: 'prioritizeModelID',
            warningMessage:
              'By prioritizing ASRs, they will be sent to the UCM FPS queue for processing. Complete the fields below, then click Prioritize.',
            componentData: {
              rowData,
              columns: Prioritize_Columns,
              tableName: 'Prioritize Table',
              tableId: 'prioritizeTable',
              programType: asrType,
            },
            panelClass: 'ip-dialog-panel',
            component: PrioritizeUcmTableComponent,
          },
          '90%',
        );
      },
      error: () => {
        this._loader.hide();
      },
    });
  }

  p1TotalCostByZoneBtnClick() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'P1TOTALZNCOST', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.p1TotalCostZones || [];
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Phase 1 ASR Cost by Jurisdiction',
              info: 'This table displays the Phase 1 ASR cost submitted amount for the ASR alerted provider per UPIC jurisdiction. The ASR cost amount is based on claims-at-risk for alerts within the last 14 days and is updated daily.',
              warningMessage:
                'Only jurisdictions with claims are displayed in the table below.',
              dialogId: 'p1AsrCostModelId',
              componentData: {
                rowData: data,
                columns: ASR_PHASE1_JURISDICTION_COLUMNS,
                tableName: 'Phase 1 ASR Cost Table',
                tableId: 'p1AsrCostTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            },
            '80%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Unable to load ASR Cost data due to ${err?.status || 'error'}`);
        },
      });
  }

  totalCostByZoneBtnClick() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'totalzncost', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.totalCostZones || [];
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'ASR Cost by Jurisdiction',
              info: 'This table displays the ASR cost amount paid to the ASR alerted provider per UPIC jurisdiction. The ASR Cost amount is based on claims-at-risk for alerts within the last 180 days and is updated weekly. The UPIC Jurisdiction is derived from the contractor that processed the claim for Part A and Part B and the beneficiary pricing state for DME.',
              dialogId:'asrCostModal',
              warningMessage:
                'Only jurisdictions with claims are displayed in the table below.',
              componentData: {
                rowData: data,
                columns: ASR_COST_COLUMNS,
                tableName: 'ASR Cost Table',
                tableId: 'asrCostTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            },
            '80%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Unable to load ASR Cost data due to ${err?.status || 'error'}`);
        },
      });
  }

  viewTotalPaymentModal() {
    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'TOTALZNPYMT', this.asrDetails?.provider?.npi ?? 'none')
      .subscribe({
        next: (res: any) => {
          const data = res?.responseData?.totalPymtZones || [];
          this._loader.hide();

          this.openTableDialog(
            {
              title: 'Total Payment by Jurisdiction',
              info: 'This table displays the total amount paid to the ASR alerted provider per UPIC jurisdiction and Railroad Retirement Board (RRB) MAC. The total payment amount is based on Part A, B, and DME all claims for a rolling one year timeframe and is updated weekly. The UPIC Jurisdiction and RRB MAC is derived from the contractor that processed the claim for Part A and Part B and the beneficiary pricing state for DME.',
              dialogId:'totalPmntModal',
              warningMessage:
                'Only jurisdictions with claims are displayed in the table below.',
              componentData: {
                rowData: data,
                columns: ASR_JURISDICTION_COLUMNS,
                tableName: 'Total Payment Table',
                tableId: 'totalPmntTable',
              },
              panelClass: 'ip-dialog-panel',
              component: ASRDetailsTableComponent,
              enableClose: true
            },
            '80%',
          );
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(`Unable to load Total Payment data due to ${err?.status || 'error'}`);
        },
      });
  }

  showProviderProfile() {
    window.open(environment.tableauProviderProfile + this.asrDetails?.asrDbId);
  }

  openGoogleMaps(asrptId:any): void {
      
        this.dialog.open(AsrGoogleMapModalComponent, {
        autoFocus: false,
        restoreFocus: true,
        width: '80%',
        maxWidth: '100%',
        panelClass: 'ip-dialog-panel',
        data: {
          asrptId: asrptId
        },
      });
     
    }
  
  viewNetworkViz(vizTypeMap: any) {
     
      this._loader.show();
      this._detailsService
        .getVizData({
          asrId: this.asrDetails?.provider.npi || '',
          vizType: vizTypeMap || 'viz',
          // modelId: row.models.modelName,
        })
        .subscribe({
          next: (res: any) => {
            this._loader.hide();
            this.dialog.open(VisualizationDialogComponent, {
              width: '80vw',
              data: {
                nodes: res.nodes,
                edges: res.edges,
                attributes: res.attributes,
                vizType: vizTypeMap === 'dmeviz' ? "DME" : 'HHA',
                enableClose: true,
                asrDetails: this.asrDetails,
              },
            });
          },
          error: (err: any) => {
            this._loader.hide();
            this._toaster.error('Unable to load due to ' + err.status);
          },
        });
    }
}
