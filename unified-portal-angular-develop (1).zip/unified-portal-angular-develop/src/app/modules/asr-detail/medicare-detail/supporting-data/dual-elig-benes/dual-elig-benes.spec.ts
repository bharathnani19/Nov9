import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DualEligBenesComponent } from './dual-elig-benes';

describe('DualEligBenesComponent', () => {
  let component: DualEligBenesComponent;
  let fixture: ComponentFixture<DualEligBenesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DualEligBenesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DualEligBenesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
