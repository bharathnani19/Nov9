import { Component, effect, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AsrDetailsService } from '../../../../../services/asr-details.service';
import { LoaderService } from '../../../../../services/loader.service';
import { OktaService } from '../../../../../services/okta';
import { ToastService } from '../../../../../services/toaster.service';
import { KeyValue } from '../../../model';
import { DUAL_ELIGIBLE_BENEFICIARIES_COLUMNS } from '../../../column-config';

@Component({
  selector: 'app-dual-elig-benes',
  standalone: false,
  templateUrl: './dual-elig-benes.html',
  styleUrl: '../../../asr-detail.scss'
})
export class DualEligBenesComponent {
 @Input() asrId: string = "";
 benes: KeyValue[] = [];
 debColumns = DUAL_ELIGIBLE_BENEFICIARIES_COLUMNS;

 constructor(
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    public okta: OktaService,
  ) {

  }

  ngOnInit() {

    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', 'DUALBENES',this.asrId ?? '0')
      .subscribe({
        next: (res: any) => {
          this.benes = res?.responseData?.provider?.dualBenes || [];
         
          this._loader.hide();

        
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Error loading DEB data to ${err?.status || 'error'}`,
          );
        },
      });

     
   
  }
}
