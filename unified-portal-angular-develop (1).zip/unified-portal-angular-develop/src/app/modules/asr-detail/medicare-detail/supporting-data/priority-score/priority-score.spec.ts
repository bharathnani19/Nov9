import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PriorityScore } from './priority-score';

describe('PriorityScore', () => {
  let component: PriorityScore;
  let fixture: ComponentFixture<PriorityScore>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PriorityScore]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PriorityScore);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
