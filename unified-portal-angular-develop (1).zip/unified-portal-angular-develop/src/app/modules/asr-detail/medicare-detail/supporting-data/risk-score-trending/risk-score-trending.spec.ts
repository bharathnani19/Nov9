import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RiskScoreTrending } from './risk-score-trending';

describe('RiskScoreTrending', () => {
  let component: RiskScoreTrending;
  let fixture: ComponentFixture<RiskScoreTrending>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RiskScoreTrending]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RiskScoreTrending);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
