import { AfterViewInit, Component, effect, ElementRef, Input, viewChild, ViewChild } from '@angular/core';
import { environment } from '../../../../../environments/environment.shared';
declare var tableau: any;
@Component({
  selector: 'app-risk-score-trending',
  standalone: false,
  templateUrl: './risk-score-trending.html',
  styleUrl: './risk-score-trending.scss',
})
export class RiskScoreTrendingComponent {
  tableauVizRef = viewChild<ElementRef>('tableauViz');

  @Input() asrId: string="0";
  vizUrl:string = environment.tableauRiskScoreTrending;

  constructor() {
    effect(() => {
      const viz = this.tableauVizRef();
      if (viz) {
        	viz?.nativeElement.addEventListener('firstinteractive', () => {
          console.log('Tableau Dashboard has fully loaded.');
          try {
            this.updateParameter(viz.nativeElement);
          } catch (error) {
            console.error('Failed to change parameter:', error);
          }
        });
      }
    });
  }
  ngOnChanges(){
    console.log("refreshing risk score trending");
     const viz = this.tableauVizRef();
      if (viz) {
        this.updateParameter(viz.nativeElement);
      }
  }

  
  async  updateParameter(viz:any) {
    try {
      
      const workbook = await viz.workbook;    
      
      await workbook.changeParameterValueAsync('NPI', this.asrId);
    } catch (error) {
      console.error('Error updating parameter:', error);
    }
  }
  getAsrId():string{
    return this.asrId;
  }
  onNgInit(){
    this.vizUrl = environment.tableauRiskScoreTrending;

  }

}
