import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopFiveCodesComponent } from './top-five-codes';

describe('TopFiveCodesComponent', () => {
  let component: TopFiveCodesComponent;
  let fixture: ComponentFixture<TopFiveCodesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TopFiveCodesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TopFiveCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
