import { Component, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AsrDetailsService } from '../../../../../services/asr-details.service';
import { LoaderService } from '../../../../../services/loader.service';
import { OktaService } from '../../../../../services/okta';
import { ToastService } from '../../../../../services/toaster.service';
import { TOP_HCPCS_ICD_COLUMNS } from '../../../column-config';
import { HcpcsIcdData } from '../../../model';

@Component({
  selector: 'app-top-five-codes',
  standalone: false,
  templateUrl: './top-five-codes.html',
  styleUrl: '../../../asr-detail.scss',
})
export class TopFiveCodesComponent {
 @Input() asrId: string = "";
 @Input() type: string = "HCPCS";
 topData: HcpcsIcdData[] = [];
 topColumns = TOP_HCPCS_ICD_COLUMNS;

 constructor(
    public dialog: MatDialog,
    private _detailsService: AsrDetailsService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    public okta: OktaService,
  ) {

  }

  ngOnInit() {

    this._loader.show();
    this._detailsService
      .getAsrDetailsChildData('medicare', this.type,this.asrId ?? '0')
      .subscribe({
        next: (res: any) => {
          this.topData = (this.type === 'HCPCSCODES' ? res?.responseData?.provider?.topHcpcsCds : res?.responseData?.provider?.topProcCds) || [];
         
          this._loader.hide();

        
        },
        error: (err: any) => {
          this._loader.hide();
          this._toaster.error(
            `Error loading Top 5 ${this.type} data to ${err?.status || 'error'}`,
          );
        },
      });

     
   
  }
}
