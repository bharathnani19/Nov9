import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tpe } from './tpe';

describe('Tpe', () => {
  let component: Tpe;
  let fixture: ComponentFixture<Tpe>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Tpe]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tpe);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
