export interface AsrDetails {
  history: HistoryEvent[];
  masterAlert: MasterAlert[];
  currentP1Alert: any[]; // Empty in JSON, type as needed
  provider: Provider;
  prioritized: boolean;
  partDInd: string;
  recentAlerts: string;
  recentEdits: string;
  recentInv: string;
  claimTypes: string[];
  hasEdits: string;
  hasInv: string;
  hasLegacyInv: string;
  hasSysTags: string;
  hasNotes: string;
  hasPartD: string;
  hasClaims: string;
  availableClaims: AvailableClaims;
  asrDbId: number;
  mdcdAsrDbId: string;
  mdcdPrrtyEnabledInd: string;
  recentP1Alerts: string;
  hasP1Alerts: string;
  hasAlerts: string;
  p1EnabledInd: string;
  priorities: AsrPrioritizations[];
  biuSummary: BiuSummary;
  aps: ApsRecord[];
  relatedAsr: RelatedAsr[];
  mdcdTotalPayments: [];
 mdcdUserStates: MdcdUserState[];
}

export interface MdcdUserState{
  state: string;
  lclState: string;
}

export interface HistoryEvent {
  userName: string;
  recordedDt: string;
  eventDt: string;
  riskScore: number;
  description: string;
  comments: string;
}

export interface MasterAlert {
  models: ModelDetails;
  modelId: number;
  asrptId: number;
  currentInd: string;
  recentInd: string;
  legacyInd: string;
  reportCards: any[];
  claimLines: any[];
  alerts: AlertInstance[];
  createdDt: string;
  relCreatedDt: string;
  modDt: string;
  legacyScore: number;
  riskScore: number;
  derivedZone: string;
  cost: string;
  alertCnt: number;
  createdDtAsDate: number;
  npi: string;
  modelTypeCd: string;
  hasReportCard: string;
  modelBusnsId: string;
  lookback: string;
  status: string;
  modelStatus: string;
  showViz: string;
  vizType: string;
  alertId: number;
  partDClaimInd: string;
  cadence: number;
  pathToEduInd: string;
}

export interface ModelDetails {
  modelName: string;
  modelLongName: string;
  claimType: string;
  implDt: string;
  updateDt: string;
  modelDesc: string;
  modelId: number;
  type: string;
  ownerName: string;
  ownerEmail: string;
  ownerPhone: string;
  fpsVersion: string;
  activeStatus: string;
  lastUpdateUser: string;
  docFile: string;
  lookback: string;
  priorityInd: string;
  lastProcessedTime: string;
  statusDt: string;
  priorityDt: string;
  statusChangedBy: string;
  cadence: string;
  pathToEduInd: string;
  p1Ind: string;
}

export interface AlertInstance {
  createDt: string;
  legacyScore: string;
  riskScore: string;
  derivedZone: string;
  cost: string;
  hasReportCard: string;
  currentInd: string;
  recentInd: string;
  legacyInd: string;
  insertDt: string;
  status: string;
  modelStatus: string;
  modelTypeCd: string;
  alertId: number;
  partDClaimInd: string;
  pathToEduInd: string;
  showClaimsLinkInd: string;
  relCreatedDt: string;
}

export interface Provider {
  npi: string;
  address: Address;
  providerName: string;
  riskScoreNum: string;
  totalCost: string;
  totalPmt: string;
  uniqueAlertsCnt: number;
  alerts: { alertTypeCd: string; alertId: number }[];
  createdDt: string;
  updateDt: string;
  jurisdiction: string;
  prvdrStateCd: string;
  specialtiesCnt: number;
  specialties: Specialty[];
  benesCnt: number;
  benes: any[];
  proceduresCnt: number;
  procedures: any[];
  asrProviderCnt: number;
  asrProviders: AsrProvider[];
  submitterIdCnt: number;
  submitterIds: { submitterId: string }[];
  subjectStateCd: string;
  subjectRoleCd: { roleCd: string }[];
  fidNumberCnt: number;
  ucmCaseDataCnt: number;
  biu4WeekCnt: number;
  biu1YearCnt: number;
  inWorkloadDt: string;
  inWorkload: string;
  barrierToAction: any[];
  sysTags: SysTags;
  crossoverLinesCnt: number;
  ptans: Ptan[];
  mac: string;
  revocationDate: string;
  revocationDesc: string;
  riskScore90: string;
  riskScore180: string;
  riskScore365: string;
  dualBenes: KeyValue[];
  topProcCds: HcpcsIcdData[];
  topHcpcsCds: HcpcsIcdData[];
  zrType: string;
  revocation: string;
  medicaid: string;
  ucmAsrId: string;
  enrollmentIds: EnrollmentId[];
  mdcdEnrollmentIds: MdcdEnrollmentId[];
  enrollmentId: string;
  showMacEduReport: string;
  showUpicEduReport: string;
  hasHhaNv: string;
  hasDmeNv: string;
  actionability: string;
  timeliness: string;
  hasAps: string;
  showChowReport: string;
  hasPartD: string;
  hasRrb: string;
  postEdInd: string;
  apsRecs: any[];
  relatedAsrCnt: number;
  nonAlertedPrvdrInd: string;
  uniqueAlertsNA: string;
  specialtiesNA: string;
  ptansNA: string;
  crossoverNA: string;
  rolesNA: string;
  contribScores: ContribScore[];
  riskScoreMethod: string;
  minRiskScoreInd: string;
  acoInd: string;
  p1TotalCost: string;
  p1Jurisdiction: string;
  p1RiskScore: string;
  medicaidInfo: ExternalMedicaid[];
  minRiskScoreModelTxt: string;
  priorityCriteria: AsrPriorityScore[];
}

// Helper Interfaces
export interface Address {
  id: number;
  address1: string;
  address2: string;
  city: string;
  state: string;
  zip: string;
  npi: string;
  prvdrNm: string;
}

export interface Specialty {
  specialtyTypeCd: string;
  specialtyTypeDesc: string;
}

export interface AsrProvider {
  npi: string;
  providerName: string;
  role: string;
}

export interface Ptan {
  ptan: string;
  type: string;
}

export interface KeyValue {
  key: string;
  value: string;
}

export interface HcpcsIcdData {
  key: string;
  value: string;
  desc: string;
  amt: string;
}

export interface EnrollmentId {
  code: string;
  desc: string;
}
export interface MdcdEnrollmentId {
  mdcdId: string;
  state: string;
  status: string;
  efctvDt: string;
  termDt: string;
}
export interface ContribScore {
  modelNm: string;
  modelRiskScore: string;
  contribScorePct: string;
  modelId: number;
  modelTypeCd: string;
}

export interface SysTags {
  fids: any[];
  bius: any[];
  ucms: any[];
  sysTags: any[];
}

export interface AvailableClaims {
  atRiskInd: string;
  atRiskDInd: string;
  latestInd: string;
  latestDInd: string;
  allClaimsInd: string;
  allClaimsDInd: string;
  rrbInd: string;
  atRiskP1Ind: string;
  asrCostP1Ind: string;
  asrCostInd: string;
  asrCostDInd?: string;
  noClaims: boolean;
}

export interface AsrPrioritizations {
  asrId: string;
  asrDbId: number;
  userId: string;
  zone: string;
  comments: string;
  addedDt: string;
  rrbInd: string;
  source: string;
  state: string;
  modelList: string;
  cmsPriorityAsrInd: string;
}

export interface BiuSummary {

  day90Cnt: number;
	totalCnt: number;
	biuSummary: string;
}

export interface ApsRecord {
  identityId:number;
	npi:string;
	businessName:string;
	firstName:string;
	lastName:string;
	chargeDate:string;
	chargeType:string;
	county:string;
	courtName:string;
	crimSource:string;
	disposition:string;
	dispositionDate:string;
	incarcerationDate:string;
	sentence:string;
	sentenceDate:string;
	state:string;
	charge:string;
	courtJurisdiction:string;
	offenseId:string;
	updateDt:string;
	newInd:string;
}
export interface ExternalMedicaid{
	state:string;
	npi:string;
	prvdrName:string;
	reason:string;
	asOfDate:string;
	claimCnt:string;
	dollars:string;
	number:string;
  data: ExternalMedicaidData[];
}

export interface ExternalMedicaidData {
	attrDef:string;
	threshold:string;
	prvdrVal:string;
	attrThresh:string;
	stateMedian:string;
	statePct:string;
}

export interface RelatedAsr {
  npi:string;
	asrptId:number;
	name:string;
	relationships:string;
	riskScore:string;
	priorityScore:string;
	asrCost:string;
	newModels:string;
	agedModels:string;
}

export interface AsrPriorityScore {
	asrptId:number;
	criteriaDesc:string;
	criteriaScore:number;
	criteriaVal:string;
	criteriaWeight:number;
	rangeDesc:string;
	criteriaNm:string;
}
export interface Tpe {
	prvdrNpi:string;		
	ptan:string;		
	prvdrStateCd:string;			
	macRvwRsnDesc:string;		
	cartRvwTopicDesc:string;	
	tpeRnd:number;		
	intraProbeEdctnOfrd:string;		
	intraProbeEdctnAcptd:string;
	intraProbeEdctn1Dt:string;		
	intraProbeEdctn1Desc:string;
	intraProbeEdctn2Dt:string;		
	intraProbeEdctn2Desc:string;
	intraProbeEdctn3Dt:string;		
	intraProbeEdctn3Desc:string;
	intraProbeEdctn4Dt:string;		
	intraProbeEdctn4Desc:string;
	intraProbeEdctn5Dt:string;		
	intraProbeEdctn5Desc:string;		
	postProbeEdctnOfrd:string;		
	postProbeEdctnActpd:string;	
	postProbeEdctnDt:string;		
	postProbeEdctnDesc:string;		
	edctnDnlRsn1Desc:string;		
	edctnDnlRsn2Desc:string;		
	edctnDnlRsn3Desc:string;		
	edctnDnlRateIncrInd:string;		
	rfrlToDesc:string;		
	rfrlRsnDesc:string;		
	cmtTxt:string;		
	ctrctrId:string;		
	asrptId:number;		
	tpeInd:string;	
	lastDtEdctn:string;	
	edctnSucsInd:string;		
	edctnOffered:string;
}

export interface AsrAddress {
  address1: string | null;
  address2?: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
  firstName?: string | null;
  lastName?: string | null;
  hicn?: string | null;
  id?: string | null;
  npi?: string | null;
  prvdrNm?: string | null;
}

export interface AsrMapBeneficiary {
  address: AsrAddress;
}

export interface AsrMapProvider {
  address: AsrAddress;
  benes: AsrMapBeneficiary[];
}

export interface AsrMapResponse {
  responseData: {
    provider: AsrMapProvider;
  };
}

export type AsrMapMessageType = 'info' | 'error';