import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { of } from 'rxjs';
import { HeaderComponent } from './header';
import { OktaService } from '../../../services/okta';
import { HomePageService } from '../../../services/homepage.service';
import { FileUploadService } from '../../../services/file-upload.service';
import { ToastService } from '../../../services/toaster.service';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async () => {
    const oktaServiceMock = jasmine.createSpyObj('OktaService', ['user', 'signOut']);
    const homePageServiceMock = jasmine.createSpyObj('HomePageService', ['getSearchLookup']);
    const fileUploadServiceMock = jasmine.createSpyObj('FileUploadService', ['uploadFile']);
    const toastServiceMock = jasmine.createSpyObj('ToastService', ['error', 'success']);
    const matDialogMock = jasmine.createSpyObj('MatDialog', ['open']);
    const routerMock = { events: of(), url: '/' };
    const activatedRouteMock = { snapshot: { params: {} }, queryParams: of({}) };

    await TestBed.configureTestingModule({
      declarations: [HeaderComponent],
      providers: [
        { provide: OktaService, useValue: oktaServiceMock },
        { provide: ActivatedRoute, useValue: activatedRouteMock },
        { provide: Router, useValue: routerMock },
        { provide: MatDialog, useValue: matDialogMock },
        { provide: HomePageService, useValue: homePageServiceMock },
        { provide: FileUploadService, useValue: fileUploadServiceMock },
        { provide: ToastService, useValue: toastServiceMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    // Don't call detectChanges to avoid Material menu template reference errors
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
