import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { BreakpointObserver } from '@angular/cdk/layout';
import { of } from 'rxjs';
import { LandingComponent } from './landing';
import { OktaService } from '../../../services/okta';
import { HomePageService } from '../../../services/homepage.service';

describe('Landing', () => {
  let component: LandingComponent;
  let fixture: ComponentFixture<LandingComponent>;

  beforeEach(async () => {
    const oktaServiceMock = jasmine.createSpyObj('OktaService', ['user']);
    const homePageServiceMock = jasmine.createSpyObj('HomePageService', ['getHomeTiles']);
    homePageServiceMock.getHomeTiles.and.returnValue(of({ homepageTiles: [] }));
    const breakpointObserverMock = { observe: jasmine.createSpy('observe').and.returnValue(of({ breakpoints: {} })) };

    await TestBed.configureTestingModule({
      declarations: [LandingComponent],
      providers: [
        Title,
        { provide: OktaService, useValue: oktaServiceMock },
        { provide: HomePageService, useValue: homePageServiceMock },
        { provide: BreakpointObserver, useValue: breakpointObserverMock }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
