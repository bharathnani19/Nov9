import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { LayoutComponent } from './layout';
import { SessionService } from '../../../services/session-timeout-service';
import { OktaService } from '../../../services/okta';

describe('Layout', () => {
  let component: LayoutComponent;
  let fixture: ComponentFixture<LayoutComponent>;

  beforeEach(async () => {
    const sessionServiceMock = jasmine.createSpyObj('SessionService', ['startSessionTimeout']);
    const oktaServiceMock = jasmine.createSpyObj('OktaService', ['signOut']);

    await TestBed.configureTestingModule({
      declarations: [LayoutComponent],
      providers: [
        { provide: SessionService, useValue: sessionServiceMock },
        { provide: OktaService, useValue: oktaServiceMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
