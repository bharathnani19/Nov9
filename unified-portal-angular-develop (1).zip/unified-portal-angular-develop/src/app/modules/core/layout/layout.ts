import { Component, OnInit } from '@angular/core';
import { SessionService } from '../../../services/session-timeout-service';
import { OktaService } from '../../../services/okta';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.html',
  styleUrl: './layout.scss',
  standalone: false,
})
export class LayoutComponent implements OnInit {

  constructor(private sessionService: SessionService, private okta: OktaService) {

  }
  ngOnInit(): void {
      this.sessionService.startSessionTimeout();


    window.addEventListener('force-app-logout', () => {
      this.okta.signOut();
    });
  }

   


}
