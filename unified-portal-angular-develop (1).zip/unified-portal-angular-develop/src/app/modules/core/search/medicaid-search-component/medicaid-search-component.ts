import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { HomePageService } from '../../../../services/homepage.service';
import { ToastService } from '../../../../services/toaster.service';
import moment from 'moment';
import {
  dateRangeValidator,
  minMaxValidator,
  tenDigitPerLineValidator,
  getIds,
} from '../../../../utilities/utils';
import { SearchLookup } from '../../../../shared/interface';
import { upics } from '../../../../utilities/constants';
type Option = { code: string; label?: string };
@Component({
  selector: 'app-medicaid-search-component',
  templateUrl: './medicaid-search-component.html',
  styleUrl: './medicaid-search-component.scss',
  standalone: false,
})
export class MedicaidSearchComponent implements OnInit {
  @Input() searchLookups: SearchLookup | any = {};
  @Input() selectedValues: any = {};
  form!: FormGroup;
  actionabilities: any[] = [];
  alertStatuses!: Option[];
  upics = upics as any;
  private readonly verifyErrorKeys = ['asriderror', 'asrformaterror', 'asrverifyerror'];
  constructor(
    private fb: FormBuilder,
    private _homeService: HomePageService,
    private _toaster: ToastService,
  ) {}
  ngOnInit(): void {
    this.initOptions();
    this.initForm();
    //if (this.initData?.initialValues) {
    //   this.form.patchValue(this.initData.initialValues);
    // }
    const notAllowedCodes = ['Conflicting Billing', 'Duplicate Billing', 'Bust Out/New Enroll/Spike', 'No Prior Qualifying Stay', 'Prescribing High Cost w/ Alternatives', 'Provider Education', 'Telemarketing', 'False Referral'].map((code) => code.toLowerCase())
    this.searchLookups.modelSchemes = this.searchLookups.modelSchemes.filter((scheme: Option) => !notAllowedCodes.includes(scheme.code.toLowerCase()))
  }

 

  compareByCodeOrValue(a: any, b: any): boolean {
    if (a === b) return true;
    if (!a || !b) return false;
    if (a.code != null && b.code != null) return a.code === b.code;
    if (a.key != null && b.key != null) return a.key === b.key;
    return false;
  }
  getFormPairMax(variableRoot: String): any {
    return this.form.get(variableRoot + 'Max')?.value;
  }
  private initOptions(): void {
    this.alertStatuses = [
      { code: '12', label: 'New' },
      { code: '13', label: 'Aged' },
    ];

    this.actionabilities = [
      { code: 'Highly Likely' },
      { code: 'Somewhat Likely' },
      { code: 'Less Likely' },
    ];
  }
  private initForm(): void {
    this.form = this.fb.group(
      {
        // Frequently Used
        asrptIds: [null, [tenDigitPerLineValidator()]],
        alerts: [null],
        alertStatus: [null],
        jurisdictions: [null],
        billingNpis: [null, [tenDigitPerLineValidator()]],

        // ASR Information
        prvdrName: [null],
        riskScoreLow: [null],
        riskScoreHigh: [null],
        prvdrPractState: [null],
        createdDtMin: [null],
        createdDtMax: [null],

        // Alert Information
        modelSchemes: [null],
        asrCostMin: [null],
        asrCostMax: [null],

        // Claims Information
        mdcdRoles: [null],
        mdcdSvcSubCats: [null],
        mdcdSvcCats: [null],

        // Investigation Information
        zoneRestrict: [null],
        leadInvStatus: [null],
        myZoneOnlyInd: [null],
        priorUcm: [null],
        leadInd: [null],
        ucmAsrId: [null],
        ucmCaseId: [null],
        // Exclusions
        exclusions: [null],
        exclusionsInd: [null],
      },

      {
        validators: [
          minMaxValidator('riskScoreLow', 'riskScoreHigh', 'riskRangeInvalid'),
          minMaxValidator('asrCostMin', 'asrCostMax', 'asrCostRangeInvalid'),
          dateRangeValidator('createdDtMin', 'createdDtMax', 'createdDtRangeInvalid'),
        ],
      },
    );
    this.form.patchValue(this.selectedValues);
  }

  verifyAsrIds(): void {
    const asrControl = this.form.get('asrptIds');
    const clearValidationFlags = () => {
      const errors = { ...(asrControl?.errors ?? {}) };
      this.verifyErrorKeys.forEach((key) => delete errors[key]);
      asrControl?.setErrors(Object.keys(errors).length ? errors : null);
    };

    const setValidationFlag = (key: string) => {
      asrControl?.setErrors({ ...(asrControl?.errors ?? {}), [key]: true });
    };

    const raw = String(asrControl?.value ?? '');
    const ids = raw
      .split(/[\s,]+/g)
      .map((x) => x.trim())
      .filter(Boolean);

    clearValidationFlags();

    if (!ids.length) {
      this._toaster.error('Please enter ASRs to verify.');
      return;
    }

    const invalidIds = ids.filter((id) => !/^\d{10}$/.test(id));

    if (invalidIds.length) {
      setValidationFlag('asrformaterror');
      const message = `The following NPIs have an incorrect format: ${invalidIds.join(', ')}`;
      this._toaster.error(message);
      return;
    }

    if (ids.length > 200) {
      setValidationFlag('asriderror');
      this._toaster.error('Number of ASRs exceeds the limit of 200.');
      return;
    }

    this._homeService.verifyASRs(ids, 1).subscribe({
      next: (res: any) => {
        const respDataArray = res?.responseData ?? res?.data?.responseData ?? [];

        if (!respDataArray.length) {
          clearValidationFlags();
          this._toaster.success('An ASR exists for all NPIs entered.');
          return;
        }

        const asrMsg = respDataArray
          .map((item: any) => item?.asrId)
          .filter(Boolean)
          .join(', ');

        this._toaster.error(
          `The following NPIs do not have an existing ASR: ${asrMsg || 'Unknown'}`,
        );
        setValidationFlag('asrverifyerror');
      },
      error: (err: any) => {
        setValidationFlag('asrverifyerror');
        this._toaster.error(
          `ASR verification failed due to ${err?.status ?? 'an unexpected error'}`,
        );
      },
    });
  }

  allowOnlyDigit(event: Event) {
    const textarea = event.target as HTMLTextAreaElement;

    // Allow digits and newline only
    const filtered = textarea.value.replace(/[^\d\n]/g, '');

    if (textarea.value !== filtered) {
      textarea.value = filtered;
      this.form.get('asrptIds')?.setValue(filtered, { emitEvent: false });
    }
  }
  /** Clear all criteria */
  clearForm(): void {
    this.form.reset();
  }

  get isFormValid(): boolean {
    return this.form.valid;
  }

  populate(payload: any, data: any = {}): any {
    if (!payload || typeof payload !== 'object') {
      return;
    }

    const toDate = (value: any): Date | null => {
      if (!value) return null;
      const parsed = new Date(value);
      return Number.isNaN(parsed.getTime()) ? null : parsed;
    };

    data.asrptIds = payload.asrptIds ?? null;
    data.billingNpis = payload.billingNpis ?? null;
    data.modelSchemes = payload.modelSchemes
      ?.map((x: any) => typeof x === 'string' ? x : x?.code)
      .filter((x: any) => x != null) ?? null;
    data.alerts = payload.alerts?.map((x: any) => x?.alertId).filter((x: any) => x != null) ?? null;
    data.alertStatus = payload.alertStatus?.map((x: any) => ({ code: x?.code })) ?? null;
    data.jurisdictions = payload.jurisdictions?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.createdDtMin = toDate(payload.createdMinDt);
    data.createdDtMax = toDate(payload.createdMaxDt);
    data.riskScoreLow = payload.riskScoreLow ?? null;
    data.riskScoreHigh = payload.riskScoreHigh ?? null;
    data.asrCostMin = payload.asrCostLow ?? null;
    data.asrCostMax = payload.asrCostHigh ?? null;

    data.prvdrName = payload.prvdrName ?? null;
    data.prvdrPractState = payload.states?.map((x: any) => ({ code: x?.code })) ?? null;

    data.mdcdRoles = payload.mdcdRoles?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.mdcdSvcSubCats = payload.mdcdSvcSubCats?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.mdcdSvcCats = payload.mdcdSvcCats?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;

    data.zoneRestrict = payload.zrTypes?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.leadInvStatus = payload.leadInvestigationInd?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.myZoneOnlyInd = payload.myZoneOnlyInd === 'Yes';
    data.priorUcm = payload.prioritizeTypes?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.leadInd = payload.leadInd ?? null;
    data.ucmAsrId = payload.ucmAsrId ?? null;
    data.ucmCaseId = payload.ucmCaseId ?? null;

    data.exclusions = payload.exclusions?.map((x: any) => x?.code).filter((x: any) => x != null) ?? null;
    data.exclusionsInd = payload.exclusionOrInd ?? null;

    this.form.patchValue(data, { emitEvent: false });
  }

  prepSubmit(): any {
    const asrControl = this.form.get('asrptIds');
    const asrErrors = asrControl?.errors ?? {};
    const hasVerifyError = this.verifyErrorKeys.some((key) => !!asrErrors[key]);

    if (hasVerifyError) {
      this._toaster.error('Please resolve ASR verification errors before searching.');
      asrControl?.markAsDirty();
      asrControl?.markAsTouched();
      return;
    }
    if (this.form.invalid) {
      this._toaster.error('Please correct the search form field errors.');
      this.form.markAllAsDirty();
      return;
    }
    const data = this.form.value;
    const payload = {
      asrptIds: typeof data.asrptIds === 'object' ? data.asrptIds : getIds(data.asrptIds),
      billingNpis:
        typeof data.billingNpis === 'object' ? data.billingNpis : getIds(data.billingNpis),
      alerts: data.alerts?.map((alertId: any) => ({ alertId })) ?? null,
      modelSchemes: data.modelSchemes?.map((code: string) => ({ code })) ?? null,
      alertStatus: data.alertStatus?.map((o: any) => ({ code: o.code })) ?? null,
      jurisdictions: data.jurisdictions?.map((code: any) => ({ code })) ?? null,
      createdMinDt: data.createdDtMin ? moment(data.createdDtMin).format('YYYY-MM-DD') : null,
      createdMaxDt: data.createdDtMax ? moment(data.createdDtMax).format('YYYY-MM-DD') : null,
      riskScoreLow: data.riskScoreLow,
      riskScoreHigh: data.riskScoreHigh,
      asrCostLow: data.asrCostMin,
      asrCostHigh: data.asrCostMax,

      // ASR Information
      prvdrName: data.prvdrName,
      states:
        data.prvdrPractState?.map((o: any) => ({ code: o?.code ?? o }))?.filter((s: any) => !!s.code) ??
        null,

      // Claims Information
      mdcdRoles: data.mdcdRoles?.map((o: any) => ({ code: o })) ?? null,
      mdcdSvcSubCats: data.mdcdSvcSubCats?.map((o: any) => ({ code: o })) ?? null,
      mdcdSvcCats: data.mdcdSvcCats?.map((o: any) => ({ code: o })) ?? null,

      // Investigation Information
      zrTypes: data.zoneRestrict?.map((o: any) => ({ code: o })) ?? null,
      leadInvestigationInd: data.leadInvStatus?.map((o: any) => ({ code: o })) ?? null,
      myZoneOnlyInd: data.myZoneOnlyInd ? 'Yes' : 'No',
      prioritizeTypes: data.priorUcm?.map((o: any) => ({ code: `${o}` })) ?? null,
      leadInd: data.leadInd,
      ucmAsrId: data.ucmAsrId,
      ucmCaseId: data.ucmCaseId,
      // Exclusions
      exclusions: data.exclusions?.map((o: any) => ({ code: o })) ?? null,
      exclusionOrInd: data.exclusionsInd,
    };

    console.log('Search payload:', payload);

    return payload;
  }
}
