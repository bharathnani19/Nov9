import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { PresetSearchComponent } from './preset-search-component';
import { HomePageService } from '../../../../services/homepage.service';
import { ToastService } from '../../../../services/toaster.service';

describe('PresetSearchComponent', () => {
  let component: PresetSearchComponent;
  let fixture: ComponentFixture<PresetSearchComponent>;

  beforeEach(async () => {
    const homePageServiceMock = jasmine.createSpyObj('HomePageService', ['getSearchLookup']);
    const toastServiceMock = jasmine.createSpyObj('ToastService', ['error', 'success']);

    await TestBed.configureTestingModule({
      declarations: [PresetSearchComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: HomePageService, useValue: homePageServiceMock },
        { provide: ToastService, useValue: toastServiceMock }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PresetSearchComponent);
    component = fixture.componentInstance;
    // Don't call detectChanges to avoid Material select form control initialization
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
