import { Component, OnInit, Input } from '@angular/core';
import { SearchLookup } from '../../../../shared/interface';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ToastService } from '../../../../services/toaster.service';
import { HomePageService } from '../../../../services/homepage.service';

type Option = { code: string; label?: string };
@Component({
  selector: 'app-preset-search-component',
  standalone: false,
  templateUrl: './preset-search-component.html',
  styleUrl: './preset-search-component.scss',
})
export class PresetSearchComponent implements OnInit {
  @Input() searchLookups: SearchLookup | any = {};
  form!: FormGroup;
  defaultSelected = 'OTHERZONEWORKLOAD';
  constructor(
    private fb: FormBuilder,
    private _homeService: HomePageService,
    private _toaster: ToastService,
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({ preset: [this.defaultSelected] });
  }

  clearForm(): void {
    this.form.patchValue({ preset: this.defaultSelected });
  }

  prepSubmit(): any {
    if (this.form.invalid) {
      this._toaster.error('Please correct the search form field errors.');
      this.form.markAllAsDirty();
      return;
    }
    const data = this.form.value;
    const payload = {
      presetSearchFlag: data.preset,
      programType : 'medicare'
    };

    console.log('Search payload:', payload);

    return payload;
  }
}
