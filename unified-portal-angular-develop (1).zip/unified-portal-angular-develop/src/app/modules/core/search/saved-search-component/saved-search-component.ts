import { Component,  OnInit, Input } from '@angular/core';
import { SearchLookup } from '../../../../shared/interface'
import { FormBuilder, FormGroup } from '@angular/forms';
import { ToastService } from '../../../../services/toaster.service';
import { HomePageService } from '../../../../services/homepage.service';

type Option = { code: string; label?: string };
@Component({
  selector: 'app-saved-search-component',
  standalone: false,
  templateUrl: './saved-search-component.html',
  styleUrl: './saved-search-component.scss',
})

export class SavedSearchComponent implements OnInit{
  @Input() searchLookups: SearchLookup | any = {};
  form!: FormGroup;
  actionabilities: any[] = [];
  alertStatuses!: Option[];
  constructor(
    private fb: FormBuilder,
    private _homeService: HomePageService,
    private _toaster: ToastService){
  }

  ngOnInit(): void {
    this.form = this.fb.group( { saved: [null] } );
  }
  
  clearForm(): void {
    this.form.reset();
  }

  asrSearchType(): any {
    if (!this.form.value.saved)
      return null;
    const found = this.searchLookups.saved.find( (item: any) => item.listId === this.form.value.saved );
    return found?.asrType;
  }

  prepSubmit(): any {
    if (this.form.invalid || !this.form.value.saved) {
      this._toaster.error('Please select a saved search.');
      this.form.markAllAsDirty();
      return;
    }
    const data = this.form.value;
    const payload = {
      saved: data.saved,
    };
    console.log('Saved Search payload:', payload);

    return payload;
  }

}


