import { Component, Inject, OnDestroy, OnInit } from '@angular/core';

import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

import { interval, Subscription } from 'rxjs';

interface SessionDialogData {
  expirationTime: number;
}

@Component({
  selector: 'app-session-inactive-modal',

  templateUrl: './session-timeout.html',

  styleUrls: ['./session-timeout.scss'],

  standalone: false,
})
export class SessionInactiveModalComponent implements OnInit, OnDestroy {
  totalWaitTime = 0;

  private timerSubscription?: Subscription;

  private actionSelected = false;

  constructor(
    private readonly dialogRef: MatDialogRef<SessionInactiveModalComponent>,

    @Inject(MAT_DIALOG_DATA)
    readonly data: SessionDialogData,
  ) {}

  ngOnInit(): void {
    this.updateRemainingTime();

    this.timerSubscription = interval(1000).subscribe(() => {
      this.updateRemainingTime();
    });
  }

  private updateRemainingTime(): void {
    if (this.actionSelected) {
      return;
    }

    const remainingMilliseconds = this.data.expirationTime - Date.now();

    if (remainingMilliseconds > 0) {
      this.totalWaitTime = Math.ceil(remainingMilliseconds / 1000);

      return;
    }

    this.totalWaitTime = 0;

    this.closeDialog('logout');
  }

  get minutes(): number {
    return Math.floor(this.totalWaitTime / 60);
  }

  get seconds(): number {
    return this.totalWaitTime % 60;
  }

  extend(): void {
    this.closeDialog('extend');
  }

  logout(): void {
    this.closeDialog('logout');
  }

  private closeDialog(result: 'extend' | 'logout'): void {
    if (this.actionSelected) {
      return;
    }

    this.actionSelected = true;
    this.timerSubscription?.unsubscribe();
    this.dialogRef.close(result);
  }

  ngOnDestroy(): void {
    this.timerSubscription?.unsubscribe();
  }
}
