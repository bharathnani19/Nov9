import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ModelsTableComponent } from './models-table';
import { OktaService } from '../../../../services/okta';
import { MatDialog } from '@angular/material/dialog';
import { FileUploadService } from '../../../../services/file-upload.service';
import { ToastService } from '../../../../services/toaster.service';
import { MaterialModule } from '../../../../shared/material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableComponent } from '../../../../shared/table/table';
import { CellTemplateDirective } from '../../../../shared/table/cell.directive';

describe('ModelsTableComponent - sortLastProcessedTime', () => {
  let component: ModelsTableComponent;
  let fixture: ComponentFixture<ModelsTableComponent>;

  beforeEach(async () => {
    // Create mock services
    const oktaServiceMock = jasmine.createSpyObj('OktaService', ['user']);
    const matDialogMock = jasmine.createSpyObj('MatDialog', ['open']);
    const fileUploadServiceMock = jasmine.createSpyObj('FileUploadService', ['downloadTrainingDocs']);
    const toastServiceMock = jasmine.createSpyObj('ToastService', ['error', 'success']);

    await TestBed.configureTestingModule({
      declarations: [ModelsTableComponent, TableComponent, CellTemplateDirective],
      imports: [MaterialModule, BrowserAnimationsModule],
      providers: [
        { provide: OktaService, useValue: oktaServiceMock },
        { provide: MatDialog, useValue: matDialogMock },
        { provide: FileUploadService, useValue: fileUploadServiceMock },
        { provide: ToastService, useValue: toastServiceMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ModelsTableComponent);
    component = fixture.componentInstance;
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  describe('Date Sorting', () => {
    it('should sort dates in ascending order', () => {
      const data = [
        { lastProcessedTime: '06/30/2025' },
        { lastProcessedTime: '12/25/2024' },
        { lastProcessedTime: '01/15/2024' },
        { lastProcessedTime: '01/16/2023' },
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      expect(sorted[0].lastProcessedTime).toBe('01/16/2023');
      expect(sorted[1].lastProcessedTime).toBe('01/15/2024');
      expect(sorted[2].lastProcessedTime).toBe('12/25/2024');
      expect(sorted[3].lastProcessedTime).toBe('06/30/2025');
    });

    it('should sort dates across different years', () => {
      const data = [
        { lastProcessedTime: '01/01/2026' },
        { lastProcessedTime: '12/31/2023' },
        { lastProcessedTime: '06/15/2024' }
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      expect(sorted[0].lastProcessedTime).toBe('12/31/2023');
      expect(sorted[1].lastProcessedTime).toBe('06/15/2024');
      expect(sorted[2].lastProcessedTime).toBe('01/01/2026');
    });

    it('should sort dates within the same month', () => {
      const data = [
        { lastProcessedTime: '05/25/2025' },
        { lastProcessedTime: '05/10/2025' },
        { lastProcessedTime: '05/30/2025' }
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      expect(sorted[0].lastProcessedTime).toBe('05/10/2025');
      expect(sorted[1].lastProcessedTime).toBe('05/25/2025');
      expect(sorted[2].lastProcessedTime).toBe('05/30/2025');
    });

    it('should handle null values by placing them first', () => {
      const data = [
        { lastProcessedTime: '12/25/2024' },
        { lastProcessedTime: null },
        { lastProcessedTime: '01/15/2024' }
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      expect(sorted[0].lastProcessedTime).toBe(null);
      expect(sorted[1].lastProcessedTime).toBe('01/15/2024');
      expect(sorted[2].lastProcessedTime).toBe('12/25/2024');
    });

    it('should handle empty strings by placing them first', () => {
      const data = [
        { lastProcessedTime: '12/25/2024' },
        { lastProcessedTime: '' },
        { lastProcessedTime: '01/15/2024' }
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      expect(sorted[0].lastProcessedTime).toBe('');
      expect(sorted[1].lastProcessedTime).toBe('01/15/2024');
      expect(sorted[2].lastProcessedTime).toBe('12/25/2024');
    });

    it('should handle mixed null and empty values', () => {
      const data = [
        { lastProcessedTime: '06/15/2024' },
        { lastProcessedTime: null },
        { lastProcessedTime: '' },
        { lastProcessedTime: '01/01/2025' }
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      // Both null and empty should be at the beginning
      expect([null, ''].includes(sorted[0].lastProcessedTime)).toBe(true);
      expect([null, ''].includes(sorted[1].lastProcessedTime)).toBe(true);
      expect(sorted[2].lastProcessedTime).toBe('06/15/2024');
      expect(sorted[3].lastProcessedTime).toBe('01/01/2025');
    });

    it('should handle single date', () => {
      const data = [
        { lastProcessedTime: '05/23/2025' }
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      expect(sorted[0].lastProcessedTime).toBe('05/23/2025');
    });

    it('should handle identical dates', () => {
      const data = [
        { lastProcessedTime: '05/23/2025' },
        { lastProcessedTime: '05/23/2025' },
        { lastProcessedTime: '05/23/2025' }
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      expect(sorted.every(item => item.lastProcessedTime === '05/23/2025')).toBe(true);
    });

    it('should correctly parse MM/DD/YYYY format', () => {
      const data = [
        { lastProcessedTime: '02/28/2024' }, // Feb 28, 2024
        { lastProcessedTime: '03/01/2024' }, // Mar 1, 2024
        { lastProcessedTime: '01/31/2024' }  // Jan 31, 2024
      ];

      const sorted = data.sort(component.sortLastProcessedTime);

      expect(sorted[0].lastProcessedTime).toBe('01/31/2024');
      expect(sorted[1].lastProcessedTime).toBe('02/28/2024');
      expect(sorted[2].lastProcessedTime).toBe('03/01/2024');
    });

    it('it handle reverse sort across multiple years', () => {
      const data = [
        { lastProcessedTime: '11/26/2024' },
        { lastProcessedTime: '11/19/2024' },
        { lastProcessedTime: '11/12/2024' },
        { lastProcessedTime: '10/15/2025' },
        { lastProcessedTime: '10/14/2025' }
      ];

      const sorted = data.sort(component.sortLastProcessedTime).reverse();

      expect(sorted[0].lastProcessedTime).toBe('10/15/2025');
      expect(sorted[1].lastProcessedTime).toBe('10/14/2025');
      expect(sorted[2].lastProcessedTime).toBe('11/26/2024');
      expect(sorted[3].lastProcessedTime).toBe('11/19/2024');
      expect(sorted[4].lastProcessedTime).toBe('11/12/2024');
    });
  });
});
