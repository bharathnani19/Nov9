import { Component, Input, OnInit } from '@angular/core';
import { OktaService } from '../../../../services/okta';
import { MatDialog } from '@angular/material/dialog';
import { ModelDetailDialogComponent } from '../../../../shared/dialog/model-detail/model-detail';
import { FileUploadService } from '../../../../services/file-upload.service';
import { ToastService } from '../../../../services/toaster.service';
import { LoaderService } from '../../../../services/loader.service';

@Component({
  selector: 'app-models-table',
  templateUrl: './models-table.html',
  styleUrl: './models-table.scss',
  standalone: false,
})
export class ModelsTableComponent {
  @Input() selectedInfoTabIndex: number = 0;
  @Input() isLoading: boolean = true;
  @Input() showButtons: boolean = false;
  @Input() disableTab2: boolean = false;
  @Input() enableSearch: boolean = true;
  @Input() tableClass?: string;
  @Input() summaryLevel?: string = 'detail';
  @Input() vulnerabilityType?: string = 'medicare';
  @Input() data: any = {};
  @Input() tab1Label: string = 'tab1Label';
  @Input() tab1Id: string = 'tab1Id';
  @Input() tab1Info: string = 'tab1Info';
  @Input() tab2Label: string = 'tab2Label';
  @Input() tab2Info: string = 'tab2Info';
  @Input() tab2Id: string = 'tab2Id';
  @Input() printOptions?: {
    fontSize?: number;
    orientation?: 'portrait' | 'landscape';
    compact?: boolean;
  };

  showMoreDesc: { [key: string]: boolean } = {};

  constructor(
    public okta: OktaService,
    private dialog: MatDialog,
    private fileUploadService: FileUploadService,
    private toaster: ToastService,
    private _loader: LoaderService,
  ) {}

  ngOnInit() {}

  get tab1Columns() {
    if (this.vulnerabilityType === 'edit') {
      return this.editSummaryColumns;
    }
    return this.summaryLevel === 'detail' ? this.modelDetailColumns : this.modelSummaryMDCRColumns;
  }

  get tab2Columns() {
    if (this.vulnerabilityType === 'edit') {
      return this.editSummaryColumns;
    }
    return this.summaryLevel === 'detail' ? this.modelDetailColumns : this.modelSummaryMDCDColumns;
  }

  formatDateForUrl(date: string): string {
    return date ? date.replace(/\//g, '-') : '';
  }

  openModelDetailDialog(vulnerabilityType: string, tab1Data: any[] = [], tab2Data: any[] = []) {
    const dialogRef = this.dialog.open(ModelDetailDialogComponent, {
      width: '80%',
      maxWidth: '100%',
      autoFocus: true,
      restoreFocus: true,
      data: { vulnerabilityType: vulnerabilityType, tab1Data, tab2Data },
      panelClass: 'ip-dialog-panel',
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log('Dialog closed with result:', result);
      }
    });
  }

  downloadTrainingDoc(name: string): void {
    this._loader.show();

    this.fileUploadService.downloadLegacyDocument(name).subscribe({
      next: () => {
        this._loader.hide();
      },
      error: (err: any) => {
        this._loader.hide();
        this.toaster.error('Unable to download ' + name + ' due to ' + err.status + '.');
      },
    });
  }

  getCadenceDisplay(row: any, tab: string): string {
    // Cadence exists
    if (row.cadence) {
      return `${row.cadence} days`;
    }
    // This is the main table
    if (this.summaryLevel === 'summary') {
      return tab === '1' ? '30 days' : '90 days';
    }
    // These are the dialogs
    return this.vulnerabilityType === 'medicare' ? '30 days' : '90 days';
  }

  toggleDesc(id: string): void {
    this.showMoreDesc[id] = !this.showMoreDesc[id];
  }

  sortLastProcessedTime = (a: any, b: any): number => {
    const parseDate = (dateStr: string): number => {
      if (!dateStr) return 0;
      const [month, day, year] = dateStr.split('/').map(Number);
      return new Date(year, month - 1, day).getTime();
    };
    return parseDate(a.lastProcessedTime) - parseDate(b.lastProcessedTime);
  };

  formatYesNo(value: string): string {
    if (value === null || value === undefined || value === '') return '';
    if (value === 'N/A') return value;
    return value.replace(/^(Y|N)/, (match: string) => (match === 'Y' ? 'Yes' : 'No'));
  }

  // Medicare Columns
  modelSummaryMDCRColumns = [
    {
      key: 'modelName',
      label: 'Name',
      custom: true,
      sortable: true,
    },
    {
      key: 'lookbackDates',
      label: 'Look Back Period',
      sortable: true,
    },
    {
      key: 'modelDesc',
      label: 'Description',
      sortable: true,
      custom: true,
    },
    {
      key: 'cadence',
      label: 'Cadence',
      custom: true,
      sortable: true,
    },
    {
      key: 'lastProcessedTime',
      label: 'Last Processed',
      custom: true,
      sortable: true,
      sortFn: this.sortLastProcessedTime,
    },
    {
      key: 'p1Ind',
      label: 'Phase 1',
      sortable: true,
      custom: true,
    },
    {
      key: 'pathToEduInd',
      label: 'Path to Education',
      sortable: false,
      custom: true,
    },
  ];

  modelDetailColumns = [
    {
      key: 'modelName',
      label: 'Model Name',
      custom: true,
      sortable: true,
    },
    {
      key: 'type',
      label: 'Model Type',
      sortable: true,
    },
    {
      key: 'claimType',
      label: 'Claim Types',
      sortable: true,
    },
    {
      key: 'version',
      label: 'Model Version Number',
      sortable: true,
    },
    {
      key: 'activeStatus',
      label: 'Model Status',
      sortable: true,
    },
    {
      key: 'statusDt',
      label: 'Model Status Update Date',
      sortable: true,
    },
    {
      key: 'cadence',
      label: 'Cadence',
      custom: true,
      sortable: true,
    },
    {
      key: 'ownerName',
      label: "Model Owner's Name",
      sortable: true,
    },
    {
      key: 'ownerEmail',
      label: "Model Owner's E-mail",
      sortable: true,
    },
    {
      key: 'ownerPhone',
      label: "Model Owner's Phone Number",
      sortable: true,
    },
    {
      key: 'implDt',
      label: 'Date Implemented',
      sortable: true,
    },
    {
      key: 'updateDt',
      label: 'Date Modified',
      sortable: true,
    },
    {
      key: 'modelDesc',
      label: 'Model Description',
      sortable: true,
      custom: true,
    },
    {
      key: 'fpsVersion',
      label: 'FPS Version',
      sortable: true,
    },
  ];

  // Medicaid Columns
  modelSummaryMDCDColumns = [
    {
      key: 'modelName',
      label: 'Name',
      custom: true,
      sortable: true,
    },
    {
      key: 'lookbackDates',
      label: 'Look Back Period',
      sortable: true,
    },
    {
      key: 'modelDesc',
      label: 'Description',
      sortable: true,
      custom: true,
    },
    {
      key: 'cadence',
      label: 'Cadence',
      custom: true,
      sortable: true,
    },
    {
      key: 'lastProcessedTime',
      label: 'Last Processed',
      custom: true,
      sortable: true,
      sortFn: this.sortLastProcessedTime,
    },
  ];

  allModelColumns = [
    {
      key: 'modelName',
      label: 'Name',
      custom: true,
      sortable: true,
    },
    {
      key: 'type',
      label: 'Model Type',
      sortable: true,
    },
    {
      key: 'claimType',
      label: 'Claim Types',
      sortable: true,
    },
    {
      key: 'activeStatus',
      label: 'Model Status',
      sortable: true,
    },
    {
      key: 'statusDt',
      label: 'Model Status Update',
      sortable: true,
    },
    {
      key: 'cadence',
      label: 'Cadence',
      custom: true,
      sortable: true,
    },
    {
      key: 'ownerName',
      label: "Model Owner's Name",
      sortable: true,
    },
    {
      key: 'ownerEmail',
      label: "Model Owner's E-mail",
      sortable: true,
    },
    {
      key: 'ownerPhone',
      label: "Model Owner's Phone Number",
      sortable: true,
    },
    {
      key: 'implDt',
      label: 'Date Implemented',
      sortable: true,
    },
    {
      key: 'updateDt',
      label: 'Date Modified',
      sortable: true,
    },
    {
      key: 'modelDesc',
      label: 'Model Description',
      sortable: true,
      custom: true,
    },
    {
      key: 'fpsVersion',
      label: 'FPS Version',
      sortable: true,
    },
  ];

  // Edit Details Columns
  editSummaryColumns = [
    {
      key: 'fpsEditNum',
      label: 'Edit Number',
      sortable: true,
    },
    {
      key: 'fpsEditName',
      label: 'Edit Name',
      sortable: true,
    },
    {
      key: 'echimpNum',
      label: 'eChimp Number',
      sortable: true,
    },
    {
      key: 'editDesc',
      label: 'Description',
      sortable: true,
      custom: true,
    },
    {
      key: 'editActnType',
      label: 'Type of Edit Action',
      sortable: true,
    },
    {
      key: 'lineOfBusns',
      label: 'Line of Business',
      sortable: true,
    },
    {
      key: 'hstry',
      label: 'History',
      sortable: true,
    },
    {
      key: 'hstryLkbckPrd',
      label: 'History Look-back Period',
      sortable: true,
    },
  ];
}
