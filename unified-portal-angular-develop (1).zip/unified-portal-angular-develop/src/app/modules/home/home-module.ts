import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing-module';
import { HomeComponent } from './home';
import { MaterialModule } from '../../shared/material.module';
import { SharedModule } from '../../shared/shared.module';
import { CriminalDetailComponent } from './components/criminal-details/criminal-details';
import { YesNoPipe } from '../../shared/custom-pipes';


const COMMON_COMPONENT = [HomeComponent, CriminalDetailComponent]

@NgModule({
  declarations: [...COMMON_COMPONENT],
  imports: [
    CommonModule,
    HomeRoutingModule,
    MaterialModule,
    SharedModule,
    YesNoPipe
]
})
export class HomeModule { }
