import { Component, Inject } from '@angular/core';

@Component({
  selector: 'app-summary-details-table',
  templateUrl: './summary-details-table.html',
  standalone: false,
})
export class SummaryDetailsTableComponent {
  rowData: any[];
  columns: any[];
  tableName: string;
  tableId: string;
  isLoading = false;
  pageSize = 10;
  enableSearch = true;

  constructor(@Inject('componentData') public data: any) {
    this.rowData = this.data?.rowData || [];
    this.columns = this.data?.columns || [];
    this.tableName = this.data?.tableName || 'Details Table';
    this.tableId = this.data?.tableId || 'detailsTable';
  }

  formatCurrencyValue(value: unknown): string {
    if (value === null || value === undefined || value === '') return '-';

    if (typeof value === 'number') {
      return this.toUsd(value);
    }

    if (typeof value === 'string') {
      const trimmed = value.trim();
      if (!trimmed || trimmed === '-' || trimmed === 'N/A') return trimmed || '-';
      if (trimmed.startsWith('$')) return trimmed;

      const normalized = Number(trimmed.replace(/[$,]/g, ''));
      return Number.isFinite(normalized) ? this.toUsd(normalized) : trimmed;
    }

    return String(value);
  }

  private toUsd(amount: number): string {
    return `$${amount.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  }

  openDetails(row: any) {
    const asrId = String(row?.clmBlngPrvdrNpiNum || '').trim();

    window.open(`/FPS2UnifiedPortal/Investigative/Details?asrId=${asrId}`, '_blank');
  }
}
