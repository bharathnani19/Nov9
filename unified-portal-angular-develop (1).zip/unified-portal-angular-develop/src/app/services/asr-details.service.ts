import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable, model, signal } from '@angular/core';
import { environment } from '../environments/environment.shared';
import { forkJoin, map, Observable, tap } from 'rxjs';
import { formatMessage } from '../utilities/utils';
import { OktaService } from './okta';
import { AsrDetails } from '../modules/asr-detail/model';

export interface ReportCardRequest {
  modelId: string;
  npi: string;
  tableId?: string;
  isMedicare: boolean;
  state?: string;
}

@Injectable({
  providedIn: 'root',
})
export class AsrDetailsService {
  asrDetails = signal<AsrDetails | null>(null);
  constructor(
    private http: HttpClient,
    private okta: OktaService,
  ) {}

  get userId() {
    return this.okta.user().oktaDetails?.preferred_username;
  }

  public getAsrDetails(
    searchType: string,
    asrType: string,
    asrId: string | number,
  ): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.asrDetails.set(null);
    return this.http
      .get<any>(
        formatMessage(environment.wsUrls.asrDetails, {
          userId: this.userId,
          asrType,
          searchType: searchType === 'medicare' ? '' : 'mdcd/',
          asrId,
        }),
        { headers },
      )
      .pipe(
        tap((res: any) => {
          this.asrDetails.set(res.responseData);
        }),
      );
  }

  public getAsrDetailsChildData(
    searchType: string,
    asrType: string,
    asrId: string,
  ): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get<any>(
      formatMessage(environment.wsUrls.asrDetails, {
        userId: this.userId,
        asrType,
        searchType: searchType === 'medicare' ? '' : 'mdcd/',
        asrId,
      }),
      { headers },
    );
  }
  public getEditClaims(editName: string, userId: string, npi: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get<any>(
      formatMessage(environment.wsUrls.editClaimsDenied, {
        userId: this.userId,
        npi,
        editName,
      }),
      { headers },
    );
  }
  public updatePreference(val: string, isMedicare: boolean): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.post<any>(
      environment.wsUrls.saveUserPrefs,
      {
        userId: this.userId,
        prefName: isMedicare ? 'sumTableCols' : 'sumTableColsMDCD',
        prefJson: JSON.stringify(val),
      },
      { headers },
    );
  }

  public ucmLeadData(leadId: any): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.ucmLeadData, {
        leadId: leadId,
      }),
      { headers },
    );
  }

  public getReportCards(data: any): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };

    const reportCardsUrl =
      data?.type === 'medicaid'
        ? environment.wsUrls.mdcdReportCards
        : environment.wsUrls.reportCards;

    let wsURL = formatMessage(reportCardsUrl, {
      modelId: data.modelId,
      npi: data.npi,
      state: data?.state,
    });

    if (data.tableId) {
      wsURL += `/viz/${data.tableId}?userId=${this.userId}`;
    } else {
      if (data.insertDt) {
        wsURL += `/${data.insertDt}?userId=${this.userId}`;
      } else {
        wsURL += `?userId=${this.userId}`;
      }
    }
    return this.http.get<any>(wsURL, { headers });
  }

  public getVizData(data: { vizType: string; asrId: string; modelId?: string }): Observable<any> {
    const url = environment.wsUrls.viz;

    let wsURL = formatMessage(url, {
      vizType: data.vizType,
      asrID: data.asrId,
      userId: this.userId,
      modelId: data.modelId ? '/' + data.modelId : '',
    });

    return this.http.get<any>(wsURL);
  }

  public getVizExportData(data: {
    vizType: string;
    asrId: string;
    modelId?: string;
  }): Observable<HttpResponse<Blob>> {
    let url = environment.wsUrls.vizExport;

    const needsModelId = data.vizType === 'vizexport';

    const wsURL = formatMessage(url, {
      vizExportType: data.vizType,
      asrID: data.asrId,
      userId: this.userId,
      modelId: needsModelId && data.modelId ? `/${data.modelId}` : '',
    });

    return this.http.get(wsURL, {
      observe: 'response',
      responseType: 'blob',
    });
  }

  getVizReportCardData(request: ReportCardRequest): Observable<any> {
    const { modelId, npi, tableId, isMedicare, state } = request;

    let url = formatMessage(environment.wsUrls.vizReportCard, {
      modelId,
      npi,
      asrType: isMedicare ? '' : 'mdcd/',
    });

    // Medicaid requires state after NPI
    if (!isMedicare && state) {
      url += `/${encodeURIComponent(state)}`;
    }

    if (tableId) {
      url += `/viz/${tableId}`;
    }

    url += `?userId=${encodeURIComponent(this.userId)}`;

    return this.http.get(url);
  }
}
