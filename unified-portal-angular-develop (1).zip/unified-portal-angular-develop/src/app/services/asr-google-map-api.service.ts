import { effect, inject, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment.shared';
import { AsrAddress, AsrMapBeneficiary, AsrMapResponse } from '../modules/asr-detail/model';
import { formatMessage } from '../utilities/utils';
import { OktaService } from './okta';
import { User } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class AsrGoogleMapApiService {
  private readonly http = inject(HttpClient);
  user!:User;
  
    constructor(
    public okta: OktaService,

  ) {
    
  }
  getAsrMapsInfo(
    asrptId: number | string,
    resultsIndex: number,
    userId: string
  ): Observable<AsrMapResponse> {
    const baseUrl = environment.wsUrls.googleMaps;
      const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
      return this.http.get<AsrMapResponse>(
        formatMessage(baseUrl, {
          asrptId,
          resultsIndex,
          userId
        }),
      { headers });
      	//log user activity
	//	$scope.trackUserActivity('MAPS', null);
  }
  getModelBenes (modelId:number, asrptId: number|string): Observable<AsrAddress[]>  {
	const baseUrl = environment.wsUrls.modelGoogleMaps;
      const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
      return this.http.get<AsrAddress[]>(
        formatMessage(baseUrl, {
          asrptId,
          modelId
        }),
      { headers });
		//log user activity
	//	$scope.trackUserActivity('MAPS', null);
	}
}