import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { catchError, map, Observable, tap, throwError } from 'rxjs';
import { environment } from '../environments/environment.shared';
import { formatMessage } from '../utilities/utils';
import { OktaService } from './okta';

export interface OpenClaimsDocumentParams {
  asrId: string;
  npi: string;
  modelId: string;
  state?: string | null;
  programType?: 'medicare' | 'medicaid';
  fileName: string;
  pType: string;
  masterClaimsUniqueId?: string;
}

@Injectable({
  providedIn: 'root',
})
export class FileUploadService {
  private readonly apiBase = environment.wsUrls.claimsExport;

  constructor(
    private http: HttpClient,
    private okta: OktaService,
  ) {}

  downloadTrainingDocs(name: string): Observable<boolean> {
    const url = formatMessage(environment.wsUrls.fileDownload, {
      fileName: name.replaceAll(' ', '_'),
      userId: this.getUserId(),
    });

    return this.http
      .get(url, {
        responseType: 'blob',
        observe: 'response',
      })
      .pipe(
        map((response) => {
          const blob = response.body;
          if (!blob) {
            return false;
          }

          const fileName = this.getFileNameFromResponse(response, name);
          this.saveBlob(blob, fileName);
          return true;
        }),
        catchError((err) => throwError(() => err)),
      );
  }

  downloadClaimsDocument(params: OpenClaimsDocumentParams): Observable<boolean> {
    const { asrId, modelId, state, fileName, pType } = params;

    const programType: 'medicare' | 'medicaid' =
      params.programType ?? (state == null ? 'medicare' : 'medicaid');

    const url = this.buildClaimsUrl({
      asrId,
      modelId,
      state,
      pType,
      programType,
    });

    const httpParams = new HttpParams().set('userId', this.getUserId());

    return this.http
      .get(url, {
        params: httpParams,
        responseType: 'text',
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .pipe(
        map((base64Response) => {
          this.downloadBase64Csv(base64Response, fileName);
          return true;
        }),
        catchError((err) => throwError(() => err)),
      );
  }

  downloadClaimsDocPost(params: any, claimsSearchObj: any): Observable<boolean> {
    const { asrId, modelId, state, fileName, pType } = params;

    const programType: 'medicare' | 'medicaid' =
      params.programType ?? (state == null ? 'medicare' : 'medicaid');

    const url = this.buildClaimsUrl({
      asrId,
      modelId,
      state,
      pType,
      programType,
    });

    const httpParams = new HttpParams().set('userId', this.getUserId());

    return this.http
      .post(
        url,
        { ...claimsSearchObj },
        {
          params: httpParams,
          responseType: 'text',
          headers: {
            'Content-Type': 'application/json',
          },
        },
      )
      .pipe(
        map((base64Response: any) => {
          this.downloadBase64Csv(base64Response, fileName);
          return true;
        }),
        catchError((err) => throwError(() => err)),
      );
  }

  downloadLegacyDocument(name: string): Observable<boolean> {
    const cleanedFileName = name.trim().replaceAll(' ', '_');

    const url = formatMessage(environment.wsUrls.fileDownload, {
      fileName: cleanedFileName,
      userId: this.getUserId(),
    });

    console.log('Legacy document URL:', url);

    return this.http
      .get(url, {
        responseType: 'blob',
        observe: 'response',
      })
      .pipe(
        map((response) => {
          const blob = response.body;

          if (!blob) {
            return false;
          }

          const fileName = this.getFileNameFromResponse(response, cleanedFileName);
          this.saveBlob(blob, fileName);

          return true;
        }),
        catchError((err) => throwError(() => err)),
      );
  }

  downloadAsrFieldExport(
    asrptId: string | number,
    programType: 'medicare' | 'medicaid',
  ): Observable<boolean> {
    const endpoint =
      programType === 'medicaid'
        ? environment.wsUrls.mdcdAsrFieldExport
        : environment.wsUrls.asrFieldExport;

    const url = formatMessage(endpoint, {
      asrptId: encodeURIComponent(String(asrptId)),
      userId: this.getUserId(),
    });

    return this.http
      .get(url, {
        responseType: 'blob',
        observe: 'response',
      })
      .pipe(
        map((response) => {
          const blob = response.body;

          if (!blob) {
            return false;
          }

          const fileName = this.getFileNameFromResponse(
            response,
            `asr-field-export-${asrptId}.xlsx`,
          );
          this.saveBlob(blob, fileName);

          return true;
        }),
        catchError((err) => throwError(() => err)),
      );
  }

  downloadMdcdTotalPaymentExport(asrptId: string | number): Observable<boolean> {
    const url = this.buildClaimsUrl({
      asrId: String(asrptId),
      modelId: '',
      pType: 'totalPayment',
      programType: 'medicaid',
    });

    const httpParams = new HttpParams().set('userId', this.getUserId());

    return this.http
      .get(url, {
        params: httpParams,
        responseType: 'blob',
        observe: 'response',
      })
      .pipe(
        map((response) => {
          const blob = response.body;

          if (!blob) {
            return false;
          }

          const fileName = this.getFileNameFromResponse(
            response,
            `medicaid-total-payment-${asrptId}.xlsx`,
          );
          this.saveBlob(blob, fileName);
          return true;
        }),
        catchError((err) => throwError(() => err)),
      );
  }

  downloadDrillReport(params: any): Observable<boolean> {
    const programType: 'medicare' | 'medicaid' =
      params?.programType === 'medicaid' ? 'medicaid' : 'medicare';
    const type = String(params?.type ?? 'claims');

    const asrPrefix =
      programType === 'medicaid' ? `${this.apiBase}/mdcd/asr` : `${this.apiBase}/asr`;

    let url =
      `${asrPrefix}/rptcard/${encodeURIComponent(String(params?.modelId ?? ''))}` +
      `/${encodeURIComponent(String(params?.npi ?? ''))}` +
      `/${encodeURIComponent(type)}`;

    if (programType === 'medicaid' && type === 'claims') {
      const state = String(params?.state ?? '').trim();
      if (state) {
        url += `/${encodeURIComponent(state)}`;
      }
    }

    url += `/${encodeURIComponent(String(params?.attrNum ?? ''))}/csv`;
    url += `?userId=${encodeURIComponent(String(params?.userId ?? this.getUserId()))}`;

    console.log('Legacy document URL:', url);

    return this.http
      .get(url, {
        responseType: 'text',
      })
      .pipe(
        map((base64Response) => {
          this.downloadBase64Csv(base64Response, params.fileName);
          return true;
        }),
        catchError((err) => throwError(() => err)),
      );
  }

  private getUserId(): string {
    return this.okta.user().oktaDetails?.preferred_username ?? '';
  }

  private buildClaimsUrl(params: {
    asrId: string;
    modelId: string;
    state?: string | null;
    pType: string;
    programType: 'medicare' | 'medicaid';
  }): string {
    const { asrId, modelId, state, pType, programType } = params;

    const asrPrefix =
      programType === 'medicaid' ? `${this.apiBase}/mdcd/asr` : `${this.apiBase}/asr`;

    if (pType === 'claimsAtRisk') {
      return `${asrPrefix}/claims/${encodeURIComponent(asrId)}`;
    }

    if (pType === 'latest' || pType === 'rrb' || pType === 'latestD' || pType === 'main') {
      return `${asrPrefix}/claimsexport`;
    }

    if (pType === 'latestP1') {
      return `${asrPrefix}/claims/p1/${encodeURIComponent(asrId)}`;
    }

    if (pType === 'p1cost') {
      return `${asrPrefix}/claims/p1cost/${encodeURIComponent(asrId)}`;
    }

    if (pType === 'asrcost') {
      return `${asrPrefix}/claims/asrcost/${encodeURIComponent(asrId)}`;
    }

     if (pType === 'partdAsrcost') {
      return `${asrPrefix}/claims/partd-asrcost/${encodeURIComponent(asrId)}`;
    }

    if (pType === 'totalPayment') {
      return `${asrPrefix}/claims/totalpayment/${encodeURIComponent(asrId)}`;
    }

    if (pType === 'partd') {
      return `${asrPrefix}/claims/partd/${encodeURIComponent(asrId)}`;
    }

    if (pType === 'Y') {
      return `${asrPrefix}/claims/partd/${encodeURIComponent(modelId)}/${encodeURIComponent(asrId)}/csv`;
    }

    const statePart = programType === 'medicaid' && state ? `/${encodeURIComponent(state)}` : '';

    return `${asrPrefix}/claims/${encodeURIComponent(modelId)}/${encodeURIComponent(asrId)}${statePart}/csv`;
  }

  private downloadBase64Csv(base64Response: string, fileName: string): void {
    if (!base64Response) {
      return;
    }

    const cleanedBase64 = base64Response.trim().replace(/^"|"$/g, '');
    const byteCharacters = atob(cleanedBase64);
    const byteArray = Uint8Array.from(byteCharacters, (char) => char.charCodeAt(0));

    let csvText = new TextDecoder('utf-8').decode(byteArray);
    csvText = this.convertYNValuesInCsv(csvText);

    const blob = new Blob(['\uFEFF' + csvText], {
      type: 'text/csv;charset=utf-8;',
    });

    this.saveBlob(blob, fileName || 'download.csv');
  }

  private convertYNValuesInCsv(csvText: string): string {
    return csvText
      .split('\n')
      .map((line) =>
        line
          .split(',')
          .map((cell) => {
            const trimmed = cell.trim().replace(/^"|"$/g, '');

            if (trimmed === 'Y') {
              return cell.replace(/\bY\b/, 'Yes');
            }

            if (trimmed === 'N') {
              return cell.replace(/\bN\b/, 'No');
            }

            return cell;
          })
          .join(','),
      )
      .join('\n');
  }

  private getFileNameFromResponse(response: HttpResponse<Blob>, fallbackFileName: string): string {
    const contentDisposition = response.headers.get('Content-Disposition');

    if (contentDisposition) {
      const match =
        contentDisposition.match(/filename\*=UTF-8''([^;]+)/i) ||
        contentDisposition.match(/filename="?([^"]+)"?/i);

      if (match?.[1]) {
        return decodeURIComponent(match[1]);
      }
    }

    return fallbackFileName;
  }

  private saveBlob(blob: Blob, fileName: string): void {
    const winNav: any = window.navigator;

    if (winNav?.msSaveOrOpenBlob) {
      winNav.msSaveOrOpenBlob(blob, fileName);
      return;
    }

    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(objectUrl);
  }
}
