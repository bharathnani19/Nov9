import { DOCUMENT } from '@angular/common';
import { inject, Injectable } from '@angular/core';

declare global {
  interface Window {
    google?: {
      maps?: unknown;
    };
  }
}

@Injectable({ providedIn: 'root' })
export class GoogleMapsLoaderService {
  private readonly document = inject(DOCUMENT);
  private loadPromise?: Promise<void>;

  load(apiKey?: string | null): Promise<void> {
    if (this.hasMapConstructor()) {
      return Promise.resolve();
    }

    if (!this.loadPromise) {
      this.loadPromise = new Promise<void>((resolve, reject) => {
        const script = this.document.createElement('script');
        const resolvedUrl = this.buildDefaultUrl(apiKey);

        script.src = resolvedUrl;
        script.async = true;
        script.defer = true;
        script.onload = () => resolve();
        script.onerror = () => reject(new Error('Failed to load Google Maps API.'));

        this.document.head.appendChild(script);
      });
    }

    return this.loadPromise;
  }

  private buildDefaultUrl(apiKey?: string | null): string {
    const params = new URLSearchParams();

    if (apiKey?.trim()) {
      params.set('key', apiKey.trim());
    }

    return `https://maps.googleapis.com/maps/api/js${params.size ? `?${params.toString()}` : ''}`;
  }
  private hasMapConstructor(): boolean {
    const maps = window.google?.maps as { Map?: unknown } | undefined;
    return typeof maps?.Map === 'function';
  }
}