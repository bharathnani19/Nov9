import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment.shared';
import { Observable, tap } from 'rxjs';
import { formatMessage } from '../utilities/utils';
import { OktaService } from './okta';

@Injectable({
  providedIn: 'root',
})
export class HomePageService {
  constructor(
    private http: HttpClient,
    private okta: OktaService,
  ) {}

  public getHomeTiles(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(environment.wsUrls.homePageTileService, { headers });
  }

  public getLandingPageData(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.getLandingPageData, {
        userId: this.okta.user().oktaDetails?.preferred_username,
        zoneId: this.okta.user().oldOrganizationVal,
      }),
      { headers },
    );
  }
  public getReportFavsData(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.getLandingPageData, {
        userId: this.okta.user().oktaDetails?.preferred_username,
        zoneId: this.okta.user().oldOrganizationVal,
      }),
      { headers },
    );
  }
  public getReportsData(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.reportsData, {
        userId: this.okta.user().oktaDetails?.preferred_username,
        zoneId: this.okta.user().oldOrganizationVal,
      }),
      { headers },
    );
  }
  public updatePreference(val: string, key: string): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.post<any>(
      environment.wsUrls.saveUserPrefs,
      {
        userId: this.okta.user().oktaDetails?.preferred_username,
        prefName: key,
        prefJson: val,
        prefLbl: null,
      },
      { headers },
    );
  }

  public getHomePageToolbar(): Observable<any> {
    const url = formatMessage(environment.wsUrls.navbarData, {
      userId: this.okta.user().oktaDetails?.preferred_username,
      zoneId: this.okta.user().oldOrganizationVal,
    });
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(url, { headers }).pipe(
      tap((res: any) => {
        const status = res.requests?.map((e: any) => e.status).join(',');
        this.okta.user.update((u) => {
          return {
            ...u,
            userRequest: status,
          };
        });
      }),
    );
  }

  public getWorkbenchData(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.workbenchItems, {
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      { headers },
    );
  }
  public getAvailableReports(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.availableReports, {
        userId: this.okta.user().oktaDetails?.preferred_username,
        zoneId: this.okta.user().oldOrganizationVal,
      }),
      { headers },
    );
  }
  public getWatchListData(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.watchlistData, {
        userId: this.okta.user().oktaDetails?.preferred_username,
        zoneId: this.okta.user().oldOrganizationVal,
      }),
      { headers },
    );
  }
  public getEditInfoData(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.editInfo, {
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      { headers },
    );
  }
  public renameWorkbench(val: any, workbenchType: string, asrType: string = ''): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.post<any>(
      formatMessage(environment.wsUrls.renameWorkbench, {
        workbenchType,
        listId: val.prioritizationListId,
      }),
      {
        ...val,
        audtInsrtId: this.okta.user().oktaDetails?.preferred_username,
      },
      { headers },
    );
  }

  public deleteWorkbench(row: any): Observable<any> {
    const workbenchType = row.listType === 'Working Set' ? 'lists' : 'searches';
    const headers = { 'Content-Type': 'application/json' };
    return this.http.delete<any>(
      formatMessage(environment.wsUrls.deleteWorkbench, {
        workbenchType,
        listId: row.listId,
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      { headers },
    );
  }

  public sharableUsers(row: any): Observable<any> {
    const asrType = row.asrType === 'MDCR' ? '' : 'mdcd/';
    const headers = { 'Content-Type': 'application/json' };
    const groupId = row.grpId ? row.grpId : '0';
    return this.http.get<any>(
      formatMessage(environment.wsUrls.sharableUsers, {
        asrType,
        groupId: groupId,
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      { headers },
    );
  }

  public shareGroup(payload: any, listType: string): Observable<any> {
    const workbenchType = listType === 'Working Set' ? 'asr' : 'search';
    const headers = { 'Content-Type': 'application/json' };

    return this.http.post<any>(
      formatMessage(environment.wsUrls.shareToGroup, {
        workbenchType,
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      { ...payload, grpType: workbenchType },
      { headers },
    );
  }

  public archive(row: any): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.post<any>(
      formatMessage(environment.wsUrls.archive, {
        groupId: row.grpId,
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      {},
      { headers },
    );
  }

  public updatePubPrivAction(actionBool: any): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.updatepubpriaction, {
        userId: this.okta.user().oktaDetails?.preferred_username,
        actionBool,
      }),
      { headers },
    );
  }

  public getCriminalDetails(data: any): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.getCriminalDetails, {
        userId: this.okta.user().oktaDetails?.preferred_username,
        searchType: data.eventType,
        asrId: data.subjId,
      }),
      { headers },
    );
  }

  public APSSubscribe(val: boolean): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    const payload = {
      action: val ? 'NEW' : 'UNSUBSCRIBE',
      event: 'APS',
      systemID: this.okta.user().oktaDetails?.preferred_username,
      type: 'WATCHLIST',
    };
    return this.http.post<any>(formatMessage(environment.wsUrls.watchlistSubscribe, {}), payload, {
      headers,
    });
  }

  public getAsrSearchRefdata(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.getAsrSearchRefdata, {
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      { headers },
    );
  }

  public getSavedSearchRefdata(): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.getSavedSearchRefdata, {
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      { headers },
    );
  }

  public getWorkbenchSearchById(listId: string): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.get<any>(
      formatMessage(environment.wsUrls.workbenchItemSearch, {
        workItemId: listId,
        userId: this.okta.user().oktaDetails?.preferred_username,
      }),
      { headers },
    );
  }

  public saveEditedSearch(prefLbl: string, prefJson: any): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    return this.http.post<any>(
      environment.wsUrls.editSearchCriteria,
      {
        userId: this.okta.user().oktaDetails?.preferred_username,
        prefName: 'asrSearch',
        prefJson: JSON.stringify(prefJson),
        prefLbl,
      },
      { headers },
    );
  }

  public verifyASRs(asrptIds: any, asrType: any): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    const asrTypePrefix = asrType === 0 ? '' : 'mdcd/';
    return this.http.post<any>(
      formatMessage(environment.wsUrls.verifyAsrs, {
        asrType: asrTypePrefix,
      }),
      { asrptIds },
      { headers },
    );
  }
}
