import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, signal } from '@angular/core';
import { environment } from '../environments/environment.shared';
import { Observable } from 'rxjs';
import { OktaService } from './okta';
import { formatMessage } from '../utilities/utils';

@Injectable({
  providedIn: 'root',
})
export class SearchService {
  searchData = signal<any>(null);
  constructor(
    private http: HttpClient,
    private okta: OktaService,
  ) {}

  clearSearchData() {
    this.searchData.set(null);
  }

  public payload2Json(payload: any): any {
    if (!payload) return null;
    if (typeof payload !== 'object') return null;
    payload['loggedInUserId'] = this.userId;
    return JSON.stringify(payload);    
  }

  public json2Payload(prefJson: string): any {
    if (!prefJson) return null;
    if (typeof prefJson !== 'string') return null;
    try {
      return JSON.parse(prefJson);
    } catch {
      return null;
    }
  }

  get userId() {
    const userId = this.okta.user().oktaDetails?.preferred_username;
    return String(userId || '').trim().toUpperCase();
  }

  public customSearch(payload: any): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const normalizedUserId = this.userId;
    const requestBody = {
      ...(payload || {}),
      loggedInUserId: normalizedUserId,
    };

    return this.http.post<any>(
      environment.wsUrls.asrSearch,
      requestBody,
      { headers },
    );
  }

  public saveSearchPreferences(name: string, preferences: string): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    const payload = this.json2Payload(preferences);

    return this.http.post<any>(
      environment.wsUrls.saveUserPrefs,
      {
        userId: this.userId,
        prefName: payload?.programType === 'medicaid' ? 'asrSearchMdcd' : 'asrSearch',
        prefJson: preferences,
        prefLbl: name,
      },
      { headers }
    );
  }
  
  public getEditedSearchCriteria(searchId: string): Observable<any> {
    const headers = { 'Content-Type': 'application/json' };
    const userId = String(this.okta.user().oktaDetails?.preferred_username || '').toUpperCase();
    return this.http.get<any>(
      formatMessage(environment.wsUrls.editSearchCriteria, {
        searchId,
        userId,
      }),
      { headers }
    );
  }

}
