import {
  Component,
  Input,
  ChangeDetectionStrategy,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
  OnDestroy,
  Host,
  HostListener,
} from '@angular/core';
import { LoaderService } from '../../services/loader.service';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-loader',
  // changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <ng-template #loaderTpl>
      <div class="app-loader-panel" role="status" aria-live="polite">
        <div class="spinner-container" role="status" aria-busy="true" data-test-id="tbl-loading">
          <div class="spinner" aria-hidden="true"></div>
          <span class="sr-only">Loading...</span>
        </div>
        @if (message) {
          <div class="message">{{ message }}</div>
        }
      </div>
    </ng-template>
  `,
  styles: [
    `
      /* Panel (rendered inside CDK overlay pane). The overlay pane itself is styled globally. */
      .app-loader-panel {
        display: flex;
        align-items: center;
        gap: 1rem;
        min-width: 220px;
        max-width: 92%;
        padding: 0.75rem 1rem;
        border-radius: 8px;
        pointer-events: auto;
      }

      .message {
        font-size: 0.95rem;
        color: #333;
        line-height: 1.2;
        word-break: break-word;
        max-width: 48ch;
      }
    `,
  ],
  standalone: false,
})
export class AppLoaderComponent {
  /**
   * Controls visibility of the global loader.
   * Bind [show] from your app state or a loader service.
   */
  @Input() show = false;

  /**
   * Optional message displayed under the spinner.
   */
  @Input() message?: string;

  constructor(
    private loaderService: LoaderService,
    private overlay: Overlay,
    private vcr: ViewContainerRef,
    private dialog: MatDialog,
  ) {
    this.loaderService.state$?.subscribe((state: any) => {
      const show = !!(state && state.show);
      this.message = state && state.message ? state.message : undefined;
      if (show) {
        this.showOverlay();
      } else {
        this.hideOverlay();
      }
    });
  }

  ngOnDestroy(): void {
    this.hideOverlay();
    if (this.overlayRef) {
      try {
        this.overlayRef.dispose();
      } catch (e) {}
      this.overlayRef = null;
    }
  }

  @ViewChild('loaderTpl') loaderTpl!: TemplateRef<any>;

  private overlayRef: OverlayRef | null = null;

  private createOverlay(): OverlayRef {
    if (this.overlayRef) return this.overlayRef;

    const position = this.overlay.position().global().centerHorizontally().centerVertically();
    this.overlayRef = this.overlay.create({
      positionStrategy: position,
      scrollStrategy: this.overlay.scrollStrategies.block(),
      hasBackdrop: false,
      panelClass: 'app-loader-overlay-panel',
    });

    return this.overlayRef;
  }

  disableClose(val: boolean): void {
    this.dialog?.openDialogs?.forEach((dialogRef) => {
      dialogRef.disableClose = val;
    });
  }

  private showOverlay(): void {
    const ref = this.createOverlay();
    if (!ref.hasAttached()) {
      const portal = new TemplatePortal(this.loaderTpl, this.vcr);
      ref.attach(portal);
      this.disableClose(true);
    }
  }

  private hideOverlay(): void {
    if (this.overlayRef && this.overlayRef.hasAttached()) {
      try {
        this.overlayRef.detach();
        this.disableClose(false);
      } catch (e) {}
    }
  }
}
