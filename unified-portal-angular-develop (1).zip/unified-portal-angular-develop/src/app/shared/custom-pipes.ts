import { Pipe, PipeTransform, Injector, Type, Injectable } from '@angular/core';
import {formatCurrency } from '@angular/common'
@Pipe({
  name: 'riskScore',
  standalone: true,
})
@Injectable({ providedIn: 'root' })

export class RiskScorePipe implements PipeTransform {
  transform(value: any): string {
    if (value !== null && value !== undefined && value !== 'N/A') {
      const num = parseFloat(value);
      if (!Number.isFinite(num)) return 'N/A';

      if (num > 0.99) return '> 0.99';
      if (num < 0.01) return '< 0.01';

      return num.toFixed(2);
    }

    return 'N/A';
  }
}
@Pipe({
  name: 'asrLink',
  standalone: true,
})
@Injectable({ providedIn: 'root' })

export class AsrDetailLinkPipe implements PipeTransform {
  transform(row: any): string {
    if(row.blngAsrptId == null){
			return row.npi;
		}
		else
		return `<a id="viewBillingNPIASRIDLink{{row.clmBlngPrvdrNpiNum}}" role="link" tabindex="0" class="viewBillingNPIASRID" aria-label="ASR ID {{row.clmBlngPrvdrNpiNum}}" title="Alerted Billing NPI {{row.clmBlngPrvdrNpiNum}}" style="cursor:pointer;">{{row.clmBlngPrvdrNpiNum}}</a>`;

  }
}
@Pipe({
  name: 'yesNoPipe',
  standalone: true,
})
@Injectable({ providedIn: 'root' })

export class YesNoPipe implements PipeTransform {
  transform(value: any): string {
    if (value == null || value === undefined){
      return "No";
    }
    if (typeof value == "boolean") {
     return value ? "Yes" : "No";
    }
    if (typeof value == "string") {
      return value === "Y" ? "Yes" : "No";
     }
    return "No";
  }
}
@Pipe({ name: 'dynamicPipe', standalone: true })
export class DynamicPipe implements PipeTransform {
  constructor(private injector: Injector) {}

  transform(value: any, pipeClass: Type<any>, ...pipeArgs: any[]): any {
    if (pipeClass === undefined || (pipeClass as any) === '') return value;
    if ((pipeClass as any) === "currencyPipe"){
      return formatCurrency(value, 'en-US', '$');
    }
    if ((pipeClass as any) === "riskScore"){
      const pipeInstance = this.injector.get(RiskScorePipe);
      return pipeInstance.transform(value);
    }
  
   
  }
}