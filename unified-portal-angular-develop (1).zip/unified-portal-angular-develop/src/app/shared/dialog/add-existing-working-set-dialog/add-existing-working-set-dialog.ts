import { Component, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ErrorStateMatcher } from '@angular/material/core';
import { LoaderService } from '../../../services/loader.service';
import { ToastService } from '../../../services/toaster.service';
import { TriageService } from '../../../services/triage.service';

export interface AddExistingWorkingSetDialogData {
  title?: string;
  instruction?: string;
  label?: string;
  cancelText?: string;
  submitText?: string;
  isMedicare: boolean;
  asrptIds: number[];
  workingSets: Array<{ listId: string; listNm: string }>;
}

@Component({
  selector: 'app-add-existing-working-set-dialog',
  templateUrl: './add-existing-working-set-dialog.html',
  styleUrl: './add-existing-working-set-dialog.scss',
  standalone: false,
})
export class AddExistingWorkingSetDialogComponent {
  workSetCtrl = new FormControl('', [Validators.required]);
  isSubmitting = false;
  addAttempted = false;
  readonly addAttemptMatcher: ErrorStateMatcher = {
    isErrorState: (control) => !!(control && control.invalid && this.addAttempted),
  };

  constructor(
    private dialogRef: MatDialogRef<AddExistingWorkingSetDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AddExistingWorkingSetDialogData,
    private _triageService: TriageService,
    private _loader: LoaderService,
    private _toaster: ToastService,
  ) {}

  cancel() {
    this.dialogRef.close(null);
  }

  add() {
    this.addAttempted = true;
    this.workSetCtrl.markAsTouched();
    if (this.workSetCtrl.invalid || this.isSubmitting) return;
    const workItemId = String(this.workSetCtrl.value || '').trim();
    if (!workItemId) return;

    this.isSubmitting = true;
    this._loader.show();

    this._triageService
      .addToExistingWorkingSet(workItemId, this.data.asrptIds || [], this.data.isMedicare)
      .subscribe({
        next: () => {
          this.isSubmitting = false;
          this._loader.hide();
          this._toaster.success('ASRs successfully added to list.');
          this.dialogRef.close(true);
        },
        error: (err: any) => {
          this.isSubmitting = false;
          this._loader.hide();
          this._toaster.error(
            `Add to Existing Working Set failed due to ${err?.status || 'error'}`,
          );
        },
      });
  }
}
