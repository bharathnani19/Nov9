import { Component, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ErrorStateMatcher } from '@angular/material/core';
import { TriageService } from '../../../services/triage.service';
import { LoaderService } from '../../../services/loader.service';
import { ToastService } from '../../../services/toaster.service';

export interface AddWorkingSetDialogData {
  title?: string;
  instruction?: string;
  label?: string;
  cancelText?: string;
  submitText?: string;
  isMedicare: boolean;
  listItems: Array<{ asrptId: string }>;
}

@Component({
  selector: 'app-add-working-set-dialog',
  templateUrl: './add-working-set-dialog.html',
  styleUrl: './add-working-set-dialog.scss',
  standalone: false,
})
export class AddWorkingSetDialogComponent {
  nameCtrl = new FormControl('', [Validators.required]);
  isSubmitting: boolean = false;
  addAttempted: boolean = false;
  readonly addAttemptMatcher: ErrorStateMatcher = {
    isErrorState: (control) => !!(control && control.invalid && this.addAttempted),
  };

  constructor(
    private dialogRef: MatDialogRef<AddWorkingSetDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AddWorkingSetDialogData,
    private _triageService: TriageService,
    private _loader: LoaderService,
    private _toaster: ToastService
  ) {}

  cancel() {
    this.dialogRef.close(null);
  }

  add() {
    this.addAttempted = true;
    this.nameCtrl.markAsTouched();
    if (this.nameCtrl.invalid) return;
    const listNm = this.nameCtrl.value?.trim();
    if (!listNm || this.isSubmitting) return;

    this.isSubmitting = true;
    this._loader.show();

    this._triageService.checkExistingWorkingSetNames(this.data.isMedicare).subscribe({
      next: (res: any[]) => {
        const exists = (res || []).some(
          (item: any) => String(item?.listNm || '').trim() === listNm
        );

        if (exists) {
          this._toaster.error('An item with that name already exists. Please choose another name.');
          this.isSubmitting = false;
          this._loader.hide();
          return;
        }

        this._triageService
          .createWorkingSet(listNm, this.data.listItems || [], this.data.isMedicare)
          .subscribe({
            next: () => {
              this.isSubmitting = false;
              this._loader.hide();
              this._toaster.success('ASRs successfully added to list.');
              this.dialogRef.close(true);
            },
            error: (err: any) => {
              this._toaster.error(`Create Working Set failed due to ${err?.status || 'error'}`);
              this.isSubmitting = false;
              this._loader.hide();
            },
          });
      },
      error: (err: any) => {
        this._toaster.error(`Unable to validate Working Set name due to ${err?.status || 'error'}`);
        this.isSubmitting = false;
        this._loader.hide();
      },
    });
  }
}
