import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'aps-dialog',
  templateUrl: './aps-dialog.html',
  styleUrls: ['./aps-dialog.scss'],
  standalone: false,
})
export class ApsDialogComponent {
  value: string | null = "1";
  errorMsg: string = '';

  constructor(
    public dialogRef: MatDialogRef<ApsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  cancel() {
    this.dialogRef.close({ confirmed: false });
  }

  confirm() {
    if (this.value === null) {
      this.errorMsg = 'Please select Yes or No';
      return;
    }

    this.dialogRef.close({
      confirmed: true,
      value: Number(this.value),
    });
  }
}
