import { Component, effect, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HomePageService } from '../../../services/homepage.service';
import { ToastService } from '../../../services/toaster.service';
import { OktaService } from '../../../services/okta';
import { SearchLookup } from '../../interface';
import { LoaderService } from '../../../services/loader.service';
import { MedicareSearchComponent } from '../../../modules/core/search/medicaire-search-component/medicare-search-component';
import { MedicaidSearchComponent } from '../../../modules/core/search/medicaid-search-component/medicaid-search-component';
import { Router } from '@angular/router';
import { PresetSearchComponent } from '../../../modules/core/search/preset-search-component/preset-search-component';
import { SavedSearchComponent } from '../../../modules/core/search/saved-search-component/saved-search-component';
import { UtilService } from '../../../services/util.service';
import { SearchService } from '../../../services/search.service';
import { TriageService } from '../../../services/triage.service';
import { HttpErrorResponse } from '@angular/common/http';

type Option = { code: string; label?: string };
type SearchDialogMode = 'newSearch' | 'modifySavedSearch' | 'modifyUnsavedSearch';

@Component({
  selector: 'app-custom-search',
  templateUrl: './custom-search-dialog.html',
  styleUrls: ['./custom-search-dialog.scss'],
  standalone: false,
})
export class CustomSearchDialogComponent implements OnInit {
  selectedTabIndex = 0;
  ASRType: number = 1;
  searchLookups: SearchLookup | any = {};
  form!: FormGroup;
  actionabilities: any[] = [];
  alertStatuses!: Option[];
  @ViewChild(MedicareSearchComponent) private medicareComponent!: MedicareSearchComponent;
  @ViewChild(MedicaidSearchComponent) private medicaidComponent!: MedicaidSearchComponent;
  @ViewChild(PresetSearchComponent) private presetComponent!: PresetSearchComponent;
  @ViewChild(SavedSearchComponent) private savedComponent!: SavedSearchComponent;

  get isModifySavedMode(): boolean {
    return this.data?.mode === 'modifySavedSearch';
  }

  public isProgramDisabled(control: string): boolean {
    if (control === 'medicare') {
      return this.isModifySavedMode && this.ASRType != 0;
    }
    return (this.isModifySavedMode && this.ASRType == 0) || !!this.okta.user().disableMedicaid;
  }

  get dialogTitle(): string {
    if (!this.isModifySavedMode) {
      return 'Search';
    }
    const savedName = String(this.data?.savedSearchName || '').trim();
    return savedName ? `Search - ${savedName}` : 'Search';
  }

  constructor(
    public dialogRef: MatDialogRef<CustomSearchDialogComponent>,
    private fb: FormBuilder,
    private _homeService: HomePageService,
    private _toaster: ToastService,
    public okta: OktaService,
    private loader: LoaderService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router,
    private utilService: UtilService,
    private _searchService: SearchService,
    private _triage: TriageService,
  ) {
    effect(() => {
      if (this.data?.ASRType != null) return;
      this.ASRType =
        this.okta.defaultAsrView() === 'medicare' || this.okta.user().disableMedicaidMAC ? 0 : 1;
    });
  }

  ngOnInit(): void {
    console.log('>>> ngOnInit: ', this.data.refData);
    if (!this.data.refData) {
      this.getSearchRefdata();
    } else {
      this.searchLookups = this.data.refData;
    }
    this.initOptions();

    if (this.data?.initialValues) {
      this.form.patchValue(this.data.initialValues);
    }

    if (this.data?.selectedTabIndex != null) {
      this.selectedTabIndex = Number(this.data.selectedTabIndex) || 0;
    }

    if (this.data?.ASRType != null) {
      this.ASRType = Number(this.data.ASRType);
    }

    const savedSearchId = String(this.data?.savedSearchId || '').trim();
    if (savedSearchId) {
      this.loader.show();
      this._searchService.getEditedSearchCriteria(savedSearchId).subscribe((res: any) => {
        const searchParams = this._searchService.json2Payload(res?.prefJson);
        this.selectedTabIndex = 0;
        this.ASRType = searchParams?.programType === 'medicare' ? 0 : 1;
        const component =
          searchParams?.programType === 'medicare'
            ? this.medicareComponent
            : this.medicaidComponent;
        component.populate(searchParams, this.data);
      });
      this.loader.hide();
    }

    if (this.isModifySavedMode) {
      this.selectedTabIndex = 0;
    }
  }

  private initOptions(): void {
    this.alertStatuses = [
      { code: '12', label: 'New' },
      { code: '13', label: 'Aged' },
    ];

    this.actionabilities = [
      { code: 'Highly Likely' },
      { code: 'Somewhat Likely' },
      { code: 'Less Likely' },
    ];
  }

  private getSearchRefdata() {
    this.loader.show();
    this._homeService.getAsrSearchRefdata().subscribe({
      next: (res: SearchLookup) => {
        console.log('>>> ASR searchLookups: ', res);
        Object.assign(this.searchLookups, res);
        this.loader.hide();
      },
      error: (err: any) => {
        this.loader.hide();
      },
    });

    this._homeService.getSavedSearchRefdata().subscribe({
      next: (res: SearchLookup) => {
        console.log('>>> Saved searchLookups: ', res);
        Object.assign(this.searchLookups, res);
      },
      error: (err: any) => {
        this.loader.hide();
      },
    });
  }

  verifyAsrIds(): void {
    const raw = String(this.form.get('asrptIds')?.value ?? '');
    const ids = raw
      .split(/[\s,]+/g)
      .map((x) => x.trim())
      .filter(Boolean);

    if (!ids.length) {
      console.warn('No ASR IDs entered to verify.');
      return;
    }

    const invalidIds = ids.filter((id) => !/^\d{10}$/.test(id));

    if (invalidIds.length) {
      const message = `The following NPI has an incorrect format: ${invalidIds.join(', ')}`;
      this._toaster.error(message);
      return;
    }

    if (ids.length > 200) {
      this._toaster.error('Number of ASRs exceeds the limit of 200.');
      return;
    }

    this._homeService.verifyASRs(ids, this.ASRType).subscribe({});
  }

  getIds(ids: string) {
    return ids
      ?.split(/[\s,]+/g)
      .map((x) => x.trim())
      .filter(Boolean);
  }

  /** Clear all criteria */
  clearForm(): void {
    if (this.selectedTabIndex == 0) {
      if (this.ASRType == 0) {
        this.medicareComponent.clearForm();
      } else {
        this.medicaidComponent.clearForm();
      }
      this.selectedTabIndex = 0;
      this._toaster.info('The search defaults have been restored.');
    } else if (this.selectedTabIndex == 1) {
      this.savedComponent.clearForm();
      this._toaster.info('The saved search selection has been cleared.');
    } else if (this.selectedTabIndex == 2) {
      this.presetComponent.clearForm();
      this._toaster.info('The preset search selection has been cleared.');
    }
  }

  submit(e: any): void {
    const slaToken = this.utilService.getSlaToken();
    this.utilService
      .logSla(
        this.okta.user().oktaDetails?.preferred_username!,
        'ASR Search - Start: ' + slaToken,
        this.okta.user().organization!,
      )
      .subscribe({
        //this.utilService.logSla('testuser', 'ASR Search - Start: ' + slaToken,'testzone').subscribe({
        next: (results) => {},
        error: (err) => {
          // This block runs if any of the observables error
          console.error(err);
        },
      });

    let payload: any = {};
    let formData: any;
    // Custom Search
    if (this.selectedTabIndex == 0) {
      const component = this.ASRType == 0 ? this.medicareComponent : this.medicaidComponent;
      if (component.isFormValid) {
        formData = component.form.value;
        payload = component.prepSubmit();
        payload.programType = this.ASRType === 1 ? 'medicaid' : 'medicare';
      } else {
        this._toaster.error('Please correct the search form field errors.');
        return;
      }

      // Saved Search
    } else if (this.selectedTabIndex == 1) {
      const selectedSavedSearchId = this.savedComponent.form.value.saved;
      console.log('Executing saved search: ', selectedSavedSearchId);
      this._searchService.getEditedSearchCriteria(selectedSavedSearchId).subscribe((res: any) => {
        payload = this._searchService.json2Payload(res?.prefJson);
        this.executeSearch(payload, null, slaToken);
      });
      return;

      // Preset Search
    } else if (this.selectedTabIndex == 2) {
      payload = this.presetComponent.prepSubmit();
      console.log('Preset Search payload:', payload);
    }

    // execute search on payload
    if (this.isModifySavedMode) {
      this.executeSearchAndSave(payload, formData, slaToken);
    } else {
      this.executeSearch(payload, formData, slaToken);
    }
  }

  cancel(): void {
    this.dialogRef.close(false);
  }

  getSelectedValuesForProgram(programType: number): any {
    if (this.isModifySavedMode) {
      return this.data?.selectedSearchFilter || {};
    }

    const initialProgramType = Number(this.data?.ASRType);
    if (Number.isNaN(initialProgramType) || initialProgramType !== programType) {
      return {};
    }
    return this.data?.selectedSearchFilter || {};
  }

  // Coming from an un-named search
  private executeSearch(payload: any, formData: any, slaToken: string): void {
    this.loader.show();
    this._searchService.customSearch(payload).subscribe(
      (res: any) => {
        const responseData =
          payload?.programType === 'medicare' ? res.responseData : res.responseDataMdcd;
        const url = this.router.url;
        console.log('Current url: ', url);

        if (!responseData?.length) {
          this._toaster.info('No matching records found.');

          if (!url?.startsWith('/Investigative/Triage')) {
            this.loader.hide();
            this.dialogRef.close();
            return;
          }
        }

        const selectedSavedSearchId = this.savedComponent.form.value.saved;
        let found = {listNm: null};
        console.log('Executing saved search: ', selectedSavedSearchId);
        if (selectedSavedSearchId) {
          const saved = this.searchLookups?.saved;
          found = saved.find( (item: any) => item.listId === selectedSavedSearchId );
        }

        this._searchService.searchData.set({
          data: res,
          filter: formData,
          programType: payload?.programType,
          savedSearchName: found?.listNm,
          savedSearchId: selectedSavedSearchId,
          prefJson: this._searchService.payload2Json(payload),
        });
        this.router.navigate(['/Investigative/Triage']);
        this.dialogRef.close(res);
        this.loader.hide();

        this.utilService
          .logSla(
            this.okta.user().oktaDetails?.preferred_username!,
            'ASR Search - End: ' + slaToken,
            this.okta.user().organization!,
          )
          .subscribe({
            next: () => {},
            error: (err) => {
              console.error(err);
            },
          });
      },
      (error: HttpErrorResponse) => {
        this.loader.hide();
        this._toaster.error('Search failed due to ' + error.status);
        console.error(error);
      },
    );
  }

  // Coming from a named search
  private executeSearchAndSave(payload: any, formData: any, slaToken: string): void {
    const searchName = this.data?.savedSearchName;
    const searchId = this.data?.savedSearchId;
    const prefJson = this._searchService.payload2Json(payload);

    this.loader.show();
    this._searchService.customSearch(payload).subscribe(
      (res: any) => {
        const responseData =
          payload?.programType === 'medicare' ? res.responseData : res.responseDataMdcd;
        const zeroResults: Boolean = !responseData?.length;
        if (zeroResults) {
          this._toaster.info('No matching records found.');
        }

        this._triage.getAddToExistInputVals().subscribe((res2: any) => {
          this._searchService.saveSearchPreferences(searchName, prefJson).subscribe(() => {
            if (!zeroResults) {
              this._toaster.success('Saved search ' + name);
            }

            this._searchService.searchData.set({
              data: res,
              filter: formData,
              programType: payload?.programType,
              savedSearchName: searchName,
              savedSearchId: searchId,
              prefJson: prefJson,
            });

            if (!zeroResults) {
              this.router.navigate(['/Investigative/Triage']);
            }
            this.dialogRef.close();
            this.loader.hide();

            this.utilService
              .logSla(
                this.okta.user().oktaDetails?.preferred_username!,
                'ASR Search - End: ' + slaToken,
                this.okta.user().organization!,
              )
              .subscribe({
                next: () => {},
                error: (err) => {
                  console.error(err);
                },
              });
          });
        });
      },
      (error: HttpErrorResponse) => {
        this.loader.hide();
        this._toaster.error('Search failed due to ' + error.status);
        console.error(error);
      },
    );
  }
}
