import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TableComponent } from '../../table/table';
import {
  CdkDragDrop,
  DragDropModule,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { HomePageService } from '../../../services/homepage.service';
import { LoaderService } from '../../../services/loader.service';
import { ToastService } from '../../../services/toaster.service';

@Component({
  selector: 'app-my-reports-dialog',
  templateUrl: './my-reports.html',
  styleUrls: ['./my-reports.scss'],
  standalone: false,
})
export class MyReportsDialogComponent {
  selectedReports: any[] = [];

  availableReports: any[] = [];
  rowData: any;
  searchText = '';
  isManagedFavoritesLoading:boolean = false;
  selectAllCheckbox:boolean = false;

  

  constructor(
    public dialogRef: MatDialogRef<MyReportsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _homeService: HomePageService,
    private loader: LoaderService,
    private _toaster: ToastService
  ) {
    this.availableReports = [...data];
    this.selectedReports = this.availableReports.filter(r=> r.checked).map(r=>r.rptId);
    this.rowData = data.rowData;
    this.selectAllCheckbox = this.isAllSelected();
  }

  managedFavoritesColumns = [
    {
      key: 'state',
      label: '',
      custom: true,
      customHeader: true,
      sortable:false
    },
    {
      key: 'rptNm',
      label: 'Report Name',
      sortable: true,
     
    },
    {
      key: 'rptDesc',
      label: 'Report Description',
      sortable: true,
    }
  ];
  
  saveManagedFavorites() {
    if (this.selectedReports.length == 0){
      this._toaster.error("Please select at least one report.");
      return;
    } 
    this.loader.show();
    this._homeService.updatePreference(JSON.stringify(this.selectedReports),"landingPageReports").subscribe({
      next: (res: any) => {
        this.loader.hide();
        this.dialogRef.close(this);
      },
      error: (err: any) =>{
        this.loader.hide();
      }
      });
  }

  onSelectedReportChange(item:any){
    if (item.checked) {
      this.selectedReports.push(item.rptId);
    } else {
      this.selectedReports = this.selectedReports.filter(id => id !== item.rptId);
    }
    this.selectAllCheckbox = this.isAllSelected();
  }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
      const numSelected = this.selectedReports.length;
      const numRows = this.availableReports.length;
      return numSelected === numRows;
    }
  
    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
      this.isAllSelected() ?
          this.unselectAllReports() :
          this.selectAllReports();
    }
    unselectAllReports(){
      this.selectAllCheckbox = false;
      this.selectedReports=[]; 
      this.availableReports.forEach((row:any) => {row.checked = false});

    }
    selectAllReports(){
      this.selectAllCheckbox = true;
      this.selectedReports=[]; 
      this.availableReports.forEach((row:any) => {row.checked = true; this.selectedReports.push(row.rptId)});

    }
}
