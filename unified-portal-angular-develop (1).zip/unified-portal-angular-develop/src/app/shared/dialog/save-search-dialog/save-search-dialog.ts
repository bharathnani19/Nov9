import { Component, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TriageService } from '../../../services/triage.service';
import { LoaderService } from '../../../services/loader.service';
import { HomePageService } from '../../../services/homepage.service';
import { SearchService } from '../../../services/search.service';
import { ToastService } from '../../../services/toaster.service';

export interface SaveSearchDialogData {
  selectedSearchAsJson: any;
  programType: string;
}

@Component({
  selector: 'app-save-search-dialog',
  templateUrl: './save-search-dialog.html',
  styleUrls: ['./save-search-dialog.scss'],
  standalone: false,
})
export class SaveSearchDialogComponent {
  nameCtrl = new FormControl('', [Validators.required]);

  constructor(
    private dialogRef: MatDialogRef<SaveSearchDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: SaveSearchDialogData,
    private _triageService: TriageService,
    private _loader: LoaderService,
    private _toaster: ToastService,
    private _homeService: HomePageService,
    private _searchService: SearchService,
  ) {}

  cancel() {
    this.dialogRef.close(null);
  }

  saveSearch() {
    const name = this.nameCtrl.value;
    const prefs = this.data?.selectedSearchAsJson;
    const program = this.data?.programType;

    if (!name) {
      return;
    }

    this._homeService.getSavedSearchRefdata().subscribe({
      next: (res) => {
        const exists = res.some((item: { listNm: string; }) => item.listNm === name);
        if (exists) {
          this._toaster.error('A search with that name already exists. Please choose another name.');
          return
        }

        this._searchService.saveSearchPreferences(name, prefs).subscribe({
          next: () => {
            this._toaster.success('Saved search ' + name);
            this.dialogRef.close();
          },
          error: (err) => {
            this._toaster.error('Search not saved due to ' + err.message);
            this.dialogRef.close();
          },
        });
      },
      error: (err) => {
        this._toaster.error('Search not saved due to ' + err.message);
        this.dialogRef.close();
      },
    });
  }  
}