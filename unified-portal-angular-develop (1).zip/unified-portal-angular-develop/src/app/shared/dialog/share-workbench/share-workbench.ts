import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  CdkDragDrop,
  DragDropModule,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { HomePageService } from '../../../services/homepage.service';

@Component({
  selector: 'app-share-workbench-dialog',
  templateUrl: './share-workbench.html',
  styleUrls: ['./share-workbench.scss'],
  standalone: false,
})
export class SharedUserDialogComponent {
  allUsers: any[] = [];
  sharedUsers: any[] = [];
  rowData: any;
  searchText = '';

  // Multi-select model bindings
  selectedLeft: any[] = [];
  selectedRight: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<SharedUserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _homeService: HomePageService
  ) {
    this.allUsers = [...data.availableUsers];
    this.sharedUsers = [...data.sharedUsers];
    this.rowData = data.rowData;
  }

  /** FILTER LEFT LIST */
  filteredLeftUsers() {
    if (!this.searchText.trim()) return this.allUsers;
    return this.allUsers.filter((u) =>
      (u.firstNm + u.lastNm + u.userId).toLowerCase().includes(this.searchText.toLowerCase())
    );
  }

  /** MOVE ALL TO RIGHT */
  moveAllRight() {
    this.sharedUsers.push(...this.allUsers);
    this.allUsers = [];
    this.selectedLeft = [];
  }

  /** MOVE SELECTED RIGHT */
  moveSelectedRight() {
    this.sharedUsers.push(...this.selectedLeft);
    this.allUsers = this.allUsers.filter((u) => !this.selectedLeft.includes(u));
    this.selectedLeft = [];
  }

  /** MOVE SELECTED LEFT */
  moveSelectedLeft() {
    this.allUsers.push(...this.selectedRight);
    this.sharedUsers = this.sharedUsers.filter((u) => !this.selectedRight.includes(u));
    this.selectedRight = [];
  }

  /** MOVE ALL TO LEFT */
  moveAllLeft() {
    this.allUsers.push(...this.sharedUsers);
    this.sharedUsers = [];
    this.selectedRight = [];
  }

  save() {
    const  prioritizationShareGrp = {
				grpId: this.rowData.grpId,
    			userIds: this.sharedUsers.map(o => o.userId),
    			listId: this.rowData.listId,
    			// grpTxt: pGroupComments
    		}
    this._homeService.shareGroup(prioritizationShareGrp,this.rowData.listType).subscribe({
      next: (res: any) => {
        this.dialogRef.close(this.sharedUsers);
      },
    });
  }
}
