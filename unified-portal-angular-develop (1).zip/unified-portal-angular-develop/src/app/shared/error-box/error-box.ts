import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

export type AlertType = 'success' | 'error' | 'warning' | 'info';

@Component({
  selector: 'app-alert-box',
  standalone: false,
  template: `
    @if (visible) {
      <div class="alert-box" [ngClass]="type">
        <div class="icon">
          @if (type === 'success') {
            <mat-icon>check_circle</mat-icon>
          }
          @if (type === 'error') {
            <mat-icon>error</mat-icon>
          }
          @if (type === 'warning') {
            <mat-icon>warning</mat-icon>
          }
          @if (type === 'info') {
            <mat-icon>info</mat-icon>
          }
        </div>
        <div class="message" [innerHTML]="message"></div>
        @if (closable) {
          <button
            mat-icon-button
            class="close-btn"
            (click)="close()">
            <mat-icon>close</mat-icon>
          </button>
        }
      </div>
    }
    `,
  styles: [`
    .alert-box {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 12px 16px;
      border-radius: 6px;
      font-size: 14px;
      position: relative;
      margin:0 8px;
    }

    .alert-box.success {
      background: #e6f9ec;
      border-left: 4px solid #38a169;
      color: #22543d;
    }

    .alert-box.error {
      background: #fdecea;
      border-left: 4px solid #e53e3e;
      color: #742a2a;
    }

    .alert-box.warning {
      background: #fff4e6;
      border-left: 4px solid #dd6b20;
      color: #7b341e;
    }

    .alert-box.info {
      background: #e8f4fd;
      border-left: 4px solid #3182ce;
      color: #2a4365;
    }

    .icon mat-icon {
      font-size: 22px;
    }

    .message {
      flex: 1;
      line-height: 1.4;
    }

    .close-btn {
      margin-left: auto;
      margin-top: -4px;
    }
  `],
})
export class AlertBoxComponent {
  @Input() type: AlertType = 'info';
  @Input() message: string = '';
  @Input() closable: boolean = false;

  visible = true;

  close() {
    this.visible = false;
  }
}
