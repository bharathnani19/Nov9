import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalMedicaid } from './external-medicaid';

describe('ExternalMedicaid', () => {
  let component: ExternalMedicaid;
  let fixture: ComponentFixture<ExternalMedicaid>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ExternalMedicaid]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExternalMedicaid);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
