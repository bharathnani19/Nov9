import { Component, Input } from '@angular/core';

@Component({
  selector: 'grid-item',
  standalone: false,
  template: `
    <div [ngStyle]="{ 'grid-column': 'span ' + col }">
      <ng-content></ng-content>
    </div>
  `,
  styles: [`
    :host {
      display: contents;
    }
  `],
})
export class GridItemComponent {
  @Input() col: number = 12; // default full width
}
