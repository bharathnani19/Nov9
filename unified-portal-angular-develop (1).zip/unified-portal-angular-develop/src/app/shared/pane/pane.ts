import { Component, Input, ViewEncapsulation } from '@angular/core';
import { Card } from '../interface';

@Component({
  selector: 'app-pane',
  templateUrl: './pane.html',
  styleUrl: './pane.scss',
  standalone: false,
  encapsulation: ViewEncapsulation.None, 
})
export class PaneComponent {
  @Input() card!: Card;
  selectedTabIndex: number = 0;
  selectedInfoTabIndex: number = 0;
}
