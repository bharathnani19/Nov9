import { NgModule } from '@angular/core';
import { PaneComponent } from './pane/pane';
import { MaterialModule } from './material.module';
import { CommonModule } from '@angular/common';
import { GridComponent } from './grid/grid';
import { GridItemComponent } from './grid/grid-item';
import { TableComponent } from './table/table';
import { CellTemplateDirective } from './table/cell.directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { RenameDialogComponent } from './dialog/rename-dialog/rename-dialog';
import { ConfirmationDialogComponent } from './dialog/confirmation-dialog/confirmation-dialog';
import { AlertBoxComponent } from './error-box/error-box';
import { SharedUserDialogComponent } from './dialog/share-workbench/share-workbench';
import { MyReportsDialogComponent } from './dialog/my-reports/my-reports';
import { CommonDialogComponent } from './dialog/common-dialog/common-dialog';
import { ApsDialogComponent } from './dialog/aps-dialog/aps-dialog';
import { ModelDetailDialogComponent } from './dialog/model-detail/model-detail';
import { ModelsTableComponent } from '../modules/home/components/models-table/models-table';
import { CustomSearchDialogComponent } from './dialog/custom-search-dialog/custom-search-dialog';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatOption } from '@angular/material/core';
import { MatDatepickerInput } from '@angular/material/datepicker';
import { MedicareSearchComponent } from '../modules/core/search/medicaire-search-component/medicare-search-component';
import { MedicaidSearchComponent } from '../modules/core/search/medicaid-search-component/medicaid-search-component';
import { PresetSearchComponent } from '../modules/core/search/preset-search-component/preset-search-component';
import { SavedSearchComponent } from '../modules/core/search/saved-search-component/saved-search-component';
import { AddWorkingSetDialogComponent } from './dialog/add-working-set-dialog/add-working-set-dialog';
import { AddExistingWorkingSetDialogComponent } from './dialog/add-existing-working-set-dialog/add-existing-working-set-dialog';
import { SaveSearchDialogComponent } from './dialog/save-search-dialog/save-search-dialog';
import { CustomDateAdapter } from '../utilities/custom-date-adapter';
import { PrioritizeUcmTableComponent } from './prioritize-ucm/prioritize-ucm.component';
import { AsrDetailLinkPipe, DynamicPipe, RiskScorePipe, YesNoPipe } from './custom-pipes';
import { DetailCardComponent } from './detail-card/detail-card';

const COMPONENTS = [
  PaneComponent,
  GridComponent,
  GridItemComponent,
  TableComponent,
  CellTemplateDirective,
  RenameDialogComponent,
  ConfirmationDialogComponent,
  AlertBoxComponent,
  SharedUserDialogComponent,
  MyReportsDialogComponent,
  CommonDialogComponent,
  ApsDialogComponent,
  ModelDetailDialogComponent,
  ModelsTableComponent,
  CustomSearchDialogComponent,
  MedicareSearchComponent,
  MedicaidSearchComponent,
  PresetSearchComponent,
  SavedSearchComponent,
  AddWorkingSetDialogComponent,
  AddExistingWorkingSetDialogComponent,
  SaveSearchDialogComponent,
  PrioritizeUcmTableComponent,
  DetailCardComponent,
];
const PIPES = [RiskScorePipe, YesNoPipe, DynamicPipe, AsrDetailLinkPipe];

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    MatOption,
    MatDatepickerInput,
    PIPES,
  ],
  exports: [...COMPONENTS, RouterModule],
  providers: [
    { provide: DateAdapter, useClass: CustomDateAdapter },
    { provide: MAT_DATE_LOCALE, useValue: 'en-US' },
    {
      provide: MAT_DATE_FORMATS,
      // APP_DATE_FORMATS
      useValue: {
        parse: { dateInput: 'YYYY-MM-DD' },
        display: {
          dateInput: 'YYYY-MM-DD',
          monthYearLabel: 'MMM yyyy',
          dateA11yLabel: 'LL',
          monthYearA11yLabel: 'MMMM yyyy',
        },
      },
    },
    PIPES,
  ],
})
export class SharedModule {}
