import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TableComponent } from './table';
import { MaterialModule } from '../material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('TableComponent - defaultSort', () => {
  let component: TableComponent;
  let fixture: ComponentFixture<TableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TableComponent],
      imports: [MaterialModule, BrowserAnimationsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(TableComponent);
    component = fixture.componentInstance;
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  describe('defaultSort method', () => {
    it('should return 0 when both values are null', () => {
      const result = component['defaultSort'](null, null);
      expect(result).toBe(0);
    });

    it('should return 0 when both values are undefined', () => {
      const result = component['defaultSort'](undefined, undefined);
      expect(result).toBe(0);
    });

    it('should return -1 when first value is null and second is not', () => {
      const result = component['defaultSort'](null, 'value');
      expect(result).toBe(-1);
    });

    it('should return -1 when first value is undefined and second is not', () => {
      const result = component['defaultSort'](undefined, 123);
      expect(result).toBe(-1);
    });

    it('should return 1 when second value is null and first is not', () => {
      const result = component['defaultSort']('value', null);
      expect(result).toBe(1);
    });

    it('should return 1 when second value is undefined and first is not', () => {
      const result = component['defaultSort'](456, undefined);
      expect(result).toBe(1);
    });

    describe('string comparison', () => {
      it('should sort strings alphabetically ascending', () => {
        expect(component['defaultSort']('apple', 'banana')).toBeLessThan(0);
        expect(component['defaultSort']('banana', 'apple')).toBeGreaterThan(0);
      });

      it('should return 0 for identical strings', () => {
        const result = component['defaultSort']('test', 'test');
        expect(result).toBe(0);
      });

      it('should handle case-sensitive comparison', () => {
        const result = component['defaultSort']('Apple', 'apple');
        expect(result).not.toBe(0);
      });

      it('should handle empty strings', () => {
        expect(component['defaultSort']('', 'test')).toBeLessThan(0);
        expect(component['defaultSort']('test', '')).toBeGreaterThan(0);
        expect(component['defaultSort']('', '')).toBe(0);
      });
    });

    describe('number comparison', () => {
      it('should sort numbers in ascending order', () => {
        expect(component['defaultSort'](1, 2)).toBe(-1);
        expect(component['defaultSort'](2, 1)).toBe(1);
      });

      it('should return 0 for equal numbers', () => {
        const result = component['defaultSort'](42, 42);
        expect(result).toBe(0);
      });

      it('should handle negative numbers', () => {
        expect(component['defaultSort'](-5, 5)).toBe(-1);
        expect(component['defaultSort'](5, -5)).toBe(1);
      });

      it('should handle decimal numbers', () => {
        expect(component['defaultSort'](1.5, 2.5)).toBe(-1);
        expect(component['defaultSort'](2.5, 1.5)).toBe(1);
      });

      it('should handle zero', () => {
        expect(component['defaultSort'](0, 1)).toBe(-1);
        expect(component['defaultSort'](1, 0)).toBe(1);
        expect(component['defaultSort'](0, 0)).toBe(0);
      });
    });

    describe('mixed type comparison', () => {
      it('should compare boolean values', () => {
        expect(component['defaultSort'](false, true)).toBe(-1);
        expect(component['defaultSort'](true, false)).toBe(1);
        expect(component['defaultSort'](true, true)).toBe(0);
      });

      it('should handle date objects', () => {
        const date1 = new Date('2024-01-01');
        const date2 = new Date('2024-12-31');
        expect(component['defaultSort'](date1, date2)).toBe(-1);
        expect(component['defaultSort'](date2, date1)).toBe(1);
      });
    });
  });
});
