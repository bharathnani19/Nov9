import { OptionValue } from "../models/optionvalue.model";

export enum navigationTypes {
  WINDOWHREF = 'windowhref',
  WINDOWOPEN = 'windowopen',
  ROUTER = 'router'
}

export enum allRoleTypes {
  EDITS_DEVELOPER = 'FPSUI EML Edits Developer',
  EDITS_MANAGER = 'FPSUI EML Edits Manager',
  DISM = 'FPSUI EML DISM',
  DMA = 'FPSUI EML DMA',
  DIBA = 'FPSUI EML DIBA',
  SYS_MAINTAIN = 'FPSUI EML System Maintainer',
  MODEL_MANAGER = 'FPSUI EML Model Manager',
  MODEL_DEVELOPER = 'FPSUI EML Model Developer',
  MODEL_OPS = 'FPSUI EML Model Operations',
  EDIT_OPS = 'FPSUI EML Edit Operations',
  EML_FIG = 'FPSUI EML FIG',
  PERATON = 'FPSUI Zone Peraton',
  FPS_SNOWFLAKE = 'FPS Snowflake Users',
  VM_ADMIN = 'FPSUI Attrib VM Admin',
  VM_CREATE = 'FPSUI Attrib VM Create',
  VM_READ = 'FPSUI Attrib VM Read',
  VM_UPDATE = 'FPSUI Attrib VM Update Edit',
  EI_ADMIN = 'FPSUI Attrib PRT Admin',
  EI_READ = 'FPSUI Attrib PRT Read', 
  EI_WRITE = 'FPSUI Attrib PRT Write',
  UM_IO_APPROVER = 'FPSUI Attrib IO Approver',
  UM_DMA_APPROVER = 'FPSUI Attrib DMA Approver',
  UM_MASTER_APPROVER = 'FPSUI Attrib Master Approver',
  UM_MAC_APPROVER = 'FPSUI Attrib MAC Approver',
  ROLE_ADMIN = 'FPSUI Role Admin',
  ROLE_INQUIRY = 'FPSUI Role Inquiry Only',
  ROLE_MAC = 'FPSUI Role MAC',
  ROLE_MEDIC = 'FPSUI Role MEDIC',
  ROLE_PRIORITY_SUP = 'FPSUI Role Prioritize Sup',
  ZONE_CMS = 'FPSUI Zone CMS',
  ZONE_DELOITTE = 'FPSUI Zone Deloitte',
  ZONE_MEDIC = 'FPSUI Zone MEDIC',
  ZONE_PERATON = 'FPSUI Zone Peraton',
  ZONE_GDIT = 'FPSUI Zone GDIT',
  ZONE_UPIC_MW = 'FPSUI Zone UPIC 1',
  ZONE_UPIC_NE = 'FPSUI Zone UPIC 2',
  ZONE_UPIC_W = 'FPSUI Zone UPIC 3',
  ZONE_UPIC_SW = 'FPSUI Zone UPIC 4',
  ZONE_UPICSE = 'FPSUI Zone UPIC 5',

}
export const upics = [
  {"zoneCd":"UPIC 3", "zoneDesc":"UPIC W"},
  {"zoneCd":"UPIC 4", "zoneDesc":"UPIC SW"},
  {"zoneCd":"UPIC 5", "zoneDesc":"UPIC SE"},
  {"zoneCd":"UPIC 2", "zoneDesc":"UPIC NE"},
  {"zoneCd":"UPIC 1", "zoneDesc":"UPIC MW"}
      
];


export enum allOrgTypes {
  CMS = 'CMS',
  DELOITTE = 'Deloitte',
  DLT = 'DLT',
  MEDIC = 'MEDIC',
  PERATON = 'Peraton',
  GDIT = 'GDIT',
  UPIC_1 = 'UPIC MW',
  UPIC_2 = 'UPIC NE',
  UPIC_3 = 'UPIC W',
  UPIC_4 = 'UPIC SW',
  UPIC_5 = 'UPIC SE',
  UPIC_MW = 'UPIC MW',
  UPIC_NE = 'UPIC NE',
  UPIC_W = 'UPIC W',
  UPIC_SW = 'UPIC SW',
  UPIC_SE = 'UPIC SE',
}

// search filters
export const defaultSearchRoleMap: Map<string, string[]> = new Map([
  ['modelsmedicaidno', [allRoleTypes.VM_CREATE, allRoleTypes.MODEL_MANAGER, allRoleTypes.MODEL_DEVELOPER]],
  ['modelsmedicaidyes', [allRoleTypes.MODEL_MANAGER, allRoleTypes.MODEL_DEVELOPER, allRoleTypes.VM_CREATE, allRoleTypes.SYS_MAINTAIN]],
  ['edits', [allRoleTypes.EDITS_MANAGER, allRoleTypes.EDITS_DEVELOPER]],
  ['cms', [allRoleTypes.DMA, allRoleTypes.DMA]],
]);

export const cancelRoles = [
  allRoleTypes.EDITS_DEVELOPER,
  allRoleTypes.DISM,
  allRoleTypes.EML_FIG,
  allRoleTypes.EDITS_MANAGER,
  allRoleTypes.DMA,
  allRoleTypes.SYS_MAINTAIN,
];

export const deleteRolesAll: string[] = [allRoleTypes.DMA, allRoleTypes.SYS_MAINTAIN];
export const deleteRolesByJurisdiction: string[] = [allRoleTypes.EDITS_MANAGER];
export const deleteRolesAsModeler: string[] = [allRoleTypes.EDITS_DEVELOPER];
export const deleteRolesAsSelf: string[] = [allRoleTypes.DISM, allRoleTypes.EML_FIG, allRoleTypes.EDITS_DEVELOPER];
export const deleteRolesByStatus: string[] = [allRoleTypes.DISM, allRoleTypes.EML_FIG, allRoleTypes.EDITS_DEVELOPER, allRoleTypes.EDITS_MANAGER];
export const saveRoles: string[] = [
  allRoleTypes.EDITS_DEVELOPER,
  allRoleTypes.DISM,
  allRoleTypes.EDITS_MANAGER,
  allRoleTypes.DMA,
  allRoleTypes.SYS_MAINTAIN,
  allRoleTypes.EML_FIG,
];
export const submitRoles: string[] = [
  allRoleTypes.EDITS_DEVELOPER,
  allRoleTypes.DISM,
  allRoleTypes.EDITS_MANAGER,
  allRoleTypes.DMA,
  allRoleTypes.SYS_MAINTAIN,
  allRoleTypes.EML_FIG,
];

export const EML_EDIT_VIEW_ROLES: string[] = [
  allRoleTypes.EDITS_MANAGER,
  allRoleTypes.DMA,
  allRoleTypes.DISM,
  allRoleTypes.EML_FIG,
  allRoleTypes.EDITS_DEVELOPER,
];

export const EML_EDIT_ADMIN_ROLES: string[] = [allRoleTypes.EDITS_MANAGER, allRoleTypes.DMA, allRoleTypes.SYS_MAINTAIN];

export const defaultTableColumnRoleMap: Map<string, string[]> = new Map([
  [
    'recordId',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.EDITS_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'propslType',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.EDITS_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'propslSubType',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.EDITS_DEVELOPER,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'vlnrbTag',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'submittedBy',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'crntStusDate',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'crntStus',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.EDITS_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'srvcCtgry',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.EDITS_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'srvcSubctgry',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.EDITS_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'prmrySchm',
    [allRoleTypes.VM_CREATE, allRoleTypes.MODEL_MANAGER, allRoleTypes.MODEL_DEVELOPER, allRoleTypes.DMA, allRoleTypes.DISM, allRoleTypes.EML_FIG],
  ],
  [
    'scndrySchm',
    [allRoleTypes.VM_CREATE, allRoleTypes.MODEL_MANAGER, allRoleTypes.MODEL_DEVELOPER, allRoleTypes.DMA, allRoleTypes.DISM, allRoleTypes.EML_FIG],
  ],
  [
    'modelType',
    [allRoleTypes.VM_CREATE, allRoleTypes.MODEL_MANAGER, allRoleTypes.MODEL_DEVELOPER, allRoleTypes.DMA, allRoleTypes.DISM, allRoleTypes.EML_FIG],
  ],
  [
    'propslDesc',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.EDITS_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'createDt',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.EDITS_MANAGER,
      allRoleTypes.EDITS_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  ['modelShrtName', [allRoleTypes.VM_CREATE, allRoleTypes.MODEL_MANAGER, allRoleTypes.MODEL_DEVELOPER, allRoleTypes.SYS_MAINTAIN]],
  ['modelLongName', [allRoleTypes.DMA, allRoleTypes.DISM, allRoleTypes.EML_FIG]],
  [
    'stateCd',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
  [
    'jrsdctn',
    [
      allRoleTypes.VM_CREATE,
      allRoleTypes.MODEL_MANAGER,
      allRoleTypes.MODEL_DEVELOPER,
      allRoleTypes.DMA,
      allRoleTypes.DISM,
      allRoleTypes.EML_FIG,
      allRoleTypes.SYS_MAINTAIN,
    ],
  ],
]);

export const testGroups: OptionValue[] = [
  {
    optionVal: allRoleTypes.MODEL_MANAGER,
    displayVal: allRoleTypes.MODEL_MANAGER,
    hideable: false,
  },
  {
    optionVal: allRoleTypes.MODEL_DEVELOPER,
    displayVal: allRoleTypes.MODEL_DEVELOPER,
    hideable: false,
  },
  {
    optionVal: allRoleTypes.EDITS_MANAGER,
    displayVal: allRoleTypes.EDITS_MANAGER,
    hideable: false,
  },
  {
    optionVal: allRoleTypes.EDITS_DEVELOPER,
    displayVal: allRoleTypes.EDITS_DEVELOPER,
    hideable: false,
  },
  {
    optionVal: allRoleTypes.VM_CREATE,
    displayVal: allRoleTypes.VM_CREATE,
    hideable: false,
  },
  {
    optionVal: allRoleTypes.SYS_MAINTAIN,
    displayVal: allRoleTypes.SYS_MAINTAIN,
    hideable: false,
  },
  {
    optionVal: allRoleTypes.DMA,
    displayVal: allRoleTypes.DMA,
    hideable: false,
  },
  {
    optionVal: allRoleTypes.DISM,
    displayVal: allRoleTypes.DISM,
    hideable: false,
  },
  {
    optionVal: allRoleTypes.EML_FIG,
    displayVal: allRoleTypes.EML_FIG,
    hideable: false,
  },
];

export const EDITS_ROLES: string[] = [
  allRoleTypes.EDITS_MANAGER,
  allRoleTypes.EDITS_DEVELOPER,
  allRoleTypes.DMA,
  allRoleTypes.DISM,
  allRoleTypes.EML_FIG,
  allRoleTypes.SYS_MAINTAIN,
];

export const ONE_GB_SIZE = 1073741824;
export const searchFilterKeyValueMapping = new Map([
  ['TYPES', 'types'],
  ['SCHEMES', 'schemes'],
  ['SCNDRYSCHMS', 'scndrySchms'],
  ['EDITSTATUSES', 'editStatuses'],
  ['MODELSTATUSES', 'modelStatuses'],
  ['CATEGORIES', 'categories'],
  ['SUBCATEGORIES', 'subCategories'],
  ['SUBTYPES', 'subTypes'],
  ['VLNRBID', 'vlnrbId'],
  ['JRSDCTN', 'jrsdctn'],
  ['PRRTY', 'prrty'],
  ['DATASRC', 'dataSrc'],
  ['STATECD', 'stateCd'],
  ['MODELTYPE', 'modelTypes'],
  ['MODELCNTRCTR', 'modelCntrctr'],
  ['VLNRBTAG', 'vlnrbTag'],
  ['ALERTTYPE', 'alertType'],
]);

export const searchFilterNameMapping = new Map([
  [searchFilterKeyValueMapping.get('TYPES')!, 'Record Type'],
  [searchFilterKeyValueMapping.get('SCHEMES')!, 'Primary Scheme'],
  [searchFilterKeyValueMapping.get('SCNDRYSCHMS')!, 'Secondary Scheme'],
  [searchFilterKeyValueMapping.get('MODELSTATUSES')!, 'Model Status'],
  [searchFilterKeyValueMapping.get('EDITSTATUSES')!, 'Edit Status'],
  [searchFilterKeyValueMapping.get('CATEGORIES')!, 'Service Category'],
  [searchFilterKeyValueMapping.get('SUBCATEGORIES')!, 'Service Subcategory'],
  [searchFilterKeyValueMapping.get('SUBTYPES')!, 'Record Subtype'],
  [searchFilterKeyValueMapping.get('VLNRBID')!, 'Record ID'],
  [searchFilterKeyValueMapping.get('JRSDCTN')!, 'Medicaid UPIC Jurisdiction'],
  [searchFilterKeyValueMapping.get('PRRTY')!, 'Medicaid Priority'],
  [searchFilterKeyValueMapping.get('DATASRC')!, 'Medicaid Data Sources'],
  [searchFilterKeyValueMapping.get('STATECD')!, 'Medicaid State'],
  [searchFilterKeyValueMapping.get('MODELTYPE')!, 'Model Type'],
  [searchFilterKeyValueMapping.get('VLNRBTAG')!, 'Vulnerability Tag'],
  [searchFilterKeyValueMapping.get('MODELCNTRCTR')!, 'Modeling Contractor'],
  [searchFilterKeyValueMapping.get('ALERTTYPE')!, 'NPI Alert Type'],
]);
export const defaultSearchFieldValueMap: Map<string, string[]> = new Map([
  [
    'modelsmedicaidno',
    [
      'Record ID',
      'Name',
      'Record Type',
      'Status',
      'Vulnerability Record',
      'Asignee',
    ],
  ],
  [
    'modelsmedicaidyes',
    [
      'Record ID',
      'Record Type',
      'Record Subtype',
      'Vulnerability Tag',
      'Model Status',
      'Modeling Contractor',
      'Service Category',
      'Model Type',
      'Medicaid UPIC Jurisdiction',
      'Medicaid Priority',
      'Medicaid Data Sources',
      'Medicaid State',
    ],
  ],
  [
    'edits',
    ['Record ID', 'Record Type ', 'Record Subtype', 'Vulnerability Tag', 'Edit Status', 'Edit Contractor', 'Service Category', 'Service Subcategory'],
  ],
  [
    'cms',
    [
      'Vulnerability Tag',
      'Service Category',
      'Service Subcategory',
      'Model Type',
      'Primary Scheme',
      'Secondary Scheme',
      'Medicaid UPIC Jurisdiction',
      'Medicaid Priority',
      'Medicaid Data Sources',
      'Medicaid State',
    ],
  ],
]);
// search filters
export const defaultSearchFieldMap: Map<string, string[]> = new Map([
  [
    'modelsmedicaidno',
    ['vlnrbId', 'types', 'subTypes', 'vlnrbTag', 'modelStatuses', 'modelCntrctr', 'categories', 'subCategories', 'modelTypes', 'alertType'],
  ],
  [
    'modelsmedicaidyes',
    [
      'vlnrbId',
      'types',
      'subTypes',
      'vlnrbTag',
      'modelStatuses',
      'modelCntrctr',
      'categories',
      'modelTypes',
      'jrsdctn',
      'prrty',
      'dataSrc',
      'stateCd',
    ],
  ],
  ['edits', ['vlnrbId', 'types', 'subTypes', 'vlnrbTag', 'editStatuses', 'modelCntrctr', 'categories', 'subCategories', 'alertType']],
  ['cms', ['vlnrbTag', 'categories', 'subCategories', 'modelTypes', 'schemes', 'scndrySchms', 'jrsdctn', 'prrty', 'dataSrc', 'stateCd', 'alertType']],
]);

// Add new field list for any new workflows.
// for each list, have all field names as a key, also should be passed
//     to the showFormField(field) method
// if field should show for all statuses, it should map to ['ALL']
// if not, Add all the specific Statuses that it should show for in the list.
export const EDITS_FORM_FIELDS = [
  { propslType: ['ALL'] },
  { crntStus: ['ALL'] },
  { crntStusDate: ['ALL'] },
  { propslSubType: ['ALL'] },
  { crntStusDate: ['ALL'] },
  { propslName: ['ALL'] },
  { propslDesc: ['ALL'] },
  { vulnerabilityTags: ['ALL'] },
  { primaryScheme: ['ALL'] },
  { secondaryScheme: ['ALL'] },
  { editRulsNum: ['ALL'] },
  { hstryLookbackCmt: ['ALL'] },
  { editCode: ['ALL'] },
  { editCodeType: ['ALL'] },
  { editCodeDesc: ['ALL'] },
  { macNmJrsdctn: ['FUTURE'] },
  { submitterNotified: ['ALL'] },
  { dispositionSubmitted: ['FUTURE'] },
  { srvcCtgry: ['ALL'] },
  { srvcSubCtgry: ['ALL'] },
  { clmLvl: ['ALL'] },
  { svrtyLvl: ['ALL'] },
  { editRvwDecision: ['ALL'] },
  { msnSprsnInd: ['FUTURE'] },
  { improperPmtAmtInfoAttachedInd: ['ALL'] },
  { vulnerabilityWorkbook: ['ALL'] },
  { dataAnlysTimefrmFrom: ['ALL'] },
  { dataAnlysTimefrmThru: ['ALL'] },
  { changeRqstNumber: ['FUTURE'] },
  { inPocInd: ['FUTURE'] },
  { finalCrIssuanceInd: ['FUTURE'] },
  { clearanceInd: ['FUTURE'] },
  { releaseNumber: ['FUTURE'] },
  { rlseDt: ['FUTURE'] },
  { modelTypeDesc: ['FUTURE'] },
  { modelIntent: ['FUTURE'] },
  { modelOtpt: ['FUTURE'] },
  { ptntlLmtn: ['FUTURE'] },
  { modelIntent: ['FUTURE'] },
  // dispostion form
  { dispDecision: ['FUTURE'] },
  { dispReason: ['FUTURE'] },
  { dispOtherReason: ['FUTURE'] },
  { modelCntrctrAsgnedDt: ['FUTURE'] },
  { modelCntrctr: ['FUTURE'] },
  { fpsVlnrbMgmtPocs: ['FUTURE'] },
  // release form
  { fpsEditNum: ['ALL'] },
  { clearanceInd: ['ALL'] },
  { carcId: ['ALL'] },
  { rarcId: ['ALL'] },
  { releaseNumber: ['ALL'] },
  { rlseDt: ['ALL'] },
  { inPocInd: ['ALL'] },
  { caqhCore: ['ALL'] },
  { msn: ['ALL'] },
  { msnSprsnInd: ['ALL'] },
  { finalCrIssuanceInd: ['ALL'] },
  { changeRqstNumber: ['ALL'] },
];

export const searchFieldObject = {
  vlnrbId: '',
  vlnrbTag: [''],
  propslType: [''],
  propslSubType: [''],
  crntStus: [''],
  keywords: '',
  modelCntrctr: [''],
  srvcCtgry: [''],
  srvcSubCtgry: [''],
  prmrySchm: [''],
  scndrySchms: [''],
  modelType: [''],
  prrty: [''],
  jrsdctn: [''],
  dataSrc: [''],
  stateCd: [''],
};
export const searchTableColumnMap: any[] = [
  { name: 'recordIdFormatted', label: 'Record ID', hideable: false, index: 0 },

  ///adding for FPS-28848
  { name: 'assigneeNm', label: 'Assignee', hideable: false, index: -1 },
  { name: 'recordName', label: 'Name', hideable: false, index: -1 },
  { name: 'recordType', label: 'Record Type', hideable: false, index: -1 },
  { name: 'statusDesc', label: 'Status', hideable: false, index: -1 },
  { name: 'vulnTagList', label: 'Vulnerability Record', hideable: false, index: -1 },


  // { name: 'propslType', label: 'Record Type', hideable: false, index: 1 },
  // { name: 'propslSubType', label: 'Record Subtype', hideable: false, index: 2 },
  // { name: 'vlnrbTag', label: 'Vulnerability Tag', hideable: false, index: 3 },
  // { name: 'submittedBy', label: 'Submitted By', hideable: false, index: 4 },
  // {
  //   name: 'crntStusDate',
  //   label: 'Status Update Date',
  //   hideable: false,
  //   index: 5,
  // },
  // { name: 'crntStus', label: 'Status', hideable: false, index: 6 },
  // { name: 'srvcCtgry', label: 'Service Category', hideable: false, index: 7 },
  // {
  //   name: 'srvcSubctgry',
  //   label: 'Service Subcategory',
  //   hideable: false,
  //   index: 8,
  // },
  // { name: 'prmrySchm', label: 'Primary Scheme', hideable: false, index: 9 },
  // {
  //   name: 'scndrySchm',
  //   label: 'Secondary Scheme(s)',
  //   hideable: false,
  //   index: 10,
  // },
  // { name: 'modelType', label: 'Model Type', hideable: false, index: 11 },
  // {
  //   name: 'propslDesc',
  //   label: 'Proposal Description',
  //   hideable: false,
  //   index: 12,
  // },
  // {
  //   name: 'createDt',
  //   label: 'Record Created Date',
  //   hideable: false,
  //   index: 13,
  // },
  // {
  //   name: 'modelShrtName',
  //   label: 'Model Short Name',
  //   hideable: false,
  //   index: 14,
  // },
  // {
  //   name: 'modelLongName',
  //   label: 'Model Long Name',
  //   hideable: false,
  //   index: 15,
  // },
  // { name: 'stateCd', label: 'Medicaid State', hideable: true, index: 16 },

];
export interface SearchTableElement {
  vulnTagList: string;
  statusDesc: string;
  statusCd: string;
  recordTypeCd: string;
  recordType: string;
  recordPrefix: string;
  recordId: string;
  recordName: string;
  assigneeNm: string;
  recordIdFormatted: string;
  ownerNm: string;
}

export const sourceList: string[] = ['T-MSIS', 'Medi-Medi Matched Data', 'State Data', 'Medicare', 'Other (specify)'];
export const stateList: string[] = [
  'Alabama',
  'Alaska',
  'American Samoa',
  'Arizona',
  'Arkansas',
  'California',
  'Colorado',
  'Connecticut',
  'Delaware',
  'District of Columbia',
  'Federated States of Micronesia',
  'Florida',
  'Georgia',
  'Guam',
  'Hawaii',
  'Idaho',
  'Illinois',
  'Indiana',
  'Iowa',
  'Kansas',
  'Kentucky',
  'Louisiana',
  'Maine',
  'Marshall Islands',
  'Maryland',
  'Massachusetts',
  'Michigan',
  'Minnesota',
  'Mississippi',
  'Missouri',
  'Montana',
  'Nebraska',
  'Nevada',
  'New Hampshire',
  'New Jersey',
  'New Mexico',
  'New York',
  'North Carolina',
  'North Dakota',
  'Northern Mariana Islands',
  'Ohio',
  'Oklahoma',
  'Oregon',
  'Palau',
  'Pennsylvania',
  'Puerto Rico',
  'Rhode Island',
  'South Carolina',
  'South Dakota',
  'Tennessee',
  'Texas',
  'Utah',
  'Vermont',
  'Virgin Island',
  'Virginia',
  'Washington',
  'West Virginia',
  'Wisconsin',
  'Wyoming',
];

export const languageList: string[] = ['R', 'Python'];

// METADATA - IN ORDER, MUST BE IN WORKFLOW CHRONOLOGICAL ORDER
export const metadataWorkflowStatusList = [
  'In Development',
  'Ready for DMA Approval for Handoff',
  'In QC',
  'Ready for MTE',
  'System and Mirror Testing',
  'Ready for PROD',
  'In Production',
];

// EDITS - IN ORDER, MUST BE IN WORKFLOW CHRONOLOGICAL ORDER
export const workflowStatusList = [
  'Open',
  'Submitted to Triage',
  'Additional Analysis',
  'Policy Review',
  'Moving Forward',
  'Not Moving Forward',
  'On Hold',
  'Assigned to Release',
  'Deployed to Production',
  'Withdrawn',
  'Reopen',
];

export const dispositionCrntStatusList = ['Additional Analysis', 'Policy Review', 'Moving Forward', 'Not Moving Forward', 'On Hold'];

export const GENERAL_WORKFLOW_STATUS_MAPPING: any = {
  Open: ['Open', 'Withdrawn'],
  'Submitted to Triage': ['Submitted to Triage', 'Withdrawn'],
  'Moving Forward': ['Moving Forward', 'Assigned to Release'],
  'Not Moving Forward': ['Not Moving Forward'],
  'On Hold': ['On Hold', 'Submitted to Triage'],
  'Additional Analysis': ['Additional Analysis', 'Submitted to Triage'],
  'Policy Review': ['Policy Review', 'Submitted to Triage'],
  'Assigned to Release': ['Assigned to Release', 'Deployed to Production'],
  'Deployed to Production': ['Deployed to Production'],
  Withdrawn: ['Withdrawn'],
  Reopen: ['Reopen'],
};
export const EDT_MGR_WORKFLOW_STATUS_MAPPING: any = {
  Open: ['Open', 'Withdrawn'],
  'Submitted to Triage': ['Submitted to Triage', 'Withdrawn'],
  'Moving Forward': ['Moving Forward', 'Assigned to Release'],
  'Not Moving Forward': ['Not Moving Forward'],
  'On Hold': ['On Hold', 'Submitted to Triage'],
  'Additional Analysis': ['Additional Analysis', 'Submitted to Triage'],
  'Policy Review': ['Policy Review', 'Submitted to Triage'],
  'Assigned to Release': ['Assigned to Release', 'Deployed to Production'],
  'Deployed to Production': ['Deployed to Production', 'Reopen'],
  Withdrawn: ['Withdrawn'],
  Reopen: ['Reopen'],
};

export const EDITS_NEW_UPDATE_RQD_FLDS = [
  'propslDesc',
  'propslName',
  // 'vulnerabilityTags',
  'primaryScheme',
  'propslType',
  'crntStus',
  'propslSubType',
  'crntStusDate',
  'editRulsNum',
  'hstryLookbackCmt',
  'editCode',
  'editCodeType',
  'editCodeDesc',
  'srvcCtgry',
  'clmLvl',
  'editRvwDecision',
  'svrtyLvl',
  'rptgEntCorpName',
  'rptgEntPhneNum',
  'rptgEntUserId',
  'rptgEntLastName',
  'rptgEnt1stName',
  'rptgEntEmailAdr',
  'improperFormList',
  'vBookFormList',
  'listOfPolicies',
];

export const MEDICARE_ONLY_FIELDS = ['cadence', 'modelAlertStusAgeDays', 'npiAlertTypeCd', 'npiAlertTypeCdPtd'];
export const MEDICAID_ONLY_FIELDS = ['mdStates', 'mdUSPSState', 'alertType'];

export const METADATA_NEW_UPDATE_RQD_FLDS = [
  'supColLabel',
  'cstmTblDesc',
  'supColNum',
  'cstmTblShrtName',
  'cstmTblName',
  'modelCmsOwnrName',
  'ownrCntctEmailTxt',
  'modelCoefcntNum',
  'clmAtRskTypeCd',
  'npiAlertTypeCd',
  'npiAlertTypeCdPtd',
  'modelAlertStusAgeDays',
  'modelBusnsId',
  'modelId',
  'modelName',
  'clmAtRskCstCd',
  'clmTypeCd',
  'modelVrsnNum',
  'modelTypeCd',
  'rptCardTypeDesc',
  'updtFreqDesc',
  'cadence',
  // 'modelVNumber',
  // 'modelTypeCode',
  // 'reportCardType',
  'modelDesc',
  'configFld',
  'configFldVal',
  'splmtlVizTitle',
  'splmtlVizDesc',
  'modelWindowClmDtFld',
  'strtDtCalcLastDayInd',
  'strtDtCalcAdjMnths',
  'strtDtCalcAdjDays',
  'strtDtCalcTruncTypeCd',
  'endDtCalcLastDayInd',
  'endDtCalcAdjMnths',
  'endDtCalcAdjDays',
  'endDtCalcTruncTypeCd',
  'attrLabelName',
  'attrShrtLabelName',
  'subCategories',
  'mdScheme',
  'mdStates',
  'alertType',
  'clmSrcType',
  'cdType',
  'matchCond',
  'matchType',
  'substrStartPos',
  'substrCharsToMatch',
  'matchCdList',
  'pathToEduInd',
];

export const vulnerabilityTagList = [
  'ALL',
  'Ambulance',
  'Cardiology',
  'COVID',
  'DMEPOS',
  'Home Health',
  'Hospice',
  'IDTF',
  'Inpatient',
  'Laboratory',
  'Ophthalmology/Optometry',
  'Part D',
  'Podiatry',
  'Psychiatry/Psychology/Behavioral Health',
  'Radiology',
  'SNF',
  'Dental',
  'Family Planning',
  'Long Term Care',
  'Telehealth',
  'Chiropractic care',
  'Substance Abuse',
  'Adult Day Care',
  'Personal care services',
  'Non-emergent medical transportation',
  'Prescription',
  'Other',
];

export const GroupNumberMapping: any = {
  A: 'Annually',
  D: 'Daily',
  M: 'Monthly',
  W: 'Weekly',
  Q: 'Quarterly',
  S: 'Semi-Annually',
} as const;

export const primarySchemeList = [
  'Add-on Services',
  'Beneficiary Sharing',
  'Beneficiary Solicitation',
  'Bust Out/New Enroll/Spike',
  'Captive Audience',
  'Conflicting Billing',
  'Denied Claims',
  'Drug Diversion',
  'Duplicate Billing',
  'Excessive Services',
  'Excessive Supplies',
  'False Billing',
  'False Referral',
  'HCPCS Abuse',
  'Impossible Days/Times/Distance',
  'Length of Stay or Discharge Alive',
  'Misrepresentation of Services',
  'Modifier Abuse',
  'Multiple Schemes',
  'No Prior Qualifying Stay',
  'NPR w Ordering/Referring Physician',
  'Overprescribing',
  'Patient Harm',
  'Prescribing High Cost w/ Alternatives',
  'Provider Education',
  'Provider Relationships',
  'Questionable Medical Necessity',
  'Static Billing',
  'Telemarketing',
  'Unbundling Services',
  'Unit Abuse',
  'Unlikely Trips',
  'Upcoding',
];

export const serviceCategoryList = ['Professional Services (Part B)', 'Institutional (Part A)', 'DME', 'Other'];

export const serviceSubCategoryList = [
  'All',
  'Ambulance',
  'Anesthesiology and Pain Management',
  'Cardiology',
  'Dermatology',
  'EML Service/Patient Care',
  'IDTF',
  'Injections/Infusions',
  'Lab-COVID19',
  'Lab-DrugTest',
  'Lab-GeneticTest',
  'Lab-Other',
  'Miscellaneous procedures',
  'Neurology',
  'Ophthalmology/Optometry',
  'Opioid Treatment Program',
  'PT/OT/OMT/Chiropractic',
  'Podiatry',
  'Psychiatry/Psychology/Behavioral Health',
  'Radiology',
  'Skin Substitute',
  'Surgery',
  'Telehealth',
];

export const secondarySchemeList = [
  'Add-on Services',
  'Beneficiary Sharing',
  'Beneficiary Solicitation',
  'Bust Out/New Enroll/Spike',
  'Captive Audience',
  'Conflicting Billing',
  'Denied Claims',
  'Drug Diversion',
  'Duplicate Billing',
  'Excessive Services',
  'Excessive Supplies',
  'False Billing',
  'False Referral',
  'HCPCS Abuse',
  'Impossible Days/Times/Distance',
  'Length of Stay or Discharge Alive',
  'Misrepresentation of Services',
  'Modifier Abuse',
  'No Prior Qualifying Stay',
  'NPR w Ordering/Referring Physician',
  'Overprescribing',
  'Patient Harm',
  'Prescribing High Cost w/ Alternatives',
  'Provider Education',
  'Provider Relationships',
  'Questionable Medical Necessity',
  'Static Billing',
  'Telemarketing',
  'Unbundling Services',
  'Unit Abuse',
  'Unlikely Trips',
  'Upcoding',
];

export const macNameJurList = [
  'All MACs',
  'Cahaba Government Benefit Administrators, LLC J-J A, B',
  'CGS Administrators, LLC J-15 A, B, HHH',
  'CGS Administrators, LLC J-B DME',
  'CGS Administrators, LLC J-C DME',
  'First Coast Service Options, Inc. J-N A, B',
  'National Government Services, Inc. J-6 A, B, HHH',
  'National Government Services, Inc. J-K A, B, HHH',
  'Noridian Healthcare Solutions, LLC J-A DME',
  'Noridian Healthcare Solutions, LLC J-D DME',
  'Noridian Healthcare Solutions, LLC J-E A, B',
  'Noridian Healthcare Solutions, LLC J-F A, B',
  'Novitas Solutions, Inc. J-H A, B',
  'Novitas Solutions, Inc. J-L A, B',
  'Palmetto GBA J-J A, B',
  'Palmetto GBA J-M A, B, HHH',
  'Palmetto GBA RRB',
  'Wisconsin Physicians Service Insurance Corporation J-8 A, B',
];

export const extEntityList = [
  'CMS/CPI',
  'CMS/DMA',
  'CMS/Other',
  'Deloitte',
  'GDIT',
  'Law Enforcement',
  'MEDIC',
  'UPIC MW',
  'UPIC NE',
  'UPIC SE',
  'UPIC SW',
  'UPIC W',
  'UPIC/ZPIC',
  'Other',
];

export const dispositionDecisionList = ['Moving Forward', 'Not Moving Forward', 'On Hold', 'Additional Analysis', 'Policy Review'];

export const movingForwardList = ['N/A'];
export const notMovingForwardList = [
  'Consider as a model instead of an edit',
  'Data shows potential for recovery (RAC, UPIC)',
  'Not supported by MACS',
  'Not supported by other Stakeholder entity',
  'Not a nationwide problem (MAC specific problem)',
  'Another edit exits',
];

export const onHoldList = [
  'On Hold until Part D Data is available to FPS Edits',
  'On Hold until claim suspension is available to FPS Edits',
  'On Hold for other reasons',
  'On Hold - LCD',
];

export const testRoles: OptionValue[] = [
  { optionVal: 'MAC', displayVal: 'MAC', hideable: false },
  { optionVal: 'MEDIC', displayVal: 'MEDIC', hideable: false },
  { optionVal: 'Other', displayVal: 'Other', hideable: false },
];
export enum SlaEventType {
  SlaEvent = 'SLA_EVENT',
}
export enum UpicType {
  UPICMW = 'UPIC 1',
  UPICNE = 'UPIC 2',
  UPICW = 'UPIC 3',
  UPICSW = 'UPIC 4',
  UPICSE = 'UPIC 5',
}
export namespace UpicType {
  const reverseMap = new Map<string, UpicType>();
  Object.keys(UpicType).forEach((s: string) => {
    const e = (<any>UpicType)[s];
    reverseMap.set(e.toString(), e);
  });
  export function valueOf(str: string) {
    //-console.log('looking for ' + str + ' in ' + reverseMap);
    return reverseMap.get(str);
  }
  export function valueOfDisplay(str: string) {
    return reverseMap.get(str)?.replace('UPIC', 'UPIC ');
  }
}
export enum UpicMappingType {
  UPIC1 = UpicType.UPICMW,
  UPIC2 = UpicType.UPICNE,
  UPIC3 = UpicType.UPICW,
  UPIC4 = UpicType.UPICSW,
  UPIC5 = UpicType.UPICSE,
}

export class UpicMapping {
  static readonly UPICMW = new UpicMapping('UPIC MW', 'UPIC 1');
  static readonly UPICNE = new UpicMapping('UPIC NE', 'UPIC 2');
  static readonly UPICW = new UpicMapping('UPIC W', 'UPIC 3');
  static readonly UPICSW = new UpicMapping('UPIC SW', 'UPIC 4');
  static readonly UPICSE = new UpicMapping('UPIC SE', 'UPIC 5');
  static readonly UPICS = [this.UPICMW, this.UPICNE, this.UPICW, this.UPICSE, this.UPICSW];

  // private to disallow creating other instances of this type
  private constructor(private readonly cardinal: string, public readonly ordinal: any) { }
  static getUpicCardinal(ordinal: string) {
    return UpicMapping.UPICS.find((upic) => upic.ordinal === ordinal);
  }
  static getUpicOrdinal(cardinal: string) {
    return UpicMapping.UPICS.find((upic) => upic.cardinal === cardinal);
  }
  toString() {
    return this.cardinal;
  }
  toCardinal() {
    return this.cardinal;
  }
  toOrdinal() {
    return this.ordinal;
  }
}
export const allowedRoles: string[] = [
  allRoleTypes.SYS_MAINTAIN,
  allRoleTypes.DISM,
  allRoleTypes.DMA,
  allRoleTypes.MODEL_DEVELOPER,
  allRoleTypes.MODEL_MANAGER,
  allRoleTypes.MODEL_OPS,
];

export const notAllowedRoles: string[] = [allRoleTypes.EDITS_DEVELOPER, allRoleTypes.EDITS_MANAGER, allRoleTypes.EDIT_OPS, allRoleTypes.EML_FIG];



export const MStatusList: any = {
  INDEV: {
    displayVal: 'In Development',
    optionVal: 'INDEV',
  },
  INPRD: {
    displayVal: 'In Production',
    optionVal: 'INPRD',
  },
  INQC: {
    displayVal: 'In QC',
    optionVal: 'INQC',
  },
  READYDMA: {
    displayVal: 'Ready for DMA Approval for Handoff',
    optionVal: 'READYDMA',
  },
  READYIRR: {
    displayVal: 'Ready for IRR',
    optionVal: 'READYIRR',
  },
  READYMTE: {
    displayVal: 'Ready for MTE',
    optionVal: 'READYMTE',
  },
  READYPRD: {
    displayVal: 'Ready for Prod',
    optionVal: 'READYPRD',
  },
  INMTE: {
    displayVal: 'System and Mirror Testing',
    optionVal: 'INMTE',
  },
};

export enum ModelMetadataFilterType {
  INDEV = 'INDEV',
  REFINE = 'REFINE',
  VIEW = 'VIEW',
}

export enum ModelProgramType {
  MEDICAID = 'MEDICAID',
  MEDICARE = 'MEDICARE',
  MEDIMEDI = 'MEDIMEDI',
}

export const ClaimTypeCode = [
  'Institutional',
  'Professional',
  'DME',
  'Drug',
  'Dental',
  'Long-Term Care',
  'Lab',
  'Hospice',
  'Outpatient Hospital',
  'Professional, DME',
];

export const SubCategories = [
  'All',
  'Dental',
  'Drugs and Pharmacy',
  'Home Health/Waiver Services',
  'Hospice',
  'Inpatient Hospital',
  'Lab',
  'Long Term Care',
  'Non-Professional Services',
  'Opioids',
  'Outpatient Hospital',
  'Professional Services - Physician',
  'Psychiatry/Psychology/Behavioral Health',
];

export const AlertType = [
  'Admitting',
  'Dental',
  'Home Health',
  'Operating',
  'Hospice',
  'Prescribing',
  'Referring',
  'Dispensing',
  'Servicing',
  'Supervising',
];



export const VpStatusList: Record<string, string> = {
  '01': 'Open',
  '02': 'Submitted',
  '03': 'Approved',
  '04': 'On Hold',
  '05': 'Denied',
  '06': 'Withdrawn',
} as const;

export enum VpStatusCode {
  Open = "01",
  Submitted = "02",
  Approved = "03",
  Denied = "05",
  Withdrawn = "06"
}


export const DispDecisionList: any = {
  '05': { optionVal: '05', displayVal: 'Not Moving Forward' }
};

export const DispReasonList: any = {
  '1': { optionVal: '1', displayVal: 'Vulnerability Already Exists' },
  '2': { optionVal: '2', displayVal: 'Not Moving Forward for other reason' }
};


export const assetBundleList: any[] = [{ "optionVal": "Y", "displayVal": "True" }, { "optionVal": "N", "displayVal": "False" }]


export const globalFieldToRefMapping: Map<string, string> = new Map([
  ['alertType', 'alertTypes'],
  ['categories', 'categories'],
  ['categoryGrpRuns', 'categoryGrpRuns'],
  ['claimColumnTypes', 'claimColumnTypes'],
  ['mgmtStusCd', 'statuses'],
  ['modelActvtyStus', 'metdataActivityStatus'],
  ['cdType', 'modelCodes'],
  ['modelTypeCds', 'modelTypeCds'],
  ['modelTypeCd', 'modelTypes'],
  ['modelUpdtFreqs', 'modelUpdtFreqs'],
  ['npiAlertTypeCd', 'npiAlertTypes'],
  ['npiAlertTypeCdPtd', 'npiAlertTypesPtd'],
  ['modelRlsStus', 'releaseStatusList'],
  ['modelVrsnRls', 'releaseVersions'],
  ['schemes', 'schemes'],
  ['rptCardTypeDesc', 'reportCardTypes'],
  ['stusAgeDays', 'stusAgeDays'],
  ['subCategories', 'subCategories'],
  ['updtFreqDesc', 'updateFrequency'],
  ['windowDates', 'windowDates'],
  ['modelGrpRun', 'modelGrpRun'],
  ['wrkflwStusCd', 'wkflwStusCds'],
  ['likelihdCd', 'likelihdCds'],
  ['brdthCd', 'breadthTypeCds'],
  ['finclImpctCd', 'finclImpctCds'],
  ['ptntHarmCd', 'ptntHarmCds']
]);

export const vulnerabilityProposalLabelMapping: Map<string, string> = new Map([
  ['brdthCd', 'Breadth'],
  ['brdthExplntnTxt', 'Breadth Explanation'],
  ['finclImpctCd', 'Financial Impact'],
  ['finclImpctExplntnTxt', 'Financial Impact Explanation'],
  ['likelihdCd', 'Likelihood (Likelihood for the identified vulnerability)'],
  ['likelihdExplntnTxt', 'Likelihood Explanation'],
  ['ptntHarmCd', 'Patient Harm'],
  ['ptntHarmExplntnTxt', 'Patient Harm Explanation'],
  ['riskFctrTxt', 'Risk Factors'],
  ['vlnrbPropslDesc', 'Vulnerability Description'],
  ['vlnrbPropslNm', 'Vulnerability Name'],
  ['wrkflwStusCd', 'Workflow Status'],
]);

export const disReasonsByDisDecisions: { [key: string]: OptionValue[] } = {
  '26': [{ optionVal: 'N/A', displayVal: 'N/A', hideable: false }],
  '27': [
    { optionVal: '29', displayVal: 'Need More Information', hideable: false },
    { optionVal: '30', displayVal: 'On Hold for other reason ', hideable: false },
  ],
  '28': [
    { optionVal: '31', displayVal: 'Vulnerability Already Exists', hideable: false },
    { optionVal: '32', displayVal: 'Not Moving Forward for other reason', hideable: false },
  ],
};

export const disReasonsByDisDecisionsMapping: any[] = [
  { optionVal: 'N/A', displayVal: 'N/A', hideable: false },
  { optionVal: '29', displayVal: 'Need More Information', hideable: false },
  { optionVal: '30', displayVal: 'On Hold for other reason ', hideable: false },
  { optionVal: '31', displayVal: 'Vulnerability Already Exists', hideable: false },
  { optionVal: '32', displayVal: 'Not Moving Forward for other reason', hideable: false }
]

export const dispDecisionRef  = [
      { optionVal: '26', displayVal: 'Approved' },
      { optionVal: '27', displayVal: 'On Hold' },
      { optionVal: '28', displayVal: 'Not Moving Forward' }
    ];

export enum CannedSearchType {
  VR = <any>'myRecords',
  VP = <any>'myProposals'
}

export enum asrDetailLinkType {
  BILLSUMMARY = '',

  
};