import { Injectable } from '@angular/core';
import { NativeDateAdapter } from '@angular/material/core';

@Injectable()
export class CustomDateAdapter extends NativeDateAdapter {
  // Override the format method to customize the date format
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  override format(date: Date, displayFormat: Object): string {
    const year = date.getFullYear();
    const month = this._twoDigit(date.getMonth() + 1);
    const day = this._twoDigit(date.getDate());
    return `${year}-${month}-${day}`;
  }

  // Override the parse method to handle the custom format
  override parse(value: string): Date | null {
    const parts = value.split('-');
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const day = parseInt(parts[2], 10);
    return new Date(year, month, day);
  }

  private _twoDigit(n: number): string {
    return ('00' + n).slice(-2);
  }
}
