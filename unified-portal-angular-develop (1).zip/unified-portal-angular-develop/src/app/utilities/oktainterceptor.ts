import { Injectable, Inject } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
} from '@angular/common/http';

import { Observable } from 'rxjs';
import { OktaService } from '../services/okta';
import { environment } from '../environments/environment.shared';
        const slaLoggingEnabled:boolean = environment.extended.slaLoggingEnabled;

@Injectable()
export class OktaInterceptor implements HttpInterceptor {
  constructor( private oktaService: OktaService) {}

  private usernm!:string;
  private slaLoggingEnabled:boolean = environment.extended.slaLoggingEnabled;

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (slaLoggingEnabled && req.url.includes(environment.extended.splunkUrl)) {
     
      return next.handle(req);
    }
    req = req.clone({
      headers: req.headers
        .set('Authorization', 'Bearer '+this.oktaService.oktaAuth.getAccessToken())
        .set('x-fps-user', ''+'none')

    });


    return next.handle(req);
  }
  async getValue():Promise<string>{
    const user = (await  this.oktaService.oktaAuth.token.getUserInfo()).preferred_username;
    this.usernm = user!;
    return user!;
  }
  
}
