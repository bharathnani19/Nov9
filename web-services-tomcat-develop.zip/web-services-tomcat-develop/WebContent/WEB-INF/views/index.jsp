<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<head>
<script src="<c:url value="/resources/js/jquery-1.11.2.js"/>"></script>
<script>
var asrdetailviewRequest = '{"parameters":{"asr":["123456", "234567"], "displayformat":"json"},"transactionID":"12345","requestType":"Data","requestSubType":"ASRView","systemName":"UCM"}';
//var asrdetailviewrptcardRequest = '{"parameters":{"asr":["123456", "234567"], "model":null, "rptCardSqncNum":null ,"displayformat":"json"},"transactionID":"12345","requestType":"Data","requestSubType":"ASRView","systemName":"UCM"}';
//var asrdetailviewrptcardclaimsRequest = '{"parameters":{"asr":["123456", "234567"], "model":null, "rptCardSqncNum":null ,"displayformat":"json"},"transactionID":"12345","requestType":"Data","requestSubType":"ASRView","systemName":"UCM"}';
var asrdiscoveryRequest = '{"parameters":{"startTime":null,"endTime":null,"ruling":[],"workloadStatus":null},"systemName":"FPS","transactionID":"12345","requestType":"Data","requestSubType":"ASRSummary"}';
var asrsearchRequest ='{"startTime":null,"endTime":null,"ruling":null,"workloadStatus":null,"asrptIds":null,"customClaimLineLevel":null,"customClaimLineLevelParam":null,"presetSearchFlag":null,"asrptId":null,"subjectJurisdiction":null,"assignedZone":null,"prvdrName":null,"createdMinDt":null,"createdMaxDt":null,"costSortDir":null,"barrierToActionInd":null,"models":null,"alerts":null,"loggedInUserId":null,"leadInvestigationInd":null,"riskScoreHigh":null,"riskScoreLow":null,"rulings":null,"actions":null,"activities":null,"states":null,"sysTags":null,"alertStatus":null,"barriers":null,"assigned":null,"partDInd":null,"claimTypes":null,"prioritized":null,"jurisdictions":null,"modelPriority":null,"priorityScoreHigh":null,"priorityScoreLow":null,"cityStates":null,"zrTypes":null,"edits":null,"ucmAsrId":null,"ucmCaseId":null,"enrollmentId":null,"revokedInd":null,"fps2Only":false}';
var asrsearchldgRequest ='{"presetSearchFlag":null, "loggedInUserId":null}';
var ucmcasediscoveryRequest ='{"parameters":{"asr":["123455","23445"],"npi":["0000000000","1111111111"]},"transactionID":"12345","requestType":"Data","requestSubType":"UCMCases","systemName":"FPS"}';
var FpsTestServiceRequest ='{"parameters":{"asr":["123455","23445"],"npi":["0000000000","1111111111"]},"transactionID":"12345","requestType":"Data","requestSubType":"UCMCases","systemName":"FPS"}';
var landingpageoutageRequest = '{"message":null,"id":0,"loggedInUserId":null,"jurisdiction":null,"endDate":null,"startDate":null,"zonesAffected":null,"title":null}';
var landingpagemessageRequest = '{"message":null,"id":0,"loggedInUserId":null,"dateAdded":null}';
var ldapRequest = '{"attributes":null,"filter":"(uid=UCM)","baseDn":"dc=cms,dc=hhs,dc=gov","url":"ldap://ustlvcmsp2322.prod:1389","username":"uid=UCM,ou=system accounts,dc=cms,dc=hhs,dc=gov","password":"Testing123"}';
var asrinvestigationRequest = '{"asrptId":0,"bpmProcNum":null,"taskId":null,"userId":null,"assignedUserId":null,"userRole":null}';
var landingpagemodelRequest = '{"modelDesc":null,"modelId":null,"ownerName":null,"ownerEmail":null,"ownerPhone":null,"activeStatus":null,}';
var servicesubscribeRequest = '{"transactionID":"123", "systemID":"FPS","action": "SUBSCRIBE","type": "PROVIDER","searchID": null,"returnURL": "http://some.url","event": "PRIORITY_PROVIDER"}'
var asrpriorityRequest = '{"asrId":"123, "userId":null,"zone": "ZPIC 1", "comments": "comments"}'
var investigationRequest = '{"investId":null,"userId":null,"userZone":null,"comments":null}';
var serviceretrieveRequest = '{"transactionID":null,"type":null,"producerId":null,"producerUniqueID":null}';
var servicenotifyRequest = '{"transactionID":null,"systemID":null,"type":null,"publisherUniqueID":null,"event":null,"retrieveURL":null}';
var servicecasebulkRequest = '{"transactionID":"123","systemID":"UCM","type":"CASE","publisherUniqueID":[""],"event":"CASE_UPDATE","retrieveURL":"http://x.x.x.x/:9082/ucm-dtz-ws2/rest/fps/retrieve"}';
var asrsearchexportRequest ='{"startTime":null,"endTime":null,"ruling":null,"workloadStatus":null,"asrptIds":null,"customClaimLineLevel":null,"customClaimLineLevelParam":null,"presetSearchFlag":null,"asrptId":null,"subjectJurisdiction":null,"assignedZone":null,"assignedToUserId":null,"prvdrName":null,"createdMinDt":null,"createdMaxDt":null,"costSortDir":null,"barrierToActionInd":null,"models":null,"alerts":null,"loggedInUserId":null,"leadInvestigationInd":null,"riskScoreHigh":null,"riskScoreLow":null,"legacyScoreHigh":null,"legacyScoreLow":null,"assignedToFName":null,"assignedToLName":null,"actions":null,"activities":null,"states":null,"sysTags":null,"alertStatus":null,"assigned":null, "partD": null, "claimTypes":null}';
var asrsearchexport2Request ='{"startTime":null,"endTime":null,"ruling":null,"workloadStatus":null,"asrptIds":null,"customClaimLineLevel":null,"customClaimLineLevelParam":null,"presetSearchFlag":null,"asrptId":null,"subjectJurisdiction":null,"assignedZone":null,"assignedToUserId":null,"prvdrName":null,"createdMinDt":null,"createdMaxDt":null,"costSortDir":null,"barrierToActionInd":null,"models":null,"alerts":null,"loggedInUserId":null,"leadInvestigationInd":null,"riskScoreHigh":null,"riskScoreLow":null,"legacyScoreHigh":null,"legacyScoreLow":null,"assignedToFName":null,"assignedToLName":null,"actions":null,"activities":null,"states":null,"sysTags":null,"alertStatus":null,"assigned":null, "partD": null, "claimTypes":null}';
var umemailRequest = '{"curAprCorInd":null,"updAprCorInd":null,"curAprDmaInd":null,"updAprDmaInd":null,"request":null,"role":null}';
var asrclaimsexportRequest = '{"fromDt":null,"hicns":null,"toDt":null,"claimTypes":null,"asrptId":null,"npi":null,"latest":null}';
var umtestemailRequest = '{"from":null,"to":null,"subject":null,"body":null,"template":null,"type":null,"entity":null}';
var preferencesRequest = '{"userId":null, "prefName":null, "prefJson":null}';
var umrequestRequest = '{"prtlAcsRqstId":null,"rqstrCmsUserId":null,"prtlAcsRqstTypeCd":null,"envrmtTypeCd":null,"rqstr1stName":null,"rqstrMdlName":null,"rqstrLastName":null,"rqstrEmailAdr":null,"rqstrPhneNum":null,"rqstrLctnTxt":null,"rqstrCntrctrCd":null,"rqstrOrgName":null,"rqstrCotrName":null,"cotrEmailAdr":null,"cotrPhneNum":null,"rqstrAcsJstfctnTxt":null,"aprvdInd":"P","aprvdTs":null,"aprvrSgntrTxt":null,"rqstCmtTxt":null,"audtUpdtId":null,"audtUpdtTs":null,"rqstPrivFpsAsrInd":"N","rqstPrivVmCreateInd":"N","rqstPrivVmReadInd":"N","rqstPrivVmUpdateeditInd":"N","rqstPrivVmAdminInd":"N","rqstPrivPrtRead":"N","rqstPrivPrtWriteInd":"N","rqstPrivPrtAdminInd":"N","rqstPrivMasterApproverInd":"N","apprvdPrivFpsAsrInd":null,"apprvdPrivVmCreateInd":null,"apprvdPrivVmReadInd":null,"apprvdPrivVmUpdateeditInd":null,"apprvdPrivVmAdminInd":null,"apprvdPrivPrtRead":null,"apprvdPrivPrtWriteInd":null,"apprvdPrivPrtAdminInd":null,"apprvdPrivMasterApproverInd":null,"apprvdPrivInqOnlyApproverInd":null,"apprvdPrivPrtReadInd":null,"rqstPrivInquiryOnlyApproverInd":null,"apprvdPrivInquiryOnlyApproverInd":null,"apprvdDmaInd":"P","apprvdDmaTs":null,"apprvdDmaCmt":null,"apprvdCorTs":null,"apprvdCorInd":null,"status":null,"aprvrUserId":"P","apprvdDmaUserId":null,"apprvdCorEmailAdr":null,"apprvdCor1stName":null,"apprvdCorLastName":null,"apprvdDmaEmailAdr":null,"apprvdDma1stName":null,"apprvdDmaLastName":null,"audtInsrtTs":null,"requestDt":null}';
var vmsearchRequest = '{"propslType":null,"crntStus":null,"propslName":null,"vlnrbId":null,"propslSubType":null,"rptgEntUserId":null,"rptgEntCorpName":null,"rptgEnt1stName":null,"rptgEntLastName":null,"modelCntrctr":null,"dmaOwnerName":null,"rptgEntName":null}';
var vmRequest = '{"loggedInUserId":"thoffman","vlnrbId":null,"wkflowId":null,"propslType":null,"propslSubType":null,"crntStus":null,"crntStusDate":null,"propslName":null,"propslDesc":null,"rptgEntUserId":null,"rptgEntCorpName":null,"rptgEnt1stName":null,"rptgEntEmailAdr":null,"rptgEntPhneNum":null,"rptgEntLastName":null,"extrnl1stName":null,"extrnlLastName":null,"extrnlEmailAdr":null,"extrnlPhneNum":null,"extrnlSrcOrg":null,"srvcCtgry":null,"srvcSubCtgry":null,"label":null,"modelCntrctr":null,"modelCntrctrAsgnedDt":null,"govtId":null,"modelShrtName":null,"modelType":null,"clmTypeCd":null,"asrTypeCd":null,"srvcArea":null,"modelVrsn":null,"hstryLookbackCmt":null,"editRvwDecision":null,"fpsEditNum":null,"editRulsNum":null,"clmLvl":null,"msnSprsnInd":null,"prvdrTypeCd":null,"prvdrSubType":null,"stateCd":null,"svrtyLvl":null,"dataAnlysTimefrm":null,"modelTypeDesc":null,"modelIntent":null,"modelOtpt":null,"ptntlLmtn":null,"audtInsrtId":null,"loggedInUserId":null,"audtInsrtTs":null,"audtUpdtId":null,"extrnlSrcInd":null,"priority":null,"releaseNumber":null,"changeRqstNumber":null,"vmVrsnInd":null,"dataAnlysTimefrmFrom":null,"dataAnlysTimefrmThru":null,"rlseDt":null,"audtUpdtTs":null,"actvInd":null,"modelEnhancedShrtName":null,"collabMtgDt":null,"workshopMtgDt":null,"dispDecision":null,"dispReason":null,"dispOtherReason":null,"dispFormSubmnInd":null,"submtrNotifiedInd":null,"modelSpecFinalizedInd":null,"editCodeType":null,"editCode":null,"editCodeDesc":null,"macNmJrsdctn":null,"carcId":null,"rarcId":null,"msn":null,"caqhCore":null,"improperPmtAmtInfoAttachedInd":null,"inPocInd":null,"clearanceInd":null,"finalCrIssuanceInd":null,"fpsVlnrbMacJrsdctns":null,"fpsVlnrbMgmtCmts":null,"fpsVlnrbMgmtPlcys":null}';
function doPost(){
  var serviceMethod = $("#service").val();
  var service = serviceMethod.split("|")[0];
  var method = serviceMethod.split("|")[1];
  var postData = $("#postdata").val();
  var host = $("#host").val();
  var asrptid = $("#asrptId").val();
  var userId = $("#userId").val();
  var modelId = $("#modelId").val();
  var userId = $("#userId").val();
  var toUserId = $("#toUserId").val();
  var userRole = $("#userRole").val();
  var userZone = $("#userZone").val();
  var investId = $("#investId").val();
  var userRole = $("#userRole").val();
  var prvdrNpi = $("#prvdrNpi").val();
  var superId = $("#superId").val();
  var beneSk = $("#beneSk").val();
  var tab = $("#tab").val();
  var param = $("#param").val();
  var attrSqncNum  = $("#attrSqncNum").val();
  var rptCardDt  = $("#rptCardDt").val();
  var startDt  = $("#startDt").val();
  var endDt  = $("#endDt").val();
  var prefName  = $("#prefName").val();
  var cat  = $("#cat").val();
  var subcat  = $("#subcat").val();
  var genericId  = $("#genericId").val();
  service = service.replace("\{asrptId\}", asrptid);
  service = service.replace("\{tab\}", tab);
  service = service.replace("\{prvdrNpi\}", prvdrNpi);
  service = service.replace("\{beneSk\}", beneSk);
  service = service.replace("\{userId\}", userId);
  service = service.replace("\{userRole\}", userRole);
  service = service.replace("\{userZone\}", userZone);
  service = service.replace("\{investId\}", investId);
  service = service.replace("\{modelId\}", modelId);
  service = service.replace("\{superId\}", superId);
  service = service.replace("\{toUserId\}", toUserId);
  service = service.replace("\{attrSqncNum\}", attrSqncNum);
  service = service.replace("\{rptCardDt\}", rptCardDt);
  service = service.replace("\{startDt\}", startDt);
  service = service.replace("\{endDt\}", endDt);
  service = service.replace("\{prefName\}", prefName);
  service = service.replace("\{cat\}", cat);
  service = service.replace("\{subcat\}", subcat);
  service = service.replace("\{genericId\}", genericId);
  
  if (param != ''){
	service+= "?userId="+param;
  }
	var isUpload = service.indexOf("file") > -1 && method == "POST";
	
  if (isUpload){
	  var form = document.forms[0];
    var formData = new FormData();
	formData.append("file", $("#file")[0].files[0]);
  	 $.ajax({
      url:host+service,
      type : 'POST',
      data : formData,
      cache : false,
      contentType : false,
      processData : false,enctype:"multipart/form-data",
  success: function(data, status){
				if (isFile){
					console.log("download");
					var data2 = $.parseJSON(JSON.stringify(data));
					var a = document.createElement('a');
					a.href = window.URL.createObjectURL(new Blob([data2]));
					a.download="file.csv";
					document.body.appendChild(a);
					a.click();
				}else{
					console.log("normal");
					var data2 = $.parseJSON(JSON.stringify(data));
					console.log(data2);
					if (status == "success"){
						// $("spri").val(JSON.stringify(data));
					}else{
						$("#responseData").val(status);
					}
				}
    		},
			error: function(xhr, status, error){
				console.log("error");
				console.log(error);
				$("#responseData").val(error);
				
			}
    });
  }else{
	 var isFile = false; //service.indexOf("asr/claims/") > -1;
	 
  
  	$.ajax({
    		url:host+service,
    		type:method,
    		data: method == "POST" || method == "PUT" ?  postData : "",
    		contentType:  service.indexOf("stats") > -1 ? "text/csv" : "application/json; charset=utf-8",
    		dataType:isFile?"text":"json",
    		success: function(data, status, xhr){
				if (isFile){
					console.log("download");
					var data2 = $.parseJSON(JSON.stringify(data));
					var a = document.createElement('a');
					a.href = window.URL.createObjectURL(new Blob([data2]));
					a.download="file.csv";
					document.body.appendChild(a);
					a.click();
				}else{
					console.log("normal" + xhr);
					var data2 = $.parseJSON(JSON.stringify(data));
					console.log(data2);
					if (status == "success"){
						$("#responseData").val(JSON.stringify(data));
					}else{
						$("#responseData").val(status);
					}
				}
    		},
			error: function(xhr, status, error){
				console.log("error");
				console.log(error);
				$("#responseData").val(error);
				
			}
	});
  
  }
}
function updateJson(){
	var service = $("#service").val().split("|")[0];
	service = service.replace(/\//g, "");
	if ($("#service").val().split("|")[1] == 'POST'){
		var req = eval(service + "Request");
		$("#postdata").val(req);
	}
}
$( document ).ready(function() {
    $('#host').val('http://'+window.location.host + '/fps/rest/');
	$.ajax({
    		url:$('#host').val()+"buildinfo",
    		type:"GET",
    		contentType:"application/json; charset=utf-8",
    		dataType:"json",
    		success: function(data, status){
    		 	var data2 = $.parseJSON(JSON.stringify(data));
    			console.log(data2);
    			if (status == "success"){
    				$("#buildinfo").data("metadata", data);
					$("#buildinfo span:first").text( $( "#buildinfo" ).data( "metadata" ).version );
    			}else{
    				$("#buildinfo").text(status);
    			}
    		},
			error: function(xhr, status, error){
	
				$("#buildinfo span:first").text("Error, check WAS logs");
				
			}
	});
});
</script>
</head>
<body>
<div id="buildinfo">Current build info: <span></span> </div><p/>
<form enctype="multipart/form-data">(turn off compatibility view for intranet sites)<br/>

Host/Base root:<input  type="text" size="40" id="host" value="http://ustlvcmsp2252.prod:9082/fps/rest/"/><br/>
Service:<select onchange="updateJson()" id="service"><option></option>
<option value="buildinfo|GET">buildinfo</option>
<option value="health|GET">health</option>
<!-- option value="asrdiscovery|POST">asrdiscovery</option -->
<option value="tracking/{tab}/{userId}|POST">tracking/{tab}/{userId}</option>
<option value="tracking/stats/summary|GET">tracking/stats/summary</option>
<option value="tracking/stats/summary/zone|GET">tracking/stats/summary/zone</option>
<option value="tracking/stats/full|GET">tracking/stats/full</option>
<option value="tracking/stats/full/zone|GET">tracking/stats/full/zone</option>
<option value="tracking/activity|GET">tracking/activity</option>
<option value="tracking/activity/zone|GET">tracking/activity/zone</option>
<option value="tracking/stats/summary/{startDt}|GET">tracking/stats/summary/{startDt}</option>
<option value="tracking/stats/summary/zone/{startDt}|GET">tracking/stats/summary/zone/{startDt}</option>
<option value="tracking/stats/full/{startDt}|GET">tracking/stats/full/{startDt}</option>
<option value="tracking/stats/full/zone/{startDt}|GET">tracking/stats/full/zone/{startDt}</option>
<option value="tracking/activity/{startDt}|GET">tracking/activity/{startDt}</option>
<option value="tracking/activity/zone/{startDt}|GET">tracking/activity/zone/{startDt}</option>
<option value="asr/{asrptId}/alert/{modelId}/benes|GET">asr/{asrptId}/alert/{modelId}/benes</option>
<option value="asr/{asrptId}/alert/{modelId}/benes/{superId}|GET">asr/{asrptId}/alert/{modelId}/benes/{superId}</option>
<option value="asr/rptcard/{modelId}/{prvdrNpi}|GET">asr/rptcard/{modelId}/{prvdrNpi}</option>
<option value="asr/rptcard/{modelId}/{prvdrNpi}/{rptCardDt}|GET">asr/rptcard/{modelId}/{prvdrNpi}/{rptCardDt}</option>
<option value="asr/rptcard/{modelId}/{prvdrNpi}/claims/{attrSqncNum}/csv|GET">asr/rptcard/{modelId}/{prvdrNpi}/claims/{attrSqncNum}/csv</option>
<option value="asr/custom/{modelId}/{prvdrNpi}|GET">asr/custom/{modelId}/{prvdrNpi}</option>
<option value="asr/search|POST">asr/search</option>
<option value="asr/searchldg|POST">asr/searchldg</option>
<option value="asr/searchexport|POST">asr/searchexport</option>
<option value="asr/searchexport2|GET">asr/searchexport2</option>
<option value="modeldoc/{modelId}|GET">modeldoc/{modelId}</option>
<!-- option value="asr/foia/{asrptId}|GET">asr/foia/{asrptId}</option -->
<option value="asr/search/{asrptId}|GET">asr/search/{asrptId}</option>
<option value="asr/detail/{asrptId}/{tab}|GET">asr/detail/{asrptId}/{tab}</option>
<option value="asr/detail/{asrptId}/MAPS/{superId}|GET">asr/detail/{asrptId}/MAPS/{superId}</option>
<option value="asr/detail/{asrptId}/{tab}/{startDt}/{endDt}|GET">asr/detail/{asrptId}/{tab}/{startDt}/{endDt}</option>
<option value="asr/{prvdrNpi}/alerts/{modelId}|GET">asr/{prvdrNpi}/alerts/{modelId}</option>
<option value="asrexport/{asrptId}|GET">asrexport/{asrptId}</option>
<option value="asr/totals/{userId}/{userZone}|GET">asr/totals/{userId}/{userZone}</option>
<option value="asr/claims/{modelId}/{prvdrNpi}|GET">asr/claims/{modelId}/{prvdrNpi}</option>
<option value="asr/claims/{genericId}/{asrptId}/csv|GET">asr/claims/{genericId}/{asrptId}/csv</option>
<option value="asr/claims/{modelId}/{prvdrNpi}/{rptCardDt}|GET">asr/claims/{modelId}/{prvdrNpi}/{rptCardDt}</option>
<option value="asr/claims/partd/{asrptId}|GET">asr/claims/partd/{asrptId}</option>
<option value="asr/claims/partd/{modelId}/{prvdrNpi}|GET">asr/claims/partd/{modelId}/{prvdrNpi}</option>
<option value="asr/claims/partd/{genericId}/{prvdrNpi}/csv|GET">asr/claims/partd/{genericId}/{asrptId}/csv</option>
<option value="asr/claims/partd/{modelId}/{asrptId}/{rptCardDt}|GET">asr/claims/partd/{modelId}/{prvdrNpi}/{rptCardDt}</option>
<option value="asr/claims/{asrptId}|GET">asr/claims/{asrptId}</option>
<option value="asr/claimsexport|POST">asr/claimsexport</option>
<option value="asr/hicns/{asrptId}|GET">asr/hicns/{asrptId}</option>
<option value="asr/viz/{prvdrNpi}/{modelId}|GET">asr/viz/{prvdrNpi}/{modelId}</option>
<option value="asr/viz/{prvdrNpi}/{modelId}/{modelRunDt}|GET">asr/viz/{prvdrNpi}/{modelId}/{modelRunDt}</option>
<option value="asr/hhaviz/{prvdrNpi}|GET">asr/hhaviz/{prvdrNpi}</option>
<option value="asr/hhavizexport/{prvdrNpi}|GET">asr/hhavizexport/{prvdrNpi}</option>
<option value="asr/hhaviz/{prvdrNpi}/{genericId}|GET">asr/hhaviz/{prvdrNpi}/{genericId}</option>
<option value="asr/vizexport/{prvdrNpi}/{modelId}|GET">asr/vizexport/{prvdrNpi}/{modelId}</option>
<option value="asr/vizexport/{prvdrNpi}/{modelId}/{rptCardDt}|GET">asr/vizexport/{prvdrNpi}/{modelId}/{rptCardDt}</option>
<option value="asr/investigation/{investId}|GET">asr/investigation/{investId}</option>

<option value="asrdetailview|POST">asrdetailview</option>
<option value="asrdetailview/{prvdrNpi}/rptcard/{modelId}|POST">asrdetailview/{prvdrNpi}/rptcard/{modelId}</option>
<option value="asrdetailview/{prvdrNpi}/rptcard/{modelId}/claims/{attrSqncNum}|POST">asrdetailview/{prvdrNpi}/rptcard/{modelId}/claims/{attrSqncNum}</option>
<option value="faq/cat/{cat}|GET">faq/cat/{cat}</option>
<option value="faq/subcat/{subcat}|GET">faq/subcat/{subcat}</option>
<option value="faq/cat/{cat}/subcat/{subcat}|GET">faq/cat/{cat}/subcat/{subcat}</option>
<option value="faq/{genericId}|GET">faq/{genericId}</option>
<option value="um/request/{genericId}|GET">um/request/{genericId}</option>
<option value="um/request/user/{userId}|GET">um/request/user/{userId}</option>
<option value="um/request|POST">um/request (POST)</option>
<option value="um/request|PUT">um/request (PUT)</option>
<option value="um/dashboard|GET">um/dashboard</option>
<option value="um/email|POST">um/email</option>
<option value="um/validate/{userId}|GET">um/validate/{userId}</option>
<option value="vm|POST">vm (POST)</option>
<option value="vm/comment/{userId}|POST">vm/comment/{userId} (POST)</option>
<option value="vm/search|POST">vm/search (POST)</option>
<option value="vm/{genericId}|GET">vm/{genericId} (GET)</option>
<option value="vm/{genericId}/history|GET">vm/{genericId}/history (GET)</option>
<option value="vm/summary|GET">vm/summary</option>
<option value="vm/mac|GET">vm/mac</option>
<option value="vm/poc|GET">vm/poc</option>
<option value="vm/{genericId}/file/{subcat}/{userId}|POST">vm/{genericId}/file/{subcat}/{userId} (POST)</option>
<option value="vm/file/{genericId}/{userId}|DELETE">vm/file/{genericId}/{userId} (DELETE)</option>
<option value="vm/file/{genericId}|GET">vm/file/{genericId}</option>
<option value="vm/{genericId}/files/{subcat}|GET">vm/{genericId}/files/{subcat}</option>
<option value="prt/{genericId}/files|GET">prt/{genericId}/files</option>
<option value="prt/{genericId}|GET">prt/{genericId} (GET)</option>
<option value="prt|POST">prt (POST)</option>
<option value="prt/{genericId}|PUT">prt/{genericId} (PUT)</option>
<option value="prt/summary|GET">prt/summary</option>
<option value="prt/refdata|GET">prt/refdata</option>
<option value="prt/refdata/admin|GET">prt/refdata/admin</option>
<option value="prt|POST">prt (POST)</option>
<option value="prt/{genericId}/file/{userId}|POST">prt/{genericId}/file/{userId} (POST)</option>
<option value="prt/file/{genericId}/{userId}|DELETE">prt/file/{genericId}/{userId} (DELETE)</option>
<option value="prt/file/{genericId}|GET">prt/file/{genericId}</option>
<option value="prt/refdata/issctgry|POST">prt/refdata/issctgry</option>
<option value="prt/refdata/dfct|POST">prt/refdata/dfct</option>
<option value="prt/refdata/clmcnt|POST">prt/refdata/clmcnt</option>
<option value="prt/refdata/prblmprrty|POST">prt/refdata/prblmprrty</option>
<option value="prt/refdata/mac|POST">prt/refdata/mac</option>
<option value="prt/refdata/status|POST">prt/refdata/status</option>
<option value="prt/refdata/afctdsys|POST">prt/refdata/afctdsys</option>
<option value="prt/refdata/poc|POST">prt/refdata/poc</option>
<option value="prt/refdata/edit|POST">prt/refdata/edit</option>

<option value="preferences|POST">preferences</option>
<option value="preferences/{userId}/{prefName}|GET">preferences/{userId}/{prefName}</option>
<option value="preferences/{userId}/{prefName}|DELETE">(delete) preferences/{userId}/{prefName}</option>
<option value="landingpage/{userId}/{userZone}|GET">landingpage/{userId}/{userZone}</option>
<option value="landingpage/reports/{userId}/{userZone}|GET">landingpage/reports/{userId}/{userZone}</option>
<option value="landingpage/messages/|GET">landingpage/messages</option>
<option value="landingpage/outage|POST">landingpage/outage</option>
<option value="landingpage/message|POST">landingpage/message</option>
<option value="landingpage/header/{userId}/{userZone}|GET">landingpage/header/{userId}/{userZone}</option>
<option value="landingpage/messages/view/{userId}|GET">landingpage/messages/view/{userId}</option>
<option value="landingpage/model|POST">landingpage/model</option>
<!-- 
<option value="asr/investigation|POST">asr/investigation</option>

<option value="asr/investigation/{investId}/{userId}|POST">asr/investigation/{investId}/{userId}</option>
<option value="investigation/{investId}/{userId}/{userZone}|DELETE">investigation/{investId}/{userId}/{userZone}</option>
<option value="investigation/{investId}/{userId}|DELETE">investigation/{investId}/{userId}</option>
<option value="investigation|POST">investigation</option>
-->
<option value="asr/{asrptId}/{userId}|POST">asr/{asrptId}/{userId}</option>
<option value="asr/priority|POST">asr/priority</option>
<!--
<option value="asr/{asrptId}/{superId}/{userId}|POST">(assign) asr/{asrptId}/{superId}/{userId}</option>
<option value="asr/{asrptId}/{superId}/{userId}/{toUserId}|POST">asr/{asrptId}/{superId}/{userId}/{toUserId}</option>
<option value="asr/{asrptId}/{superId}/{userId}|PUT">(unassign) asr/{asrptId}/{superId}/{userId}</option>
-->
<option value="refdata|GET">refdata</option>
<option value="refdata/{tab}|GET">refdata/{tab}</option>
<option value="users|GET">users</option>
<option value="user/{userId}|GET">user/{userId}</option>
<option value="users/{userZone}|GET">users/{userZone}</option>
<option value="ldap|POST">ldap</option>
<option value="cache|GET">cache</option>
<option value="error|GET">error-GET</option>
<option value="error|POST">error-POST</option>
<option value="service/subscribe|POST">service/subscribe</option>
<option value="service/notify|POST">service/notify</option>
<option value="service/case/bulk|POST">service/case/bulk</option>
<option value="service/retrieve|POST">service/retrieve</option>
<option value="service/test|POST">service/test</option>
<option value="service/testsendnotification|POST">service/testsendnotification</option>
<option value="test/fas/file|POST">test/fas/file</option>

<!--
<option value="hive/test|GET">hive/test</option>
<option value="solr/test|GET">solr/test</option>
<option value="solr/test2|GET">solr/test2</option> -->

</select><br/>
asrptId: <input type="text" id="asrptId" /><br/>
beneSk: <input type="text" id="beneSk" /><br/>
investId: <input type="text" id="investId" /><br/>
modelId: <input type="text" id="modelId" /><br/>
attrSqncNum: <input type="text" id="attrSqncNum" /><br/>
prvdrNpi: <input type="text" id="prvdrNpi" /><br/>
tab: <input type="text" id="tab" /><br/>
userId: <input type="text" id="userId" /><br/>
toUserId: <input type="text" id="toUserId" /><br/>
superId: <input type="text" id="superId" /><br/>
userRole: <input type="text" id="userRole" /><br/>
userZone: <input type="text" id="userZone" /><br/>
userId param: <input type="text" id="param" /><br/>
rptCardDt: <input type="text" id="rptCardDt" /><br/>
startDT: <input type="text" id="startDt" /><br/>
endDt: <input type="text" id="endDt" /><br/>
genericId: <input type="text" id="genericId" /><br/>
file: <input type="file" id="file" /><br/>
prefName: <input type="text" id="prefName" /><br/>
cat: <input type="text" id="cat" /><br/>
subcat: <input type="text" id="subcat" /><br/>
Request data: <textarea id="postdata" rows="10" cols="50">{}</textarea><br/>
Response: <textarea id="responseData" rows="10" cols="50"></textarea><br/>
<input type="button" onclick="doPost()" value="Submit"/>
</form>

</body>
</html>