package gov.hhs.cms.fps.config;

import java.util.List;

import org.hibernate.transform.ResultTransformer;

public class AsrClaimResultTransformer implements ResultTransformer {

	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List transformList(List collection) {
		// TODO Auto-generated method stub
		return null;
	}

}
