package gov.hhs.cms.fps.config;

import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.hibernate.engine.transaction.jta.platform.internal.AbstractJtaPlatform;
import org.springframework.transaction.jta.JtaTransactionManager;

public class AtomikosJtaPlatform extends AbstractJtaPlatform {

	private static final long serialVersionUID = 1L;

	static TransactionManager transactionManager;
	static UserTransaction transaction;

	@Override
	protected TransactionManager locateTransactionManager() {
		return transactionManager;
	}

	@Override
	protected UserTransaction locateUserTransaction() {
		return transaction;
	}

	public void setJtaTransactionManager(JtaTransactionManager jtaTransactionManager) {
		transactionManager = jtaTransactionManager.getTransactionManager();
		transaction = jtaTransactionManager.getUserTransaction();
	}
    public void setTransactionManager(TransactionManager txManager) {
    	transactionManager = txManager;
    }


    public void setUserTransaction(UserTransaction userTransaction) {
    	transaction = userTransaction;
    }

}