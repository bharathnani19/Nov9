package gov.hhs.cms.fps.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

//@Configuration
//@EnableTransactionManagement(proxyTargetClass = true)
//@PropertySource(value = { "classpath:application.properties" })
public class HivePersistenceConfig {
//	@Bean
	public DataSource hiveDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.apache.hive.jdbc.HiveDriver");
		dataSource.setUrl(
				"jdbc:hive2://ustsmascmsp844.prod:2181,ustsmascmsp843.prod:2181,ustsmascmsp842.prod:2181/z_solr_poc;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2-hive2");
		dataSource.setUsername("xxx");
		dataSource.setPassword("xxx");

		return dataSource;
	}

//	@Bean(name = "hiveJbcTemplate")
	public JdbcTemplate hiveJbcTemplate(@Qualifier("hiveDataSource") DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}
}
