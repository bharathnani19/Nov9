package gov.hhs.cms.fps.config;

//@Configuration
//@EnableKafka
public class KafkaProducerConfig {
//	@Autowired
//	private Environment env;
//	@Value("${kafka.bootstrap}")
//	private String bootstrapAddress;
//	@Value("${kafka.groupId}")
//	private String groupId;
//	@Value("${kafka.topic.email}")
//	private String emailTopic;
//	private static final Logger logger = Logger.getLogger(KafkaProducerConfig.class.getName());
//    @Bean
//    public ProducerFactory<String, FpsEmail> producerFactory() {
//        Map<String, Object> configProps = new HashMap<>();
//        configProps.put(
//          ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, 
//          bootstrapAddress);
//        configProps.put(
//          ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, 
//          StringSerializer.class);
//        configProps.put(
//          ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, 
//          JsonSerializer.class);
//        return new DefaultKafkaProducerFactory<>(configProps);
//    }
// 
//    @Bean
//    public KafkaTemplate<String, FpsEmail> kafkaTemplate() {
//    	logger.info("default topic  "+ emailTopic);
//    	KafkaTemplate<String, FpsEmail> kafkaTemplate = new KafkaTemplate<>(producerFactory());
//    	kafkaTemplate.setDefaultTopic(emailTopic);
//        return kafkaTemplate;
//    }
//
//	public Environment getEnv() {
//		return env;
//	}
//
//	public void setEnv(Environment env) {
//		this.env = env;
//	}
}
