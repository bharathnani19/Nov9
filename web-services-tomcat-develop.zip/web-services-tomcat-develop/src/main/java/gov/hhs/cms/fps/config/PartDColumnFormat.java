package gov.hhs.cms.fps.config;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import gov.hhs.cms.fps.util.FpsEnums;
import gov.hhs.cms.fps.util.FpsEnums.PartDEnum;
import gov.hhs.cms.fps.util.FpsEnums.PartDFormat;

@Target({METHOD, FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface PartDColumnFormat {
	
	 FpsEnums.PartDFormat format() default PartDFormat.STR;
}
