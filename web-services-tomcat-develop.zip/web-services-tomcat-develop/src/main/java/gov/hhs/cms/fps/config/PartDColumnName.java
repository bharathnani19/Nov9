package gov.hhs.cms.fps.config;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import gov.hhs.cms.fps.util.FpsEnums;
import gov.hhs.cms.fps.util.FpsEnums.PartDEnum;

@Target({METHOD, FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface PartDColumnName {
	 String name() default "";
	 FpsEnums.PartDEnum[] includes() default {PartDEnum.ALL} ;
	 FpsEnums.PartDEnum[] excludes() default {PartDEnum.NONE} ;
	 FpsEnums.PartDFormat format() default FpsEnums.PartDFormat.STR;
}
