/*
 * 
 */
package gov.hhs.cms.fps.config;

import java.util.Properties;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.JtaTransactionManager;

import com.atomikos.icatch.jta.UserTransactionImp;
import com.atomikos.icatch.jta.UserTransactionManager;
import com.atomikos.jdbc.nonxa.AtomikosNonXADataSourceBean;

import gov.hhs.cms.fps.util.DB2WithURInterceptor;
import gov.hhs.cms.fps.util.FpsDB2Dialect;
import gov.hhs.cms.fps.util.FpsSnowflakeDialect;
import gov.hhs.cms.fps.util.JavaAssistHelper;
import gov.hhs.cms.fps.util.PostgreSQLFPSDialect;
import gov.hhs.cms.fps.util.SnowflakeInterceptor;
import javassist.util.proxy.ProxyFactory.ClassLoaderProvider;

// TODO: Auto-generated Javadoc
/**
 * The Class PersistenceConfig.
 */
@Configuration
@EnableTransactionManagement(proxyTargetClass = true)
//@EnableCaching
@PropertySource(value = { "classpath:application.properties" })

public class PersistenceConfig {

	@Autowired
	private Environment env;

	private static Logger logger = Logger.getLogger(PersistenceConfig.class.getName());

	@Bean
	public ClassLoaderProvider javaAssistClassLoader() {
		return JavaAssistHelper.createJavaAssistClassLoader();
	}

//    @Bean(initMethod = "init", destroyMethod = "shutdownForce")
//    public UserTransactionServiceImp atomikosUserTransactionService () {
//    	Properties props = new Properties();
//    	props.setProperty("com.atomikos.icatch.service",  "com.atomikos.icatch.standalone.UserTransactionServiceFactory");
////    	props.setProperty("com.atomikos.icatch.log_base_name",  "fpslog");
////    	props.setProperty("com.atomikos.icatch.output_dir",  "../logs");
////    	props.setProperty("com.atomikos.icatch.log_base_dir",  "../logs");
//    	UserTransactionServiceImp s = new UserTransactionServiceImp(props);
//    	return s;
//    }
	/**
	 * Session factory.
	 *
	 * @return the local session factory bean
	 */
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setHibernateProperties(getHibernateProperties());
		sessionFactory.setPackagesToScan("gov.hhs.cms.fps.model.generated");
//		sessionFactory.setEntityInterceptor(new DB2WithURInterceptor());
//		try {
//			sessionFactory.setJtaTransactionManager(transactionManager());
//		} catch (Throwable e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		sessionFactory.setNamingStrategy(new UppercaseNamingStrategy());
		return sessionFactory;
	}

	@Bean
	public LocalSessionFactoryBean snowflakeSessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(snowflakeDataSource());
		sessionFactory.setHibernateProperties(getSnowflakeHibernateProperties());
		sessionFactory.setPackagesToScan("gov.hhs.cms.fps.model.generated");
		sessionFactory.setEntityInterceptor(new SnowflakeInterceptor());
//		sessionFactory.setEntityInterceptor(new DB2WithURInterceptor());
//		sessionFactory.setNamingStrategy(new UppercaseNamingStrategy());
		return sessionFactory;
	}

	/**
	 * Transaction manager.
	 *
	 * @param sessionFactory the session factory
	 * @return the web sphere uow transaction manager
	 */
	@Bean
	@Autowired
//	@DependsOn(value="atomikosUserTransactionService")
	public JtaTransactionManager transactionManager() throws Throwable {
		JtaTransactionManager txManager = new JtaTransactionManager();
		txManager.setTransactionManager(atomikosTransactionManager());
		txManager.setDefaultTimeout(300);
		txManager.setUserTransaction(userTransaction());
//		txManager.setAllowCustomIsolationLevels(true);
//		txManager.setSessionFactory(sessionFactory);
//		txManager.setDataSource(dataSource());
		return txManager;
	}

	@Bean(name = "userTransaction")
	public UserTransactionImp userTransaction() throws Throwable {
		UserTransactionImp userTransactionImp = new UserTransactionImp();
		userTransactionImp.setTransactionTimeout(300);
//		userTransactionImp.setRollbackOnly();
		return userTransactionImp;
	}

//
	@Bean(name = "atomikosTransactionManager", initMethod = "init", destroyMethod = "close")
	public UserTransactionManager atomikosTransactionManager() throws Throwable {
		UserTransactionManager userTransactionManager = new UserTransactionManager();
		userTransactionManager.setForceShutdown(false);
		userTransactionManager.setStartupTransactionService(true);
		userTransactionManager.setTransactionTimeout(300);

//		AtomikosJtaPlatform.transactionManager = userTransactionManager;

		return userTransactionManager;
	}

	@Bean(name = "jtaPlatformAdapter")
	public AtomikosJtaPlatform jtaPlatformAdapter() {
		AtomikosJtaPlatform p = new AtomikosJtaPlatform();
		try {
			p.setJtaTransactionManager(transactionManager());
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
	}
//	@Bean()
//	@DependsOn(value = "jtaPlatformAdapter")
//	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
//		LocalContainerEntityManagerFactoryBean b = new LocalContainerEntityManagerFactoryBean();
//		
//		return b;
//	}

	/**
	 * Exception translation.
	 *
	 * @return the persistence exception translation post processor
	 */
	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}


	/**
	 * Data source.
	 *
	 * @return the data source
	 */
	// }
	@Bean
	public DataSource dataSource() {
		final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		String dataSourceNm = "jdbc/FPSDataSource";
		String propDataSourceNm = env.getProperty("datasource.jndi");
		if (propDataSourceNm != null) {
			dataSourceNm = propDataSourceNm;
		}
		DataSource  dataSource = (DataSource )dsLookup.getDataSource(dataSourceNm);
		
		return dataSource;
	}

	@Bean
	public DataSource snowflakeDataSource() {
		final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		String propDataSourceNm = env.getProperty("datasource.jndi.snowflake");
		if (propDataSourceNm != null) {

			DataSource dataSource = dsLookup.getDataSource(propDataSourceNm);
			return dataSource;
		} else { // when snowflake is enabled, this block won't be reached
			// but it it's here when snowflake is disabled to prevent WAS
			// startup errors.
			DataSource dataSource = dsLookup.getDataSource("jdbc/FPSDataSource");
			return dataSource;
		}
	}



	/**
	 * Gets the hibernate properties.
	 * 
	 * @return the hibernate properties
	 */
	private Properties getHibernateProperties() {
		Properties props = new Properties();
//		props.put("hibernate.dialect", FpsDB2Dialect.class.getName());
		props.put("hibernate.dialect", PostgreSQLFPSDialect.class.getName());
		props.put("hibernate.default_schema", "fps2");
		props.put("spring.jpa.properties.hibernate.default_schema", "fps2");
		props.put("spring.jpa.properties.hibernate.default_catalog", "fps2");

//		props.put("hibernate.generate_statistics", "true");
//		props.put("hibernate.order_inserts", true);
//		props.put("spring.jpa.properties.hibernate.jdbc.batch_size", "20");
		props.put("hibernate.current_session_context_class", "jta");
//		props.put("hibernate.transaction.manager_lookup_class", "com.atomikos.icatch.jta.hibernate4.TransactionManagerLookup");
		props.put("hibernate.transaction.factory_class",
				"org.hibernate.engine.transaction.internal.jta.CMTTransactionFactory");
		props.put("hibernate.transaction.jta.platform", "com.atomikos.icatch.jta.hibernate4.AtomikosPlatform");
		
//		props.put("spring.jta.atomikos.properties.default-jta-timeout", "60000");
		return props;
	}

	private Properties getSnowflakeHibernateProperties() {
		Properties props = new Properties();
		props.put("hibernate.dialect", FpsSnowflakeDialect.class.getName());
//		props.put("hibernate.dialect", DerbyDialect.class.getName());
		props.put("CLIENT_RESULT_COLUMN_CASE_INSENSITIVE", "true");
//		props.put("hibernate.use_sql_comments", true);
//		props.put("hibernate.show_sql", "true");
//		props.put("hibernate.ejb.naming_strategy", "gov.hhs.cms.fps.util.UppercaseNamingStrategy");
//		props.put("spring.jpa.hibernate.naming_strategy", "gov.hhs.cms.fps.util.UppercaseNamingStrategy");
//		props.put("spring.jpa.properties.hibernate.generate_statistics", "true");
//		props.put("hibernate.jdbc.batch_size", "20");
		props.put("hibernate.default_schema", "FPS_PORTAL");
//		props.put("hibernate.cache.use_query_cache", "false");
//		props.put("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.SingletonEhCacheRegionFactory");
//		props.put("hibernate.transaction.factory_class",
//				"org.hibernate.engine.transaction.internal.jta.CMTTransactionFactory");
//		props.put("org.hibernate.service.jta.platform.internal.TransactionManagerLookupBridge",
//				"org.hibernate.transaction.WebSphereExtendedJTATransactionLookup");
//		props.put("hibernate.transaction.jta.platform",
//				"org.hibernate.service.jta.platform.internal.WebSphereExtendedJtaPlatform");
		props.put("hibernate.current_session_context_class", "jta");
//		props.put("hibernate.transaction.manager_lookup_class", "com.atomikos.icatch.jta.hibernate3.TransactionManagerLookup");
//		props.put("hibernate.transaction.factory_class", "org.hibernate.transaction.JTATransactionFactory");
		props.put("hibernate.transaction.factory_class",
				"org.hibernate.engine.transaction.internal.jta.CMTTransactionFactory");
		props.put("hibernate.transaction.jta.platform", "com.atomikos.icatch.jta.hibernate4.AtomikosPlatform");
		return props;
	}

}
