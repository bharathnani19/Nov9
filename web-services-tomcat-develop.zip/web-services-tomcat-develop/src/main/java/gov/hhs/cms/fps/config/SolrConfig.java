package gov.hhs.cms.fps.config;

//import org.apache.solr.client.solrj.SolrClient;
//import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.springframework.beans.factory.annotation.Autowired;
//import org.apache.solr.client.solrj.SolrServer;
//import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.data.solr.repository.config.EnableSolrRepositories;
import org.springframework.core.env.Environment;

@Configuration
// @EnableSolrRepositories(
// basePackages = "gov.hhs.cms.fps.solr",multicoreSupport=true,
// namedQueriesLocation = "classpath:solr-named-queries.properties")
public class SolrConfig {
	@Autowired
	private Environment env;

	// @Bean
	// public SolrServer solrServer() {
	// return new HttpSolrServer(("http://ustsmascmsp841.prod:8983/solr"));
	// }

//	@Bean
//	public SolrClient solrClient() {
//		String solrUrl = env.getProperty("solr.url");
//		String solrZk = env.getProperty("solr.zk");
////		return new HttpSolrClient(solrUrl);
//		CloudSolrClient c = new CloudSolrClient(solrZk);
//		c.setZkClientTimeout(60000);
//		c.setZkConnectTimeout(60000);
//		return c;
//
//	}
}
