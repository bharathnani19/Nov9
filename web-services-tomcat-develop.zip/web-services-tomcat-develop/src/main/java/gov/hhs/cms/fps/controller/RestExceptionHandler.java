package gov.hhs.cms.fps.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.hibernate.exception.GenericJDBCException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.hibernate5.HibernateJdbcException;
import org.springframework.transaction.UnexpectedRollbackException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.RestClientException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.NestedServletException;

import gov.hhs.cms.fps.util.MicroserviceException;
import gov.hhs.cms.fps.util.MissingModelGuidianceDocException;
import jakarta.transaction.RollbackException;

@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {
	private static Logger logger = Logger.getLogger(RestExceptionHandler.class.getName());
	@ExceptionHandler({ UnexpectedRollbackException.class})
	protected ResponseEntity<Object> handleJtaError(UnexpectedRollbackException ex, HttpServletRequest hreq,
			WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		final String uri = hreq.getRequestURI();
		logger.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: " + uri, ExceptionUtils.getRootCause(ex));
		headers.setContentType(MediaType.APPLICATION_JSON);
		ex.printStackTrace(System.out);
		return new ResponseEntity<Object>("{\"statusMessage\":" + ExceptionUtils.getStackTrace(ex) + "}", headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler({ IOException.class})
	protected ResponseEntity<Object> handleConnectionError(IOException ex, HttpServletRequest hreq,
			WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		final String uri = hreq.getRequestURI();
		logger.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: " + uri, ex);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ex.printStackTrace(System.out);
		return new ResponseEntity<Object>("{\"statusMessage\":" + ExceptionUtils.getStackTrace(ex) + "}", headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ SQLException.class, NestedServletException.class, HibernateJdbcException.class,
			GenericJDBCException.class, DataIntegrityViolationException.class })
	protected ResponseEntity<Object> handleInvalidRequest(RuntimeException ex, HttpServletRequest hreq,
			WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		final String uri = hreq.getRequestURI();
		logger.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: " + uri, ex);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ex.printStackTrace(System.out);
		return new ResponseEntity<Object>("{\"statusMessage\":" + ExceptionUtils.getStackTrace(ex) + "}", headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ RuntimeException.class, NullPointerException.class })
	protected ResponseEntity<Object> handleRuntimeException(RuntimeException ex, HttpServletRequest hreq,
			WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		final String uri = hreq.getRequestURI();
		logger.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: " + uri, ex);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ex.printStackTrace(System.out);
		return new ResponseEntity<Object>("{\"statusMessage\":" + ExceptionUtils.getStackTrace(ex) + "}", headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ RestClientException.class })
	protected ResponseEntity<Object> handleRestClientException(RestClientException ex, HttpServletRequest hreq,
			WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		final String uri = hreq.getRequestURI();
		logger.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: " + uri, ex);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ex.printStackTrace(System.out);
		return new ResponseEntity<Object>("{\"statusMessage\":" + ExceptionUtils.getStackTrace(ex) + "}", headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ AbstractMethodError.class })
	protected ResponseEntity<Object> handleRestClientExceptionAME(AbstractMethodError ex, HttpServletRequest hreq,
			WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		final String uri = hreq.getRequestURI();
		logger.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: " + uri, ex);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ex.printStackTrace(System.out);
		return new ResponseEntity<Object>("{\"statusMessage\":" + ExceptionUtils.getStackTrace(ex) + "}", headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ RollbackException.class })
	protected ResponseEntity<Object> handleInvalidRequestRollback(RollbackException ex, HttpServletRequest hreq,
			WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		final String uri = hreq.getRequestURI();
		logger.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: " + uri, ex);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ex.printStackTrace(System.out);
		return new ResponseEntity<Object>("{\"statusMessage\":" + ExceptionUtils.getStackTrace(ex) + "}", headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ResponseBody
	@ExceptionHandler({ MissingModelGuidianceDocException.class })
	@ResponseStatus(HttpStatus.NOT_FOUND)
	protected String handleMissingModelGuidanceDoc(MissingModelGuidianceDocException ex) {
		return "";
	}

	@ResponseBody
	@ExceptionHandler({ MicroserviceException.class })
	protected ResponseEntity<Object> handleMicroserviceException(MicroserviceException ex) {
		if (ex.getRootException() instanceof FileNotFoundException) {
			return new ResponseEntity<Object>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ExceptionHandler({ Exception.class })
	protected ResponseEntity<Object> handleInvalidRequestMisc(Exception ex, HttpServletRequest hreq,
			WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		final String uri = hreq.getRequestURI();
		logger.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: " + uri, ex);
		headers.setContentType(MediaType.APPLICATION_JSON);
		ex.printStackTrace(System.out);
		return new ResponseEntity<Object>("{\"statusMessage\":" + ExceptionUtils.getStackTrace(ex) + "}", headers,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
