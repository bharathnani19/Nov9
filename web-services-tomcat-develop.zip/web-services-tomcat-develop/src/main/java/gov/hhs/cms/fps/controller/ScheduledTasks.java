package gov.hhs.cms.fps.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Response.Status.Family;
import javax.ws.rs.core.Response.StatusType;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import gov.hhs.cms.fps.dao.FpsTrackingDao;
import gov.hhs.cms.fps.model.FpsEmail;
import gov.hhs.cms.fps.model.FpsEventNotification;
import gov.hhs.cms.fps.model.FpsSentEvent;
import gov.hhs.cms.fps.model.WatchlistHandler;
import gov.hhs.cms.fps.model.WatchlistItem;
import gov.hhs.cms.fps.model.generated.FpsOktaGrpUserAsctn;
import gov.hhs.cms.fps.model.generated.FpsOktaUser;
import gov.hhs.cms.fps.model.hub.CaseRetrieveResponse;
import gov.hhs.cms.fps.model.hub.EventNotification;
import gov.hhs.cms.fps.model.hub.RetrieveRequest;
import gov.hhs.cms.fps.model.hub.Subscription;
import gov.hhs.cms.fps.model.hub.UcmCase;
import gov.hhs.cms.fps.model.okta.OktaGroup;
import gov.hhs.cms.fps.model.okta.OktaUser;
import gov.hhs.cms.fps.model.ucm.FpsResponse;
import gov.hhs.cms.fps.service.FpsApiService;
import gov.hhs.cms.fps.service.FpsEmailService;
import gov.hhs.cms.fps.service.FpsHubService;
import gov.hhs.cms.fps.service.WatchlistAutowireService;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.FpsEnums.EntityType;
import gov.hhs.cms.fps.util.FpsEnums.EventType;
import gov.hhs.cms.fps.util.FpsEnums.SubscriptionAction;
import gov.hhs.cms.fps.util.FpsHubConverter;
import gov.hhs.cms.fps.util.RestHelper;
import gov.hhs.cms.fps.util.RestHelper2;

@Component
@PropertySource({ "classpath:application.properties" })
public class ScheduledTasks {

	private static final Logger log = Logger.getLogger(ScheduledTasks.class.getName());

	@Autowired
	private Environment env;

	@Autowired
	private FpsHubService fpsHubService;

	@Autowired
	private FpsApiService fpsApiService;

	private Integer maxAttemptCnt = 5;
//	@Autowired
//	private KafkaTemplate<String, FpsEmail> kafkaTemplate;

	@Value("${email.disabled}")
	private String emailDisabled;
	@Value("${email.helpdesk}")
	private String helpdeskEmail;
	@Value("${email.from}")
	private String fromEmail;
	@Value("${email.from}")
	private String ucmRest;
	@Autowired
	private WatchlistAutowireService watchlistAutowireService;
	@Autowired
	private FpsEmailService fpsEmailService;

//	@Scheduled(initialDelay = 60000, fixedDelay = Long.MAX_VALUE)
	public void subscribe() {
		String svchubtest = env.getProperty("svchub.testmode");
		boolean testMode = "true".equals(svchubtest);
		if (testMode) {
			log.info("testMode = " + testMode);
			return;
		}
		String newApiOn = env.getProperty("svchub.api.v2", "false");
		// the new API/UCM nextgen does not require subscriptions
		if ("true".equals(newApiOn)) {
			return;
		}
		log.info("startup, make sure subscription is active");
		String eventsEnv = env.getProperty("svchub.subscribe.events");
		String subscribeUrl = env.getProperty("svchub.subscribe.url");
		String returnUrl = env.getProperty("svchub.return.url");
		if (StringUtils.isNotBlank(eventsEnv)) {
			StringTokenizer tokens = new StringTokenizer(eventsEnv, ",");

			while (tokens.hasMoreTokens()) {
				String event = tokens.nextToken();
				Subscription payload = new Subscription();
				payload.setAction(SubscriptionAction.NEW);
				payload.setEvent(EventType.valueOf(event));
				payload.setReturnURL(returnUrl);
				payload.setSystemID("FPS");
				payload.setType(EntityType.CASE);
				payload.setTransactionID(FpsDomainObjectConverter.createTransactionId());
				StatusType type = RestHelper.send(subscribeUrl, payload);

				if (type.getFamily().equals(Family.SUCCESSFUL)) {
					log.info("FPS2:SUBSCRIPTION:SUCCESS:subscribe to " + event + " re-established");
				} else {
					log.warning("FPS2:SUBSCRIPTION:FAILURE:subscribe to " + event + " failed due to "
							+ type.getStatusCode());

				}
				fpsHubService.saveUpdateSubscription(payload);

			}
		}
	}

	@Scheduled(cron = " 0 0 6-22/4 * * MON-FRI ")
	public void checkForUnsentNotifications() {
		// check for unsent events that have failed for 4 or more hours (48 or more send
		// attempts)
		List<FpsSentEvent> events = fpsHubService.findUnsentEvents(48);
		if (events != null && events.size() > 1) {
			log.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: There are " + events.size()
					+ " unsent UCM notifications older than one day.  Check to make sure UCM is online and that there are no network issues between the two systems");
		}
	}

	private boolean processWatchListNotifications(WatchlistHandler handler) {
		log.fine("Processing watchlist events");
		try {
			String svchubtest = env.getProperty("svchub.testmode.watchlist", "false");
			boolean testMode = "true".equals(svchubtest);
			if (testMode) {
				log.fine("watchlist testMode = " + testMode);
				return true;
			}
			List<Integer> asrIds = new ArrayList<Integer>();
			for (String type : handler.getWatchlists().keySet()) {
				Map<String, List<WatchlistItem>> userMap = handler.getWatchlistMap(type);
				for (String key : userMap.keySet()) {
					List<WatchlistItem> evts = userMap.get(key);
					log.info(" found " + evts.size() + " items for " + type + " for " + key);
					FpsEmail email = new FpsEmail();
					email.setFrom(fromEmail);
					email.setTo(Arrays.asList(new String[] { key }));

					email = watchlistAutowireService.prepEmail(type, email, evts);

					log.log(Level.INFO, "sending email " + email);
					if (!"true".equals(emailDisabled)) {
						fpsEmailService.sendEmail((FpsEmail) email);
//						ListenableFuture<SendResult<String, FpsEmail>> future = kafkaTemplate.send("fpsemail", email);
//
//						try {
//							SendResult<String, FpsEmail> result = future.get(5000, TimeUnit.MILLISECONDS);
//							// if (result.getRecordMetadata() != null) {
//							// kr.setOk(true);
//							//
//							// }
//						} catch (InterruptedException e) {
//							log.log(Level.SEVERE, "error1 putting email on queue", e);
//							return false;
//						} catch (ExecutionException e) {
//							log.log(Level.SEVERE, "error putting email on queue", e);
//							return false;
//						} catch (TimeoutException e) {
//							log.log(Level.SEVERE, "timeout putting email on queue", e);
//							return false;
//						}
					} else {
						log.log(Level.INFO,
								"Email disabled, not sending message.  This is set in application.properties");
					}
					for (WatchlistItem evt : evts) {
						Integer asrId = Integer.parseInt(evt.getEvent().getPublisherUniqueID());
						if (!asrIds.contains(asrId)) {
							asrIds.add(asrId);
						}
						fpsHubService.setEventAsPublished(evt.getEvent());
						FpsEventNotification evt2 = FpsHubConverter.cloneEvent(evt.getEvent());
						evt2.setSystemID(evt.getUserId());
						fpsHubService.insertNotification(evt2, true);

					}

				}

			}
		} catch (Exception e) {
			log.log(Level.SEVERE, "Error running scheduled task ", e);
			return false;
		}
		return true;
	}

	@Scheduled(cron = "0 */5 6-22 * * MON-FRI ")
	public void checkForEvents() {
		log.fine("Checking for events");
		try {
			String retrieveUrl = env.getProperty("svchub.retrieve.url");
			String svchubtest = env.getProperty("svchub.testmode");
			String newApiOn = env.getProperty("svchub.api.v2", "false");
			String newApiOnUrl = env.getProperty("svchub.api.v2.updateasr", "false");
			String serverEnv = env.getProperty("buildfor", "DEV");
			String runOnServers = env.getProperty("scheduledtask.asr.servers", "");
			// dynamic trigger to enable the new API if the config file isn't yet updated
			String url = "";
			boolean apiOverride = false;
			boolean testMode = "true".equals(svchubtest);
			if (testMode) {
				log.fine("testMode = " + testMode);
				return;
			}
			String thisServer = InetAddress.getLocalHost().getHostName();
			if (!runOnServers.toLowerCase().contains(thisServer.toLowerCase())) {
				log.info("asr event processing not set up to run on this server, " + thisServer + ", only "
						+ runOnServers);
				return;
			}
			if ("false".equals(newApiOn)) {
				apiOverride = fpsApiService.isUcmNextGenCutoverEnabled();
				if (apiOverride) {
//					url = "https://pxfer1.awscloud.cms.local/fps-service/fps/v1/update-asr";
					log.info("UCM nexgen is disabled, but override is enabled, so sending to nexgen");

					newApiOn = "true";
				} else {
					log.info("UCM nexgen is disabled, but no override is specified, so still sending to 1.0");
				}
			}

			List<FpsEventNotification> events = fpsHubService.findEvents();
			Integer eventId = null;
			// log.info("foundevents = " + events.size());
			for (FpsEventNotification event : events) {

				boolean hadFailures = false;
				boolean noMoreRetries = true;
				List<Subscription> subs = fpsHubService.findSubscribers(event.getEvent(), event.getPublisherUniqueID());
				// log.info("foundsubs = " + subs.size());

				for (Subscription sub : subs) {
					event.setRetrieveURL(retrieveUrl);
					event.setTransactionID(FpsDomainObjectConverter.createTransactionId());
					EventNotification eventToSend = new EventNotification();
					eventToSend.setEvent(event.getEvent());
					eventToSend.setPublisherUniqueID(event.getPublisherUniqueID());
					eventToSend.setRetrieveURL(event.getRetrieveURL());
					eventToSend.setSystemID("FPS");
					eventToSend.setTransactionID(event.getTransactionID());
					eventToSend.setType(event.getType());

					log.log(Level.FINE, "checking notification event " + eventToSend.getEvent());

					List<FpsSentEvent> sentEvents = fpsHubService.findSentEvents(event.getEventId(), sub.getSystemID());
					log.log(Level.FINE, "getting sent events for  " + event.getEventId() + ", " + sub.getSystemID());

					boolean neverSent = false;
					boolean failedSent = false;
					if (sentEvents == null || sentEvents.size() == 0) {
						log.info("no notifications, need to send");
						neverSent = true;
					} else {

						for (FpsSentEvent sentEvent : sentEvents) {
							if (!"Y".equals(sentEvent.getStatus())) {
								failedSent = true;
							}
						}
					}
					// log.info("flag " + ((neverSent || failedSent) && !testMode));
					// log.info("flag " + neverSent + ", " + failedSent + ", " + testMode);
					if ((neverSent || failedSent) && !testMode) {
						switch (event.getType()) {

						case PROVIDER:
							StatusType responseStatus = null;
							log.log(Level.FINE,
									"sending notification for " + RestHelper.getJsonFromObject(eventToSend));
							log.log(Level.FINE, "sending notification to " + sub.getReturnURL());
							if ("true".equals(newApiOn)) {
								Integer asrId = Integer.parseInt(event.getPublisherUniqueID());
								FpsResponse r = new FpsResponse();
								r.setType(event.getEvent());
								try {
									r = fpsApiService.getAsrBySection(asrId, "summary");
								}catch (Exception e) {
									log.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: error loading ASR notification for "
											+ RestHelper.getJsonFromObject(eventToSend));
									break;
								}

//								}
								String sendUrl = sub.getReturnURL();
								
								responseStatus = RestHelper2.send(sendUrl, r);

							} else {
								responseStatus = RestHelper.send(sub.getReturnURL(), eventToSend);

							}

							// if success, insert into notification log.
							log.info("status = " + responseStatus.getStatusCode() + " - " + responseStatus.getFamily());
							boolean successSent = responseStatus.getFamily().equals(Status.Family.SUCCESSFUL);

							if (!successSent) {
								log.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: error sending notification for "
										+ RestHelper.getJsonFromObject(eventToSend));
								log.log(Level.SEVERE,
										"FPS2:EXECUTION:ERROR: error sending notification to " + sub.getReturnURL());
								hadFailures = true;
							}
							if (neverSent) {
								log.info(successSent ? "success" : "failure" + ", no notifications have been sent");
								FpsEventNotification clone = FpsHubConverter.cloneEvent(event);
								clone.setSystemID(sub.getSystemID());
								fpsHubService.insertNotification(clone, successSent);
							} else {
								log.info("already sent, checking if any previous need updated");
								for (FpsSentEvent sentEvent : sentEvents) {

									if (!"Y".equals(sentEvent.getStatus())) {

										log.info((successSent ? "success" : "failure") + ", updating "
												+ sentEvent.getSentEventId() + " of " + sentEvent.getStatus());
										if (successSent) {
											fpsHubService.updateNotificationAsSent(sentEvent.getSentEventId());
										} else {
											if (sentEvent.getAttemptCnt() < maxAttemptCnt) {
												noMoreRetries = false;
											}
											fpsHubService.updateNotificationAsFailed(sentEvent.getSentEventId());
										}
									}
								}
							}
							break;

						}
					} else {
						log.log(Level.INFO, "notification event no need to send " + eventToSend.getEvent());

					}

				}
				if (!hadFailures && noMoreRetries) {
					log.log(Level.INFO, "setting event as published: " + event);
					fpsHubService.setEventAsPublished(event);
				}

			}
		} catch (Exception e) {
			log.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: Error running scheduled task ", e);
		}

		// if all suc

	}

	@Scheduled(cron = "0 */5 6-22 * * MON-FRI ")
	public void checkForMdcdEvents() {
		log.fine("Checking for events");
		try {
			String retrieveUrl = env.getProperty("svchub.retrieve.url");
			String svchubtest = env.getProperty("svchub.mdcd.testmode");
			String mdcdOn = env.getProperty("svchub.mdcd", "false");
			String serverEnv = env.getProperty("buildfor", "DEV");
			// dynamic trigger to enable the new API if the config file isn't yet updated
			if ("false".equals(mdcdOn)) {
				boolean override = fpsApiService.isUcmNextGenCutoverEnabledMdcd();
				if (override) {
					mdcdOn = "true";
				}
			}
			boolean testMode = "true".equals(svchubtest);
			if (testMode) {
				log.fine("testMode = " + testMode);
				return;
			}
			boolean mdcdMode = "true".equals(mdcdOn);
			if (!mdcdMode) {
				log.fine("mdcdMode = " + mdcdMode);
				return;
			}
			List<FpsEventNotification> events = fpsHubService.findMdcdEvents();
			Integer eventId = null;
			// log.info("foundevents = " + events.size());
			for (FpsEventNotification event : events) {

				boolean hadFailures = false;
				boolean noMoreRetries = true;
				List<Subscription> subs = fpsHubService.findSubscribers(event.getEvent()+"MCD", event.getPublisherUniqueID());
				// log.info("foundsubs = " + subs.size());

				for (Subscription sub : subs) {
					event.setRetrieveURL(retrieveUrl);
					event.setTransactionID(FpsDomainObjectConverter.createTransactionId());
					EventNotification eventToSend = new EventNotification();
					eventToSend.setEvent(event.getEvent());
					eventToSend.setPublisherUniqueID(event.getPublisherUniqueID());
					eventToSend.setRetrieveURL(event.getRetrieveURL());
					eventToSend.setSystemID("FPS");
					eventToSend.setTransactionID(event.getTransactionID());
					eventToSend.setType(event.getType());

					log.log(Level.FINE, "checking notification event " + eventToSend.getEvent());

					List<FpsSentEvent> sentEvents = fpsHubService.findMdcdSentEvents(event.getEventId(),
							sub.getSystemID());
					log.log(Level.FINE, "getting sent events for  " + event.getEventId() + ", " + sub.getSystemID());

					boolean neverSent = false;
					boolean failedSent = false;
					if (sentEvents == null || sentEvents.size() == 0) {
						log.info("no notifications, need to send");
						neverSent = true;
					} else {

						for (FpsSentEvent sentEvent : sentEvents) {
							if (!"Y".equals(sentEvent.getStatus())) {
								failedSent = true;
							}
						}
					}
					// log.info("flag " + ((neverSent || failedSent) && !testMode));
					// log.info("flag " + neverSent + ", " + failedSent + ", " + testMode);
					if ((neverSent || failedSent) && !testMode) {
						switch (event.getType()) {

						case PROVIDER:
							StatusType responseStatus = null;
							log.log(Level.FINE,
									"sending notification for " + RestHelper.getJsonFromObject(eventToSend));
							log.log(Level.FINE, "sending notification to " + sub.getReturnURL());
							Integer asrId = Integer.parseInt(event.getPublisherUniqueID());
							FpsResponse r = new FpsResponse();
							r.setType(event.getEvent());
//								if ("DEV".equals(serverEnv)) {
//									ASR asr = new ASR();
//									r.setCode(200);
//									r.setAsr(asr);
//								}else {
							r = fpsApiService.getMdcdAsrBySection(asrId, "summary", "");

//								}
							responseStatus = RestHelper2.send(sub.getReturnURL(), r);

							// if success, insert into notification log.
							log.info("status = " + responseStatus.getStatusCode() + " - " + responseStatus.getFamily());
							boolean successSent = responseStatus.getFamily().equals(Status.Family.SUCCESSFUL);

							if (!successSent) {
								log.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: error sending notification for "
										+ RestHelper.getJsonFromObject(eventToSend));
								log.log(Level.SEVERE,
										"FPS2:EXECUTION:ERROR: error sending notification to " + sub.getReturnURL());
								hadFailures = true;
							}
							if (neverSent) {
								log.info(successSent ? "success" : "failure" + ", no notifications have been sent");
								FpsEventNotification clone = FpsHubConverter.cloneEvent(event);
								clone.setSystemID(sub.getSystemID());
								fpsHubService.insertMdcdNotification(clone, successSent);
							} else {
								log.info("already sent, checking if any previous need updated");
								for (FpsSentEvent sentEvent : sentEvents) {

									if (!"Y".equals(sentEvent.getStatus())) {

										log.info((successSent ? "success" : "failure") + ", updating "
												+ sentEvent.getSentEventId() + " of " + sentEvent.getStatus());
										if (successSent) {
											fpsHubService.updateMdcdNotificationAsSent(sentEvent.getSentEventId());
										} else {
											if (sentEvent.getAttemptCnt() < maxAttemptCnt) {
												noMoreRetries = false;
											}
											fpsHubService.updateMdcdNotificationAsFailed(sentEvent.getSentEventId());
										}
									}
								}
							}
							break;

						}
					} else {
						log.log(Level.INFO, "notification event no need to send " + eventToSend.getEvent());

					}

				}
				if (!hadFailures && noMoreRetries) {
					log.log(Level.INFO, "setting event as published: " + event);
					fpsHubService.setMdcdEventAsPublished(event);
				}

			}
		} catch (Exception e) {
			log.log(Level.SEVERE, "FPS2:EXECUTION:ERROR: Error running scheduled task ", e);
		}

		// if all suc

	}

//	@Scheduled(cron = "0 0 1 * * MON")
	public void checkForInactiveUsers(Integer days) {
		String doCheck = env.getProperty("okta.inactiveusercheck", "false");
		// since multiple environments share an okta instance, no need to run this
		// on every environment. DEV, VAL and PROD are the only places this needs to run
		if (!"true".equals(doCheck)) {
			return;
		}
		List<OktaUser> users = RestHelper.getOktaUsers();
		LocalDateTime ld = LocalDateTime.now();
		ld = ld.minusDays(days == null ? 180 : days);
		Date old = Date.from(ld.atZone(ZoneId.systemDefault()).toInstant());
		log.finest("using date " + old);
		List<String> never = new ArrayList<>();
		List<String> neverLapsed = new ArrayList<>();
		List<String> lapsed = new ArrayList<>();
		List<String> have = new ArrayList<>();
		int count = users.size();
		for (OktaUser user : users) {
			if ("SUSPENDED".equalsIgnoreCase(user.getStatus())) {
				continue;
			}
			if (user.getLastLogin() == null) {
				if (user.getCreated().before(old)) {
					neverLapsed.add(user.getProfile().getLogin());
					log.finest(user.getProfile().getLogin() + " has never logged in and was created on "
							+ user.getCreated());
				} else {
					never.add(user.getProfile().getLogin());
				}
			} else if (user.getLastLogin().before(old)) {
				lapsed.add(user.getProfile().getLogin());
				log.info(user.getProfile().getLogin() + " has not logged in since " + user.getLastLogin());
			} else {
				have.add(user.getProfile().getLogin());

			}
		}

		FpsEmail email = new FpsEmail();
		email.getTo().add(helpdeskEmail);
		email.setSubject("FPS 180 Day User Report: " + env.getProperty("buildfor"));
		String body = "<b>Users that should be reviewed:</b><p/><b>Users who have not logged in within 180 days:</b><br/>";
		if (lapsed.size() > 0) {
			body += StringUtils.join(lapsed, ", ");
		} else {
			body += "None";
		}
		body += "<p/>";
		body += "<b>Users who have never logged in with accounts older than 180 days:</b><br/>";
		if (neverLapsed.size() > 0) {
			body += StringUtils.join(neverLapsed, ", ");
		} else {
			body += "None";
		}
		body += "<p/>";
		body += "<b>Users listed for informational purposes:</b><p/><b>Users who have logged in within 180 days:</b><br/>";
		if (have.size() > 0) {
			body += StringUtils.join(have, ", ");
		} else {
			body += "None";
		}
		body += "<p/>";
		body += "<b>Users who have never logged in with accounts newer than 180 days:</b><br/>";
		if (never.size() > 0) {
			body += StringUtils.join(never, ", ");
		} else {
			body += "None";
		}

		body += "<p/>";
		body += "<b>Number of users reviewed: " + count + "</b><br/>";

		email.setBody(body);
//		log.info(body);

		email.setFrom(fromEmail);
		fpsEmailService.sendEmail(email);

	}

	@Scheduled(cron = "0 30 5 * * *")
//	@Scheduled(fixedRate = 180000)
	public void checkForWatchlistEvents() {
		log.info("Checking for watchlist events");
		String runOnServers = env.getProperty("scheduledtask.watchlist.servers", "");
		try {
			String thisServer = InetAddress.getLocalHost().getHostName();
			if (!runOnServers.toLowerCase().contains(thisServer.toLowerCase())) {
				log.info("watchlist event processing not set up to run on this server, " + thisServer + ", only "
						+ runOnServers);
				return;
			}
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			String retrieveUrl = env.getProperty("svchub.retrieve.url");
			String svchubtest = env.getProperty("svchub.testmode.watchlist", "false");
			boolean testMode = "true".equals(svchubtest);
			if (testMode) {
				log.fine("testMode = " + testMode);
				return;
			}
			List<FpsEventNotification> events = fpsHubService.findWatchlistEvents();
			Integer eventId = null;
			// log.info("foundevents = " + events.size());
			WatchlistHandler handler = new WatchlistHandler();

			for (FpsEventNotification event : events) {

				boolean hadFailures = false;
				boolean noMoreRetries = true;
				List<String> zones = fpsHubService.loadZonesByAsrptId(Integer.parseInt(event.getPublisherUniqueID()));
				if (zones == null || zones.size() == 0) {
					log.info("No jurisdiction set for ASR, so skipping - " + event.getPublisherUniqueID());
					fpsHubService.setEventAsPublished(event);
					continue;
				}
				List<Subscription> subs = fpsHubService.findSubscribers(event.getEvent(), event.getPublisherUniqueID(),
						zones);
				// log.info("foundsubs = " + subs.size());

				if (subs == null || subs.size() == 0) {
					log.info("No watchlist subscribers for " + event.getEventId() + ", " + event.getEvent());
					fpsHubService.setEventAsPublished(event);
					continue;
				}
				for (Subscription sub : subs) {
					event.setTransactionID(FpsDomainObjectConverter.createTransactionId());

					log.log(Level.FINE, "checking watchlist notification event " + event.getEvent());

					List<FpsSentEvent> sentEvents = fpsHubService.findSentEvents(event.getEventId(), sub.getSystemID());
					log.log(Level.FINE,
							"getting watchlist sent events for  " + event.getEventId() + ", " + sub.getSystemID());

					boolean neverSent = false;
					boolean failedSent = false;
					if (sentEvents == null || sentEvents.size() == 0) {
						log.info("no watchlist notifications, need to send");
						neverSent = true;
					} else {
						log.info("old watchlist notifications, already sent");

						for (FpsSentEvent sentEvent : sentEvents) {
							if (!"Y".equals(sentEvent.getStatus())) {
								failedSent = true;
							}
						}
					}
					// log.info("flag " + ((neverSent || failedSent) && !testMode));
					// log.info("flag " + neverSent + ", " + failedSent + ", " + testMode);
					if ((neverSent || failedSent) && !testMode) {
						switch (event.getType()) {
						case WATCHLIST:

							WatchlistItem item = WatchlistItem.getInstance(event.getEvent(), sub.getSystemID());
							item.setId(event.getPublisherUniqueID());
							item.setEvent(event);
							item.setSubscriptionId(sub.getSubscriptionId());
							event.setRetrieveURL(sub.getEmail());
							handler.addToWatchlistMap(event.getEvent(), sub.getEmail(), item);
							// CM-4211
//							watchlistAutowireService.doExtra(event.getEvent(),event.getPublisherUniqueID());
							break;
						default:
							break;
						}
					} else {
						log.log(Level.INFO, "notification event no need to send " + event.getEvent());

					}

				}

			}
			processWatchListNotifications(handler);

		} catch (Exception e) {
			log.log(Level.SEVERE, "Error running scheduled task ", e);
		}

	}

	public Environment getEnv() {
		return env;
	}

	public void setEnv(Environment env) {
		this.env = env;
	}

	@Scheduled(cron = " 0 0 5 * * * ")
//	@Scheduled(fixedRate = 300000)

	public void findWatchlistNotifications() {
		watchlistAutowireService.buildNotifications();
		// fpsHubService.updateLastWatchlistRun();
	}

	@Scheduled(cron = "0 0 4 * * *  ")
	public void autoPruneExclusionLists() {
		// set actv_id = 'N' where follow up date is <= current date
		fpsHubService.autoPruneExclusionLists();

	}

//	 @Scheduled(cron = "0 0 4 * * *  ")
//	 public void checkForProcessedCustomASRs() {
//		 // find pending lists
//		 // check for ASRs in that list
//		 // if ASRs are found, send email
//		 // update the request status
//		 // create watchlist
//	 }
	@Scheduled(cron = "0 0 4 * * *  ")
	public void checkForExpiredExclusionSets() {
		log.info("Checking for any expired exclusion set items");
		fpsHubService.checkForExpiredExclusionSets();
	}

	public void autoUpdateExclusionLists() {
		checkForExpiredExclusionSets();

	}

	// @Scheduled(cron = "0 0 0 * * * ")
	public void refreshOktaUsers() {
		List<OktaUser> users = RestHelper.getOktaUsers();
		List<FpsOktaUser> dbUsers = new ArrayList<>();
		for (OktaUser user : users) {
			FpsOktaUser dbUser = new FpsOktaUser();
			dbUser.setEmail(user.getProfile().getEmail());
			dbUser.setUserNm(user.getProfile().getLogin());
			if (StringUtils.isNotBlank(user.getProfile().getDisplayName())) {
				dbUser.setFriendlyNm(user.getProfile().getDisplayName());
			} else {
				dbUser.setFriendlyNm(user.getProfile().getFirstName() + " " + user.getProfile().getLastName());

			}
			dbUsers.add(dbUser);
		}
		fpsHubService.saveBatch(dbUsers);
		List<OktaGroup> groups = RestHelper.getOktaGroups();
		List<FpsOktaGrpUserAsctn> allGroupUsers = new ArrayList<>();

		for (OktaGroup group : groups) {
			List<OktaUser> groupUsers = RestHelper.getOktaUsersByGroup(group.getId());
			for (OktaUser groupUser : groupUsers) {
				FpsOktaGrpUserAsctn dbGroupUser = new FpsOktaGrpUserAsctn();
				dbGroupUser.setGroupNm(group.getProfile().getName());
				dbGroupUser.setUserNm(groupUser.getProfile().getLogin());
				allGroupUsers.add(dbGroupUser);
			}
		}
		fpsHubService.saveBatch(allGroupUsers);

	}

//	@Scheduled(cron = "0 0 5 * * SUN  ")
	// the crosswalk is now a DB2 view
	public void updateCrosswalk() {

		fpsHubService.updateCrosswalk();
	}

//	@Scheduled(cron = "0 0 1 * * *  ")
	public void checkForMissingUcmCases() {
		String svchubtest = env.getProperty("svchub.testmode.missingucm");
		boolean testMode = "true".equals(svchubtest);

		EventNotification notification = new EventNotification();
		List<String> missingUcmCases = fpsHubService.getOnePiCasesForAsrs();
		log.info("missing UCM cases to retrieve  " + missingUcmCases.size());
		if (testMode) {
			log.info("checkForMissingUcmCases::testMode = " + testMode);
			return;
		}
		for (String ucmCase : missingUcmCases) {
			log.info("retrieving missing UCM case  " + ucmCase);
			// Subscription newSub =
			// subscriptionService.saveUpdateSubscription(subscription);
			RetrieveRequest rr = new RetrieveRequest();
			// rr.setProducerId(notification.getPublisherUniqueID());
			rr.setProducerUniqueID(ucmCase);
			rr.setTransactionID(FpsDomainObjectConverter.createTransactionId());
			rr.setType(EntityType.CASE);

			// retrieve details

			// CaseRetrieveResponse resp = FpsCommonDataGenerator.getTestZr();
			CaseRetrieveResponse resp = RestHelper.sendRetrieveCase(notification.getRetrieveURL(), rr);

			// returns an array, though for this case it'll always be one value
			List<UcmCase> ucmCases = resp.getResponseData();
			log.info("missing UCM case response received  = " + ucmCases.size() + " cases");
			if (ucmCases.size() > 0) {
				log.info("missing UCM case response = " + ucmCases.get(0));
				String caseId = ucmCases.get(0).getUcmRecordID();

				// load cases for that UCM Case ID.
				// if there are any cases, soft-delete from investigation,
				// investigation user, action, activity, ruling and model
				// usefulness
				// table
				// soft delete is changing the REC_CHG_IND to 'R'
				// re-insert all data again into those applicable tables.
				fpsHubService.processUcmCase(ucmCases.get(0), false);

			} else {
				log.info("missing UCM case response returned no cases");

			}
		}
	}

}