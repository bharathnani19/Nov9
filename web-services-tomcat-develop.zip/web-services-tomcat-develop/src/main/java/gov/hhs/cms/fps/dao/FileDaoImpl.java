package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import gov.hhs.cms.fps.model.generated.FpsFilStore;
@Repository(value="fileDao")
public class FileDaoImpl extends BaseDao<Integer, FpsFilStore> implements FileDao {
	@Override
	public FpsFilStore loadFile(Integer id) {
		FpsFilStore f = (FpsFilStore) getCurrentSession().load(FpsFilStore.class, id);

		return f;
	}
	@Override
	public List<FpsFilStore> deleteFile(Integer id, String userId) {
		FpsFilStore f = loadFile(id);
		String section = f.getAppName();
		getCurrentSession().createQuery("update FpsFilStore set actvInd = 'N', audtUpdtId = :userId"
				+ " where filStoreId= :id")
		.setInteger("id", id)
		.setString("userId", userId).executeUpdate();
		List<FpsFilStore> files = loadVmFiles(id, section);
		return files;

		
	}
	@Override
	public List<FpsFilStore> loadVmFiles(Integer id, String section) {
		return getCurrentSession().createQuery("from FpsFilStore where appRecId= :id and appName=:section and actvInd = 'Y'")
				.setInteger("id", id).setString("section",section).list();

		
	}
	
	@Override
	public Integer saveFile(Integer id, String userId,MultipartFile file, String section) throws IOException {
		FpsFilStore f =  new FpsFilStore();
		//f.setFilCntnt(file.getBytes());
		String name = file.getOriginalFilename();
		String mime = "application/octet-stream";
		if (name.toLowerCase().endsWith("pdf")){
			mime = "application/pdf";
		}else if (name.toLowerCase().endsWith("docx")){
			mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		}else if (name.toLowerCase().endsWith("xlsx")){
			mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		}else if (name.toLowerCase().endsWith("doc")){
			mime = "application/msword";
		}else if (name.toLowerCase().endsWith("xls")){
			mime = "application/vnd.ms-excel";
		}
		f.setFilType(mime);
		f.setFilName(file.getOriginalFilename());
		f.setFilSize(file.getSize()+"");
		f.setAppRecId(id);
		f.setAudtInsrtId(userId);
		f.setAudtInsrtTs(new Date());
		f.setAppName(section);
		f.setAppRecId(id);
		f.setActvInd('Y');
		Integer newId = (Integer) getCurrentSession().save(f);
		return newId;
		
	}
}
