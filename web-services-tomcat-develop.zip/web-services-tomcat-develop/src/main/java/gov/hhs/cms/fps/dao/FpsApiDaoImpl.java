package gov.hhs.cms.fps.dao;

import gov.hhs.cms.fps.model.generated.FpsAlert;
import gov.hhs.cms.fps.model.generated.FpsAlertMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsRptCardDtl;
import gov.hhs.cms.fps.model.generated.FpsRptCardRskSnaDtl;
import gov.hhs.cms.fps.model.ucm.CaseDetail;
import gov.hhs.cms.fps.model.ucm.Claims;
import gov.hhs.cms.fps.model.ucm.PartDClaims;
import java.util.List;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

@Repository("fpsApiDao")
public class FpsApiDaoImpl extends BaseDao<Integer, Integer> implements FpsApiDao {
	public FpsAsrpt getAsrBySection(Integer asrId, String section) {
		return null;
	}

	public void saveCaseEvent(CaseDetail caseDetail) {
	}

	public List<Claims> getASRClaims(Integer asrId) {
		return null;
	}

	public List<PartDClaims> getASRClaimsPtd(Integer asrId) {
		return null;
	}

	public List<PartDClaims> getPtdReportCardClaims(Integer alertId, Integer attribute) {
		return null;
	}

	public List<Claims> getReportCardClaims(Integer alertId) {
		return null;
	}

	public List<FpsRptCardDtl> getReportCard(Integer alertId) {
		return null;
	}

	public List<FpsRptCardRskSnaDtl> getReportCardSna(Integer alertId) {
		return null;
	}

	public List<Claims> getReportCardClaimsAttr(Integer alertId, Integer attribute) {
		return null;
	}

	public List<PartDClaims> getPtdReportCardClaims(Integer alertId) {
		return null;
	}

	public FpsAlert getAlertFromAlertId(Integer alertId) {
		FpsAlert alert = (FpsAlert) getCurrentSession().createCriteria(FpsAlert.class, "alert")
				.add((Criterion) Restrictions.eq("alert.alertId", alertId)).uniqueResult();
		return alert;
	}

	@Override
	public Integer getAsrptIdFromAlertId(Integer alertId) {
		Integer alert = (Integer) getCurrentSession().createCriteria(FpsAlert.class, "alert")
				.createAlias("alert.fpsAsrptAlertAsctns", "asctns").createAlias("asctns.fpsAsrpt", "asrpt")
				.add(Restrictions.eq("alert.alertId", alertId)).setProjection(Projections.property("asrpt.asrptId"))
				.uniqueResult();
		return alert;
	}

	@Override
	public String getModelTypeFromAlert(Integer alertId) {
		String modelType = (String) getCurrentSession().createCriteria(FpsAlert.class, "alert")
				.createAlias("alert.fpsModel", "model")
				.add(Restrictions.eq("alert.alertId", alertId)).setProjection(Projections.property("model.rptCardTypeDesc"))
				.uniqueResult();
		return modelType;
	}

	@Override
	public FpsAlertMdcd getMdcdAlertFromAlertId(Integer alertId) {
		FpsAlertMdcd alert = (FpsAlertMdcd) getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.add((Criterion) Restrictions.eq("alert.alertId", alertId)).uniqueResult();
		return alert;
	}

	@Override
	public Integer getMdcdAsrptIdFromAlertId(Integer alertId) {
		Integer alert = (Integer) getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.createAlias("alert.fpsAsrptAlertAsctns", "asctns").createAlias("asctns.fpsAsrpt", "asrpt")
				.add(Restrictions.eq("alert.alertId", alertId)).setProjection(Projections.property("asrpt.asrptId"))
				.uniqueResult();
		return alert;
	}

	@Override
	public String getMdcdModelTypeFromAlert(Integer alertId) {
		String modelType = (String) getCurrentSession().createCriteria(FpsAlertMdcd.class, "alert")
				.createAlias("alert.fpsModel", "model")
				.add(Restrictions.eq("alert.alertId", alertId)).setProjection(Projections.property("model.rptCardTypeDesc"))
				.uniqueResult();
		return modelType;
	}
}
