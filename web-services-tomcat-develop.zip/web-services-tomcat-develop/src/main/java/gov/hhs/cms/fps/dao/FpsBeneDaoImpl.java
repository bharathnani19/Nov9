/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.hhs.cms.fps.model.FpsCommonBeneficiary;
import gov.hhs.cms.fps.model.FpsGeoBene;
import gov.hhs.cms.fps.model.generated.FpsAsrptBenePmtsVw;
import gov.hhs.cms.fps.model.generated.FpsBene;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;

@Repository("beneDao")
public class FpsBeneDaoImpl extends BaseDao<Integer, FpsBene> implements FpsBeneDao {

	@Override
	public FpsBene loadBene(long beneSk) {
		Criteria c = getCurrentSession().createCriteria(FpsBene.class).add(Restrictions.eq("beneSk", beneSk));
		List<FpsBene> l = c.list();
		if (l != null && l.size() > 0) {
			return (FpsBene) l.get(0);
		}
		return new FpsBene();
	}

	@Override
	@Transactional
	public List<Object[]> loadBenesForAsrByModel(int asrptId, int modelId, int pageId) {
		List<Object[]> allAssoc = new ArrayList<Object[]>();

		Criteria c2 = getCurrentSession().createCriteria(FpsAsrptBenePmtsVw.class, "asrbene");
		c2.createAlias("asrbene.fpsBene", "bene", JoinType.LEFT_OUTER_JOIN);
		c2.createAlias("asrbene.fpsAsrpt", "asr");
		c2.createAlias("asr.fpsAsrptAlertAsctns", "aa");
		c2.createAlias("aa.fpsAlert", "alert");
		c2.createAlias("alert.fpsModel", "model");

		c2.add(Restrictions.eq("asrbene.asrptId", asrptId));
		c2.add(Restrictions.eq("model.modelId", modelId));
		c2.addOrder(Order.desc("asrbene.clmPrvdrPmtAmt"));
		c2.setProjection(Projections.projectionList().add(Projections.distinct(Projections.property("asrbene.beneSk")))
				.add(Projections.property("asrbene.clmHicNum")).add(Projections.property("asrbene.clmPrvdrPmtAmt"))
				.add(Projections.property("bene.bene1stName")).add(Projections.property("bene.beneLastName"))
				.add(Projections.property("bene.beneLine1Adr")).add(Projections.property("bene.beneLine2Adr"))
				.add(Projections.property("bene.srcZipPlcName")).add(Projections.property("bene.srcUspsStateCd"))
				.add(Projections.property("bene.srcZip4Cd")).add(Projections.property("bene.srcZip5Cd"))
				.add(Projections.property("bene.benePhneNum")));

		c2.setMaxResults(10);
		c2.setFirstResult(pageId * 10);
		allAssoc = c2.list();

		return allAssoc;
	}

	@Override
	public List<FpsCommonBeneficiary> getBeneAddressData(int asrptId, int pageId) {
		List<Object[]> allAssoc = new ArrayList<Object[]>();
		List<FpsCommonBeneficiary> benes = new ArrayList<FpsCommonBeneficiary>();

		Criteria c2 = getCurrentSession().createCriteria(FpsAsrptBenePmtsVw.class, "asrbene");
		c2.createAlias("asrbene.fpsBene", "bene", JoinType.LEFT_OUTER_JOIN);
		c2.createAlias("asrbene.fpsAsrpt", "asr");

		c2.add(Restrictions.eq("asrbene.asrptId", asrptId));
		c2.addOrder(Order.desc("asrbene.clmPrvdrPmtAmt"));
		c2.setProjection(Projections.projectionList().add(Projections.distinct(Projections.property("asrbene.beneSk")))
				.add(Projections.property("asrbene.clmHicNum")).add(Projections.property("asrbene.clmPrvdrPmtAmt"))
				.add(Projections.property("bene.bene1stName")).add(Projections.property("bene.beneLastName"))
				.add(Projections.property("bene.beneLine1Adr")).add(Projections.property("bene.beneLine2Adr"))
				.add(Projections.property("bene.srcZipPlcName")).add(Projections.property("bene.srcUspsStateCd"))
				.add(Projections.property("bene.srcZip4Cd")).add(Projections.property("bene.srcZip5Cd"))
				.add(Projections.property("bene.benePhneNum"))				
				.add(Projections.property("bene.latitude")).add(Projections.property("bene.longitude")));

		c2.setMaxResults(10);
		c2.setFirstResult(pageId * 10);
		allAssoc = c2.list();
		for (Object[] row : allAssoc) {
			FpsCommonBeneficiary item = new FpsCommonBeneficiary();
			item.setHicn(FpsDomainObjectConverter.maskHicn(row[1].toString()));
			FpsGeoBene beneAddr = new FpsGeoBene();
			beneAddr.setHicn(FpsDomainObjectConverter.maskHicn(row[1].toString()));
			beneAddr.setFirstName(FpsDomainObjectConverter.maskName(row[3]));
			beneAddr.setLastName(FpsDomainObjectConverter.maskName(row[4]));
			beneAddr.setAddress1(FpsDomainObjectConverter.maskName(row[5]));
			beneAddr.setAddress2(FpsDomainObjectConverter.maskName(row[6]));
			beneAddr.setCity(FpsDomainObjectConverter.maskName(row[7]));
			beneAddr.setState(FpsDomainObjectConverter.maskState(row[8]));
			beneAddr.setZip(FpsDomainObjectConverter.maskNumber(row[10]));
			beneAddr.setPhone(FpsDomainObjectConverter.maskPhone(row[11]));
//			future
//			beneAddr.setLatitude((Double)row[12]);
//			beneAddr.setLongitude((Double)row[13]);
			item.setAddress(beneAddr);

			benes.add(item);
		}
		return benes;
	}

}
