package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.generated.FpsHomepageRfrnc;
import gov.hhs.cms.fps.model.okta.OktaGroup;

public interface FpsHomepageDao {

	List<FpsHomepageRfrnc> loadHomepageTiles(String userId, List<String> groups);

}
