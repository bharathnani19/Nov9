package gov.hhs.cms.fps.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.generated.FpsHomepageRfrnc;
import gov.hhs.cms.fps.model.okta.OktaGroup;
@Repository("fpsHomepageDao")
public class FpsHomepageDaoImpl extends BaseDao<Integer, FpsHomepageRfrnc>  implements FpsHomepageDao {
	@Value("${buildfor:null}")
	private String buildfor;
	@Override
	public List<FpsHomepageRfrnc> loadHomepageTiles(String userId, List<String> groups) {
		Criteria c = getCurrentSession().createCriteria(FpsHomepageRfrnc.class, "fpsHomepageRfrnc");
		c.createAlias("fpsHomepageRfrnc.fpsHomepageRoleRfrncs", "roles");
		c.add(Restrictions.or(Restrictions.eq("homepageEnvCd", buildfor), Restrictions.isNull("homepageEnvCd")));

		c.add(Restrictions.in("roles.roleNm", groups));
		c.add(Restrictions.eq("actvInd", "Y"));

		c.addOrder(Order.asc("homepageSqncNum"));
		c.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return c.list();
	}

}
