package gov.hhs.cms.fps.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.hhs.cms.fps.model.FpsUser;
import gov.hhs.cms.fps.model.NvUcmSummary;
import gov.hhs.cms.fps.model.generated.FpsActnBrrRfrnc;
import gov.hhs.cms.fps.model.generated.FpsActnTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsActvtyTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsAlertUsflnsRfrnc;
import gov.hhs.cms.fps.model.generated.FpsApsWatchlist;
import gov.hhs.cms.fps.model.generated.FpsApsWatchlistRoot;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsAsrptInvstgtn;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrty;
import gov.hhs.cms.fps.model.generated.FpsAsrptPrrtyMdcd;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserActvty;
import gov.hhs.cms.fps.model.generated.FpsAsrptUserAdminvActn;
import gov.hhs.cms.fps.model.generated.FpsCustomAsrList;
import gov.hhs.cms.fps.model.generated.FpsCustomAsrListItem;
import gov.hhs.cms.fps.model.generated.FpsFdsEvntTrans;
import gov.hhs.cms.fps.model.generated.FpsFdsEvntTransMdcd;
import gov.hhs.cms.fps.model.generated.FpsFdsEvntTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsFdsNtfctn;
import gov.hhs.cms.fps.model.generated.FpsFdsNtfctnMdcd;
import gov.hhs.cms.fps.model.generated.FpsFdsSbscrptn;
import gov.hhs.cms.fps.model.generated.FpsFdsSysRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrvdrZnRstctnDtlFact;
import gov.hhs.cms.fps.model.generated.FpsRulngRfrnc;
import gov.hhs.cms.fps.model.generated.FpsRulngRsnRfrnc;
import gov.hhs.cms.fps.util.FpsEnums.ApiDeleteActionType;
import gov.hhs.cms.fps.util.FpsEnums.EventType;

@Repository(value = "fpsHubDao")
@Transactional
public class FpsHubDaoImpl extends BaseDao<Integer, Object> implements FpsHubDao {
	private static Logger logger = Logger.getLogger(FpsHubDaoImpl.class.getName());

	@Override
	public List<FpsFdsEvntTrans> findEvents() {
		return findEvents(null);

	}

	public List<FpsFdsEvntTrans> findEvents(EventType type) {
		Criteria c = getCurrentSession().createCriteria(FpsFdsEvntTrans.class)
				.add(Restrictions.eq("ntfctnStusCd", "12"));
		if (type != null) {
			c.add(Restrictions.eqOrIsNull("evntTypeCd", type.name()));
		}
		c.add(Restrictions.eq("objTypeCd", "PR"));

		return c.list();

	}

	@Override
	public List<FpsFdsEvntTrans> findWatchlistEvents() {
		return findEvents(null);

	}

	@Override
	public List<FpsFdsEvntTrans> findWatchlistEvents(EventType type) {
		Criteria c = getCurrentSession().createCriteria(FpsFdsEvntTrans.class)
				.add(Restrictions.eq("ntfctnStusCd", "12"));
		if (type != null) {
			c.add(Restrictions.eqOrIsNull("evntTypeCd", type.name()));
		}
		c.add(Restrictions.eq("objTypeCd", "WL"));

		return c.list();

	}

	@Override
	public FpsFdsEvntTrans insertEvent(FpsFdsEvntTrans evnt) {
		getCurrentSession().save(evnt);
		return evnt;
	}
	@Override
	public FpsFdsEvntTransMdcd insertEvent(FpsFdsEvntTransMdcd evnt) {
		getCurrentSession().save(evnt);
		return evnt;
	}
	@Override
	public FpsFdsEvntTrans setEventAsPublished(FpsFdsEvntTrans dbEvent) {
		dbEvent = (FpsFdsEvntTrans) getCurrentSession().load(FpsFdsEvntTrans.class, dbEvent.getEvntTransId());
		dbEvent.setNtfctnStusCd("11");
		dbEvent.setAudtUpdtId("FPS");
		dbEvent.setAudtUpdtTs(new Date());
		getCurrentSession().merge(dbEvent);
		getCurrentSession().flush();
		return dbEvent;
	}

	@Override
	public FpsFdsSbscrptn insertUpdateSubscription(FpsFdsSbscrptn sub) throws DataAccessException {
		getCurrentSession().save(sub);
		return sub;
	}

	@Override
	public List<FpsFdsSbscrptn> findSubscriptions(String url) {
		return getCurrentSession().createCriteria(FpsFdsSbscrptn.class).add(Restrictions.eq("eventTypeCd", url)).list();
	}

	@Override
	public List<FpsFdsSbscrptn> findSubscriptions(String eventType, String entityId, String systemId) {
		Criteria c = getCurrentSession().createCriteria(FpsFdsSbscrptn.class).add(Restrictions
				.and(Restrictions.eq("eventTypeCd", eventType), Restrictions.eqOrIsNull("objSrchId", entityId)));
		if (!"APS".equals(eventType)) {
			c.add(Restrictions.eq("sbscrptnActnCd", "1"));
		}
		if (systemId != null) {
			c.add(Restrictions.eq("sysCd", systemId.toLowerCase()).ignoreCase());
		}

		return c.list();
	}

	@Override
	public List<FpsFdsSbscrptn> findSubscriptionsForWatchlist(String userId) {
		Criteria c = getCurrentSession().createCriteria(FpsFdsSbscrptn.class).add(Restrictions.eq("objTypeCd", "WL"))
				.add(Restrictions.eq("sbscrptnActnCd", "1"))
				.add(Restrictions.eq("sysCd", userId.toLowerCase()).ignoreCase());

		return c.list();
	}

	@Override
	public List<FpsFdsEvntTypeRfrnc> findWatchlistTypes() {
		Criteria c = getCurrentSession().createCriteria(FpsFdsEvntTypeRfrnc.class)
				.add(Restrictions.eq("objTypeCd", "WL"));

		return c.list();
	}

	@Override
	public List<FpsFdsSbscrptn> findSubscriptionsForNotifications(String eventType, String entityId, String systemId) {
		return findSubscriptionsForNotifications(eventType, entityId, systemId, null);
	}

	@Override
	public List<FpsFdsSbscrptn> findSubscriptionsForNotifications(String eventType, String entityId, String systemId,
			List<String> zones) {
		Criteria c = getCurrentSession().createCriteria(FpsFdsSbscrptn.class).createAlias("fpsFdsSysRfrnc", "ref")
				.add(Restrictions.and(Restrictions.eq("eventTypeCd", eventType),
						Restrictions.or(Restrictions.eq("objSrchId", entityId), Restrictions.isNull("objSrchId"))))
				.add(Restrictions.eq("sbscrptnActnCd", "1"));
		if (systemId != null) {
			c.add(Restrictions.eq("sysCd", systemId));
		}
		if (zones != null) {
			c.add(Restrictions.in("ref.sysJrsdctn", zones));
		}

		return c.list();
	}

	@Override
	public void insertPriority(FpsAsrptPrrty p) {

		getCurrentSession().save(p);
//		p.setFpsAsrptPrrtyModels(new HashSet<FpsAsrptPrrtyModel>());

	}
	@Override
	public void insertPriority(FpsAsrptPrrtyMdcd p) {

		getCurrentSession().save(p);
//		p.setFpsAsrptPrrtyModels(new HashSet<FpsAsrptPrrtyModel>());

	}
	@Override
	public List<FpsFdsSysRfrnc> findSystem(String systemName) {
		return getCurrentSession().createCriteria(FpsFdsSysRfrnc.class).add(Restrictions.eq("sysShrtName", systemName))
				.list();

	}

	@Override
	public List<FpsRulngRfrnc> findRulingByDesc(String desc) {
		return getCurrentSession().createCriteria(FpsRulngRfrnc.class).add(Restrictions.eq("rulngDesc", desc)).list();

	}

	@Override
	public List<FpsActnTypeRfrnc> findActionByDesc(String desc) {
		return getCurrentSession().createCriteria(FpsActnTypeRfrnc.class).add(Restrictions.eq("actnTypeDesc", desc))
				.list();

	}

	@Override
	public List<FpsActvtyTypeRfrnc> findActivityByDesc(String desc) {
		return getCurrentSession().createCriteria(FpsActvtyTypeRfrnc.class).add(Restrictions.eq("actvtyTypeDesc", desc))
				.list();

	}

	@Override
	public List<FpsActnBrrRfrnc> findBarrierByDesc(String desc) {
		return getCurrentSession().createCriteria(FpsActnBrrRfrnc.class).add(Restrictions.eq("actnBrrDesc", desc))
				.list();

	}

	@Override
	public List<FpsAlertUsflnsRfrnc> findUsefulnessByDesc(String desc) {
		return getCurrentSession().createCriteria(FpsAlertUsflnsRfrnc.class)
				.add(Restrictions.eq("alertUsflnsDesc", desc).ignoreCase()).list();

	}

	@Override
	public FpsFdsNtfctn insertSentNotification(FpsFdsNtfctn dbNot) {
		getCurrentSession().save(dbNot);
		return dbNot;
	}

	@Override
	public List<FpsFdsNtfctn> findSentEvents(Integer eventId, String systemId) {
		return getCurrentSession().createCriteria(FpsFdsNtfctn.class).add(Restrictions.eq("evntTransId", eventId))
				.add(Restrictions.eq("toSysId", systemId)).list();
	}

	@Override
	public List<FpsFdsNtfctn> findUnsentEvents(int failedNum) {
		return getCurrentSession().createCriteria(FpsFdsNtfctn.class).add(Restrictions.eq("ntfctnSucsflInd", "N"))
				.add(Restrictions.ge("ntfctnCnt", failedNum)).list();
	}

	@Override
	public FpsFdsNtfctn findSentEvent(Integer sentEventId) {
		return (FpsFdsNtfctn) getCurrentSession().createCriteria(FpsFdsNtfctn.class)
				.add(Restrictions.eq("ntfctnId", sentEventId)).uniqueResult();

	}
	@Override
	public FpsFdsNtfctnMdcd findMdcdSentEvent(Integer sentEventId) {
		return (FpsFdsNtfctnMdcd) getCurrentSession().createCriteria(FpsFdsNtfctnMdcd.class)
				.add(Restrictions.eq("ntfctnId", sentEventId)).uniqueResult();

	}
	@Override
	public void updateNotification(Integer sentEventId, boolean success) {
		FpsFdsNtfctn n = findSentEvent(sentEventId);
		n.setAudtUpdtId("FPS");
		n.setAudtUpdtTs(new Date());
		if (success) {
			n.setNtfctnSucsflInd("Y");
		} else {
			n.setNtfctnCnt(n.getNtfctnCnt() + 1);
			n.setNtfctnSucsflInd("N");
		}
		getCurrentSession().save(n);

	}

	@Override
	public List<FpsAsrptInvstgtn> findUcmInvestigations(String caseId) {
		Criteria c = getCurrentSession().createCriteria(FpsAsrptInvstgtn.class)
				.add(Restrictions.eq("extrnlCaseId", caseId));

		return c.list();
	}

	@Override
	public void deleteUcmCases(String caseId) {
		deleteUcmCases(caseId, ApiDeleteActionType.ALL, null);
	}

	@Override
	public void deleteUcmCases(String caseId, ApiDeleteActionType deleteType, Integer investId) {
		deleteUcmCases(caseId, deleteType, investId, null);
	}
	@Override
	public void deleteStandaloneUcmRecord(String caseId, ApiDeleteActionType deleteType, String npi, String eventId) {
		if (ApiDeleteActionType.ALL.equals(deleteType) || ApiDeleteActionType.ACTION.equals(deleteType)) {
			String sql = "update FpsAsrptUserAdminvActn set recChgInd = 'R',  audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId";
			
			if (ApiDeleteActionType.ACTION.equals(deleteType)) {
				sql+=" and asrptSubjId = :npi";
			}
			if (eventId != null) {
				sql+=" and ucmEvntId = :eventId";
			}
			Query q4 = getCurrentSession().createQuery(
					sql);
			q4.setParameter("caseId", caseId);
			q4.setParameter("newdate", new Date());
			if (ApiDeleteActionType.ACTION.equals(deleteType)) {
				q4.setParameter("npi", npi);
			}
			if (eventId != null) {
				q4.setParameter("eventId", eventId);
			}
			int result4 = q4.executeUpdate();
		}
	}
	@Override
	public void deleteUcmCases(String caseId, ApiDeleteActionType deleteType, Integer investId, String eventId) {
		if (ApiDeleteActionType.ALL.equals(deleteType) || ApiDeleteActionType.PARENT.equals(deleteType)) {
			String sql = "update FpsAsrptInvstgtn set recChgInd = 'R', actvInd = 'N', audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId";
			Query q1 = getCurrentSession().createQuery(sql);
			q1.setParameter("caseId", caseId);
			q1.setParameter("newdate", new Date());
			int result1 = q1.executeUpdate();

			Query q2 = getCurrentSession().createQuery(
					"update FpsAsrptUserInvstgtn set recChgInd = 'R', audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId");
			q2.setParameter("caseId", caseId);
			q2.setParameter("newdate", new Date());

			int result2 = q2.executeUpdate();
		}
		if (ApiDeleteActionType.ALL.equals(deleteType) || ApiDeleteActionType.RULING.equals(deleteType)) {
			String sql = "update FpsAsrptUserRulng set recChgInd = 'R',  audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId ";
			if (ApiDeleteActionType.RULING.equals(deleteType)) {
				sql+=" and fpsAsrptInvstgtn.asrptInvstgtnId = :id";
			}
			if (eventId != null) {
				sql+=" and ucmEvntId = :eventId";
			}
			Query q3 = getCurrentSession().createQuery(
					sql);
			q3.setParameter("caseId", caseId);
			q3.setParameter("newdate", new Date());
			if (ApiDeleteActionType.RULING.equals(deleteType)) {
				q3.setParameter("id", investId);
			}
			if (eventId != null) {
				q3.setParameter("eventId", eventId);
			}
			int result3 = q3.executeUpdate();
		}
		if (ApiDeleteActionType.ALL.equals(deleteType) || ApiDeleteActionType.ACTION.equals(deleteType)) {
			String sql = "update FpsAsrptUserAdminvActn set recChgInd = 'R',  audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId";
			
			if (ApiDeleteActionType.ACTION.equals(deleteType)) {
				sql+=" and fpsAsrptInvstgtn.asrptInvstgtnId = :id";
			}
			if (eventId != null) {
				sql+=" and ucmEvntId = :eventId";
			}
			Query q4 = getCurrentSession().createQuery(
					sql);
			q4.setParameter("caseId", caseId);
			q4.setParameter("newdate", new Date());
			if (ApiDeleteActionType.ACTION.equals(deleteType)) {
				q4.setParameter("id", investId);
			}
			if (eventId != null) {
				q4.setParameter("eventId", eventId);
			}
			int result4 = q4.executeUpdate();
		}
		if (ApiDeleteActionType.ALL.equals(deleteType) || ApiDeleteActionType.BARRIER.equals(deleteType)) {
			String sql = "update FpsAsrptUserActnBrr set recChgInd = 'R',  audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId";
			
			if (ApiDeleteActionType.ACTION.equals(deleteType)) {
				sql+=" and fpsAsrptInvstgtn.asrptInvstgtnId = :id";
			}
			if (eventId != null) {
				sql+=" and ucmEvntId = :eventId";
			}
			Query q4 = getCurrentSession().createQuery(
					sql);
			q4.setParameter("caseId", caseId);
			q4.setParameter("newdate", new Date());
			if (ApiDeleteActionType.ACTION.equals(deleteType)) {
				q4.setParameter("id", investId);
			}
			if (eventId != null) {
				q4.setParameter("eventId", eventId);
			}
			int result4 = q4.executeUpdate();
		}
		if (ApiDeleteActionType.ALL.equals(deleteType) || ApiDeleteActionType.ACTIVITY.equals(deleteType)) {
			String sql = "update FpsAsrptUserActvty set recChgInd = 'R', audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId";
			if (ApiDeleteActionType.ACTIVITY.equals(deleteType)) {
				sql+=" and fpsAsrptInvstgtn.asrptInvstgtnId = :id";
			}
			if (eventId != null) {
				sql+=" and ucmEvntId = :eventId";
			}
			Query q5 = getCurrentSession().createQuery(
					sql);
			q5.setParameter("caseId", caseId);
			q5.setParameter("newdate", new Date());
			if (ApiDeleteActionType.ACTIVITY.equals(deleteType)) {
				q5.setParameter("id", investId);
			}
			if (eventId != null) {
				q5.setParameter("eventId", eventId);
			}
			int result5 = q5.executeUpdate();
		}
		if (ApiDeleteActionType.ALL.equals(deleteType) || ApiDeleteActionType.USEFUL.equals(deleteType)) {
			String sql = "update FpsUserModelUsflns set recChgInd = 'R',  audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId";
			if (eventId != null) {
				sql+=" and ucmEvntId = :eventId";
			}
			Query q6 = getCurrentSession().createQuery(sql);
			q6.setParameter("caseId", caseId);
			q6.setParameter("newdate", new Date());
			
			if (eventId != null) {
				q6.setParameter("eventId", eventId);
			}
			int result6 = q6.executeUpdate();
		}
		if (ApiDeleteActionType.ALL.equals(deleteType) || ApiDeleteActionType.LINK.equals(deleteType)) {
			String sql = "update FpsAsrptUserLinkEvnt set recChgInd = 'R',  audtUpdtTs = :newdate, audtUpdtId = 'UCM' where extrnlCaseId = :caseId";
			if (ApiDeleteActionType.ACTIVITY.equals(deleteType)) {
				sql+=" and asrptInvstgtnId = :id";
			}
			if (eventId != null) {
				sql+=" and ucmEvntId = :eventId";
			}
			Query q7 = getCurrentSession().createQuery(sql
					);
			q7.setParameter("caseId", caseId);
			q7.setParameter("newdate", new Date());
			if (ApiDeleteActionType.ACTIVITY.equals(deleteType)) {
				q7.setParameter("id", investId);
			}
			if (eventId != null) {
				q7.setParameter("eventId", eventId);
			}
			int result7 = q7.executeUpdate();
		}

	}

	@Override
	public List<FpsRulngRsnRfrnc> findRulingReasonByDesc(String value) {
//		Waste, Billing Error
//		Unconfirmed Allegations - Not substantiated by additional data analysis
//		Unconfirmed Allegations - No policy could be identified
//		Unconfirmed Allegations - Peer Comparison determination that provider was within norm
//		Unconfirmed Allegations - Other
//		Low Return - Dollars not significant
//		Low Return - Low priority
//		Low Return - Other
//		Services Validated - Services documented in beneficiary interviews
//		Services Validated - Services documented in medical records
//		Services Validated - Provider is an outlier due to specialized beneficiary population
//		Services Validated - Physician Identified as Medical Director
//		Services Validated - Qualified Personnel Render Services for Physician
//		Services Validated - Signed Attestation Available
//		Services Validated - Other
//		Corroborated
//		Agumented/Expedited
		if (value == null) {
			return null;
		}
		String[] valueArr = value.contains(":") ? value.split(":") : value.split("-");
		String shortCd = valueArr[0].trim();
		String longCd = valueArr.length > 1 ? valueArr[1].trim() : shortCd;
		return getCurrentSession().createCriteria(FpsRulngRsnRfrnc.class)
				.add(Restrictions.eq("rulngRsnPrnt", shortCd).ignoreCase())
				.add(Restrictions.eq("rulngRsnDesc", longCd).ignoreCase()).list();
	}

	@Override
	public void processZoneRestriction(FpsPrvdrZnRstctnDtlFact zr) {
		getCurrentSession().merge(zr);

	}

	@Override
	public FpsPrvdrZnRstctnDtlFact loadZoneRestriction(String npi) {
		Criteria c = getCurrentSession().createCriteria(FpsPrvdrZnRstctnDtlFact.class)
				.add(Restrictions.eq("npiNum", npi));
		List<FpsPrvdrZnRstctnDtlFact> zprs = c.list();
		// somehow duplicate ZPRs started getting added after UCM NG go-live.
		// This is a workaround for now while investigating.
		return (zprs != null && zprs.size() > 0 ? zprs.get(0) : null);

	}

	@Override
	public void deleteZoneRestriction(FpsPrvdrZnRstctnDtlFact zr) {
		getCurrentSession().delete(zr);

	}

	@Override
	public void updateAsrUcmLink(String ucmAsr, String npi) {
		Query q1 = getCurrentSession()
				.createQuery("update FpsAsrpt set ucmAsrId = :ucmAsr, audtUpdtTs = audtUpdtTs where subjId = :npi")
				.setString("npi", npi).setString("ucmAsr", ucmAsr);
		int ct = q1.executeUpdate();

	}
	@Override
	public void updateMdcdAsrUcmLink(String ucmAsr, String npi) {
		Query q1 = getCurrentSession()
				.createQuery("update FpsAsrptMdcd set ucmAsrId = :ucmAsr, audtUpdtTs = audtUpdtTs where subjId = :npi")
				.setString("npi", npi).setString("ucmAsr", ucmAsr);
		int ct = q1.executeUpdate();

	}
	@Override
	public FpsAsrptUserActvty loadActivityByUcmId(String ucmId) {
		Query q1 = getCurrentSession().createQuery("from FpsAsrptUserActvty where ucmEvntId = :ucmId")
				.setString("ucmEvntId", ucmId);
		List<FpsAsrptUserActvty> l = q1.list();
		if (l.size() > 0) {
			if (l.size() > 1) {
				logger.warning("Multiple records exist for activity " + ucmId);
			}
			return l.get(0);
		}
		return null;
	}

	@Override
	public FpsAsrptUserAdminvActn loadActionByUcmId(String ucmId) {
		Query q1 = getCurrentSession().createQuery("from FpsAsrptUserAdminvActn where ucmEvntId = :ucmId")
				.setString("ucmEvntId", ucmId);
		List<FpsAsrptUserAdminvActn> l = q1.list();
		if (l.size() > 0) {
			if (l.size() > 1) {
				logger.warning("Multiple records exist for action " + ucmId);
			}
			return l.get(0);
		}
		return null;
	}

	@Override
	public void refreshMqt(String table) {
		getCurrentSession().createSQLQuery("refresh TABLE fps2." + table).executeUpdate();

	}

	@Override
	public List<FpsAsrpt> findNewApsAsrs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<FpsAsrpt> findFollowUpAsrs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertSys(FpsFdsSysRfrnc sys) {
		getCurrentSession().save(sys);
		getCurrentSession().flush();

	}

	@Override
	public void autoPruneExclusionLists() {
		Query q1 = getCurrentSession().createQuery(
				"update FpsPrioritizationExclsnItem set actvInd = 'N', audtUpdtTs = current_timestamp() , audtUpdtId='SYSTEM', actvUpdtTs = current_timestamp() , actvUpdtId='SYSTEM', actvUpdtRsn = 'auto prune' where rollOffDt is not null and rollOffDt < current_date()  and actvInd = 'Y' ");
		int ct = q1.executeUpdate();
		logger.info(ct + " exclusion(s) inactivated due to roll off date");

	}

	@Override
	public List<String> loadZonesByAsrptId(Integer asrptId) {
		List<String> rawJurisdictions = getCurrentSession()
				.createSQLQuery("select jurisdiction from fps2.FPS_ASRPT_RPT_FILTER_JURISDICTION where asrpt_id = :asrptId")
				.setInteger("asrptId", asrptId).list();

		return rawJurisdictions;
	}

	@Override
	public void insertWatchlistItem(FpsApsWatchlist wl) {
		List<Object> existing = getCurrentSession().createCriteria(FpsApsWatchlistRoot.class)
				.add(Restrictions.eq("asrptId", wl.getAsrptId())).add(Restrictions.eq("sbscrptnId", wl.getSbscrptnId()))
				.list();
		// only write the record if it hasn't been written.
		if (existing == null || existing.size() == 0) {
			FpsApsWatchlistRoot root = new FpsApsWatchlistRoot(wl.getSbscrptnId(), wl.getAsrptId(), wl.getAudtInsrtTs(), wl.getAudtInsrtId(), wl.getIdentityId(), wl.getIdentityCrimId(), wl.getUpdatedDt(), wl.getRefreshDt());
			getCurrentSession().save(root);
		}
	}

	@Override
	public Set<Object> submitCustomASRRequest(FpsUser user, List<Object> asrptIds) {
		// check if any ASRs exist, ignore them
		List<Object[]> existingAsrList = new ArrayList<Object[]>();

		Criteria c2 = getCurrentSession().createCriteria(FpsAsrpt.class, "asr");
		boolean isNpi = true;

		c2.add(Restrictions.in("asr.subjId", asrptIds));
		c2.setProjection(Projections.property("asr.subjId"));

		existingAsrList = c2.list();
		Set<Object> existingAsrs = new HashSet<>();
		for (Object o : existingAsrList) {
			existingAsrs.add(o);
		}
		// if all ASRs exists, return

		// insert subscription

		// insert into custom ASR parent table
		FpsCustomAsrList list = new FpsCustomAsrList();
		list.setListNm("Custom ASR Request");
		list.setActvInd("Y");
		list.setAudtInsrtId(user.getUserId());
		list.setUserNm(user.getUserId());
		list.setUserJrsdctn(user.getBusinessCategory());
		list.setAudtInsrtTs(new Date());
		// insert into custom ASR child table
		for (Object id : asrptIds) {
			FpsCustomAsrListItem item = new FpsCustomAsrListItem();
			item.setFpsCustomAsrList(list);
			item.setAudtInsrtId(user.getUserId());
			item.setPrvdrNpiNum(id.toString());
			item.setAudtInsrtTs(new Date());
		}
		// return any ASRs that exist to alert the user
		return existingAsrs;
	}

	@Override
	public boolean isInsightEngineRunning() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void markCustomAsrListAsProcessed(Integer listId) {
		getCurrentSession().createQuery(
				"update FpsCustomAsrList set recChgInd = 'R', audtUpdtTs = :newdate, audtUpdtId = 'SYSTEM' where customAsrListId = :listId")
				.setParameter("newdate", new Date()).setParameter("listId", listId).executeUpdate();

	}

	@Override
	public List<NvUcmSummary> findUcmSummaryForNpis(List<String> npis) {
		List<Object[]> zrs = getCurrentSession().createSQLQuery("select " + "a.PRVDR_NPI_NUM, "
				+ "a.UCM_ZR_STATUS_TXT, " + "a.UCM_CASE_STATUS, "
				+ "	case when   UCM_LEAD_CNT > 0 then 'Y' else 'N' end LEAD_IND				"
				+ "from fps2.FPS_PRIORITIZATION_UCM_ITEMS_VW a " + "left  join lateral ( select "
				+ "   prvdr_npi_num,sum(LEAD_CNT) UCM_LEAD_CNT "
				+ "   from fps2.FPS_PRIORITIZATION_WKLY_DATASET_JURISDICTION_ITEM_VW b " + "   where UCM_LEAD_IND = 'Y' "
				+ "   AND b.prvdr_npi_num = a.prvdr_npi_num group by prvdr_npi_num) UCM2 on ucm2.prvdr_npi_num = a.prvdr_npi_num "
				+ "where a.PRVDR_NPI_NUM in   :npis").setParameterList("npis", npis).list();
		List<NvUcmSummary> zrData = new ArrayList<>();
		for (Object[] zr : zrs) {
			NvUcmSummary item = new NvUcmSummary();
			item.setNpi(zr[0].toString());
			if (zr[1] != null) {
				item.setZrStatus(zr[1].toString());
			}
			if (zr[2] != null) {
				item.setCaseStatus(zr[2].toString());
			}
			if (zr[3] != null) {
				item.setLeadInd(zr[3].toString());
			}
			zrData.add(item);

		}
		return zrData;
	}

	@Override
	public void checkForExpiredExclusionSets() {
		// deactivate categories
		String step1 = "MERGE INTO  FPS2.FPS_PRIORITIZATION_EXCLSN_ITEM_CTGRY_ASCTN src " + "USING " + "  ( "
				+ "     select PRIORITIZATION_EXCLSN_ITEM_ID, " + "            EXCLSN_CTGRY_CD, "
				+ "            REMOVAL_RSN " + "     from fps2.fps_exclsn_auto_remove_items_to_update_vw " + " "
				+ "  ) trg " + "on src.PRIORITIZATION_EXCLSN_ITEM_ID = trg.PRIORITIZATION_EXCLSN_ITEM_ID "
				+ "  and src.EXCLSN_CTGRY_CD = trg.EXCLSN_CTGRY_CD " + "WHEN MATCHED THEN " + "  UPDATE set "
				+ "      actv_ind = 'N', " + "      actv_updt_ts = localtimestamp, " + "      actv_updt_id = 'FPS', "
				+ "      actv_updt_rsn = 'CONDITION NO LONGER APPLICABLE: ' || trg.removal_rsn, "
				+ "      audt_updt_id = 'FPS', " + "      audt_updt_ts = localtimestamp ";
		int step1Cnt = getCurrentSession().createSQLQuery(step1).executeUpdate();
		logger.info(step1Cnt + " ASR exclusion categories removed from exclusion sets due to data changes");
		// deactivate exclusion if all categories are deactivated
		String step2 = "update FPS2.FPS_PRIORITIZATION_EXCLSN_ITEM " + "set   actv_ind = 'N', "
				+ "      actv_updt_ts = localtimestamp, " + "      actv_updt_id = 'FPS', "
				+ "      actv_updt_rsn = 'CONDITION NO LONGER APPLICABLE', " + "      audt_updt_id = 'FPS', "
				+ "      audt_updt_ts = localtimestamp " + "where PRIORITIZATION_EXCLSN_ITEM_ID in " + "( "
				+ "select  ei.PRIORITIZATION_EXCLSN_ITEM_ID " + "from FPS2.FPS_PRIORITIZATION_EXCLSN_ITEM  EI "
				+ "inner join FPS2.FPS_PRIORITIZATION_EXCLSN_ITEM_CTGRY_ASCTN eca "
				+ "  on ei.PRIORITIZATION_EXCLSN_ITEM_ID = eca.PRIORITIZATION_EXCLSN_ITEM_ID "
				+ "where ei.actv_ind = 'Y' " + "group by ei.PRIORITIZATION_EXCLSN_ITEM_ID "
				+ "having sum (case when eca.actv_ind = 'Y' then 1 else 0 end) = 0 " + ")";
		int step2Cnt = getCurrentSession().createSQLQuery(step2).executeUpdate();
		logger.info(step2Cnt + " ASRs removed from exclusion sets due to data changes");

	}
	@Override
	public void updateCrosswalk() {
		// deactivate categories
		String step1 =	"MERGE INTO FPS2.FPS_ASRPT_ID_XWALK T " +
				"				USING " +
				"				(SELECT DISTINCT " +
				"				        a.ASRPT_ID, " +
				"				        a.subj_id, " +
				"				        a.UCM_ASR_ID " +
				"				FROM FPS2.fps_asrpt a " +
				" " +
				"				) AS S " +
				"				ON   T.subj_id = S.subj_id " +
				"				WHEN NOT MATCHED THEN " +
				"				      INSERT ( " +
				"				              MDCR_ASRPT_ID, " +
				"				              subj_id, " +
				"				              UCM_ASR_ID, " +
				"				              AUDT_INSRT_ID, " +
				"				              AUDT_INSRT_TS) " +
				"				       VALUES ( " +
				"				              S.ASRPT_ID, " +
				"				              S.subj_id, " +
				"				              S.UCM_ASR_ID, " +
				"				               'SYSTEM', " +
				"				                localtimestamp) " +
				"				WHEN  MATCHED THEN " +
				"					UPDATE set   MDCR_ASRPT_ID = s.ASRPT_ID, AUDT_UPDT_ID = 'SYSTEM', AUDT_UPDT_TS = localtimestamp " +
				"				  ELSE IGNORE  ; ";
		int step1Cnt = getCurrentSession().createSQLQuery(step1).executeUpdate();
		logger.info(step1Cnt + " medicare ASR crosswalk entries updated");
		// deactivate exclusion if all categories are deactivated
		String step2 = 				 " MERGE INTO FPS2.FPS_ASRPT_ID_XWALK T " +
				"				USING " +
				"				(SELECT DISTINCT " +
				"				        a.ASRPT_ID, " +
				"				        a.subj_id, " +
				"				        a.UCM_ASR_ID " +
				"				FROM FPS2.FPS_ASRPT_MDCD a " +
				" " +
				"				) AS S " +
				"				ON   T.subj_id = S.subj_id " +
				"				WHEN NOT MATCHED THEN " +
				"				      INSERT ( " +
				"				              MDCD_ASRPT_ID, " +
				"				              subj_id, " +
				"				              AUDT_INSRT_ID, " +
				"				              AUDT_INSRT_TS) " +
				"				       VALUES ( " +
				"				              S.ASRPT_ID, " +
				"				              S.subj_id, " +
				"				               'SYSTEM', " +
				"				                localtimestamp) " +
				"				WHEN  MATCHED THEN " +
				"					UPDATE set   MDCD_ASRPT_ID = s.ASRPT_ID, AUDT_UPDT_ID = 'SYSTEM', AUDT_UPDT_TS = localtimestamp " +
				"				  ELSE IGNORE  ; ";;
		int step2Cnt = getCurrentSession().createSQLQuery(step2).executeUpdate();
		logger.info(step2Cnt + " medicaid ASR crosswalk entries updated");

	}
	@Override
	public List<String> getOnePiCasesForAsrs() {
		String sql = " with known_cases as( " + " select distinct asr.asrpt_id, invstgtn.extrnl_case_id  "
				+ " from fps2.fps_asrpt_invstgtn invstgtn inner join fps_asrpt asr on invstgtn.asrpt_id = asr.asrpt_id "
				+ " inner join fps2.fps_asrpt_alert_asctn aaa on asr.asrpt_id = aaa.asrpt_id "
				+ " inner join fps2.fps_alert al on aaa.alert_id = al.alert_id "
				+ " inner join fps2.fps_Stus_rfrnc stus_rfrnc on invstgtn.stus_cd = stus_rfrnc.stus_cd where invstgtn.actv_ind = 'Y' and invstgtn.rec_chg_ind = 'A' and invstgtn.extrnl_case_id is not null "
				+ " and date(to_date(case when cast(substring(extrnl_case_id,5,2) as integer) >90 then '19' else '20' end || substring(extrnl_case_id,5,6)  ,'YYYYMMDD')) > asr.asrpt_Creat_dt - interval '180 days' "
				+ " and alert_Creat_dt > current date - 2 years) "
				+ " select distinct  opi.ucm_case_Rec_id  from fps_asrpt_opi_ucm_fraud_case opi left join known_cases on opi.asrpt_id = known_cases.asrpt_id and opi.ucm_case_rec_id = known_cases.extrnl_case_id ";
		List<String> results = getCurrentSession().createSQLQuery(sql).list();

		return results;
	}

	@Override
	public FpsFdsEvntTransMdcd setMdcdEventAsPublished(FpsFdsEvntTransMdcd dbEvent) {
		dbEvent = (FpsFdsEvntTransMdcd) getCurrentSession().load(FpsFdsEvntTransMdcd.class, dbEvent.getEvntTransId());
		dbEvent.setNtfctnStusCd("11");
		dbEvent.setAudtUpdtId("FPS");
		dbEvent.setAudtUpdtTs(new Date());
		getCurrentSession().merge(dbEvent);
		getCurrentSession().flush();
		return dbEvent;
	}

	@Override
	public void updateMdcdNotification(Integer sentEventId, boolean success) {
		FpsFdsNtfctnMdcd n = findMdcdSentEvent(sentEventId);
		n.setAudtUpdtId("FPS");
		n.setAudtUpdtTs(new Date());
		if (success) {
			n.setNtfctnSucsflInd("Y");
		} else {
			n.setNtfctnCnt(n.getNtfctnCnt() + 1);
			n.setNtfctnSucsflInd("N");
		}
		getCurrentSession().save(n);
		
	}

	@Override
	public List<FpsFdsEvntTransMdcd> findMdcdEvents(EventType type) {
		Criteria c = getCurrentSession().createCriteria(FpsFdsEvntTransMdcd.class)
				.add(Restrictions.eq("ntfctnStusCd", "12"));
		if (type != null) {
			c.add(Restrictions.eqOrIsNull("evntTypeCd", type.name()));
		}
		c.add(Restrictions.eq("objTypeCd", "PR"));

		return c.list();
	}

	@Override
	public List<FpsFdsNtfctnMdcd> findMdcdSentEvents(Integer eventId, String systemID) {
		return getCurrentSession().createCriteria(FpsFdsNtfctnMdcd.class).add(Restrictions.eq("evntTransId", eventId))
				.add(Restrictions.eq("toSysId", systemID)).list();
	}

	@Override
	public FpsFdsNtfctnMdcd insertMdcdSentNotification(FpsFdsNtfctnMdcd dbNot) {
		getCurrentSession().save(dbNot);
		return dbNot;
	}

}
