/*
 * 
 */
package gov.hhs.cms.fps.dao;

import gov.hhs.cms.fps.model.generated.FpsPrvdr;
import gov.hhs.cms.fps.model.generated.FpsPrvdrPrflDtl;

public interface FpsProviderDao {
	public FpsPrvdr loadProvider(String npi);
	public FpsPrvdrPrflDtl loadProviderProfile(String npi);
	
	
	

}
