/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.generated.FpsPrvdr;
import gov.hhs.cms.fps.model.generated.FpsPrvdrPrflDtl;
@Repository("providerDao")
public class FpsProviderDaoImpl extends BaseDao<Integer, FpsPrvdr> implements FpsProviderDao {

	@Override
	public FpsPrvdr loadProvider(String npi) {
		Criteria c = getCurrentSession().createCriteria(FpsPrvdr.class)
				.add(Restrictions.eq("prvdrNpiNum", npi));
		List<?> l = c.list();
		if (l != null && l.size() > 0){
			return (FpsPrvdr) l.get(0);
		}
		return new FpsPrvdr();
	}

	@Override
	public FpsPrvdrPrflDtl loadProviderProfile(String npi) {
		Criteria c = getCurrentSession().createCriteria(FpsPrvdrPrflDtl.class)
				.add(Restrictions.eq("prfldPrvdrNpiNum", npi));
		List<?> l = c.list();
		if (l != null && l.size() > 0){
			return (FpsPrvdrPrflDtl) l.get(0);
		}
		return new FpsPrvdrPrflDtl();
	

	}



}
