/*
 * 
 */
package gov.hhs.cms.fps.dao;

import java.util.Date;
import java.util.List;

import gov.hhs.cms.fps.model.FpsUserPreference;
import gov.hhs.cms.fps.model.PortalTrackingResult;
import gov.hhs.cms.fps.model.generated.FpsPortalActvtyHstry;
import gov.hhs.cms.fps.model.generated.FpsPortalSrchHstry;
import gov.hhs.cms.fps.model.generated.FpsUsrGuiPrfrnc;

public interface FpsTrackingDao {
	public void  logTracking(FpsPortalActvtyHstry h);
	public void  logSearch(FpsPortalSrchHstry h);
	public List<PortalTrackingResult> getSearchHistory(boolean withZone);

	List<PortalTrackingResult> getActivityHistory(boolean withZone, Date thedate);
	List<PortalTrackingResult> getActivityHistory(boolean withZone);
	public FpsUsrGuiPrfrnc saveUserPrefs(FpsUserPreference request);
	FpsUsrGuiPrfrnc loadUserPrefs(String userId, String prefName);
	void clearUserPrefs(String userId, String prefName);
	List<PortalTrackingResult> getSearchHistory(boolean withZone, Date thedate);
	public FpsUsrGuiPrfrnc loadUserPrefs(Integer listId);
	FpsUsrGuiPrfrnc loadUserPrefs(String userId, String prefName, String prefLbl);

}
