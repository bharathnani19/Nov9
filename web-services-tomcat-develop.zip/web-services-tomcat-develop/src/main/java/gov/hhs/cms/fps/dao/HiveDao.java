package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.AsrDetailClaimLineItem;

public interface HiveDao {

	public List<AsrDetailClaimLineItem> test();
}
