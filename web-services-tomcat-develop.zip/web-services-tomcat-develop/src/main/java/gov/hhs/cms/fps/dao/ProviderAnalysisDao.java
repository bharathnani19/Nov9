package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.ExclusionSet;
import gov.hhs.cms.fps.model.ExclusionSetItem;
import gov.hhs.cms.fps.model.FpsUser;
import gov.hhs.cms.fps.model.FpsWorkbenchAction;
import gov.hhs.cms.fps.model.FpsWorkbenchList;
import gov.hhs.cms.fps.model.PrioritizationShareGroup;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationExclsnItem;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationList;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationListItem;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationShareGrp;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationShareGrpUserAsctn;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlys;
import gov.hhs.cms.fps.model.generated.FpsUsrGuiPrfrnc;
import gov.hhs.cms.fps.model.hub.FpsAsrUser;
import gov.hhs.cms.fps.util.FpsEnums.ModelProgram;
import gov.hhs.cms.fps.util.FpsEnums.WorkbenchListType;


public interface ProviderAnalysisDao {
	

	public List<FpsPrioritizationList> loadAsrListsByUser(FpsUser user);
	public FpsPrioritizationList  loadAsrListByListId(Integer listId);
	public FpsPrioritizationList  pruneList(Integer listId, FpsWorkbenchAction itemId, String userId);
	public Integer  saveAsList(FpsPrioritizationList list);
	public FpsPrioritizationList  addToList(Integer listId, FpsWorkbenchAction items, String userId);
	public FpsPrioritizationList  addToList(Integer listId, ExclusionSet items, String userId);
	public FpsPrioritizationList renameList(Integer listId, FpsPrioritizationList list, WorkbenchListType type);
	public Integer saveListGroup(PrioritizationShareGroup grp, String shareUserId);
	public List<FpsPrioritizationShareGrpUserAsctn> loadGroupMembers(Integer groupId);
	public List<FpsUser> loadOpenAmUsers();
	public List<FpsUser> loadOpenAmUsersMdcd();
	public FpsUser loadOpenAmUser(String userId);
	public List<FpsUsrGuiPrfrnc> getSavedSearchesForUser(String userId);
	List<FpsWorkbenchList> loadAsrNamesListsByUser(String userId);
	FpsPrioritizationShareGrp loadSharedUsers(Integer listId);
	Integer saveSearchGroup(PrioritizationShareGroup grp, String shareUserId);
	void markAsrAsPrioritized(Integer listItemId, String userId);
	public void deleteList(Integer listId, String userId);
	List<Integer> loadAsrIdsByListId(Integer listId);
	public FpsUsrGuiPrfrnc loadSavedSearchBySearchId(Integer listId);
	public void deleteSearch(Integer listId, String userId);
	public Integer findExclusionListByUserId(String userId);
	public List<FpsPrioritizationExclsnItem> loadExclusionListHistoryByAsrId(Integer asrptId, String userId,
			String businessCategory);
	public List<FpsPrvdrAnlys> loadPicExclusionList();
	public void pruneExclusionList(Integer listId, FpsWorkbenchAction item, String userId);
	public void updateExclusion(Integer listId, ExclusionSetItem item, String userId);
	public void toggleExclusionSetVisibility(String userId, boolean toggle);
	List<Integer> loadExcludedAsrIdsByListId(Integer listId);
	public void archiveList(Integer groupId, String userId);
	public void markAsrAsPrioritizedMdcd(Integer listItemId, String auditId);
	List<FpsPrioritizationList> loadAsrListsByUser(FpsUser user, boolean mdcd);
	List<FpsUsrGuiPrfrnc> getSavedSearchesForUser(String userId, ModelProgram pgm);
	List<FpsWorkbenchList> loadAsrNamesListsByUser(String userId, String type);
	List<FpsUsrGuiPrfrnc> getP1SavedSearch(String userId, String searchName);

}
