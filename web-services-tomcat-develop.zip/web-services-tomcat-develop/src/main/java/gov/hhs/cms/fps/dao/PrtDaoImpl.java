package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsFilStore;
import gov.hhs.cms.fps.model.generated.prt.FpsAfctdSysRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsClmCntRngRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsCmsCreqRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsDfctCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsIssCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsMacJrsdctnRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsPrblmAfctdSys;
import gov.hhs.cms.fps.model.generated.prt.FpsPrblmCmsCreq;
import gov.hhs.cms.fps.model.generated.prt.FpsPrblmPrrtyRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsProdnPrblmRpt;
import gov.hhs.cms.fps.model.generated.prt.FpsProdnPrblmRptOrgPoc;
import gov.hhs.cms.fps.model.generated.prt.FpsProdnPrblmRptStusRfrnc;
import gov.hhs.cms.fps.model.generated.prt.FpsRltdPrblm;

@Repository("prtDao")
public class PrtDaoImpl extends BaseDao<Integer, Object>  implements PrtDao {
	@Value("${prt.testMode}")
	private String testMode;
	private static Logger logger = Logger.getLogger(PrtDaoImpl.class.getName());

	@Override
	public List<FpsAfctdSysRfrnc> loadAffectedSystems(boolean hideDeleted) {
		String sql = "from FpsAfctdSysRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}
		sql +="order by afctdSysCd";
		return getCurrentSession().createQuery(sql).list();
	}
	@Override
	public List<FpsProdnPrblmRptOrgPoc> loadEmailPocs(boolean hideDeleted) {
		String sql = "from FpsProdnPrblmRptOrgPoc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}
		sql +="order by pocOrg,pocEmailAdr";
		return getCurrentSession().createQuery(sql).list();
	}
	@Override
	public List<FpsProdnPrblmRptStusRfrnc> loadStatuses(boolean hideDeleted) {
		String sql = "from FpsProdnPrblmRptStusRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}	
		sql +="order by prodnPrblmRptStusCd";
		return getCurrentSession().createQuery(sql).list();
	}
	@Override
	public List<FpsClmCntRngRfrnc> loadClaimCountRanges(boolean hideDeleted) {
		String sql = "from FpsClmCntRngRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}
		sql +="order by clmCntRngCd";
		return getCurrentSession().createQuery(sql).list();
	}

	@Override
	public List<FpsCmsCreqRfrnc> loadCmsCreqs(boolean hideDeleted) {
		String sql = "from FpsCmsCreqRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}
		sql +="order by creqDesc";
		return getCurrentSession().createQuery(sql).list();
	}

	@Override
	public List<FpsDfctCtgryRfrnc> loadDefectCategories(boolean hideDeleted) {
		String sql = "from FpsDfctCtgryRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}
		sql +="order by dfctCtgryDesc";
		return getCurrentSession().createQuery(sql).list();
	}

	@Override
	public List<FpsEditNumRfrnc> loadEditNumbers(boolean hideDeleted) {
		String sql = "from FpsEditNumRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd in ('N', 'Y') ";
		}
		sql +="order by fpsEditNum";
		return getCurrentSession().createQuery(sql).list();
	}

	@Override
	public List<FpsIssCtgryRfrnc> loadIssueCategories(boolean hideDeleted) {
		String sql = "from FpsIssCtgryRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}
		sql +="order by issCtgryDesc";
		return getCurrentSession().createQuery(sql).list();
	}

	@Override
	public List<FpsPrblmPrrtyRfrnc> loadProblemPriorities(boolean hideDeleted) {
		String sql = "from FpsPrblmPrrtyRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}
		sql +="order by prblmPrrtyCd";
		return getCurrentSession().createQuery(sql).list();
	}

	@Override
	public FpsProdnPrblmRpt loadPrt(Integer prtId) {
		return (FpsProdnPrblmRpt) getCurrentSession().load(FpsProdnPrblmRpt.class, prtId);
	}

	@Override
	public Integer savePrt(FpsProdnPrblmRpt prt) {
		if (prt.getProdnPrblmRptId() == null || prt.getProdnPrblmRptId() == 0){
			if (prt.getProdnPrblmRptId() != null  && prt.getProdnPrblmRptId() == 0) {
				logger.info("new prt ID is somehow 0, resetting");
				prt.setProdnPrblmRptId(null);
			}
			Integer id= (Integer) getCurrentSession().save(prt);
			logger.info("saved prt, returned id " + id + " before manual flush");
			getCurrentSession().flush();
			logger.info("saved prt, returned id " + prt.getProdnPrblmRptId() + " after manual flush");

			return id == 0 ? prt.getProdnPrblmRptId()  : id;
		}else{
			logger.info("updating prt, using id " + prt.getProdnPrblmRptId() );

			getCurrentSession().merge(prt);
			logger.info("updating prt, returned id " + prt.getProdnPrblmRptId() );
			getCurrentSession().flush();
			return prt.getProdnPrblmRptId();
		}
	}

	@Override
	public void deletePrt(Integer prtId) {
		int rows = getCurrentSession().createQuery("update FpsProdnPrblmRpt set actvInd = 'N' where prodnPrblmRptId = :id").setInteger("id", prtId).executeUpdate();
		
	}

	@Override
	public Integer saveFile(Integer id, String userId,MultipartFile file) throws IOException {
		FpsFilStore f =  new FpsFilStore();
		//f.setFilCntnt(file.getBytes());
		String name = file.getOriginalFilename();
		String mime = "application/octet-stream";
		if (name.toLowerCase().endsWith("pdf")){
			mime = "application/pdf";
		}else if (name.toLowerCase().endsWith("docx")){
			mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		}else if (name.toLowerCase().endsWith("xlsx")){
			mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		}else if (name.toLowerCase().endsWith("doc")){
			mime = "application/msword";
		}else if (name.toLowerCase().endsWith("xls")){
			mime = "application/vnd.ms-excel";
		}
		f.setFilType(mime);
		f.setFilName(file.getOriginalFilename());
		f.setFilSize(file.getSize()+"");
		f.setAppRecId(id);
		f.setAudtInsrtId(userId);
		f.setAudtInsrtTs(new Date());
		f.setAppName("PRT");
		f.setAppRecId(id);
		f.setActvInd('Y');
		Integer newId = (Integer) getCurrentSession().save(f);
		return newId;
		
	}
	@Override
	public Integer saveFile(Integer id, String userId,FpsFilStore f)  {
		//f.setFilCntnt(file.getBytes());
		String name = f.getFilName();
		String mime = "application/octet-stream";
		if (name.toLowerCase().endsWith("pdf")){
			mime = "application/pdf";
		}else if (name.toLowerCase().endsWith("docx")){
			mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		}else if (name.toLowerCase().endsWith("xlsx")){
			mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		}
		f.setFilType(mime);
		f.setFilName(f.getFilName());
		f.setFilSize(f.getFilSize()+"");
		f.setAppRecId(id);
		f.setAudtInsrtId(userId);
		f.setAudtInsrtTs(new Date());
		f.setAppName("PRT");
		f.setAppRecId(id);
		f.setActvInd('Y');
		Integer newId = (Integer) getCurrentSession().save(f);
		return newId;
		
	}

	@Override
	public FpsFilStore loadFile(Integer id) {
		FpsFilStore f = (FpsFilStore) getCurrentSession().load(FpsFilStore.class, id);

		return f;
	}
	@Override
	public List<FpsFilStore> deleteFile(Integer id, String userId) {
		getCurrentSession().createQuery("update FpsFilStore set actvInd = 'N', audtUpdtId = :userId"
				+ " where filStoreId= :id")
		.setInteger("id", id)
		.setString("userId", userId).executeUpdate();
		List<FpsFilStore> files = loadPrtFiles(id);
		return files;

		
	}
	@Override
	public void deleteDbFile(Integer id) {
		getCurrentSession().createQuery("delete from FpsFilStore where filStoreId= :id").setInteger("id", id).executeUpdate();

		
	}
	@Override
	public List<FpsFilStore> loadPrtFiles(Integer id) {
		return getCurrentSession().createQuery("from FpsFilStore where appRecId= :id and appName='PRT' and actvInd = 'Y'")
		.setInteger("id", id).list();

		
	}
	@Override
	public List<FpsMacJrsdctnRfrnc> loadMacs(boolean hideDeleted) {
		String sql ="from FpsMacJrsdctnRfrnc ";
		if (hideDeleted){
			sql +=" where actvInd = 'Y' ";
		}
		sql += "order by macJrsdctnCd";
		return getCurrentSession().createQuery(sql).list();
	}
	@Override
	public List<FpsProdnPrblmRptOrgPoc> loadContactsByOrg(String org){
		String searchOrg = "true".equals(testMode) ? "TEST" : org;
		return getCurrentSession().createQuery("from FpsProdnPrblmRptOrgPoc where actvInd = 'Y' and pocOrg = :org").setString("org",  searchOrg).list();
	}
	@Override
	public List<FpsProdnPrblmRpt> getPrtSummary() {
		// TODO Auto-generated method stub
		return getCurrentSession().createQuery("from FpsProdnPrblmRpt where actvInd = 'Y' order by coalesce(audtUpdtTs,audtInsrtTs) desc").list();
	}
	@Override
	public <T> T saveRefData(T target) {
		 getCurrentSession().merge(target);
//		 getCurrentSession().flush();
		 return target;
	}
	@Override
	public void deleteChildren(FpsProdnPrblmRpt dbPrt) {
		for (FpsPrblmAfctdSys affSys : dbPrt.getFpsPrblmAfctdSys()) {
			
			getCurrentSession().delete(affSys);
		}
		for (FpsPrblmCmsCreq req : dbPrt.getFpsPrblmCmsCreqs()) {
			
			getCurrentSession().delete(req);
		}
		for (FpsRltdPrblm rel : dbPrt.getFpsRltdPrblms()) {
			
			getCurrentSession().delete(rel);
		}
		
	}
	@Override
	public String loadStatusByCode(Integer statusCd){
		FpsProdnPrblmRptStusRfrnc ref = (FpsProdnPrblmRptStusRfrnc) getCurrentSession().get(FpsProdnPrblmRptStusRfrnc.class, statusCd);
		if (ref != null){
			return ref.getProdnPrblmRptStusDesc();
		}
		return "N/A";
	}
	@Override
	public <T> T deleteEntityData(T target) {
		getCurrentSession().delete(target);
		 return target;
	}

}
