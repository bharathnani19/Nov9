package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.generated.FpsActnBrrRfrnc;
import gov.hhs.cms.fps.model.generated.FpsActnTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsActvtyTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsAlertTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsAsrptStatMatVw;
import gov.hhs.cms.fps.model.generated.FpsCntrctrRfrnc;
import gov.hhs.cms.fps.model.generated.FpsEditNumRfrnc;
import gov.hhs.cms.fps.model.generated.FpsGeoStateRfrnc;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.model.generated.FpsModelMdcd;
import gov.hhs.cms.fps.model.generated.FpsModelSchmRfrnc;
import gov.hhs.cms.fps.model.generated.FpsModelSrvcCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrioritizationExclsnCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrtlAcsRqstGrpRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlysExclusionRfrnc;
import gov.hhs.cms.fps.model.generated.FpsPrvdrAnlysExclusionRfrncMdcd;
import gov.hhs.cms.fps.model.generated.FpsPrvdrSpcltyTypeRfrnc;
import gov.hhs.cms.fps.model.generated.FpsRulngRfrnc;
import gov.hhs.cms.fps.model.generated.FpsStateCntrctrInfo;
import gov.hhs.cms.fps.model.generated.FpsStusRfrnc;
import gov.hhs.cms.fps.model.generated.FpsZnRfrnc;
import gov.hhs.cms.fps.util.FpsEnums.ModelProgram;

public  interface ReferenceDataDao {
	public  List<FpsCntrctrRfrnc> loadContractorZones(boolean isMac, boolean isMedic);

	public  List<FpsCntrctrRfrnc> loadContractorZonesNoMAC();

	public  List<FpsZnRfrnc> loadZones();


	public  List<FpsAlertTypeRfrnc> loadAlertTypes();

	public  List<FpsModel> loadModels();
	public  List<FpsModelMdcd> loadMdcdModels();

	public  List<FpsActnBrrRfrnc> loadBarriers();

	public  List<String> doHealthCheck();

	public  List<FpsActvtyTypeRfrnc> loadActivities();

	public  List<FpsActnTypeRfrnc> loadActions();

	public  List<FpsGeoStateRfrnc> loadStates();

	public  List<FpsRulngRfrnc> loadRulings();

	public List<FpsCntrctrRfrnc> loadActualAssignedZones();

	public  List<FpsAsrptStatMatVw> loadCityStates();

	List<FpsModel> loadNonActiveModels();

	List<FpsModel> loadEditModels();

	public  List<FpsCntrctrRfrnc> loadPrioritizeZones();
	
	public  List<FpsStusRfrnc> loadPrioritizationTypes();
	public  List<FpsEditNumRfrnc> loadEdits();
	public  List<FpsPrvdrAnlysExclusionRfrnc> loadExclusions();

	public  List<FpsPrioritizationExclsnCtgryRfrnc> loadExclusionCategories();

	public List<FpsPrvdrSpcltyTypeRfrnc> loadSpecialties();

	public List<FpsStateCntrctrInfo> loadStatesForUpic(String upic);

	List<FpsModelSrvcCtgryRfrnc> loadVmtCategories(ModelProgram pgm);

	List<FpsModelSchmRfrnc> loadVmtSchemes();
	List<String> loadSearchModelSchemes();

	List<FpsPrvdrAnlysExclusionRfrncMdcd> loadExclusionsMdcd();

	public List<FpsPrtlAcsRqstGrpRfrnc> loadEmlRoles();
}
