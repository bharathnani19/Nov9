package gov.hhs.cms.fps.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import gov.hhs.cms.fps.model.AsrDetailClaimLineItem;
import gov.hhs.cms.fps.model.AvailableClaims;
import gov.hhs.cms.fps.model.ClaimsSearchParameter;
import gov.hhs.cms.fps.model.ClaimsSolrStream;
import gov.hhs.cms.fps.model.FpsCommonBeneficiary;
import gov.hhs.cms.fps.model.FpsVisualization;
import gov.hhs.cms.fps.model.FpsVisualizationEdge;
import gov.hhs.cms.fps.model.generated.FpsModel;
import gov.hhs.cms.fps.util.CsvHelper;
import gov.hhs.cms.fps.util.FpsEnums.SolrClaimType;

public interface SolrDao {

	List<AsrDetailClaimLineItem> testClaims();
	List<AsrDetailClaimLineItem> getClaimsForAlert(int modelId, String subjId, int asrptId);
	List<AsrDetailClaimLineItem> getClaimsForReportCard(short attrSqncNum, int alertId,int asrptId);
	List<AsrDetailClaimLineItem> getClaimsForReportCard(short attrSqncNum, int alertId,int asrptId, boolean isPartD);
//	List<AsrDetailClaimLineItem> getClaimsForAsr(Integer asrptId,List<String> claimTypes,
//			Date fromDate, Date toDate, List<String> hicns, boolean latestClaims, String subjId, int maxResults, int startAt);
	List<AsrDetailClaimLineItem> getClaimsForAsrPartD(Integer asrptId, int maxResults, int startAt);
	long getClaimsForReportCardCount(short attrSqncNum, int alertId,int asrptId);
	List<AsrDetailClaimLineItem> getClaimsFromSolr(Map<String, String> params);
	long getClaimsFromSolrCount(Map<String, String> p,SolrClaimType claimCollection);
	
//	long getClaimsForAsrCount(Integer asrptId,  List<String> claimTypes, Date fromDate, Date toDate,
//			List<String> hicns, boolean latestClaims, String subjId, SolrClaimType claimCollection, boolean searchAllNpis, boolean isRrb);
//	List<AsrDetailClaimLineItem> getClaimsForAsr(Integer asrptId, List<String> claimTypes, Date fromDate, Date toDate,
//			List<String> hicns, boolean latestClaims, String subjId,int startAt, int maxResults, boolean isCsv);
	List<FpsCommonBeneficiary> getHicnsForASR(int asrptId);
	List<FpsCommonBeneficiary> getHicnsForASR(String subjId);
	void getClaimsFromSolrCsv(Map<String, String> p, CsvHelper sb,SolrClaimType claimCollection);
//	void getClaimsForAsrCsv(Integer asrptId, List<String> claimTypes, Date fromDate, Date toDate, List<String> hicns,  boolean latestClaims, String subjId,
//			int maxResults, int startAt,CsvHelper sb,SolrClaimType claimCollection);
//	void getClaimsFromSolrCsvCursor(Map<String, String> params, CsvHelper sb, SolrClaimType claimCollection);
	void getClaimsFromSolrCsvCursor(Map<String, String> p, CsvHelper sb, SolrClaimType claimCollection, int pageSize);
	List<AsrDetailClaimLineItem> getClaimsForAlert(int modelId, String npi, int asrptId, int alertId);
//	byte[] getClaimsForAsrCsv(Integer asrptId, List<String> claimTypes, Date fromDate, Date toDate, List<String> hicns,
//			boolean isLatest, String subjId, int maxResults, int startAt, SolrClaimType claimCollection, boolean searchAllNpis, boolean isRrb);
	List<AsrDetailClaimLineItem> getClaimsFromSolr(Map<String, String> p, SolrClaimType claimsCollection);
	List<AsrDetailClaimLineItem> getClaimsForAlert(int modelId, String npi, int asrptId, int i, boolean isPartD);
	List<AsrDetailClaimLineItem> getClaimsForAlert(int modelId, String subjId, int asrptId, boolean isPartD);
	public FpsVisualization loadVisualization(String subjId, String modelId);
	FpsVisualization loadVisualization(String subjId, String modelId, Date modelRunDt);
	List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId);
	List<FpsVisualizationEdge> loadVisualizationDates(String subjId, String modelId, int rows);
	ClaimsSolrStream loadVizSharedBenes(FpsModel model, String npi, Date modelRunDt, List<String> relatedNPIs);
	long getClaimsForReportCardCount(short attrSqncNum, int alertId, int asrptId, boolean partD);
	FpsVisualization loadHhaVisualization(String subjId, Integer ranking);
	FpsVisualization loadDmeVisualization(String subjId, Integer ranking);
	byte[] getClaimsForReportCardCsv(short attrSqncNum, int alertId, int asrptId, boolean isPartD, int pageSize, int index);
	byte[] getClaimsForAlertCsv(int modelId, String subjId, int asrptId, int alertId, boolean isPartD, int maxResults, int startAt);
	long getClaimsForAlertCount(int modelId, String subjId, int asrptId, boolean partD);
	List<AsrDetailClaimLineItem> getClaimsForAsr(ClaimsSearchParameter param, int maxResults, int startAt);
	byte[] getClaimsForAsrCsv(ClaimsSearchParameter param, int maxResults, int startAt);
	long getClaimsForAsrCount(ClaimsSearchParameter param);
	String checkForVisualization(String subjId);
	String checkForDmeVisualization(String subjId);
	AvailableClaims getAvailableClaimsForAsr(Integer asrptId, String npi);

	
	
}
