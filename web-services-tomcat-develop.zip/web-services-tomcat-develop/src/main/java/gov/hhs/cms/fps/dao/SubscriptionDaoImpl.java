package gov.hhs.cms.fps.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.generated.FpsFdsNtfctn;
import gov.hhs.cms.fps.model.generated.FpsFdsSbscrptn;
import gov.hhs.cms.fps.model.hub.Event;

@Repository("SubscriptionDao")
public class SubscriptionDaoImpl  extends BaseDao<Integer, Object> implements SubscriptionDao {

	@Override
	public FpsFdsSbscrptn saveUpdateSubscription(FpsFdsSbscrptn s) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<FpsFdsSbscrptn> getSubscriptions(Event event) {
		// TODO Auto-generated method stub
		return getSubscriptions(event, null);
	}

	@Override
	public List<FpsFdsSbscrptn> getSubscriptions(Object entityId) {
		// TODO Auto-generated method stub
		return getSubscriptions(null, entityId);
	}

	@Override
	public List<FpsFdsSbscrptn> getSubscriptions(Event event, Object entityId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<FpsFdsNtfctn> getNewNotifications() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FpsFdsNtfctn insertEventNotification(FpsFdsNtfctn s) {
		getCurrentSession().save(s);
		return s;
	}

}
