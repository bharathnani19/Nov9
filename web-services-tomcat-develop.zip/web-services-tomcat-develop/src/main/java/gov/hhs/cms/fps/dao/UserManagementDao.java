package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.generated.FpsPrtlAcsRqst;
import gov.hhs.cms.fps.model.um.UserManagementRequest;

public interface UserManagementDao {

	UserManagementRequest saveRequest(UserManagementRequest request);

	UserManagementRequest updateRequest(UserManagementRequest request);

	FpsPrtlAcsRqst loadRequest(Integer requestId);

	List<FpsPrtlAcsRqst> loadRequests();

	void updateRequest(FpsPrtlAcsRqst currentRequest) throws Exception;

	FpsPrtlAcsRqst loadRequest(String userId);

	FpsPrtlAcsRqst loadRequestForNewRequest(String userId);

}
