package gov.hhs.cms.fps.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.model.FaqSearchParameter;
import gov.hhs.cms.fps.model.generated.faq.FpsUsrSprtQstn;
import gov.hhs.cms.fps.model.generated.faq.FpsUsrSprtQstnAcsHstry;
import gov.hhs.cms.fps.model.generated.faq.FpsUsrSprtQstnCtgryRfrnc;
import gov.hhs.cms.fps.model.generated.faq.FpsUsrSprtQstnSrchHstry;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
@Repository(value="userSupportDao")
public class UserSupportDaoImpl extends BaseDao<Integer,FpsUsrSprtQstn>implements UserSupportDao {

	@Override
	public FpsUsrSprtQstn loadQuestionById(Integer id) {
		// TODO Auto-generated method stub
		return (FpsUsrSprtQstn) getCurrentSession().get(FpsUsrSprtQstn.class, id);
	}

	@Override
	public List<FpsUsrSprtQstn> loadQuestionsByCategory(String ct) {
		// TODO Auto-generated method stub
		return (List<FpsUsrSprtQstn>) getCurrentSession().createCriteria(FpsUsrSprtQstn.class).add(Restrictions.eq("usrSprtQstnCtgryCd", ct)).addOrder(Order.asc("usrSprtQstnTxt")).list();
	}

	@Override
	public List<FpsUsrSprtQstn> loadQuestionsBySubcategory(String sct) {
		return (List<FpsUsrSprtQstn>) getCurrentSession().createCriteria(FpsUsrSprtQstn.class).add(Restrictions.eq("usrSprtQstnSbctgryCd", sct)).addOrder(Order.asc("usrSprtQstnTxt")).list();

	}

	@Override
	public List<FpsUsrSprtQstn> loadQuestions(String ct, String sct) {
		return (List<FpsUsrSprtQstn>) getCurrentSession().createCriteria(FpsUsrSprtQstn.class).add(Restrictions.eq("usrSprtQstnCtgryCd", ct)).addOrder(Order.asc("usrSprtQstnTxt")).add(Restrictions.eq("usrSprtQstnSbctgryCd", sct)).list();

	}
	@Override
	public List<FpsUsrSprtQstn> loadLandingPageQuestions() {
		return (List<FpsUsrSprtQstn>) getCurrentSession().createCriteria(FpsUsrSprtQstn.class).add(Restrictions.eq("dfltInd", "Y")).addOrder(Order.asc("usrSprtQstnTxt")).list();

	}

	@Override
	public void saveHistory(Integer id, String userId, String zn) {
		FpsUsrSprtQstnAcsHstry h = new FpsUsrSprtQstnAcsHstry();
		h.setUsrSprtQstnId(id);
		h.setAudtInsrtId(userId);
		h.setAudtInsrtTs(new Date());
		h.setUsrSprtQstnUserId(userId);
		h.setUsrSprtQstnZnCd(zn);
		getCurrentSession().save(h);
		
	}
	@Override
	public void saveSearch(FaqSearchParameter search, String userId, String zn) {
		FpsUsrSprtQstnSrchHstry h = new FpsUsrSprtQstnSrchHstry();
		h.setAudtInsrtId(userId);
		h.setAudtInsrtTs(new Date());
		h.setUsrSprtQstnUserId(userId);
		h.setUsrSprtQstnZnCd(zn);
		h.setUsrSprtQstnSrchTxt(FpsDomainObjectConverter.clean(search.getSearch(), 1000));
		getCurrentSession().save(h);
		
	}

	@Override
	public List<FpsUsrSprtQstn> search(String criteriaTxt) {
		return (List<FpsUsrSprtQstn>) getCurrentSession().createCriteria(FpsUsrSprtQstn.class).add(Restrictions.ilike("usrSprtQstnAswrTxt", criteriaTxt)).addOrder(Order.asc("usrSprtQstnTxt")).list();
	}
	
	@Override
	public List<FpsUsrSprtQstnCtgryRfrnc> loadDefault() {
		return (List<FpsUsrSprtQstnCtgryRfrnc>) getCurrentSession().createCriteria(FpsUsrSprtQstnCtgryRfrnc.class).add(Restrictions.eq("actvInd", "Y")).addOrder(Order.asc("usrSprtQstnCtgryDesc")).list();
	}
}
