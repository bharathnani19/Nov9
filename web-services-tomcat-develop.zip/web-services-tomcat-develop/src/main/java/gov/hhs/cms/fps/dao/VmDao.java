package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import gov.hhs.cms.fps.model.VmInitialModel;
import gov.hhs.cms.fps.model.generated.FpsFilStore;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMacJrsdctn;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtCmt;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtMacCntrctrRfrnc;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtPocRfrnc;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtRqst;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtStus;
import gov.hhs.cms.fps.model.generated.vm.VwFpsVlnrbMgmtChgHstry;
import gov.hhs.cms.fps.model.generated.vm.VwFpsVlnrbMgmtCmtChgHstry;
import gov.hhs.cms.fps.model.generated.vm.VwFpsVlnrbMgmtStusChgHstry;
import gov.hhs.cms.fps.model.vm.VmHistoryResponse;
import gov.hhs.cms.fps.model.vm.VmSearch;

public interface VmDao {

	public List<FpsVlnrbMgmtRqst> searchRequests(VmSearch search);
	public List<VwFpsVlnrbMgmtChgHstry> loadHistory(Integer reqId);
	public List<VwFpsVlnrbMgmtCmtChgHstry> loadCommentHistory(Integer reqId);
	public List<VwFpsVlnrbMgmtStusChgHstry> loadStatusHistory(Integer reqId);
	public FpsVlnrbMgmtRqst loadRequest(Integer reqId);
	public FpsVlnrbMgmtRqst saveRequest(FpsVlnrbMgmtRqst req);
	public FpsFilStore loadFile(Integer id);
	public List<FpsFilStore> deleteFile(Integer id, String userId);
	public List<FpsFilStore> loadVmFiles(Integer id, String section);
	public Integer saveFile(Integer id, String userId, MultipartFile file, String section) throws IOException;
	public List<FpsVlnrbMgmtPocRfrnc> loadContactsByOrg(String modelCntrctr);
	public List<FpsVlnrbMgmtRqst> getSummary();
	public List<FpsVlnrbMgmtPocRfrnc> loadPocs();
	public List<FpsVlnrbMgmtMacCntrctrRfrnc> loadMacs();
	void deleteItem(Object o);
	public void saveUpdateComment(FpsVlnrbMgmtCmt cmt);
	public FpsVlnrbMgmtStus loadStatus(Integer id);
	public void saveUpdateStatus(FpsVlnrbMgmtStus stus);
	public List<VmInitialModel> loadInitialMedicaidModelList();
	
}
