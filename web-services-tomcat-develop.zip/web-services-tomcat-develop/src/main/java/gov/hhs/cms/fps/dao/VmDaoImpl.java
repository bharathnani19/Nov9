package gov.hhs.cms.fps.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import gov.hhs.cms.fps.model.VmInitialModel;
import gov.hhs.cms.fps.model.generated.FpsFilStore;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtCmt;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtMacCntrctrRfrnc;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtPocRfrnc;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtRqst;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtRqstCtgry;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtRqstSbctgry;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtRqstSchm;
import gov.hhs.cms.fps.model.generated.vm.FpsVlnrbMgmtStus;
import gov.hhs.cms.fps.model.generated.vm.VwFpsVlnrbMgmtChgHstry;
import gov.hhs.cms.fps.model.generated.vm.VwFpsVlnrbMgmtCmtChgHstry;
import gov.hhs.cms.fps.model.generated.vm.VwFpsVlnrbMgmtStusChgHstry;
import gov.hhs.cms.fps.model.vm.VmSearch;

@Repository(value = "vmDao")
public class VmDaoImpl extends BaseDao<Integer, FpsVlnrbMgmtRqst> implements VmDao {
	@Value("${vm.testMode}")
	private String testMode;

	@Override
	public List<FpsVlnrbMgmtRqst> searchRequests(VmSearch search) {
		Criteria c = getCurrentSession().createCriteria(FpsVlnrbMgmtRqst.class, "vm");
		// current status
		if (StringUtils.isNotBlank(search.getCrntStus()) && !"ALL".equals((search.getCrntStus()))) {
			c.add(Restrictions.eq("crntStus", search.getCrntStus().toLowerCase()).ignoreCase());
		}
		// keyword
		if (StringUtils.isNotBlank(search.getPropslName()) || StringUtils.isNotBlank(search.getKeywords())) {
			// account for both until keywords is implemented on the front end
			String keyword = search.getPropslName();
			if (StringUtils.isNotBlank(search.getKeywords())) {
				keyword = search.getKeywords();

			}
			Disjunction keywordSearch = Restrictions.or(new Criterion[] {});
			c.createAlias("fpsVlnrbMgmtRqstSchms", "schemes", JoinType.LEFT_OUTER_JOIN);

			keywordSearch.add(Restrictions.ilike("propslName", keyword.toLowerCase(), MatchMode.ANYWHERE));
			keywordSearch.add(Restrictions.ilike("propslDesc", keyword.toLowerCase(), MatchMode.ANYWHERE));
			keywordSearch.add(Restrictions.ilike("modelIntent", keyword.toLowerCase(), MatchMode.ANYWHERE));
			keywordSearch.add(Restrictions.ilike("modelOtpt", keyword.toLowerCase(), MatchMode.ANYWHERE));
			keywordSearch.add(Restrictions.ilike("fwaDesc", keyword.toLowerCase(), MatchMode.ANYWHERE));
			keywordSearch.add(Restrictions.ilike("bkgrndDesc", keyword.toLowerCase(), MatchMode.ANYWHERE));
			keywordSearch.add(Restrictions.ilike("modelTypeDesc", keyword.toLowerCase(), MatchMode.ANYWHERE));
			keywordSearch.add(Restrictions.ilike("ptntlLmtn", keyword.toLowerCase(), MatchMode.ANYWHERE));
			keywordSearch.add(Restrictions.ilike("schemes.srvcSchmCd", keyword.toLowerCase(), MatchMode.ANYWHERE));

			c.add(keywordSearch);
		}
		// proposal sub category
		if (StringUtils.isNotBlank(search.getPropslSubType()) && !"ALL".equals((search.getPropslSubType()))) {
			String subtype = search.getPropslSubType().toLowerCase();
			// handle the all part D subtype option which is a selectable option, where as
			// the generic "all" is not

			c.add(Restrictions.eq("propslSubType", subtype).ignoreCase());
		}
		// proposal category
		if (StringUtils.isNotBlank(search.getPropslType()) && !"ALL".equals((search.getPropslType()))) {
			c.add(Restrictions.eq("propslType", search.getPropslType().toLowerCase()).ignoreCase());
		}
		// reporting entity name
		if (StringUtils.isNotBlank(search.getRptgEntName()) && !"ALL".equals((search.getRptgEntName()))) {
			String[] ent = search.getRptgEntName().split(" ");
			if (ent.length > 1) {
				c.add(Restrictions.eq("rptgEntLastName", ent[1].toLowerCase()).ignoreCase());
				c.add(Restrictions.eq("rptgEnt1stName", ent[0].toLowerCase()).ignoreCase());
			} else {
				c.add(Restrictions.eq("rptgEntLastName", ent[0].toLowerCase()).ignoreCase());
			}
		}
		// reporting corp name
		if (StringUtils.isNotBlank(search.getRptgEntCorpName()) && !"ALL".equals((search.getRptgEntCorpName()))) {
			c.add(Restrictions.eq("rptgEntCorpName", search.getRptgEntCorpName().toLowerCase()).ignoreCase());
		}
		// reporting user ID
		if (StringUtils.isNotBlank(search.getRptgEntUserId()) && !"ALL".equals((search.getRptgEntUserId()))) {
			c.add(Restrictions.eq("rptgEntUserId", search.getRptgEntUserId().toLowerCase()).ignoreCase());
		}

		// DMA owner
		if ((StringUtils.isNotBlank(search.getDmaOwnerName()) && !"ALL".equals((search.getDmaOwnerName())))) {
			c.createAlias("fpsVlnrbMgmtPocs", "poc");

			if ((StringUtils.isNotBlank(search.getDmaOwnerName()) && !"ALL".equals((search.getDmaOwnerName())))) {
				String[] dma = search.getDmaOwnerName().split(" ");
				if (dma.length > 1) {
					c.add(Restrictions.eq("poc.pocLastName", dma[1].toLowerCase()).ignoreCase());
					c.add(Restrictions.eq("poc.poc1stName", dma[0].toLowerCase()).ignoreCase());

				} else {
					c.add(Restrictions.eq("poc.pocLastName", dma[0].toLowerCase()).ignoreCase());
				}
				c.add(Restrictions.eq("poc.pocType", "DMA OWNER"));
				c.add(Restrictions.eq("poc.actvInd", 'Y'));
			}

		}

		// model contractor
		if (StringUtils.isNotBlank(search.getModelCntrctr()) && !"ALL".equals((search.getModelCntrctr()))) {

			c.add(Restrictions.eq("modelCntrctr", search.getModelCntrctr().toLowerCase()).ignoreCase());

		}
		// VM ID
		if (search.getVlnrbId() != null) {
			c.add(Restrictions.eq("vlnrbId", search.getVlnrbId()));
		}

		// MAC
		if (search.getMacNmJrsdctn() != null) {
			if (!search.getMacNmJrsdctn().contains("ALL MAC's")) {

				Disjunction macDisjunction = Restrictions.disjunction();
				String macArray[] = search.getMacNmJrsdctn().split(";");
				for (String mac : macArray) {
					if (mac != null && mac.length() > 0) {
						macDisjunction.add(Restrictions.like("macNmJrsdctn", mac, MatchMode.ANYWHERE));
					}
				}
				c.add(macDisjunction);
				// c.add(Restrictions.in("macNmJrsdctn", search.getMacs()));

			}
		}
		// service cat
		if (StringUtils.isNotBlank(search.getSrvcCtgry()) && !"ALL".equals((search.getSrvcCtgry()))) {
			c.createAlias("fpsVlnrbMgmtRqstCtgrys", "svccat");
			c.add(Restrictions.eq("svccat.srvcCtgryCd", search.getSrvcCtgry().toLowerCase()).ignoreCase());

			// c.add(Restrictions.eq("srvcCtgry",
			// search.getSrvcCtgry().toLowerCase()).ignoreCase());
		}
		// service subcat
		if (StringUtils.isNotBlank(search.getSrvcSubCtgry()) && !"ALL".equals((search.getSrvcSubCtgry()))) {
			String subcat = search.getSrvcSubCtgry().toLowerCase();
			if ("allpartd".equals(subcat))
				subcat = "all";
			// do a like since these are stored comma separated
			c.add(Restrictions.or(Restrictions.eq("srvcSubCtgry", subcat).ignoreCase(),
					Restrictions.ilike("srvcSubCtgry", "," + subcat + ",", MatchMode.ANYWHERE),
					Restrictions.ilike("srvcSubCtgry", "," + subcat, MatchMode.END),
					Restrictions.ilike("srvcSubCtgry", subcat + ",", MatchMode.START)));
		}
		if ((StringUtils.isNotBlank(search.getPrmrySchm()) && !"ALL".equals((search.getPrmrySchm())))
				|| (search.getScndrySchms() != null && search.getScndrySchms().size() > 0)) {
			// primary scheme
			if (StringUtils.isNotBlank(search.getPrmrySchm()) && !"ALL".equals((search.getPrmrySchm()))) {
				DetachedCriteria priSchm = DetachedCriteria.forClass(FpsVlnrbMgmtRqstSchm.class, "priSchm");
				priSchm.setProjection(Projections.distinct(Projections.property("priSchm.vlnrbId")));
				priSchm.add(Restrictions.eq("priSchm.srvcSchmCd", search.getPrmrySchm().toLowerCase()).ignoreCase());
				priSchm.add(Restrictions.eq("priSchm.prmryInd", 'Y'));
				c.add(Subqueries.propertyIn("vlnrbId", priSchm));

				// c.add(Restrictions.eq("srvcCtgry",
				// search.getSrvcCtgry().toLowerCase()).ignoreCase());
			}
			// secondary scheme
			if (search.getScndrySchms() != null && search.getScndrySchms().size() > 0) {
				if (search.getScndrySchms().size() > 1
						|| (search.getScndrySchms().size() == 1 && !search.getScndrySchms().get(0).equals("ALL"))) {

					DetachedCriteria scndSchm = DetachedCriteria.forClass(FpsVlnrbMgmtRqstSchm.class, "scndSchm");
					scndSchm.setProjection(Projections.distinct(Projections.property("scndSchm.vlnrbId")));

					Disjunction schemes = Restrictions.disjunction();
					for (String scheme : search.getScndrySchms()) {
						if (scheme.equalsIgnoreCase("ALL")) {
							continue;
						}
						schemes.add(Restrictions.eq("scndSchm.srvcSchmCd", scheme.toLowerCase()).ignoreCase());
					}
					scndSchm.add(Restrictions.eq("scndSchm.prmryInd", 'N'));
					scndSchm.add(schemes);
					c.add(Subqueries.propertyIn("vlnrbId", scndSchm));
				}
				// c.add(Restrictions.eq("srvcCtgry",
				// search.getSrvcCtgry().toLowerCase()).ignoreCase());
			}
		}
		// model type
		if (StringUtils.isNotBlank(search.getModelType()) && !"ALL".equals((search.getModelType()))) {
			c.add(Restrictions.eq("modelType", search.getModelType().toLowerCase()).ignoreCase());
		}
		// return only active VMs
		c.add(Restrictions.ne("actvInd", 'N'));
		// sort by VM ID
		c.addOrder(Order.desc("vlnrbId"));
		// medicaid priority
		if (StringUtils.isNotBlank(search.getPrrty()) && !"ALL".equals((search.getPrrty()))) {
			c.add(Restrictions.eq("prrty", search.getPrrty().toLowerCase()).ignoreCase());
		}
		// medicaid data source
		if (StringUtils.isNotBlank(search.getDataSrc()) && !"ALL".equals((search.getDataSrc()))) {
			c.add(Restrictions.or(Restrictions.eq("dataSrc", search.getDataSrc().toLowerCase()).ignoreCase(),
					Restrictions.ilike("dataSrc", ";" + search.getDataSrc().toLowerCase() + ";", MatchMode.ANYWHERE),
					Restrictions.ilike("dataSrc", ";" + search.getDataSrc().toLowerCase(), MatchMode.END),
					Restrictions.ilike("dataSrc", search.getDataSrc().toLowerCase() + ";", MatchMode.START),
					Restrictions.eq("dataSrcOther", search.getDataSrc().toLowerCase()).ignoreCase()));
		}
		// medicaid state
		if (StringUtils.isNotBlank(search.getStateCd()) && !"ALL".equals((search.getStateCd()))) {
//			if (search.getStateCd().contains(";")) {
			String[] states = search.getStateCd().split(";");
			Disjunction statesOr = Restrictions.disjunction();
			for (int i = 0; i < states.length; i++) {
//					statesOr.add(Restrictions.eq("stateCd", states[i].toLowerCase()).ignoreCase());
//				}
//				c.add(statesOr);
				statesOr.add(Restrictions.or(Restrictions.eq("stateCd", states[i].toLowerCase()).ignoreCase(),
						Restrictions.ilike("stateCd", ";" + states[i].toLowerCase() + ";", MatchMode.ANYWHERE),
						Restrictions.ilike("stateCd", ";" + states[i].toLowerCase(), MatchMode.END),
						Restrictions.ilike("stateCd", states[i].toLowerCase() + ";", MatchMode.START)));
			}
			c.add(statesOr);

//			}else {
//				c.add(Restrictions.eq("stateCd", search.getStateCd().toLowerCase()).ignoreCase());
//			}
		}
		// medicaid jurisdiction
		if (StringUtils.isNotBlank(search.getJrsdctn()) && !"ALL".equals((search.getJrsdctn()))) {
			c.add(Restrictions.eq("jrsdctn", search.getJrsdctn().toLowerCase()).ignoreCase());
		}
		return c.list();
	}

	@Override
	public FpsVlnrbMgmtRqst loadRequest(Integer reqId) {
		return (FpsVlnrbMgmtRqst) getCurrentSession().load(FpsVlnrbMgmtRqst.class, reqId);
	}

	@Override
	public FpsVlnrbMgmtRqst saveRequest(FpsVlnrbMgmtRqst req) {
		if (req.getVlnrbId() == null) {
			getCurrentSession().save(req);
			getCurrentSession().flush();
			if (req.getFpsVlnrbMgmtRqstCtgrys() != null) {
				for (FpsVlnrbMgmtRqstCtgry cat : req.getFpsVlnrbMgmtRqstCtgrys()) {
					getCurrentSession().save(cat);
				}
			}
			if (req.getFpsVlnrbMgmtRqstSbctgrys() != null) {
				for (FpsVlnrbMgmtRqstSbctgry scat : req.getFpsVlnrbMgmtRqstSbctgrys()) {
					getCurrentSession().save(scat);
				}
			}
			if (req.getFpsVlnrbMgmtRqstSchms() != null) {
				for (FpsVlnrbMgmtRqstSchm sch : req.getFpsVlnrbMgmtRqstSchms()) {
					getCurrentSession().save(sch);
				}
			}
			return req;
		}
//		req.setAudtInsrtId("test");
//		getCurrentSession().saveOrUpdate( req);

		// dbReq.getFpsVlnrbMgmtPocs().clear();
		// dbReq.getFpsVlnrbMgmtPocs().addAll(req.getFpsVlnrbMgmtPocs());
		if (req.getFpsVlnrbMgmtRqstCtgrys() != null && req.getFpsVlnrbMgmtRqstCtgrys().size() > 0) {
			for (FpsVlnrbMgmtRqstCtgry cat : req.getFpsVlnrbMgmtRqstCtgrys()) {
				getCurrentSession().save(cat);
			}
		}
		if (req.getFpsVlnrbMgmtRqstSbctgrys() != null && req.getFpsVlnrbMgmtRqstSbctgrys().size() > 0) {
			for (FpsVlnrbMgmtRqstSbctgry scat : req.getFpsVlnrbMgmtRqstSbctgrys()) {
				getCurrentSession().save(scat);
			}
		}
		if (req.getFpsVlnrbMgmtRqstSchms() != null && req.getFpsVlnrbMgmtRqstSchms().size() > 0) {
			for (FpsVlnrbMgmtRqstSchm sch : req.getFpsVlnrbMgmtRqstSchms()) {
				getCurrentSession().save(sch);
			}
		}
		req = (FpsVlnrbMgmtRqst) getCurrentSession().merge(req);
//		getCurrentSession().merge(req);
		getCurrentSession().flush();

		getCurrentSession().refresh(req);
		Hibernate.initialize(req.getFpsVlnrbMacJrsdctns());
		Hibernate.initialize(req.getFpsVlnrbMgmtPlcys());
		Hibernate.initialize(req.getFpsVlnrbMgmtCmts());
		Hibernate.initialize(req.getFpsVlnrbMgmtPocs());
		Hibernate.initialize(req.getFpsVlnrbMgmtRqstCtgrys());
		Hibernate.initialize(req.getFpsVlnrbMgmtRqstSbctgrys());
		Hibernate.initialize(req.getFpsVlnrbMgmtRqstSchms());

		return req;
	}

	@Override
	public List<FpsVlnrbMgmtPocRfrnc> loadContactsByOrg(String org) {
		String searchOrg = "true".equals(testMode) ? "TEST" : org;
		return getCurrentSession().createQuery("from FpsVlnrbMgmtPocRfrnc where actvInd = 'Y' and pocOrg = :org")
				.setString("org", searchOrg).list();
	}

	@Override
	public FpsFilStore loadFile(Integer id) {
		FpsFilStore f = (FpsFilStore) getCurrentSession().load(FpsFilStore.class, id);

		return f;
	}

	@Override
	public List<FpsFilStore> deleteFile(Integer id, String userId) {
		FpsFilStore f = loadFile(id);
		String section = f.getAppName();
		getCurrentSession()
				.createQuery("update FpsFilStore set actvInd = 'N', audtUpdtId = :userId" + " where filStoreId= :id")
				.setInteger("id", id).setString("userId", userId).executeUpdate();
		List<FpsFilStore> files = loadVmFiles(id, section);
		return files;

	}

	@Override
	public List<FpsFilStore> loadVmFiles(Integer id, String section) {
		return getCurrentSession()
				.createQuery("from FpsFilStore where appRecId= :id and appName=:section and actvInd = 'Y'")
				.setInteger("id", id).setString("section", section).list();

	}

	@Override
	public Integer saveFile(Integer id, String userId, MultipartFile file, String section) throws IOException {
		FpsFilStore f = new FpsFilStore();
		// f.setFilCntnt(file.getBytes());
		String name = file.getOriginalFilename();
		String mime = "application/octet-stream";
		if (name.toLowerCase().endsWith("pdf")) {
			mime = "application/pdf";
		} else if (name.toLowerCase().endsWith("docx")) {
			mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
		} else if (name.toLowerCase().endsWith("xlsx")) {
			mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		} else if (name.toLowerCase().endsWith("doc")) {
			mime = "application/msword";
		} else if (name.toLowerCase().endsWith("xls")) {
			mime = "application/vnd.ms-excel";
		}
		f.setFilType(mime);
		f.setFilName(file.getOriginalFilename());
		f.setFilSize(file.getSize() + "");
		f.setAppRecId(id);
		f.setAudtInsrtId(userId);
		f.setAudtInsrtTs(new Date());
		f.setAppName(section);
		f.setAppRecId(id);
		f.setActvInd('Y');
		Integer newId = (Integer) getCurrentSession().save(f);
		return newId;

	}

	@Override
	public List<FpsVlnrbMgmtRqst> getSummary() {
		Criteria c = getCurrentSession().createCriteria(FpsVlnrbMgmtRqst.class, "vm");
		c.add(Restrictions.ne("actvInd", 'N'));
		c.addOrder(Order.desc("vlnrbId"));

		return c.list();
	}

	@Override
	public List<VwFpsVlnrbMgmtChgHstry> loadHistory(Integer reqId) {
		Criteria c = getCurrentSession().createCriteria(VwFpsVlnrbMgmtChgHstry.class, "vm");
		c.add(Restrictions.eq("vlnrbId", reqId));

		c.addOrder(Order.desc("changeTs"));
		return c.list();
	}

	@Override
	public List<VwFpsVlnrbMgmtCmtChgHstry> loadCommentHistory(Integer reqId) {
		Criteria c = getCurrentSession().createCriteria(VwFpsVlnrbMgmtCmtChgHstry.class, "vm");
		c.add(Restrictions.eq("vlnrbId", reqId));
		c.addOrder(Order.desc("changeTs"));
		return c.list();
	}

	@Override
	public List<VwFpsVlnrbMgmtStusChgHstry> loadStatusHistory(Integer reqId) {
		Criteria c = getCurrentSession().createCriteria(VwFpsVlnrbMgmtStusChgHstry.class, "vm");
		c.add(Restrictions.eq("vlnrbId", reqId));

		c.addOrder(Order.desc("changeTs"));
		return c.list();
	}

	@Override
	public List<FpsVlnrbMgmtPocRfrnc> loadPocs() {
		Criteria c = getCurrentSession().createCriteria(FpsVlnrbMgmtPocRfrnc.class, "poc");
		c.add(Restrictions.eq("actvInd", 'Y'));

		c.addOrder(Order.asc("poc1stName"));
		return c.list();
	}

	@Override
	public List<FpsVlnrbMgmtMacCntrctrRfrnc> loadMacs() {
		Criteria c = getCurrentSession().createCriteria(FpsVlnrbMgmtMacCntrctrRfrnc.class, "mac");

		c.addOrder(Order.asc("macCntrctrJrsdctn"));
		return c.list();
	}

	@Override
	public void deleteItem(Object o) {
		getCurrentSession().delete(o);
	}

	@Override
	public void saveUpdateComment(FpsVlnrbMgmtCmt cmt) {
		FpsVlnrbMgmtRqst req = loadRequest(cmt.getVlnrbId());
		cmt.setFpsVlnrbMgmtRqst(req);
		getCurrentSession().saveOrUpdate(cmt);
		// getCurrentSession().flush();
	}

	@Override
	public FpsVlnrbMgmtStus loadStatus(Integer id) {
		FpsVlnrbMgmtStus stus = (FpsVlnrbMgmtStus) getCurrentSession().get(FpsVlnrbMgmtStus.class, id);
		return stus;
	}

	@Override
	public void saveUpdateStatus(FpsVlnrbMgmtStus stus) {

		getCurrentSession().saveOrUpdate(stus);

	}

	@Override
	public List<VmInitialModel> loadInitialMedicaidModelList() {
		String sql = "with x as (select max(VLNRB_ID) VLNRB_ID, MODEL_SHRT_NAME from fps2.FPS_VLNRB_MGMT_RQST a where a.crnt_stus = 'Model Specifications Document Finalized' and a.PROPSL_TYPE in ('MODEL - Medicaid', 'MODEL - Medi-Medi') "
				+ "group by MODEL_SHRT_NAME ) "
				+ "select a.MODEL_SHRT_NAME, x.VLNRB_ID from fps2.FPS_VLNRB_MGMT_RQST a left join  x on a.MODEL_SHRT_NAME = x.MODEL_SHRT_NAME "
				+ "where a.crnt_stus = 'Model Specifications Document Finalized' and a.PROPSL_TYPE in ('MODEL - Medicaid', 'MODEL - Medi-Medi') "
				+ "and a.PROPSL_SUB_TYPE = 'New' ";
		SQLQuery query = getCurrentSession().createSQLQuery(sql);

		List<Object[]> rows = query.list();
		List<VmInitialModel> models = new ArrayList<>();
		for (Object[] row : rows) {
			VmInitialModel item = new VmInitialModel();
			if (row[0] != null) {
				item.setModelName(row[0].toString());
				item.setLatestVmId(Integer.parseInt(row[1].toString()));

				models.add(item);
			}
		}
		return models;
	}
}
