package gov.hhs.cms.fps.dao;

import java.util.List;

import gov.hhs.cms.fps.model.AsrSummary;
import gov.hhs.cms.fps.model.WatchlistItem;
import gov.hhs.cms.fps.model.generated.FpsApsWatchlist;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsCustomAsrList;

public interface WatchlistDao {

	public List<WatchlistItem> findNotifications();

	List<String> findModelsSinceFollowup(int asrptId);

	List<AsrSummary> findNewApsAsrs();

	List<FpsAsrpt> findFollowUpAsrs();

	public String getApsChangeDateByAsr(Integer target);

	List<FpsApsWatchlist> loadApsWatchlistSummary(String myZone);

	public List<FpsCustomAsrList> loadCustomAsrWatchlistSummary(String userId);

	public List<AsrSummary> findNewProcessedCustomAsrs();

	public FpsCustomAsrList loadCustomAsrWatchlist(Object id);

}
