package gov.hhs.cms.fps.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.hhs.cms.fps.controller.ScheduledTasks;
import gov.hhs.cms.fps.model.AsrSummary;
import gov.hhs.cms.fps.model.WatchlistItem;
import gov.hhs.cms.fps.model.generated.FpsApsWatchlist;
import gov.hhs.cms.fps.model.generated.FpsApsWatchlistRoot;
import gov.hhs.cms.fps.model.generated.FpsAsrpt;
import gov.hhs.cms.fps.model.generated.FpsCustomAsrList;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.FpsEnums.EventType;
@Repository( value="watchlistDao")
public class WatchlistDaoImpl extends BaseDao<Integer,Object> implements WatchlistDao {
	private static final Logger logger = Logger.getLogger(WatchlistDaoImpl.class.getName());

	@Override
	public List<WatchlistItem> findNotifications() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<String> findModelsSinceFollowup(int asrptId) {
		List<String> models = new ArrayList<String>();
		return models;
	}
	@Override
	public List<AsrSummary> findNewApsAsrs(){
		String findSql = "MERGE INTO FPS2.FPS_APS_REFRESH_HSTRY T " + 
				"USING  " + 
				"(SELECT DISTINCT " + 
				"        a.ASRPT_ID, " + 
				"        a.identity_id, " + 
				"        b.offense_unique_id, " + 
				"        b.identity_crim_id, " + 
				"        b.updated_date, " + 
				"        DATE(b.AUDT_INSRT_TS)  REFRESH_DT " + 
				"FROM FPS2.fps_asrpt_aps_vw a " + 
				"  inner join FPS2.FPS_APS_CURR_IDENTITY_CRIM b " + 
				"   on a.identity_id = b.identity_id " + 
				") AS S " + 
				"ON   T.ASRPT_ID = S.ASRPT_ID " + 
				" AND T.IDENTITY_ID = S.IDENTITY_ID " + 
				" AND T.IDENTITY_CRIM_ID = S.IDENTITY_CRIM_ID " + 
				"WHEN NOT MATCHED THEN " + 
				"      INSERT ( " + 
				"              ASRPT_ID, " + 
				"              IDENTITY_ID, " + 
				"              IDENTITY_CRIM_ID, " + 
				"              OFFENSE_UNIQUE_ID, " + 
				"              UPDATED_DATE, " + 
				"              REFRESH_DT, " + 
				"              AUDT_INSRT_ID, " + 
				"              AUDT_INSRT_TS) " + 
				"       VALUES ( " + 
				"              S.ASRPT_ID, " + 
				"              S.IDENTITY_ID, " + 
				"              S.IDENTITY_CRIM_ID, " + 
				"              S.OFFENSE_UNIQUE_ID, " + 
				"              S.UPDATED_DATE, " + 
				"              S.REFRESH_DT, " + 
				"               'SYSTEM', " + 
				"                localtimestamp) " + 
				"  WHEN MATCHED THEN DO NOTHING " ;
		int count = getCurrentSession().createSQLQuery(findSql).executeUpdate();
		logger.info("APS check found " + count + " new ASRs to notify");
		String startNotify = "WITH APS AS " + 
				"( " + 
				"SELECT distinct hstry.asrpt_id,hstry.identity_id,hstry.identity_crim_id, REFRESH_DT " + 
				"FROM FPS2.FPS_APS_REFRESH_HSTRY HSTRY " + 
				"  INNER JOIN FPS2.FPS_APS_REFRESH_CHGS_VW CHGS " + 
				"ON hstry.identity_id = chgs.identity_id  " + 
				"and   hstry.identity_crim_id = chgs.identity_crim_id "
				+ "where date(hstry.audt_insrt_ts) = current_date " + 
				") " + 
						"SELECT  DISTINCT" + 
				"            APS.ASRPT_ID,identity_id,identity_crim_id, REFRESH_DT " + 
				"        from APS ";
		List<Object[]> notifyAsrs = getCurrentSession().createSQLQuery(startNotify).list();
		List<AsrSummary> asrs = new ArrayList<>();
		List<Integer> asrptIds = new ArrayList<>();
		for (Object[] o : notifyAsrs) {
			FpsApsWatchlistRoot dbWl = new FpsApsWatchlistRoot();
			dbWl.setAsrptId((Integer)o[0]);
			dbWl.setAudtInsrtId("SYSTEM");
			dbWl.setAudtInsrtTs(new Date());
			dbWl.setAudtUpdtId("SYSTEM");
			dbWl.setAudtUpdtTs(new Date());
			dbWl.setIdentityId((BigDecimal)o[1]);
			dbWl.setIdentityCrimId((BigDecimal)o[2]);
			dbWl.setUpdatedDt((Date)o[3]);
			getCurrentSession().save(dbWl);
			if (!asrptIds.contains((Integer)o[0])) {
				AsrSummary asr = new AsrSummary();
				asr.setAsrDbid((Integer)o[0]);
				asrs.add(asr);
				asrptIds.add((Integer)o[0]);
			}
		}
		return asrs;
	}

	@Override
	public List<FpsAsrpt> findFollowUpAsrs() {
		List<FpsAsrpt> asrs = new ArrayList<FpsAsrpt>();
		return asrs;
	}

	@Override
	public String getApsChangeDateByAsr(Integer target) {
		Date o = (Date) getCurrentSession().createSQLQuery("select max(UPDATED_DATE) dt from fps2.fps_aps_refresh_hstry where asrpt_id = :asrptId")
				.setInteger("asrptId", target).uniqueResult();
		return FpsDomainObjectConverter.convertDateToShortString(o);
	}

	@Override
	public List<FpsApsWatchlist> loadApsWatchlistSummary(String myZone) {
		// get subscriptions for specific type
		// load relevant metadata from results of that subscription

		Calendar cal30 = Calendar.getInstance();
		cal30.add(Calendar.DATE, -30);
		cal30.set(Calendar.MINUTE, 59);
		cal30.set(Calendar.SECOND, 59);
		cal30.set(Calendar.HOUR_OF_DAY, 23);

		Criteria c =  getCurrentSession().createCriteria(FpsApsWatchlist.class)
				.createAlias("fpsPrvdrAnlys", "asr")
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		if ("medic".equalsIgnoreCase(myZone)) {
			c.add(Restrictions.eq("asr.partDInd", "Y"));
		}else {
		
			c.add(Restrictions.or(Restrictions.eq("asr.jurisdiction", myZone).ignoreCase(), Restrictions.ilike("asr.macJurisdiction", "%"+myZone+"%")));
		}
		c.add(Restrictions.ge("updatedDt", cal30.getTime()));
		c.addOrder(Order.desc("updatedDt")).list();
		
		return c.list();
	}

	@Override
	public List<FpsCustomAsrList> loadCustomAsrWatchlistSummary(String userId) {
		// select all pending and recently completed ASR lists for user
		Calendar cal7 = Calendar.getInstance();
		cal7.add(Calendar.DATE, -7);
		cal7.set(Calendar.MINUTE, 59);
		cal7.set(Calendar.SECOND, 59);
		cal7.set(Calendar.HOUR_OF_DAY, 23);
		return  getCurrentSession().createCriteria(FpsCustomAsrList.class)
				.add(Restrictions.eq("audtInsrtId", userId))
				.add(Restrictions.or(Restrictions.eq("status", ""),Restrictions.and(Restrictions.eq("status", ""),Restrictions.ge("audtInsrtTs", cal7))))
				.addOrder(Order.desc("audtInsrtTs"))
				.list();
	}

	@Override
	public List<AsrSummary> findNewProcessedCustomAsrs() {
		//select from pending lists join on fps_asrpt
		return null;
	}

	@Override
	public FpsCustomAsrList loadCustomAsrWatchlist(Object id) {
		return  (FpsCustomAsrList) getCurrentSession().createCriteria(FpsCustomAsrList.class)
				.add(Restrictions.eq("customAsrListId", id)).uniqueResult();
	}

	
}
