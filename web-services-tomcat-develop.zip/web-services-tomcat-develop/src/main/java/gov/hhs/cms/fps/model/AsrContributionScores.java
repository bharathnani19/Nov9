package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class AsrContributionScores implements Serializable {

	private String modelNm;
	private String modelRiskScore;
	private String contribScorePct;
	private Integer modelId;
	private String modelTypeCd;
	public String getModelNm() {
		return modelNm;
	}
	public void setModelNm(String modelNm) {
		this.modelNm = modelNm;
	}
	public String getModelRiskScore() {
		return modelRiskScore;
	}
	public void setModelRiskScore(String modelRiskScore) {
		this.modelRiskScore = modelRiskScore;
	}
	public String getContribScorePct() {
		return contribScorePct;
	}
	public void setContribScorePct(String contribScorePct) {
		this.contribScorePct = contribScorePct;
	}
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}
	public String getModelTypeCd() {
		return modelTypeCd;
	}
	public void setModelTypeCd(String modelTypeCd) {
		this.modelTypeCd = modelTypeCd;
	}
}
