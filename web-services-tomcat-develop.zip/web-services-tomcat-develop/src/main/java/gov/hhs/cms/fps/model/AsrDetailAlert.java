package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.joda.time.DateTimeComparator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonIgnoreProperties(value={"currentInd", "legacyInd", "modDt", "createDtAsDate"})
@JsonInclude(Include.NON_NULL)
public class AsrDetailAlert implements Serializable ,  Comparable<AsrDetailAlert>{

	private String createDt;
	private String legacyScore;
	private String riskScore;
	private String derivedZone;
	private String cost;
	private String hasReportCard;
	private String hasViz;
	
	@JsonIgnore
	private String currentInd;
	private String recentInd;
	private String priorityInd;
	@JsonIgnore
	private String legacyInd;
	@JsonIgnore
	private String modDt;
	@JsonIgnore
	private Date createDtAsDate;
	private String insertDt;
	private String status;
	private String modelStatus;
	private String modelTypeCd;
	private Integer alertId;
	private String partDClaimInd;
	private String modelBusnsId;
	private List<MdcdModelState> states;
	private String state;
	private String mdcdState;
	private String disabled;
	private String pathToEduInd;
	private String sevScore;
	private String showClaimsLinkInd = "Y";
	private String relCreatedDt;

	public String getCreateDt() {
		return createDt;
	}
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	public String getLegacyScore() {
		return legacyScore;
	}
	public void setLegacyScore(String legacyScore) {
		this.legacyScore = legacyScore;
	}
	public String getRiskScore() {
		return riskScore;
	}
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	public String getDerivedZone() {
		return derivedZone;
	}
	public void setDerivedZone(String derivedZone) {
		this.derivedZone = derivedZone;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "(createDt:" + createDt + ", legacyScore:" + legacyScore + ", riskScore:" + riskScore
				+ ", derivedZone:" + derivedZone + ", cost:" + cost + ")";
	}
	@JsonIgnore
	public String getCurrentInd() {
		return currentInd;
	}
	public void setCurrentInd(String currentInd) {
		this.currentInd = currentInd;
	}
	@JsonIgnore
	public String getLegacyInd() {
		return legacyInd;
	}
	public void setLegacyInd(String legacyInd) {
		this.legacyInd = legacyInd;
	}
	@JsonIgnore
	public String getModDt() {
		return modDt;
	}
	public void setModDt(String modDt) {
		this.modDt = modDt;
	}
	@Override
	public int compareTo(AsrDetailAlert o1) {
		DateTimeComparator d = DateTimeComparator.getInstance();
		return  d.compare(o1.getCreateDtAsDate(),  this.getCreateDtAsDate());
	}
	@JsonIgnore
	public Date getCreateDtAsDate() {
		return createDtAsDate;
	}
	public void setCreateDtAsDate(Date createDtAsDate) {
		this.createDtAsDate = createDtAsDate;
	}
	public String getHasReportCard() {
		return hasReportCard;
	}
	public void setHasReportCard(String hasReportCard) {
		this.hasReportCard = hasReportCard;
	}
	public String getRecentInd() {
		return recentInd;
	}
	public void setRecentInd(String recentInd) {
		this.recentInd = recentInd;
	}
	public String getPriorityInd() {
		return priorityInd;
	}
	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}
	public String getInsertDt() {
		return insertDt;
	}
	public void setInsertDt(String insertDt) {
		this.insertDt = insertDt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getModelTypeCd() {
		return modelTypeCd;
	}
	public void setModelTypeCd(String modelTypeCd) {
		this.modelTypeCd = modelTypeCd;
	}
	public String getHasViz() {
		return hasViz;
	}
	public void setHasViz(String hasViz) {
		this.hasViz = hasViz;
	}
	public String getModelStatus() {
		return modelStatus;
	}
	public void setModelStatus(String modelStatus) {
		this.modelStatus = modelStatus;
	}
	public Integer getAlertId() {
		return alertId;
	}
	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}
	public String getPartDClaimInd() {
		return partDClaimInd;
	}
	public void setPartDClaimInd(String partDClaimInd) {
		this.partDClaimInd = partDClaimInd;
	}
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	
	public List<MdcdModelState> getStates() {
		return states;
	}
	public void setStates(List<MdcdModelState> states) {
		this.states = states;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getMdcdState() {
		return mdcdState;
	}
	public void setMdcdState(String mdcdState) {
		this.mdcdState = mdcdState;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((alertId == null) ? 0 : alertId.hashCode());
		result = prime * result + ((cost == null) ? 0 : cost.hashCode());
		result = prime * result + ((createDt == null) ? 0 : createDt.hashCode());
		result = prime * result + ((createDtAsDate == null) ? 0 : createDtAsDate.hashCode());
		result = prime * result + ((currentInd == null) ? 0 : currentInd.hashCode());
		result = prime * result + ((derivedZone == null) ? 0 : derivedZone.hashCode());
		result = prime * result + ((hasReportCard == null) ? 0 : hasReportCard.hashCode());
		result = prime * result + ((hasViz == null) ? 0 : hasViz.hashCode());
		result = prime * result + ((insertDt == null) ? 0 : insertDt.hashCode());
		result = prime * result + ((legacyInd == null) ? 0 : legacyInd.hashCode());
		result = prime * result + ((legacyScore == null) ? 0 : legacyScore.hashCode());
		result = prime * result + ((mdcdState == null) ? 0 : mdcdState.hashCode());
		result = prime * result + ((modDt == null) ? 0 : modDt.hashCode());
		result = prime * result + ((modelBusnsId == null) ? 0 : modelBusnsId.hashCode());
		result = prime * result + ((modelStatus == null) ? 0 : modelStatus.hashCode());
		result = prime * result + ((modelTypeCd == null) ? 0 : modelTypeCd.hashCode());
		result = prime * result + ((partDClaimInd == null) ? 0 : partDClaimInd.hashCode());
		result = prime * result + ((priorityInd == null) ? 0 : priorityInd.hashCode());
		result = prime * result + ((recentInd == null) ? 0 : recentInd.hashCode());
		result = prime * result + ((riskScore == null) ? 0 : riskScore.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((states == null) ? 0 : states.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AsrDetailAlert other = (AsrDetailAlert) obj;
		if (alertId == null) {
			if (other.alertId != null)
				return false;
		} else if (!alertId.equals(other.alertId))
			return false;
		if (cost == null) {
			if (other.cost != null)
				return false;
		} else if (!cost.equals(other.cost))
			return false;
		if (createDt == null) {
			if (other.createDt != null)
				return false;
		} else if (!createDt.equals(other.createDt))
			return false;
		if (createDtAsDate == null) {
			if (other.createDtAsDate != null)
				return false;
		} else if (!createDtAsDate.equals(other.createDtAsDate))
			return false;
		if (currentInd == null) {
			if (other.currentInd != null)
				return false;
		} else if (!currentInd.equals(other.currentInd))
			return false;
		if (derivedZone == null) {
			if (other.derivedZone != null)
				return false;
		} else if (!derivedZone.equals(other.derivedZone))
			return false;
		if (hasReportCard == null) {
			if (other.hasReportCard != null)
				return false;
		} else if (!hasReportCard.equals(other.hasReportCard))
			return false;
		if (hasViz == null) {
			if (other.hasViz != null)
				return false;
		} else if (!hasViz.equals(other.hasViz))
			return false;
		if (insertDt == null) {
			if (other.insertDt != null)
				return false;
		} else if (!insertDt.equals(other.insertDt))
			return false;
		if (legacyInd == null) {
			if (other.legacyInd != null)
				return false;
		} else if (!legacyInd.equals(other.legacyInd))
			return false;
		if (legacyScore == null) {
			if (other.legacyScore != null)
				return false;
		} else if (!legacyScore.equals(other.legacyScore))
			return false;
		if (mdcdState == null) {
			if (other.mdcdState != null)
				return false;
		} else if (!mdcdState.equals(other.mdcdState))
			return false;
		if (modDt == null) {
			if (other.modDt != null)
				return false;
		} else if (!modDt.equals(other.modDt))
			return false;
		if (modelBusnsId == null) {
			if (other.modelBusnsId != null)
				return false;
		} else if (!modelBusnsId.equals(other.modelBusnsId))
			return false;
		if (modelStatus == null) {
			if (other.modelStatus != null)
				return false;
		} else if (!modelStatus.equals(other.modelStatus))
			return false;
		if (modelTypeCd == null) {
			if (other.modelTypeCd != null)
				return false;
		} else if (!modelTypeCd.equals(other.modelTypeCd))
			return false;
		if (partDClaimInd == null) {
			if (other.partDClaimInd != null)
				return false;
		} else if (!partDClaimInd.equals(other.partDClaimInd))
			return false;
		if (priorityInd == null) {
			if (other.priorityInd != null)
				return false;
		} else if (!priorityInd.equals(other.priorityInd))
			return false;
		if (recentInd == null) {
			if (other.recentInd != null)
				return false;
		} else if (!recentInd.equals(other.recentInd))
			return false;
		if (riskScore == null) {
			if (other.riskScore != null)
				return false;
		} else if (!riskScore.equals(other.riskScore))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (states == null) {
			if (other.states != null)
				return false;
		} else if (!states.equals(other.states))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
	public String getDisabled() {
		return disabled;
	}
	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}
	public String getPathToEduInd() {
		return pathToEduInd;
	}
	public void setPathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}
	public String getSevScore() {
		return sevScore;
	}
	public void setSevScore(String sevScore) {
		this.sevScore = sevScore;
	}
	public String getShowClaimsLinkInd() {
		return showClaimsLinkInd;
	}
	public void setShowClaimsLinkInd(String showClaimsLinkInd) {
		this.showClaimsLinkInd = showClaimsLinkInd;
	}
	public String getRelCreatedDt() {
		return relCreatedDt;
	}
	public void setRelCreatedDt(String relCreatedDt) {
		this.relCreatedDt = relCreatedDt;
	}
}
