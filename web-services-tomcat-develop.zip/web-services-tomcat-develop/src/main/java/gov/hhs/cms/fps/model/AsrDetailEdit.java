/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailEdits.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailEdit  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7409584585513585477L;

	private int editNum;	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private Date dateLastReconciled;
	private String alertName;		
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private Date firstDetectedDenialDt;	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")

	private Date lastDetectedDenialDt;
	private long numClaimsDenied;
	private BigDecimal totalDeniedPaymentsClaimsAmt;
	private long numLineItemsDenied;
	private BigDecimal totalDeniedPaymentsLinesAmt;
	private long numProcCodes;
	private long numDenialCodes;
	private String fpsEditNum;
	private String longName;
	public int getEditNum() {
		return editNum;
	}
	public void setEditNum(int editNum) {
		this.editNum = editNum;
	}
	public Date getDateLastReconciled() {
		return dateLastReconciled;
	}
	public void setDateLastReconciled(Date dateLastReconciled) {
		this.dateLastReconciled = dateLastReconciled;
	}
	public String getAlertName() {
		return alertName;
	}
	public void setAlertName(String alertName) {
		this.alertName = alertName;
	}
	public Date getFirstDetectedDenialDt() {
		return firstDetectedDenialDt;
	}
	public void setFirstDetectedDenialDt(Date firstDetectedDenialDt) {
		this.firstDetectedDenialDt = firstDetectedDenialDt;
	}
	public Date getLastDetectedDenialDt() {
		return lastDetectedDenialDt;
	}
	public void setLastDetectedDenialDt(Date lastDetectedDenialDt) {
		this.lastDetectedDenialDt = lastDetectedDenialDt;
	}
	public Long getNumClaimsDenied() {
		return numClaimsDenied;
	}
	public void setNumClaimsDenied(Long numClaimsDenied) {
		this.numClaimsDenied = numClaimsDenied;
	}
	public BigDecimal getTotalDeniedPaymentsClaimsAmt() {
		return totalDeniedPaymentsClaimsAmt;
	}
	public void setTotalDeniedPaymentsClaimsAmt(BigDecimal totalDeniedPaymentsClaimsAmt) {
		this.totalDeniedPaymentsClaimsAmt = totalDeniedPaymentsClaimsAmt;
	}
	public Long getNumLineItemsDenied() {
		return numLineItemsDenied;
	}
	public void setNumLineItemsDenied(Long numLineItemsDenied) {
		this.numLineItemsDenied = numLineItemsDenied;
	}
	public BigDecimal getTotalDeniedPaymentsLinesAmt() {
		return totalDeniedPaymentsLinesAmt;
	}
	public void setTotalDeniedPaymentsLinesAmt(BigDecimal totalDeniedPaymentsLinesAmt) {
		this.totalDeniedPaymentsLinesAmt = totalDeniedPaymentsLinesAmt;
	}
	public Long getNumProcCodes() {
		return numProcCodes;
	}
	public void setNumProcCodes(Long numProcCodes) {
		this.numProcCodes = numProcCodes;
	}
	public Long getNumDenialCodes() {
		return numDenialCodes;
	}
	public void setNumDenialCodes(Long numDenialCodes) {
		this.numDenialCodes = numDenialCodes;
	}
	public String getFpsEditNum() {
		return fpsEditNum;
	}
	public void setFpsEditNum(String fpsEditNum) {
		this.fpsEditNum = fpsEditNum;
	}
	public String getLongName() {
		return longName;
	}
	public void setLongName(String longName) {
		this.longName = longName;
	}
	
	
}
