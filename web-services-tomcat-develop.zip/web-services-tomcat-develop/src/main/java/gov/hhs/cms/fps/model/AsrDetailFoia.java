/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailFoia.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailFoia  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4379813658546087823L;

	private Integer controlNumber;
	private String creatorName;
	private String status;
	private String subStatus;
	private String jurisdiction;
	private String heatInd;
	private String investigatorName;
	private String zpicReceivedDt;
	private String priority;
	private String requestedDeliveryDt;
	private String closedDt;
	private String closedReminderSentInd;
	private Integer reminderInterval;
	private String requestType;
	private String subRequestType;
	private String claimDataInd;
	private String costReportInd;
	private String requesterType;
	private String requesterFirstName;
	private String requesterLastName;
	private String requesterEmail;
	private String requesterPhoneNum;
	private String requesterFaxNum;
	private String fileLocation;
	private String description;

	private String benefitTypeCd;
	private String zpicInitiatedInd;
	private String subjId;
	public Integer getControlNumber() {
		return controlNumber;
	}
	public void setControlNumber(Integer controlNumber) {
		this.controlNumber = controlNumber;
	}
	public String getCreatorName() {
		return creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSubStatus() {
		return subStatus;
	}
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getHeatInd() {
		return heatInd;
	}
	public void setHeatInd(String heatInd) {
		this.heatInd = heatInd;
	}
	public String getInvestigatorName() {
		return investigatorName;
	}
	public void setInvestigatorName(String investigatorName) {
		this.investigatorName = investigatorName;
	}
	public String getZpicReceivedDt() {
		return zpicReceivedDt;
	}
	public void setZpicReceivedDt(String zpicReceivedDt) {
		this.zpicReceivedDt = zpicReceivedDt;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getRequestedDeliveryDt() {
		return requestedDeliveryDt;
	}
	public void setRequestedDeliveryDt(String requestedDeliveryDt) {
		this.requestedDeliveryDt = requestedDeliveryDt;
	}
	public String getClosedDt() {
		return closedDt;
	}
	public void setClosedDt(String closedDt) {
		this.closedDt = closedDt;
	}
	public String getClosedReminderSentInd() {
		return closedReminderSentInd;
	}
	public void setClosedReminderSentInd(String closedReminderSentInd) {
		this.closedReminderSentInd = closedReminderSentInd;
	}
	public Integer getReminderInterval() {
		return reminderInterval;
	}
	public void setReminderInterval(Integer reminderInterval) {
		this.reminderInterval = reminderInterval;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getSubRequestType() {
		return subRequestType;
	}
	public void setSubRequestType(String subRequestType) {
		this.subRequestType = subRequestType;
	}
	public String getClaimDataInd() {
		return claimDataInd;
	}
	public void setClaimDataInd(String claimDataInd) {
		this.claimDataInd = claimDataInd;
	}
	public String getCostReportInd() {
		return costReportInd;
	}
	public void setCostReportInd(String costReportInd) {
		this.costReportInd = costReportInd;
	}
	public String getRequesterType() {
		return requesterType;
	}
	public void setRequesterType(String requesterType) {
		this.requesterType = requesterType;
	}
	public String getRequesterFirstName() {
		return requesterFirstName;
	}
	public void setRequesterFirstName(String requesterFirstName) {
		this.requesterFirstName = requesterFirstName;
	}
	public String getRequesterLastName() {
		return requesterLastName;
	}
	public void setRequesterLastName(String requesterLastName) {
		this.requesterLastName = requesterLastName;
	}
	public String getRequesterEmail() {
		return requesterEmail;
	}
	public void setRequesterEmail(String requesterEmail) {
		this.requesterEmail = requesterEmail;
	}
	public String getRequesterPhoneNum() {
		return requesterPhoneNum;
	}
	public void setRequesterPhoneNum(String requesterPhoneNum) {
		this.requesterPhoneNum = requesterPhoneNum;
	}
	public String getRequesterFaxNum() {
		return requesterFaxNum;
	}
	public void setRequesterFaxNum(String requesterFaxNum) {
		this.requesterFaxNum = requesterFaxNum;
	}
	public String getFileLocation() {
		return fileLocation;
	}
	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBenefitTypeCd() {
		return benefitTypeCd;
	}
	public void setBenefitTypeCd(String benefitTypeCd) {
		this.benefitTypeCd = benefitTypeCd;
	}
	public String getZpicInitiatedInd() {
		return zpicInitiatedInd;
	}
	public void setZpicInitiatedInd(String zpicInitiatedInd) {
		this.zpicInitiatedInd = zpicInitiatedInd;
	}
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	
}
