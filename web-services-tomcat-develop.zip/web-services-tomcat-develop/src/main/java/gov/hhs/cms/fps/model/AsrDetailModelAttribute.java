package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailModelAttribute implements Serializable {

	private String attribute;
	private String reasonForAttr;
	private String calculatedAttr;
	private String threshold;
	private String purposeOfStrClm;
	public String getAttribute() {
		return attribute;
	}
	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}
	public String getReasonForAttr() {
		return reasonForAttr;
	}
	public void setReasonForAttr(String reasonForAttr) {
		this.reasonForAttr = reasonForAttr;
	}
	public String getCalculatedAttr() {
		return calculatedAttr;
	}
	public void setCalculatedAttr(String calculatedAttr) {
		this.calculatedAttr = calculatedAttr;
	}
	public String getThreshold() {
		return threshold;
	}
	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}
	public String getPurposeOfStrClm() {
		return purposeOfStrClm;
	}
	public void setPurposeOfStrClm(String purposeOfStrClm) {
		this.purposeOfStrClm = purposeOfStrClm;
	}
	
}
