/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailNotes.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailNote  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4809633156787948833L;
	private int leaderInvId;
	private String userId;
	private String activityActionRuling;
	private String recordedDt;
	private String eventDt;
	private String note;
	
	public int getLeaderInvId() {
		return leaderInvId;
	}
	public void setLeaderInvId(int leaderInvId) {
		this.leaderInvId = leaderInvId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getActivityActionRuling() {
		return activityActionRuling;
	}
	public void setActivityActionRuling(String activityActionRuling) {
		this.activityActionRuling = activityActionRuling;
	}
	public String getRecordedDt() {
		return recordedDt;
	}
	public void setRecordedDt(String recordedDt) {
		this.recordedDt = recordedDt;
	}
	public String getEventDt() {
		return eventDt;
	}
	public void setEventDt(String eventDt) {
		this.eventDt = eventDt;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
	
}
