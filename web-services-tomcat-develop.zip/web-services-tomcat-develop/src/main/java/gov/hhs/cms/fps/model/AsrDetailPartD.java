package gov.hhs.cms.fps.model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailPartD  implements Serializable{
	
	private List<AsrDetailPartDItem> reports = new ArrayList<AsrDetailPartDItem> ();

	public List<AsrDetailPartDItem> getReports() {
		return reports;
	}

	public void setReports(List<AsrDetailPartDItem> reports) {
		this.reports = reports;
	}
}
