package gov.hhs.cms.fps.model;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.apache.commons.lang3.time.FastDateFormat;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import gov.hhs.cms.fps.util.FpsEnums.PartDFormat;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailPartDAdHocItem  implements Serializable{
	
	private Integer order;
	private String name;
	private String value;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getOrder() {
		return order;
	}
	public void setOrder(Integer order) {
		this.order = order;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public void buildValue(String value, PartDFormat format){
		String newval = value;
		if (value != null){
			if (format.equals(PartDFormat.DECIMAL) || format.equals(PartDFormat.DOLLAR) || format.equals(PartDFormat.PCT)  ){
				
				BigDecimal bd = new BigDecimal(value);
			
				if ( format.equals(PartDFormat.PCT) ){
					bd = bd.multiply(new BigDecimal("100"));
					bd = bd.setScale(1, RoundingMode.HALF_UP);
					NumberFormat nf = NumberFormat.getNumberInstance();
					nf.setMaximumFractionDigits(1);
					nf.setMinimumFractionDigits(1);
					newval = nf.format(bd).toString();
				}else{
					bd = bd.setScale(2, RoundingMode.HALF_UP);
					newval = bd.toString();
					
				}
				
				
				if (format.equals(PartDFormat.DOLLAR)){
					newval = NumberFormat.getCurrencyInstance().format(bd);
				}
				if (format.equals(PartDFormat.PCT) ){
					
					newval = newval + "%";
				}
			}else if (format.equals(PartDFormat.INT) ){
				NumberFormat nf = NumberFormat.getIntegerInstance();
				BigDecimal bd = new BigDecimal(value);
				bd = bd.setScale(0, RoundingMode.HALF_UP);
				
				newval = nf.format(bd.intValue());
				
			}else if (format.equals(PartDFormat.DATE) ){
				FastDateFormat.getInstance("MM/dd/yyyy").format(value);
				
			}
		}
		
		setValue(newval);
	}
}
