package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import gov.hhs.cms.fps.util.FpsEnums.PartDEnum;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailPartDAdHocSet implements Serializable {
	protected String adhocRptNm;
	protected String var006Nm;
	protected String var007Nm;
	protected String var008Nm;
	protected String var009Nm;
	protected String var010Nm;
	protected String var011Nm;
	protected String var012Nm;
	protected String var013Nm;
	protected String var014Nm;
	protected String var015Nm;
	protected String var016Nm;
	protected String var017Nm;
	protected String var018Nm;
	protected String var019Nm;
	protected String var020Nm;
	protected String var021Nm;
	protected String var022Nm;
	protected String var023Nm;
	protected String var024Nm;
	protected String var025Nm;
	protected String var026Nm;
	protected String var027Nm;
	protected String var028Nm;
	protected String var029Nm;
	protected String var030Nm;
	protected String var031Nm;
	protected String var032Nm;
	protected String var033Nm;
	protected String var034Nm;
	protected String var035Nm;
	protected String var036Nm;
	protected String var037Nm;
	protected String var038Nm;
	protected String var039Nm;
	protected String var040Nm;
	protected String var041Nm;
	protected String var042Nm;
	protected String var043Nm;
	protected String var044Nm;
	protected String var045Nm;
	protected String var046Nm;
	protected String var047Nm;
	protected String var048Nm;
	protected String var049Nm;
	protected String var050Nm;
	protected String var051Nm;
	protected String var052Nm;
	protected String var053Nm;
	protected String var054Nm;
	protected String var055Nm;
	protected String var056Nm;
	protected String var057Nm;
	protected String var058Nm;
	protected String var059Nm;
	protected String var060Nm;
	protected String var061Nm;
	protected String var062Nm;
	protected String var063Nm;
	protected String var064Nm;
	protected String var065Nm;
	protected String var066Nm;
	protected String var067Nm;
	protected String var068Nm;
	protected String var069Nm;
	protected String var070Nm;
	protected String var071Nm;
	protected String var072Nm;
	protected String var073Nm;
	protected String var074Nm;
	protected String var075Nm;
	protected String var076Nm;
	protected String var077Nm;
	protected String var078Nm;
	protected String var079Nm;
	protected String var080Nm;
	protected String var081Nm;
	protected String var082Nm;
	protected String var083Nm;
	protected String var084Nm;
	protected String var085Nm;
	protected String var086Nm;
	protected String var087Nm;
	protected String var088Nm;
	protected String var089Nm;
	protected String var090Nm;
	protected String var091Nm;
	protected String var092Nm;
	protected String var093Nm;
	protected String var094Nm;
	protected String var095Nm;
	protected String var096Nm;
	protected String var097Nm;
	protected String var098Nm;
	protected String var099Nm;
	protected String var100Nm;
	protected String var006;
	protected String var007;
	protected String var008;
	protected String var009;
	protected String var010;
	protected String var011;
	protected String var012;
	protected String var013;
	protected String var014;
	protected String var015;
	protected String var016;
	protected String var017;
	protected String var018;
	protected String var019;
	protected String var020;
	protected String var021;
	protected String var022;
	protected String var023;
	protected String var024;
	protected String var025;
	protected String var026;
	protected String var027;
	protected String var028;
	protected String var029;
	protected String var030;
	protected String var031;
	protected String var032;
	protected String var033;
	protected String var034;
	protected String var035;
	protected String var036;
	protected String var037;
	protected String var038;
	protected String var039;
	protected String var040;
	protected String var041;
	protected String var042;
	protected String var043;
	protected String var044;
	protected String var045;
	protected String var046;
	protected String var047;
	protected String var048;
	protected String var049;
	protected String var050;
	protected String var051;
	protected String var052;
	protected String var053;
	protected String var054;
	protected String var055;
	protected String var056;
	protected String var057;
	protected String var058;
	protected String var059;
	protected String var060;
	protected String var061;
	protected String var062;
	protected String var063;
	protected String var064;
	protected String var065;
	protected String var066;
	protected String var067;
	protected String var068;
	protected String var069;
	protected String var070;
	protected String var071;
	protected String var072;
	protected String var073;
	protected String var074;
	protected String var075;
	protected String var076;
	protected String var077;
	protected String var078;
	protected String var079;
	protected String var080;
	protected String var081;
	protected String var082;
	protected String var083;
	protected String var084;
	protected String var085;
	protected String var086;
	protected String var087;
	protected String var088;
	protected String var089;
	protected String var090;
	protected String var091;
	protected String var092;
	protected String var093;
	protected String var094;
	protected String var095;
	protected String var096;
	protected String var097;
	protected String var098;
	protected String var099;
	protected String var100;
	
	public AsrDetailPartDAdHocSet (){
		
	}
	public static AsrDetailPartDAdHocSet getInstance(String type, String name){
		if (type.equals(PartDEnum.OIG.name())){
			return new AsrDetailPartDAdHocSetOig();
		}
		if (type.equals(PartDEnum.OIG2.name())){
			return new AsrDetailPartDAdHocSetOig2();
		}
		if (type.equals(PartDEnum.HAR.name()) && name.toLowerCase().contains("hospice")){
			return new AsrDetailPartDAdHocSetHar();
		}
		return new AsrDetailPartDAdHocSet();
	}
	public String getAdhocRptNm() {
		return adhocRptNm;
	}
	public void setAdhocRptNm(String adhocRptNm) {
		this.adhocRptNm = adhocRptNm;
	}
	public String getVar032Nm() {
		return var032Nm;
	}
	public void setVar032Nm(String var032Nm) {
		this.var032Nm = var032Nm;
	}
	public String getVar033Nm() {
		return var033Nm;
	}
	public void setVar033Nm(String var033Nm) {
		this.var033Nm = var033Nm;
	}
	public String getVar034Nm() {
		return var034Nm;
	}
	public void setVar034Nm(String var034Nm) {
		this.var034Nm = var034Nm;
	}
	public String getVar035Nm() {
		return var035Nm;
	}
	public void setVar035Nm(String var035Nm) {
		this.var035Nm = var035Nm;
	}
	public String getVar036Nm() {
		return var036Nm;
	}
	public void setVar036Nm(String var036Nm) {
		this.var036Nm = var036Nm;
	}
	public String getVar037Nm() {
		return var037Nm;
	}
	public void setVar037Nm(String var037Nm) {
		this.var037Nm = var037Nm;
	}
	public String getVar038Nm() {
		return var038Nm;
	}
	public void setVar038Nm(String var038Nm) {
		this.var038Nm = var038Nm;
	}
	public String getVar039Nm() {
		return var039Nm;
	}
	public void setVar039Nm(String var039Nm) {
		this.var039Nm = var039Nm;
	}
	public String getVar040Nm() {
		return var040Nm;
	}
	public void setVar040Nm(String var040Nm) {
		this.var040Nm = var040Nm;
	}
	public String getVar041Nm() {
		return var041Nm;
	}
	public void setVar041Nm(String var041Nm) {
		this.var041Nm = var041Nm;
	}
	public String getVar042Nm() {
		return var042Nm;
	}
	public void setVar042Nm(String var042Nm) {
		this.var042Nm = var042Nm;
	}
	public String getVar043Nm() {
		return var043Nm;
	}
	public void setVar043Nm(String var043Nm) {
		this.var043Nm = var043Nm;
	}
	public String getVar044Nm() {
		return var044Nm;
	}
	public void setVar044Nm(String var044Nm) {
		this.var044Nm = var044Nm;
	}
	public String getVar045Nm() {
		return var045Nm;
	}
	public void setVar045Nm(String var045Nm) {
		this.var045Nm = var045Nm;
	}
	public String getVar046Nm() {
		return var046Nm;
	}
	public void setVar046Nm(String var046Nm) {
		this.var046Nm = var046Nm;
	}
	public String getVar047Nm() {
		return var047Nm;
	}
	public void setVar047Nm(String var047Nm) {
		this.var047Nm = var047Nm;
	}
	public String getVar048Nm() {
		return var048Nm;
	}
	public void setVar048Nm(String var048Nm) {
		this.var048Nm = var048Nm;
	}
	public String getVar049Nm() {
		return var049Nm;
	}
	public void setVar049Nm(String var049Nm) {
		this.var049Nm = var049Nm;
	}
	public String getVar050Nm() {
		return var050Nm;
	}
	public void setVar050Nm(String var050Nm) {
		this.var050Nm = var050Nm;
	}
	public String getVar051Nm() {
		return var051Nm;
	}
	public void setVar051Nm(String var051Nm) {
		this.var051Nm = var051Nm;
	}
	public String getVar052Nm() {
		return var052Nm;
	}
	public void setVar052Nm(String var052Nm) {
		this.var052Nm = var052Nm;
	}
	public String getVar053Nm() {
		return var053Nm;
	}
	public void setVar053Nm(String var053Nm) {
		this.var053Nm = var053Nm;
	}
	public String getVar054Nm() {
		return var054Nm;
	}
	public void setVar054Nm(String var054Nm) {
		this.var054Nm = var054Nm;
	}
	public String getVar055Nm() {
		return var055Nm;
	}
	public void setVar055Nm(String var055Nm) {
		this.var055Nm = var055Nm;
	}
	public String getVar056Nm() {
		return var056Nm;
	}
	public void setVar056Nm(String var056Nm) {
		this.var056Nm = var056Nm;
	}
	public String getVar057Nm() {
		return var057Nm;
	}
	public void setVar057Nm(String var057Nm) {
		this.var057Nm = var057Nm;
	}
	public String getVar058Nm() {
		return var058Nm;
	}
	public void setVar058Nm(String var058Nm) {
		this.var058Nm = var058Nm;
	}
	public String getVar059Nm() {
		return var059Nm;
	}
	public void setVar059Nm(String var059Nm) {
		this.var059Nm = var059Nm;
	}
	public String getVar060Nm() {
		return var060Nm;
	}
	public void setVar060Nm(String var060Nm) {
		this.var060Nm = var060Nm;
	}
	public String getVar061Nm() {
		return var061Nm;
	}
	public void setVar061Nm(String var061Nm) {
		this.var061Nm = var061Nm;
	}
	public String getVar062Nm() {
		return var062Nm;
	}
	public void setVar062Nm(String var062Nm) {
		this.var062Nm = var062Nm;
	}
	public String getVar063Nm() {
		return var063Nm;
	}
	public void setVar063Nm(String var063Nm) {
		this.var063Nm = var063Nm;
	}
	public String getVar064Nm() {
		return var064Nm;
	}
	public void setVar064Nm(String var064Nm) {
		this.var064Nm = var064Nm;
	}
	public String getVar065Nm() {
		return var065Nm;
	}
	public void setVar065Nm(String var065Nm) {
		this.var065Nm = var065Nm;
	}
	public String getVar066Nm() {
		return var066Nm;
	}
	public void setVar066Nm(String var066Nm) {
		this.var066Nm = var066Nm;
	}
	public String getVar067Nm() {
		return var067Nm;
	}
	public void setVar067Nm(String var067Nm) {
		this.var067Nm = var067Nm;
	}
	public String getVar068Nm() {
		return var068Nm;
	}
	public void setVar068Nm(String var068Nm) {
		this.var068Nm = var068Nm;
	}
	public String getVar069Nm() {
		return var069Nm;
	}
	public void setVar069Nm(String var069Nm) {
		this.var069Nm = var069Nm;
	}
	public String getVar070Nm() {
		return var070Nm;
	}
	public void setVar070Nm(String var070Nm) {
		this.var070Nm = var070Nm;
	}
	public String getVar071Nm() {
		return var071Nm;
	}
	public void setVar071Nm(String var071Nm) {
		this.var071Nm = var071Nm;
	}
	public String getVar072Nm() {
		return var072Nm;
	}
	public void setVar072Nm(String var072Nm) {
		this.var072Nm = var072Nm;
	}
	public String getVar073Nm() {
		return var073Nm;
	}
	public void setVar073Nm(String var073Nm) {
		this.var073Nm = var073Nm;
	}
	public String getVar074Nm() {
		return var074Nm;
	}
	public void setVar074Nm(String var074Nm) {
		this.var074Nm = var074Nm;
	}
	public String getVar075Nm() {
		return var075Nm;
	}
	public void setVar075Nm(String var075Nm) {
		this.var075Nm = var075Nm;
	}
	public String getVar076Nm() {
		return var076Nm;
	}
	public void setVar076Nm(String var076Nm) {
		this.var076Nm = var076Nm;
	}
	public String getVar077Nm() {
		return var077Nm;
	}
	public void setVar077Nm(String var077Nm) {
		this.var077Nm = var077Nm;
	}
	public String getVar078Nm() {
		return var078Nm;
	}
	public void setVar078Nm(String var078Nm) {
		this.var078Nm = var078Nm;
	}
	public String getVar079Nm() {
		return var079Nm;
	}
	public void setVar079Nm(String var079Nm) {
		this.var079Nm = var079Nm;
	}
	public String getVar080Nm() {
		return var080Nm;
	}
	public void setVar080Nm(String var080Nm) {
		this.var080Nm = var080Nm;
	}
	public String getVar081Nm() {
		return var081Nm;
	}
	public void setVar081Nm(String var081Nm) {
		this.var081Nm = var081Nm;
	}
	public String getVar082Nm() {
		return var082Nm;
	}
	public void setVar082Nm(String var082Nm) {
		this.var082Nm = var082Nm;
	}
	public String getVar083Nm() {
		return var083Nm;
	}
	public void setVar083Nm(String var083Nm) {
		this.var083Nm = var083Nm;
	}
	public String getVar084Nm() {
		return var084Nm;
	}
	public void setVar084Nm(String var084Nm) {
		this.var084Nm = var084Nm;
	}
	public String getVar085Nm() {
		return var085Nm;
	}
	public void setVar085Nm(String var085Nm) {
		this.var085Nm = var085Nm;
	}
	public String getVar086Nm() {
		return var086Nm;
	}
	public void setVar086Nm(String var086Nm) {
		this.var086Nm = var086Nm;
	}
	public String getVar087Nm() {
		return var087Nm;
	}
	public void setVar087Nm(String var087Nm) {
		this.var087Nm = var087Nm;
	}
	public String getVar088Nm() {
		return var088Nm;
	}
	public void setVar088Nm(String var088Nm) {
		this.var088Nm = var088Nm;
	}
	public String getVar089Nm() {
		return var089Nm;
	}
	public void setVar089Nm(String var089Nm) {
		this.var089Nm = var089Nm;
	}
	public String getVar090Nm() {
		return var090Nm;
	}
	public void setVar090Nm(String var090Nm) {
		this.var090Nm = var090Nm;
	}
	public String getVar091Nm() {
		return var091Nm;
	}
	public void setVar091Nm(String var091Nm) {
		this.var091Nm = var091Nm;
	}
	public String getVar092Nm() {
		return var092Nm;
	}
	public void setVar092Nm(String var092Nm) {
		this.var092Nm = var092Nm;
	}
	public String getVar093Nm() {
		return var093Nm;
	}
	public void setVar093Nm(String var093Nm) {
		this.var093Nm = var093Nm;
	}
	public String getVar094Nm() {
		return var094Nm;
	}
	public void setVar094Nm(String var094Nm) {
		this.var094Nm = var094Nm;
	}
	public String getVar095Nm() {
		return var095Nm;
	}
	public void setVar095Nm(String var095Nm) {
		this.var095Nm = var095Nm;
	}
	public String getVar096Nm() {
		return var096Nm;
	}
	public void setVar096Nm(String var096Nm) {
		this.var096Nm = var096Nm;
	}
	public String getVar097Nm() {
		return var097Nm;
	}
	public void setVar097Nm(String var097Nm) {
		this.var097Nm = var097Nm;
	}
	public String getVar098Nm() {
		return var098Nm;
	}
	public void setVar098Nm(String var098Nm) {
		this.var098Nm = var098Nm;
	}
	public String getVar099Nm() {
		return var099Nm;
	}
	public void setVar099Nm(String var099Nm) {
		this.var099Nm = var099Nm;
	}
	public String getVar100Nm() {
		return var100Nm;
	}
	public void setVar100Nm(String var100Nm) {
		this.var100Nm = var100Nm;
	}
	public String getVar062() {
		return var062;
	}
	public void setVar062(String var062) {
		this.var062 = var062;
	}
	public String getVar032() {
		return var032;
	}
	public void setVar032(String var032) {
		this.var032 = var032;
	}
	public String getVar033() {
		return var033;
	}
	public void setVar033(String var033) {
		this.var033 = var033;
	}
	public String getVar034() {
		return var034;
	}
	public void setVar034(String var034) {
		this.var034 = var034;
	}
	public String getVar035() {
		return var035;
	}
	public void setVar035(String var035) {
		this.var035 = var035;
	}
	public String getVar036() {
		return var036;
	}
	public void setVar036(String var036) {
		this.var036 = var036;
	}
	public String getVar037() {
		return var037;
	}
	public void setVar037(String var037) {
		this.var037 = var037;
	}
	public String getVar038() {
		return var038;
	}
	public void setVar038(String var038) {
		this.var038 = var038;
	}
	public String getVar039() {
		return var039;
	}
	public void setVar039(String var039) {
		this.var039 = var039;
	}
	public String getVar040() {
		return var040;
	}
	public void setVar040(String var040) {
		this.var040 = var040;
	}
	public String getVar041() {
		return var041;
	}
	public void setVar041(String var041) {
		this.var041 = var041;
	}
	public String getVar042() {
		return var042;
	}
	public void setVar042(String var042) {
		this.var042 = var042;
	}
	public String getVar043() {
		return var043;
	}
	public void setVar043(String var043) {
		this.var043 = var043;
	}
	public String getVar044() {
		return var044;
	}
	public void setVar044(String var044) {
		this.var044 = var044;
	}
	public String getVar045() {
		return var045;
	}
	public void setVar045(String var045) {
		this.var045 = var045;
	}
	public String getVar046() {
		return var046;
	}
	public void setVar046(String var046) {
		this.var046 = var046;
	}
	public String getVar047() {
		return var047;
	}
	public void setVar047(String var047) {
		this.var047 = var047;
	}
	public String getVar048() {
		return var048;
	}
	public void setVar048(String var048) {
		this.var048 = var048;
	}
	public String getVar049() {
		return var049;
	}
	public void setVar049(String var049) {
		this.var049 = var049;
	}
	public String getVar050() {
		return var050;
	}
	public void setVar050(String var050) {
		this.var050 = var050;
	}
	public String getVar051() {
		return var051;
	}
	public void setVar051(String var051) {
		this.var051 = var051;
	}
	public String getVar052() {
		return var052;
	}
	public void setVar052(String var052) {
		this.var052 = var052;
	}
	public String getVar053() {
		return var053;
	}
	public void setVar053(String var053) {
		this.var053 = var053;
	}
	public String getVar054() {
		return var054;
	}
	public void setVar054(String var054) {
		this.var054 = var054;
	}
	public String getVar055() {
		return var055;
	}
	public void setVar055(String var055) {
		this.var055 = var055;
	}
	public String getVar056() {
		return var056;
	}
	public void setVar056(String var056) {
		this.var056 = var056;
	}
	public String getVar057() {
		return var057;
	}
	public void setVar057(String var057) {
		this.var057 = var057;
	}
	public String getVar058() {
		return var058;
	}
	public void setVar058(String var058) {
		this.var058 = var058;
	}
	public String getVar059() {
		return var059;
	}
	public void setVar059(String var059) {
		this.var059 = var059;
	}
	public String getVar060() {
		return var060;
	}
	public void setVar060(String var060) {
		this.var060 = var060;
	}
	public String getVar061() {
		return var061;
	}
	public void setVar061(String var061) {
		this.var061 = var061;
	}
	public String getVar063() {
		return var063;
	}
	public void setVar063(String var063) {
		this.var063 = var063;
	}
	public String getVar064() {
		return var064;
	}
	public void setVar064(String var064) {
		this.var064 = var064;
	}
	public String getVar065() {
		return var065;
	}
	public void setVar065(String var065) {
		this.var065 = var065;
	}
	public String getVar066() {
		return var066;
	}
	public void setVar066(String var066) {
		this.var066 = var066;
	}
	public String getVar067() {
		return var067;
	}
	public void setVar067(String var067) {
		this.var067 = var067;
	}
	public String getVar068() {
		return var068;
	}
	public void setVar068(String var068) {
		this.var068 = var068;
	}
	public String getVar069() {
		return var069;
	}
	public void setVar069(String var069) {
		this.var069 = var069;
	}
	public String getVar070() {
		return var070;
	}
	public void setVar070(String var070) {
		this.var070 = var070;
	}
	public String getVar071() {
		return var071;
	}
	public void setVar071(String var071) {
		this.var071 = var071;
	}
	public String getVar072() {
		return var072;
	}
	public void setVar072(String var072) {
		this.var072 = var072;
	}
	public String getVar073() {
		return var073;
	}
	public void setVar073(String var073) {
		this.var073 = var073;
	}
	public String getVar074() {
		return var074;
	}
	public void setVar074(String var074) {
		this.var074 = var074;
	}
	public String getVar075() {
		return var075;
	}
	public void setVar075(String var075) {
		this.var075 = var075;
	}
	public String getVar076() {
		return var076;
	}
	public void setVar076(String var076) {
		this.var076 = var076;
	}
	public String getVar077() {
		return var077;
	}
	public void setVar077(String var077) {
		this.var077 = var077;
	}
	public String getVar078() {
		return var078;
	}
	public void setVar078(String var078) {
		this.var078 = var078;
	}
	public String getVar079() {
		return var079;
	}
	public void setVar079(String var079) {
		this.var079 = var079;
	}
	public String getVar080() {
		return var080;
	}
	public void setVar080(String var080) {
		this.var080 = var080;
	}
	public String getVar081() {
		return var081;
	}
	public void setVar081(String var081) {
		this.var081 = var081;
	}
	public String getVar082() {
		return var082;
	}
	public void setVar082(String var082) {
		this.var082 = var082;
	}
	public String getVar083() {
		return var083;
	}
	public void setVar083(String var083) {
		this.var083 = var083;
	}
	public String getVar084() {
		return var084;
	}
	public void setVar084(String var084) {
		this.var084 = var084;
	}
	public String getVar085() {
		return var085;
	}
	public void setVar085(String var085) {
		this.var085 = var085;
	}
	public String getVar086() {
		return var086;
	}
	public void setVar086(String var086) {
		this.var086 = var086;
	}
	public String getVar087() {
		return var087;
	}
	public void setVar087(String var087) {
		this.var087 = var087;
	}
	public String getVar088() {
		return var088;
	}
	public void setVar088(String var088) {
		this.var088 = var088;
	}
	public String getVar089() {
		return var089;
	}
	public void setVar089(String var089) {
		this.var089 = var089;
	}
	public String getVar090() {
		return var090;
	}
	public void setVar090(String var090) {
		this.var090 = var090;
	}
	public String getVar091() {
		return var091;
	}
	public void setVar091(String var091) {
		this.var091 = var091;
	}
	public String getVar092() {
		return var092;
	}
	public void setVar092(String var092) {
		this.var092 = var092;
	}
	public String getVar093() {
		return var093;
	}
	public void setVar093(String var093) {
		this.var093 = var093;
	}
	public String getVar094() {
		return var094;
	}
	public void setVar094(String var094) {
		this.var094 = var094;
	}
	public String getVar095() {
		return var095;
	}
	public void setVar095(String var095) {
		this.var095 = var095;
	}
	public String getVar096() {
		return var096;
	}
	public void setVar096(String var096) {
		this.var096 = var096;
	}
	public String getVar097() {
		return var097;
	}
	public void setVar097(String var097) {
		this.var097 = var097;
	}
	public String getVar098() {
		return var098;
	}
	public void setVar098(String var098) {
		this.var098 = var098;
	}
	public String getVar099() {
		return var099;
	}
	public void setVar099(String var099) {
		this.var099 = var099;
	}
	public String getVar100() {
		return var100;
	}
	public void setVar100(String var100) {
		this.var100 = var100;
	}
	public String getVar006Nm() {
		return var006Nm;
	}
	public void setVar006Nm(String var006Nm) {
		this.var006Nm = var006Nm;
	}
	public String getVar007Nm() {
		return var007Nm;
	}
	public void setVar007Nm(String var007Nm) {
		this.var007Nm = var007Nm;
	}
	public String getVar008Nm() {
		return var008Nm;
	}
	public void setVar008Nm(String var008Nm) {
		this.var008Nm = var008Nm;
	}
	public String getVar009Nm() {
		return var009Nm;
	}
	public void setVar009Nm(String var009Nm) {
		this.var009Nm = var009Nm;
	}
	public String getVar010Nm() {
		return var010Nm;
	}
	public void setVar010Nm(String var010Nm) {
		this.var010Nm = var010Nm;
	}
	public String getVar011Nm() {
		return var011Nm;
	}
	public void setVar011Nm(String var011Nm) {
		this.var011Nm = var011Nm;
	}
	public String getVar012Nm() {
		return var012Nm;
	}
	public void setVar012Nm(String var012Nm) {
		this.var012Nm = var012Nm;
	}
	public String getVar013Nm() {
		return var013Nm;
	}
	public void setVar013Nm(String var013Nm) {
		this.var013Nm = var013Nm;
	}
	public String getVar014Nm() {
		return var014Nm;
	}
	public void setVar014Nm(String var014Nm) {
		this.var014Nm = var014Nm;
	}
	public String getVar015Nm() {
		return var015Nm;
	}
	public void setVar015Nm(String var015Nm) {
		this.var015Nm = var015Nm;
	}
	public String getVar016Nm() {
		return var016Nm;
	}
	public void setVar016Nm(String var016Nm) {
		this.var016Nm = var016Nm;
	}
	public String getVar017Nm() {
		return var017Nm;
	}
	public void setVar017Nm(String var017Nm) {
		this.var017Nm = var017Nm;
	}
	public String getVar018Nm() {
		return var018Nm;
	}
	public void setVar018Nm(String var018Nm) {
		this.var018Nm = var018Nm;
	}
	public String getVar019Nm() {
		return var019Nm;
	}
	public void setVar019Nm(String var019Nm) {
		this.var019Nm = var019Nm;
	}
	public String getVar020Nm() {
		return var020Nm;
	}
	public void setVar020Nm(String var020Nm) {
		this.var020Nm = var020Nm;
	}
	public String getVar021Nm() {
		return var021Nm;
	}
	public void setVar021Nm(String var021Nm) {
		this.var021Nm = var021Nm;
	}
	public String getVar022Nm() {
		return var022Nm;
	}
	public void setVar022Nm(String var022Nm) {
		this.var022Nm = var022Nm;
	}
	public String getVar023Nm() {
		return var023Nm;
	}
	public void setVar023Nm(String var023Nm) {
		this.var023Nm = var023Nm;
	}
	public String getVar024Nm() {
		return var024Nm;
	}
	public void setVar024Nm(String var024Nm) {
		this.var024Nm = var024Nm;
	}
	public String getVar025Nm() {
		return var025Nm;
	}
	public void setVar025Nm(String var025Nm) {
		this.var025Nm = var025Nm;
	}
	public String getVar026Nm() {
		return var026Nm;
	}
	public void setVar026Nm(String var026Nm) {
		this.var026Nm = var026Nm;
	}
	public String getVar027Nm() {
		return var027Nm;
	}
	public void setVar027Nm(String var027Nm) {
		this.var027Nm = var027Nm;
	}
	public String getVar028Nm() {
		return var028Nm;
	}
	public void setVar028Nm(String var028Nm) {
		this.var028Nm = var028Nm;
	}
	public String getVar029Nm() {
		return var029Nm;
	}
	public void setVar029Nm(String var029Nm) {
		this.var029Nm = var029Nm;
	}
	public String getVar030Nm() {
		return var030Nm;
	}
	public void setVar030Nm(String var030Nm) {
		this.var030Nm = var030Nm;
	}
	public String getVar031Nm() {
		return var031Nm;
	}
	public void setVar031Nm(String var031Nm) {
		this.var031Nm = var031Nm;
	}
	public String getVar006() {
		return var006;
	}
	public void setVar006(String var006) {
		this.var006 = var006;
	}
	public String getVar007() {
		return var007;
	}
	public void setVar007(String var007) {
		this.var007 = var007;
	}
	public String getVar008() {
		return var008;
	}
	public void setVar008(String var008) {
		this.var008 = var008;
	}
	public String getVar009() {
		return var009;
	}
	public void setVar009(String var009) {
		this.var009 = var009;
	}
	public String getVar010() {
		return var010;
	}
	public void setVar010(String var010) {
		this.var010 = var010;
	}
	public String getVar011() {
		return var011;
	}
	public void setVar011(String var011) {
		this.var011 = var011;
	}
	public String getVar012() {
		return var012;
	}
	public void setVar012(String var012) {
		this.var012 = var012;
	}
	public String getVar013() {
		return var013;
	}
	public void setVar013(String var013) {
		this.var013 = var013;
	}
	public String getVar014() {
		return var014;
	}
	public void setVar014(String var014) {
		this.var014 = var014;
	}
	public String getVar015() {
		return var015;
	}
	public void setVar015(String var015) {
		this.var015 = var015;
	}
	public String getVar016() {
		return var016;
	}
	public void setVar016(String var016) {
		this.var016 = var016;
	}
	public String getVar017() {
		return var017;
	}
	public void setVar017(String var017) {
		this.var017 = var017;
	}
	public String getVar018() {
		return var018;
	}
	public void setVar018(String var018) {
		this.var018 = var018;
	}
	public String getVar019() {
		return var019;
	}
	public void setVar019(String var019) {
		this.var019 = var019;
	}
	public String getVar020() {
		return var020;
	}
	public void setVar020(String var020) {
		this.var020 = var020;
	}
	public String getVar021() {
		return var021;
	}
	public void setVar021(String var021) {
		this.var021 = var021;
	}
	public String getVar022() {
		return var022;
	}
	public void setVar022(String var022) {
		this.var022 = var022;
	}
	public String getVar023() {
		return var023;
	}
	public void setVar023(String var023) {
		this.var023 = var023;
	}
	public String getVar024() {
		return var024;
	}
	public void setVar024(String var024) {
		this.var024 = var024;
	}
	public String getVar025() {
		return var025;
	}
	public void setVar025(String var025) {
		this.var025 = var025;
	}
	public String getVar026() {
		return var026;
	}
	public void setVar026(String var026) {
		this.var026 = var026;
	}
	public String getVar027() {
		return var027;
	}
	public void setVar027(String var027) {
		this.var027 = var027;
	}
	public String getVar028() {
		return var028;
	}
	public void setVar028(String var028) {
		this.var028 = var028;
	}
	public String getVar029() {
		return var029;
	}
	public void setVar029(String var029) {
		this.var029 = var029;
	}
	public String getVar030() {
		return var030;
	}
	public void setVar030(String var030) {
		this.var030 = var030;
	}
	public String getVar031() {
		return var031;
	}
	public void setVar031(String var031) {
		this.var031 = var031;
	}
}
