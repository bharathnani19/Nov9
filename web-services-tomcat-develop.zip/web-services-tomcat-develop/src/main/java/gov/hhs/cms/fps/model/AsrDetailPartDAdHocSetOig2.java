package gov.hhs.cms.fps.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import gov.hhs.cms.fps.config.PartDColumnFormat;
import gov.hhs.cms.fps.util.FpsEnums.PartDFormat;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.ANY)
@JsonInclude(Include.NON_NULL)
public class AsrDetailPartDAdHocSetOig2 extends AsrDetailPartDAdHocSet {
	

	
	public String getAdhocRptNm() {
		return adhocRptNm;
	}
	public void setAdhocRptNm(String adhocRptNm) {
		this.adhocRptNm = adhocRptNm;
	}
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var006Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var007Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var008Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var009Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var010Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var011Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var012Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var013Fmt;
	@PartDColumnFormat(format=PartDFormat.STR) //STR
	private String var014Fmt;
	@PartDColumnFormat(format=PartDFormat.STR) //STR
	private String var015Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var016Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var017Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var018Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var019Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var020Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var021Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var022Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var023Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var024Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var025Fmt;
	@PartDColumnFormat(format=PartDFormat.STR)
	private String var026Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var027Fmt;
	@PartDColumnFormat(format=PartDFormat.DATE)
	private String var028Fmt;
	@PartDColumnFormat(format=PartDFormat.DATE)
	private String var029Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var030Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var031Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var032Fmt;

	@PartDColumnFormat(format=PartDFormat.INT)
	private String var033Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var034Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var035Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String  var036Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String  var037Fmt;
	
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var038Fmt;
	
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var039Fmt;

	@PartDColumnFormat(format=PartDFormat.INT)
	private String var040Fmt;
 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var041Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var042Fmt;
 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var043Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var044Fmt;
 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var045Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var046Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var047Fmt;
	
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var048Fmt;
 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var049Fmt;
	 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var050Fmt;
	 
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var051Fmt;
	 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var052Fmt;

	@PartDColumnFormat(format=PartDFormat.INT)
	private String var053Fmt;
	 
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var054Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var055Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var056Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var057Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var058Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var059Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var060Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var061Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var062Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var063Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var064Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var065Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var066Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var067Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var068Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var069Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var070Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var071Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var072Fmt;
	@PartDColumnFormat(format=PartDFormat.INT)
	private String var073Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var074Fmt;
	@PartDColumnFormat(format=PartDFormat.DOLLAR)
	private String var075Fmt;
	@PartDColumnFormat(format=PartDFormat.DOLLAR)
	private String var076Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var077Fmt;
	@PartDColumnFormat(format=PartDFormat.DOLLAR)
	private String var078Fmt;
	@PartDColumnFormat(format=PartDFormat.DOLLAR)
	private String var079Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var080Fmt;
	@PartDColumnFormat(format=PartDFormat.DOLLAR)
	private String var081Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var082Fmt;
	@PartDColumnFormat(format=PartDFormat.DOLLAR)
	private String var083Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var084Fmt;
	@PartDColumnFormat(format=PartDFormat.DOLLAR)
	private String var085Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var086Fmt;
	@PartDColumnFormat(format=PartDFormat.DOLLAR)
	private String var087Fmt;
	@PartDColumnFormat(format=PartDFormat.PCT)
	private String var088Fmt;
	private String var089Fmt;
	private String var090Fmt;
	private String var091Fmt;
	private String var092Fmt;
	private String var093Fmt;
	private String var094Fmt;
	private String var095Fmt;
	private String var096Fmt;
	private String var097Fmt;
	private String var098Fmt;
	private String var099Fmt;
	private String var100Fmt;
}
