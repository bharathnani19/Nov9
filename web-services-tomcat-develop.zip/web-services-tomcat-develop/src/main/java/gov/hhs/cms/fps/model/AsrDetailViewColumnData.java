/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
// TODO: Auto-generated Javadoc

/**
 * The Class AsrDetailViewColumnData.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailViewColumnData implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7834702464111298712L;
	
	/** The data fields. */
	private HashMap<String,String> dataFields = new HashMap<String,String>();


	/**
	 * Adds the.
	 *
	 * @param key the key
	 * @param value the value
	 */
	public void add(String key, String value){
		dataFields.put(key, value);
	}
	

}
