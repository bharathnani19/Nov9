/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
// TODO: Auto-generated Javadoc

/**
 * The Class AsrDetailViewResponse.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailViewCustomResponse  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1766391575720920055L;
	
	/** The transaction ID. */
	private String transactionID;
	
	/** The status. */
	private String status;
	
	/** The status description type. */
	private String statusDescription;
	
	/** The response data. */
	private AsrDetailViewData responseData;
	
	/**
	 * Gets the transaction ID.
	 *
	 * @return the transaction ID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	
	/**
	 * Sets the transaction ID.
	 *
	 * @param transactionID the new transaction ID
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the response type.
	 *
	 * @return the responseType
	 */
	public String getStatusDescription() {
		return statusDescription;
	}
	
	/**
	 * Sets the response type.
	 *
	 * @param responseType the responseType to set
	 */
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	
	/**
	 * Gets the response data.
	 *
	 * @return the responseData
	 */
	public AsrDetailViewData getResponseData() {
		return responseData;
	}
	
	/**
	 * Sets the response data.
	 *
	 * @param responseData the responseData to set
	 */
	public void setResponseData(AsrDetailViewData responseData) {
		this.responseData = responseData;
	}
	
	
}
