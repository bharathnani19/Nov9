/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailViewData.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailViewData extends BaseObject implements Serializable  {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3696213403912463045L;
	
	/** The tabs. */
	private List<AsrDetailViewDataItem> tabs = new ArrayList<AsrDetailViewDataItem>();
	
	/**
	 * Gets the tabs.
	 *
	 * @return the tabs
	 */
	public List<AsrDetailViewDataItem> getTabs() {
		return tabs;
	}
	
	/**
	 * Sets the tabs.
	 *
	 * @param tabs the tabs to set
	 */
	public void setTabs(List<AsrDetailViewDataItem> tabs) {
		this.tabs = tabs;
	}
	
	/**
	 * Adds the tab.
	 *
	 * @param tab the tab
	 */
	public void addTab(AsrDetailViewDataItem tab){
		tabs.add(tab);
	}
	
	public void addTabs(List<AsrDetailViewDataItem> tabs){
		this.tabs.addAll(tabs);
	}

	
}
