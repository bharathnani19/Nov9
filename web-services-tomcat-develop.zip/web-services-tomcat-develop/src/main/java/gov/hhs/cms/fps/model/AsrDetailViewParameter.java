/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailViewParameter.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailViewParameter  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5680814436894391521L;
	
	/** The asr. */
	private List<Integer> asr;
	
	/** The displayformat. */
	private String displayformat;
	
	private String tab;

	private String model;
	private Integer rptCardSqncNum;
	/**
	 * Gets the asr.
	 *
	 * @return the asr
	 */
	public List<Integer> getAsr() {
		return asr;
	}
	
	/**
	 * Sets the asr.
	 *
	 * @param asr the asr to set
	 */
	public void setAsr(List<Integer> asr) {
		this.asr = asr;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AsrDetailViewParameter [asr=" + asr + "]";
	}
	
	/**
	 * Gets the displayformat.
	 *
	 * @return the displayformat
	 */
	public String getDisplayformat() {
		return displayformat;
	}
	
	/**
	 * Sets the displayformat.
	 *
	 * @param displayformat the displayformat to set
	 */
	public void setDisplayformat(String displayformat) {
		this.displayformat = displayformat;
	}

	public String getTab() {
		return tab;
	}

	public void setTab(String tab) {
		this.tab = tab;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Integer getRptCardSqncNum() {
		return rptCardSqncNum;
	}

	public void setRptCardSqncNum(Integer rptCardSqncNum) {
		this.rptCardSqncNum = rptCardSqncNum;
	}
	
	
}
