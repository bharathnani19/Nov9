/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDetailViewRequest.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDetailViewRequest implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9115744605609812948L;
	
	/** The system name. */
	private String systemName;
	
	/** The request type. */
	private String requestType;
	
	/** The request sub type. */
	private String requestSubType;
	
	/** The parameters. */
	private AsrDetailViewParameter parameters;
	
	/** The transaction ID. */
	//key:value
	private String transactionID;
	
	/**
	 * Gets the system name.
	 *
	 * @return the systemName
	 */
	public String getSystemName() {
		return systemName;
	}
	
	/**
	 * Sets the system name.
	 *
	 * @param systemName the systemName to set
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	
	/**
	 * Gets the request type.
	 *
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	
	/**
	 * Sets the request type.
	 *
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	/**
	 * Gets the request sub type.
	 *
	 * @return the requestSubType
	 */
	public String getRequestSubType() {
		return requestSubType;
	}
	
	/**
	 * Sets the request sub type.
	 *
	 * @param requestSubType the requestSubType to set
	 */
	public void setRequestSubType(String requestSubType) {
		this.requestSubType = requestSubType;
	}
	
	/**
	 * Gets the transaction ID.
	 *
	 * @return the transactionID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	
	/**
	 * Sets the transaction ID.
	 *
	 * @param transactionID the transactionID to set
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	/**
	 * Gets the parameters.
	 *
	 * @return the parameters
	 */
	public AsrDetailViewParameter getParameters() {
		return parameters;
	}
	
	/**
	 * Sets the parameters.
	 *
	 * @param parameters the parameters to set
	 */
	public void setParameters(AsrDetailViewParameter parameters) {
		this.parameters = parameters;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AsrDetailViewRequest [systemName=" + systemName
				+ ", requestType=" + requestType + ", requestSubType="
				+ requestSubType + ", parameters=" + parameters
				+ ", transactionID=" + transactionID + "]";
	}

	
}
