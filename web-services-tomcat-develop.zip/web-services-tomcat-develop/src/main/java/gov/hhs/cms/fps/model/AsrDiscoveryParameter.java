/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrDiscoveryParameter.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDiscoveryParameter  extends BaseSearchParameter implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5040288069253217212L;
	
	public AsrDiscoveryParameter(){
		super();
	}

}
