package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrDiscoveryResponse  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7304361723231342657L;
	private String transactionID;
	private String status;
	private List<FpsCommon> responseData;
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the responseData
	 */
	public List<FpsCommon> getResponseData() {
		return responseData;
	}
	/**
	 * @param responseData the responseData to set
	 */
	public void setResponseData(List<FpsCommon> responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "AsrDiscoveryResponse [transactionID=" + transactionID
				+ ", status=" + status + ", responseData=" + responseData + "]";
	}
	
	
}
