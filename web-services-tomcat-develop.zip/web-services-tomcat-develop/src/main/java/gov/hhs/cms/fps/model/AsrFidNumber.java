package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class AsrFidNumber implements Serializable {
	private String fidNumber;

	public String getFidNumber() {
		return fidNumber;
	}

	public void setFidNumber(String fidNumber) {
		this.fidNumber = fidNumber;
	}
}
