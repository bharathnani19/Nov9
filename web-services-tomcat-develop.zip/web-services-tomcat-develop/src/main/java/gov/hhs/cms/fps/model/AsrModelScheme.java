package gov.hhs.cms.fps.model;

import java.io.Serializable;

public class AsrModelScheme implements Serializable {

	private final String code;
	private final String label;

	public AsrModelScheme(String code, String label) {
		this.code = code;
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}