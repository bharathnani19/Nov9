package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrPrioritizationModelItem implements Serializable {
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy/MM/dd", timezone="America/New_York")
	private Date createDt;
	private String modelBusnsId;
	private String prioritizedInd;
	private String status;
	private List<MdcdModelState> states;

	public Date getCreateDt() {
		return createDt;
	}
	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	public String getPrioritizedInd() {
		return prioritizedInd;
	}
	public void setPrioritizedInd(String prioritizedInd) {
		this.prioritizedInd = prioritizedInd;
	}
	public List<MdcdModelState> getStates() {
		return states;
	}
	public void setStates(List<MdcdModelState> states) {
		this.states = states;
	}
	@Override
	public String toString() {
		return "{\"" + (createDt != null ? "createDt\":\"" + createDt + "\", \"" : "")
				+ (modelBusnsId != null ? "modelBusnsId\":\"" + modelBusnsId + "\", \"" : "")
				+ (prioritizedInd != null ? "prioritizedInd\":\"" + prioritizedInd + "\", \"" : "")
				+ (states != null ? "states\":\"" + states : "") + "\"}";
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
