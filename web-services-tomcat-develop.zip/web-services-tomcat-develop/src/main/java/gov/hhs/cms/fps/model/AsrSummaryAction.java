/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummaryAction.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryAction  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -45483993735818545L;
	
	/** The action type cd. */
	private String actionTypeCd;
	
	/** The action type desc. */
	private String actionTypeDesc;
	private String source;
	
	/**
	 * Gets the action type cd.
	 *
	 * @return the action type cd
	 */
	public String getActionTypeCd() {
		return actionTypeCd;
	}
	
	/**
	 * Sets the action type cd.
	 *
	 * @param actionTypeCd the new action type cd
	 */
	public void setActionTypeCd(String actionTypeCd) {
		this.actionTypeCd = actionTypeCd;
	}
	
	/**
	 * Gets the action type desc.
	 *
	 * @return the action type desc
	 */
	public String getActionTypeDesc() {
		return actionTypeDesc;
	}
	
	/**
	 * Sets the action type desc.
	 *
	 * @param actionTypeDesc the new action type desc
	 */
	public void setActionTypeDesc(String actionTypeDesc) {
		this.actionTypeDesc = actionTypeDesc;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
}
