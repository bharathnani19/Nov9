/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummaryAlert.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryAlert  implements Serializable,Comparable<AsrSummaryAlert> {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5759854565569674242L;
	
	/** The alert type cd. */
	private String alertTypeCd;
	
	/** The alert type desc. */
	private String alertTypeDesc;
	
	private int alertId;
	
	private String alertDesc;
	
	private String alertStatusCd;
	
	private String modelName;
	
	private BigDecimal riskScore;
	
	/**
	 * Gets the alert type cd.
	 *
	 * @return the alert type cd
	 */
	public String getAlertTypeCd() {
		return alertTypeCd;
	}
	
	/**
	 * Sets the alert type cd.
	 *
	 * @param alertTypeCd the new alert type cd
	 */
	public void setAlertTypeCd(String alertTypeCd) {
		this.alertTypeCd = alertTypeCd;
	}
	
	/**
	 * Gets the alert type desc.
	 *
	 * @return the alert type desc
	 */
	public String getAlertTypeDesc() {
		return alertTypeDesc;
	}
	
	/**
	 * Sets the alert type desc.
	 *
	 * @param alertTypeDesc the new alert type desc
	 */
	public void setAlertTypeDesc(String alertTypeDesc) {
		this.alertTypeDesc = alertTypeDesc;
	}

	public int getAlertId() {
		return alertId;
	}

	public void setAlertId(int alertId) {
		this.alertId = alertId;
	}

	public String getAlertDesc() {
		return alertDesc;
	}

	public void setAlertDesc(String alertDesc) {
		this.alertDesc = alertDesc;
	}
	
	@Override
	public String toString(){
		return alertId+"";
	}

	public String getAlertStatusCd() {
		return alertStatusCd;
	}

	public void setAlertStatusCd(String alertStatusCd) {
		this.alertStatusCd = alertStatusCd;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	@Override
	public int compareTo(AsrSummaryAlert target) {
		
		return target.getAlertTypeCd().compareTo(this.getAlertTypeCd());
	}

	public BigDecimal getRiskScore() {
		return riskScore;
	}

	public void setRiskScore(BigDecimal riskScore) {
		this.riskScore = riskScore;
	}
}
