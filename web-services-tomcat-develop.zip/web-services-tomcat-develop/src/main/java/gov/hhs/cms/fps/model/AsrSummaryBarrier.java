package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryBarrier implements Serializable {

	private String barrierCd;
	private Integer leadInvestigationId;
	private String source;
	public String getBarrierCd() {
		return barrierCd;
	}
	public void setBarrierCd(String barrierCd) {
		this.barrierCd = barrierCd;
	}
	public Integer getLeadInvestigationId() {
		return leadInvestigationId;
	}
	public void setLeadInvestigationId(Integer leadInvestigationId) {
		this.leadInvestigationId = leadInvestigationId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((barrierCd == null) ? 0 : barrierCd.hashCode());
		result = prime * result + ((leadInvestigationId == null) ? 0 : leadInvestigationId.hashCode());
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AsrSummaryBarrier other = (AsrSummaryBarrier) obj;
		if (barrierCd == null) {
			if (other.barrierCd != null)
				return false;
		} else if (!barrierCd.equals(other.barrierCd))
			return false;
		if (leadInvestigationId == null) {
			if (other.leadInvestigationId != null)
				return false;
		} else if (!leadInvestigationId.equals(other.leadInvestigationId))
			return false;
		if (source == null) {
			if (other.source != null)
				return false;
		} else if (!source.equals(other.source))
			return false;
		return true;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
}
