package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryLeadInv implements Serializable {

	private String leadInvstNum;
	private String leadOpen;
	private String source;
	public String getLeadInvstNum() {
		return leadInvstNum;
	}
	public void setLeadInvstNum(String leadInvstNum) {
		this.leadInvstNum = leadInvstNum;
	}
	public String getLeadOpen() {
		return leadOpen;
	}
	public void setLeadOpen(String leadOpen) {
		this.leadOpen = leadOpen;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
}
