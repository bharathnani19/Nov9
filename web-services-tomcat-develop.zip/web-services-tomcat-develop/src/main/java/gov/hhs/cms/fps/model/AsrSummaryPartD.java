package gov.hhs.cms.fps.model;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryPartD  implements Serializable{
	
	private Integer count;
	private List<AsrSummaryPartDItem> items = new ArrayList<AsrSummaryPartDItem>();
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public List<AsrSummaryPartDItem> getItems() {
		return items;
	}
	public void setItems(List<AsrSummaryPartDItem> items) {
		this.items = items;
	}
	
}
