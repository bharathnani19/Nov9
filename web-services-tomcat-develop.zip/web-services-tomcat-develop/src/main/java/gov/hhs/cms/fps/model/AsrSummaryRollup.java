package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryRollup implements Serializable {

	private List<FpsUser> users = new ArrayList<FpsUser>();
	private List<AsrSummaryActivity> activitiess = new ArrayList<AsrSummaryActivity>();
	private List<FpsZone> assignedZones = new ArrayList<FpsZone>();
	private List<AsrSummaryBarrier> barrierCds = new ArrayList<AsrSummaryBarrier>();
	private List<AsrSummaryAlert> alerts = new ArrayList<AsrSummaryAlert>();
	private List<AsrSummaryAlert> currentAlerts = new ArrayList<AsrSummaryAlert>();
	private List<AsrSummaryAlert> recentAlerts = new ArrayList<AsrSummaryAlert>();
	private List<AsrSummaryAlert> priorityAlerts = new ArrayList<AsrSummaryAlert>();
	private List<AsrSummaryAction> actions = new ArrayList<AsrSummaryAction>();
	private List<AsrSummaryLeadInv> invs = new ArrayList<AsrSummaryLeadInv>();
	private List<AsrSummarySpecialty> specialties = new ArrayList<AsrSummarySpecialty>();
	private List<AsrSummaryProcedure> procedures = new ArrayList< AsrSummaryProcedure>();
	private List<AsrSummaryClaimType> claimTypes= new ArrayList< AsrSummaryClaimType>();
	private List<AsrGenericCode> drugClasses= new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> cityStates= new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> beneStates= new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> diagnoses= new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> hcpcs= new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> taxIds= new ArrayList<AsrGenericCode>();
	private List<FpsCommonPtan> ptans= new ArrayList<FpsCommonPtan>();
	private AsrSummaryPartD partD;
	private Integer crossoverCnt;
	private long ptanCount;
	private Date lastAlertDt;
	private boolean hasCurrentAlerts;
	private boolean hasRecentAlerts;
	private boolean hasMedicaid;
	private boolean hasMedic;
	public boolean isHasMedicaid() {
		return hasMedicaid;
	}
	public void setHasMedicaid(boolean hasMedicaid) {
		this.hasMedicaid = hasMedicaid;
	}
	public List<FpsUser> getUsers() {
		return users;
	}
	public void setUsers(List<FpsUser> users) {
		this.users = users;
	}
	public List<AsrSummaryActivity> getActivitiess() {
		return activitiess;
	}
	public void setActivitiess(List<AsrSummaryActivity> activitiess) {
		this.activitiess = activitiess;
	}
	public List<FpsZone> getAssignedZones() {
		return assignedZones;
	}
	public void setAssignedZones(List<FpsZone> assignedZones) {
		this.assignedZones = assignedZones;
	}
	public List<AsrSummaryBarrier> getBarrierCds() {
		return barrierCds;
	}
	public void setBarrierCds(List<AsrSummaryBarrier> barrierCds) {
		this.barrierCds = barrierCds;
	}
	public List<AsrSummaryAction> getActions() {
		return actions;
	}
	public void setActions(List<AsrSummaryAction> actions) {
		this.actions = actions;
	}
	public List<AsrSummaryLeadInv> getInvs() {
		return invs;
	}
	public void setInvs(List<AsrSummaryLeadInv> invs) {
		this.invs = invs;
	}
	public List<AsrSummaryAlert> getAlerts() {
		return alerts;
	}
	public void setAlerts(List<AsrSummaryAlert> alerts) {
		this.alerts = alerts;
	}
	public List<AsrSummarySpecialty> getSpecialties() {
		return specialties;
	}
	public void setSpecialties(List<AsrSummarySpecialty> specialties) {
		this.specialties = specialties;
	}
	public List<AsrSummaryProcedure> getProcedures() {
		return procedures;
	}
	public void setProcedures(List<AsrSummaryProcedure> procedures) {
		this.procedures = procedures;
	}
	public List<AsrSummaryClaimType> getClaimTypes() {
		return claimTypes;
	}
	public void setClaimTypes(List<AsrSummaryClaimType> claimTypes) {
		this.claimTypes = claimTypes;
	}
	public Date getLastAlertDt() {
		return lastAlertDt;
	}
	public void setLastAlertDt(Date lastAlertDt) {
		this.lastAlertDt = lastAlertDt;
	}
	public List<AsrSummaryAlert> getCurrentAlerts() {
		return currentAlerts;
	}
	public void setCurrentAlerts(List<AsrSummaryAlert> currentAlerts) {
		this.currentAlerts = currentAlerts;
	}
	public Integer getCrossoverCnt() {
		return crossoverCnt;
	}
	public void setCrossoverCnt(Integer crossoverCnt) {
		this.crossoverCnt = crossoverCnt;
	}

	public boolean isHasRecentAlerts() {
		return hasRecentAlerts;
	}
	public void setHasRecentAlerts(boolean hasRecentAlerts) {
		this.hasRecentAlerts = hasRecentAlerts;
	}
	public boolean isHasCurrentAlerts() {
		return hasCurrentAlerts;
	}
	public void setHasCurrentAlerts(boolean hasCurrentAlerts) {
		this.hasCurrentAlerts = hasCurrentAlerts;
	}
	public AsrSummaryPartD getPartD() {
		return partD;
	}
	public void setPartD(AsrSummaryPartD partD) {
		this.partD = partD;
	}
	public List<AsrSummaryAlert> getRecentAlerts() {
		return recentAlerts;
	}
	public void setRecentAlerts(List<AsrSummaryAlert> recentAlerts) {
		this.recentAlerts = recentAlerts;
	}
	public List<AsrSummaryAlert> getPriorityAlerts() {
		return priorityAlerts;
	}
	public void setPriorityAlerts(List<AsrSummaryAlert> priorityAlerts) {
		this.priorityAlerts = priorityAlerts;
	}
	public List<AsrGenericCode> getDrugClasses() {
		return drugClasses;
	}
	public void setDrugClasses(List<AsrGenericCode> drugClasses) {
		this.drugClasses = drugClasses;
	}
	public List<AsrGenericCode> getCityStates() {
		return cityStates;
	}
	public void setCityStates(List<AsrGenericCode> cityStates) {
		this.cityStates = cityStates;
	}
	public List<AsrGenericCode> getBeneStates() {
		return beneStates;
	}
	public void setBeneStates(List<AsrGenericCode> beneStates) {
		this.beneStates = beneStates;
	}
	public List<AsrGenericCode> getDiagnoses() {
		return diagnoses;
	}
	public void setDiagnoses(List<AsrGenericCode> diagnoses) {
		this.diagnoses = diagnoses;
	}
	public List<AsrGenericCode> getHcpcs() {
		return hcpcs;
	}
	public void setHcpcs(List<AsrGenericCode> hcpcs) {
		this.hcpcs = hcpcs;
	}
	public List<AsrGenericCode> getTaxIds() {
		return taxIds;
	}
	public void setTaxIds(List<AsrGenericCode> taxIds) {
		this.taxIds = taxIds;
	}
	public long getPtanCount() {
		return ptanCount;
	}
	public void setPtanCount(long ptanCount) {
		this.ptanCount = ptanCount;
	}
	public List<FpsCommonPtan> getPtans() {
		return ptans;
	}
	public void setPtans(List<FpsCommonPtan> ptans) {
		this.ptans = ptans;
	}
	public boolean isHasMedic() {
		return hasMedic;
	}
	public void setHasMedic(boolean hasMedic) {
		this.hasMedic = hasMedic;
	}
}
