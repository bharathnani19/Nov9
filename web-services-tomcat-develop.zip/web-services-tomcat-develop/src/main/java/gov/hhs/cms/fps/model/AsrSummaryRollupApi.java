/*     */ package gov.hhs.cms.fps.model;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import gov.hhs.cms.fps.model.ucm.AsrSpecialtyDetail;
/*     */ import gov.hhs.cms.fps.model.ucm.UniqueAlertDetail;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.codehaus.jackson.annotate.JsonAutoDetect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
/*     */ @JsonInclude(JsonInclude.Include.NON_NULL)
/*     */ public class AsrSummaryRollupApi
/*     */   implements Serializable
/*     */ {
/*  20 */   private List<FpsUser> users = new ArrayList<>();
/*  21 */   private List<AsrSummaryActivity> activitiess = new ArrayList<>();
/*  22 */   private List<FpsZone> assignedZones = new ArrayList<>();
/*  23 */   private List<AsrSummaryBarrier> barrierCds = new ArrayList<>();
/*  24 */   private List<UniqueAlertDetail> alerts = new ArrayList<>();
/*  25 */   private List<UniqueAlertDetail> currentAlerts = new ArrayList<>();
/*  26 */   private List<UniqueAlertDetail> recentAlerts = new ArrayList<>();
/*  27 */   private List<AsrSummaryAction> actions = new ArrayList<>();
/*  28 */   private List<AsrSummaryLeadInv> invs = new ArrayList<>();
/*  29 */   private List<AsrSpecialtyDetail> specialties = new ArrayList<>();
/*  30 */   private List<AsrSummaryProcedure> procedures = new ArrayList<>();
/*  31 */   private List<AsrSummaryClaimType> claimTypes = new ArrayList<>();
/*  32 */   private List<AsrGenericCode> drugClasses = new ArrayList<>();
/*  33 */   private List<AsrGenericCode> cityStates = new ArrayList<>();
/*  34 */   private List<AsrGenericCode> beneStates = new ArrayList<>();
/*  35 */   private List<AsrGenericCode> diagnoses = new ArrayList<>();
/*  36 */   private List<AsrGenericCode> hcpcs = new ArrayList<>();
/*  37 */   private List<AsrGenericCode> taxIds = new ArrayList<>(); private AsrSummaryPartD partD; private Integer crossoverCnt; private long ptanCount; private Date lastAlertDt;
/*  38 */   private List<FpsCommonPtan> ptans = new ArrayList<>();
/*     */   
/*     */   private boolean hasCurrentAlerts;
/*     */   
/*     */   private boolean hasRecentAlerts;
/*     */   
/*     */   private boolean hasMedicaid;
/*     */   private boolean hasMedic;
/*     */   
/*     */   public boolean isHasMedicaid() {
/*  48 */     return this.hasMedicaid;
/*     */   }
/*     */   public void setHasMedicaid(boolean hasMedicaid) {
/*  51 */     this.hasMedicaid = hasMedicaid;
/*     */   }
/*     */   public List<FpsUser> getUsers() {
/*  54 */     return this.users;
/*     */   }
/*     */   public void setUsers(List<FpsUser> users) {
/*  57 */     this.users = users;
/*     */   }
/*     */   public List<AsrSummaryActivity> getActivitiess() {
/*  60 */     return this.activitiess;
/*     */   }
/*     */   public void setActivitiess(List<AsrSummaryActivity> activitiess) {
/*  63 */     this.activitiess = activitiess;
/*     */   }
/*     */   public List<FpsZone> getAssignedZones() {
/*  66 */     return this.assignedZones;
/*     */   }
/*     */   public void setAssignedZones(List<FpsZone> assignedZones) {
/*  69 */     this.assignedZones = assignedZones;
/*     */   }
/*     */   public List<AsrSummaryBarrier> getBarrierCds() {
/*  72 */     return this.barrierCds;
/*     */   }
/*     */   public void setBarrierCds(List<AsrSummaryBarrier> barrierCds) {
/*  75 */     this.barrierCds = barrierCds;
/*     */   }
/*     */   public List<AsrSummaryAction> getActions() {
/*  78 */     return this.actions;
/*     */   }
/*     */   public void setActions(List<AsrSummaryAction> actions) {
/*  81 */     this.actions = actions;
/*     */   }
/*     */   public List<AsrSummaryLeadInv> getInvs() {
/*  84 */     return this.invs;
/*     */   }
/*     */   public void setInvs(List<AsrSummaryLeadInv> invs) {
/*  87 */     this.invs = invs;
/*     */   }
/*     */   public List<UniqueAlertDetail> getAlerts() {
/*  90 */     return this.alerts;
/*     */   }
/*     */   public void setAlerts(List<UniqueAlertDetail> alerts) {
/*  93 */     this.alerts = alerts;
/*     */   }
/*     */   public List<AsrSpecialtyDetail> getSpecialties() {
/*  96 */     return this.specialties;
/*     */   }
/*     */   public void setSpecialties(List<AsrSpecialtyDetail> specialties) {
/*  99 */     this.specialties = specialties;
/*     */   }
/*     */   public List<AsrSummaryProcedure> getProcedures() {
/* 102 */     return this.procedures;
/*     */   }
/*     */   public void setProcedures(List<AsrSummaryProcedure> procedures) {
/* 105 */     this.procedures = procedures;
/*     */   }
/*     */   public List<AsrSummaryClaimType> getClaimTypes() {
/* 108 */     return this.claimTypes;
/*     */   }
/*     */   public void setClaimTypes(List<AsrSummaryClaimType> claimTypes) {
/* 111 */     this.claimTypes = claimTypes;
/*     */   }
/*     */   public Date getLastAlertDt() {
/* 114 */     return this.lastAlertDt;
/*     */   }
/*     */   public void setLastAlertDt(Date lastAlertDt) {
/* 117 */     this.lastAlertDt = lastAlertDt;
/*     */   }
/*     */   public List<UniqueAlertDetail> getCurrentAlerts() {
/* 120 */     return this.currentAlerts;
/*     */   }
/*     */   public void setCurrentAlerts(List<UniqueAlertDetail> currentAlerts) {
/* 123 */     this.currentAlerts = currentAlerts;
/*     */   }
/*     */   public Integer getCrossoverCnt() {
/* 126 */     return this.crossoverCnt;
/*     */   }
/*     */   public void setCrossoverCnt(Integer crossoverCnt) {
/* 129 */     this.crossoverCnt = crossoverCnt;
/*     */   }
/*     */   
/*     */   public boolean isHasRecentAlerts() {
/* 133 */     return this.hasRecentAlerts;
/*     */   }
/*     */   public void setHasRecentAlerts(boolean hasRecentAlerts) {
/* 136 */     this.hasRecentAlerts = hasRecentAlerts;
/*     */   }
/*     */   public boolean isHasCurrentAlerts() {
/* 139 */     return this.hasCurrentAlerts;
/*     */   }
/*     */   public void setHasCurrentAlerts(boolean hasCurrentAlerts) {
/* 142 */     this.hasCurrentAlerts = hasCurrentAlerts;
/*     */   }
/*     */   public AsrSummaryPartD getPartD() {
/* 145 */     return this.partD;
/*     */   }
/*     */   public void setPartD(AsrSummaryPartD partD) {
/* 148 */     this.partD = partD;
/*     */   }
/*     */   public List<UniqueAlertDetail> getRecentAlerts() {
/* 151 */     return this.recentAlerts;
/*     */   }
/*     */   public void setRecentAlerts(List<UniqueAlertDetail> recentAlerts) {
/* 154 */     this.recentAlerts = recentAlerts;
/*     */   }
/*     */   
/*     */   public List<AsrGenericCode> getDrugClasses() {
/* 158 */     return this.drugClasses;
/*     */   }
/*     */   public void setDrugClasses(List<AsrGenericCode> drugClasses) {
/* 161 */     this.drugClasses = drugClasses;
/*     */   }
/*     */   public List<AsrGenericCode> getCityStates() {
/* 164 */     return this.cityStates;
/*     */   }
/*     */   public void setCityStates(List<AsrGenericCode> cityStates) {
/* 167 */     this.cityStates = cityStates;
/*     */   }
/*     */   public List<AsrGenericCode> getBeneStates() {
/* 170 */     return this.beneStates;
/*     */   }
/*     */   public void setBeneStates(List<AsrGenericCode> beneStates) {
/* 173 */     this.beneStates = beneStates;
/*     */   }
/*     */   public List<AsrGenericCode> getDiagnoses() {
/* 176 */     return this.diagnoses;
/*     */   }
/*     */   public void setDiagnoses(List<AsrGenericCode> diagnoses) {
/* 179 */     this.diagnoses = diagnoses;
/*     */   }
/*     */   public List<AsrGenericCode> getHcpcs() {
/* 182 */     return this.hcpcs;
/*     */   }
/*     */   public void setHcpcs(List<AsrGenericCode> hcpcs) {
/* 185 */     this.hcpcs = hcpcs;
/*     */   }
/*     */   public List<AsrGenericCode> getTaxIds() {
/* 188 */     return this.taxIds;
/*     */   }
/*     */   public void setTaxIds(List<AsrGenericCode> taxIds) {
/* 191 */     this.taxIds = taxIds;
/*     */   }
/*     */   public long getPtanCount() {
/* 194 */     return this.ptanCount;
/*     */   }
/*     */   public void setPtanCount(long ptanCount) {
/* 197 */     this.ptanCount = ptanCount;
/*     */   }
/*     */   public List<FpsCommonPtan> getPtans() {
/* 200 */     return this.ptans;
/*     */   }
/*     */   public void setPtans(List<FpsCommonPtan> ptans) {
/* 203 */     this.ptans = ptans;
/*     */   }
/*     */   public boolean isHasMedic() {
/* 206 */     return this.hasMedic;
/*     */   }
/*     */   public void setHasMedic(boolean hasMedic) {
/* 209 */     this.hasMedic = hasMedic;
/*     */   }
/*     */ }


/* Location:              D:\fpsapps\WEB-INF\classes\!\gov\hhs\cms\fps\model\AsrSummaryRollupApi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */