package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSummaryRulingChangeReason implements Serializable {
	private String rulingChangeReasonCd;
	private String rulingChangeReasonDesc;
	public String getRulingChangeReasonCd() {
		return rulingChangeReasonCd;
	}
	public void setRulingChangeReasonCd(String rulingChangeReasonCd) {
		this.rulingChangeReasonCd = rulingChangeReasonCd;
	}
	public String getRulingChangeReasonDesc() {
		return rulingChangeReasonDesc;
	}
	public void setRulingChangeReasonDesc(String rulingChangeReasonDesc) {
		this.rulingChangeReasonDesc = rulingChangeReasonDesc;
	}

}
