/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class AsrSummarySysTag.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class AsrSysTagItem implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2113852056122450965L;
	
	/** The sys tag id. */
	private int sysTagId;
	
	/** The sys tag txt. */
	private String sysTagTxt;
	
	private String yesNoInd;
	
	/**
	 * Gets the sys tag id.
	 *
	 * @return the sys tag id
	 */
	public int getSysTagId() {
		return sysTagId;
	}
	
	/**
	 * Sets the sys tag id.
	 *
	 * @param sysTagId the new sys tag id
	 */
	public void setSysTagId(int sysTagId) {
		this.sysTagId = sysTagId;
	}
	
	/**
	 * Gets the sys tag txt.
	 *
	 * @return the sys tag txt
	 */
	public String getSysTagTxt() {
		return sysTagTxt;
	}
	
	/**
	 * Sets the sys tag txt.
	 *
	 * @param sysTagTxt the new sys tag txt
	 */
	public void setSysTagTxt(String sysTagTxt) {
		this.sysTagTxt = sysTagTxt;
	}

	@Override
	public String toString() {
		return "(System Tag -" + sysTagTxt + ")";
	}

	public String getYesNoInd() {
		return yesNoInd;
	}

	public void setYesNoInd(String yesNoInd) {
		this.yesNoInd = yesNoInd;
	}
}
