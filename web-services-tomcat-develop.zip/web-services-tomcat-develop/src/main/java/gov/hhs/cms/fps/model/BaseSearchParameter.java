package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class BaseSearchParameter.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class BaseSearchParameter  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5040288069253217212L;
	
	/** The start time. */
	private String startTime; //FPS_ASRPT_USER_RULNG.CRNT_RULNG_DT
	
	/** The end time. */
	private String endTime;
	
	/** The ruling. */
	private List<String> ruling; //FPS_ASRPT_USER_RULNG.CRNT_RULNG_CD
	
	/** The workload status. */
	private String workloadStatus; //?
	
	
	/**
	 * Gets the start time.
	 *
	 * @return the start time
	 */
	public String getStartTime() {
		return startTime;
	}
	
	/**
	 * Sets the start time.
	 *
	 * @param startTime the new start time
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	
	/**
	 * Gets the end time.
	 *
	 * @return the end time
	 */
	public String getEndTime() {
		return endTime;
	}
	
	/**
	 * Sets the end time.
	 *
	 * @param endTime the new end time
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	/**
	 * Gets the ruling.
	 *
	 * @return the ruling
	 */
	public List<String> getRuling() {
		return ruling;
	}
	
	/**
	 * Sets the ruling.
	 *
	 * @param ruling the new ruling
	 */
	public void setRuling(List<String> ruling) {
		this.ruling = ruling;
	}
	
	/**
	 * Gets the workload status.
	 *
	 * @return the workload status
	 */
	public String getWorkloadStatus() {
		return workloadStatus;
	}
	
	/**
	 * Sets the workload status.
	 *
	 * @param workloadStatus the new workload status
	 */
	public void setWorkloadStatus(String workloadStatus) {
		this.workloadStatus = workloadStatus;
	}


}
