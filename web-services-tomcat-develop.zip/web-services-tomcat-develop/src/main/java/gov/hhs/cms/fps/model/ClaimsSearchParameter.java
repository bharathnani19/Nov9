package gov.hhs.cms.fps.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import gov.hhs.cms.fps.util.FpsEnums;
import gov.hhs.cms.fps.util.FpsEnums.SolrClaimType;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class ClaimsSearchParameter {

	private Integer asrptId;
	private List<AsrGenericCode> claimTypes = new ArrayList<AsrGenericCode>();
	private List<FpsCommonBeneficiary> hicns = new ArrayList<FpsCommonBeneficiary>();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/New_York")
	private Date fromDt;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/New_York")
	private Date toDt;
	private String latest = "N";
	private String npi;
	private String searchAllRoles = "N";
	private String rrb = "N";
	private FpsEnums.SolrClaimType searchType = SolrClaimType.RAW;
	private String diagnosis;
	private String hcpcs;
	private String procedure;
	private String latestD = "N";
	private String atRiskInd = "N";
	private String atRiskDInd = "N";	
	private String allClaimsInd = "N";
	private String allClaimsDInd = "N";

	private String asrCostInd = "N";
	private List<AsrGenericCode> diagnosises = new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> hcpcses = new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> procedures = new ArrayList<AsrGenericCode>();
	private Integer pageSize;
	private Integer startAt;
	private List<AsrGenericCode> mdcdSvcCats = new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> mdcdSvcSubcats = new ArrayList<AsrGenericCode>();
	private List<AsrGenericCode> mdcdStates = new ArrayList<AsrGenericCode>();


	public List<AsrGenericCode> getClaimTypes() {
		return claimTypes;
	}

	public void setClaimTypes(List<AsrGenericCode> claimTypes) {
		this.claimTypes = claimTypes;
	}

	public List<FpsCommonBeneficiary> getHicns() {
		return hicns;
	}

	public void setHicns(List<FpsCommonBeneficiary> hicns) {
		this.hicns = hicns;
	}

	public Date getFromDt() {
		return fromDt;
	}

	public void setFromDt(Date fromDt) {
		this.fromDt = fromDt;
	}

	public Date getToDt() {
		return toDt;
	}

	public void setToDt(Date toDt) {
		this.toDt = toDt;
	}

	public Integer getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}

	public String getLatest() {
		return latest;
	}

	public void setLatest(String latest) {
		this.latest = latest;
	}

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getSearchAllRoles() {
		return searchAllRoles;
	}

	public void setSearchAllRoles(String searchAllRoles) {
		this.searchAllRoles = searchAllRoles;
	}

	public String getRrb() {
		return rrb;
	}

	public void setRrb(String rrb) {
		this.rrb = rrb;
	}

	public FpsEnums.SolrClaimType getSearchType() {
		return searchType;
	}

	public void setSearchType(FpsEnums.SolrClaimType searchType) {
		this.searchType = searchType;
	}

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getHcpcs() {
		return hcpcs;
	}

	public void setHcpcs(String hcpcs) {
		this.hcpcs = hcpcs;
	}

	public String getProcedure() {
		return procedure;
	}

	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}

	@Override
	public String toString() {
		return "ClaimsSearchParameter [asrptId=" + asrptId + ", claimTypes=" + claimTypes + ", hicns=" + hicns
				+ ", fromDt=" + fromDt + ", toDt=" + toDt + ", latest=" + latest + ", npi=" + npi + ", searchAllRoles="
				+ searchAllRoles + ", rrb=" + rrb + ", searchType=" + searchType + ", diagnosis=" + diagnosis
				+ ", hcpcs=" + hcpcs + ", procedure=" + procedure + ", latestD=" + latestD + ", atRiskInd=" + atRiskInd
				+ ", atRiskDInd=" + atRiskDInd + ", allClaimsInd=" + allClaimsInd + ", allClaimsDInd=" + allClaimsDInd
				+ ", diagnosises=" + diagnosises + ", hcpcses=" + hcpcses + ", procedures=" + procedures + "]";
	}

	public String getLatestD() {
		return latestD;
	}

	public void setLatestD(String latestD) {
		this.latestD = latestD;
	}

	public String getAtRiskInd() {
		return atRiskInd;
	}

	public void setAtRiskInd(String atRiskInd) {
		this.atRiskInd = atRiskInd;
	}

	public String getAtRiskDInd() {
		return atRiskDInd;
	}

	public void setAtRiskDInd(String atRiskDInd) {
		this.atRiskDInd = atRiskDInd;
	}

	public String getAllClaimsInd() {
		return allClaimsInd;
	}

	public void setAllClaimsInd(String allClaimsInd) {
		this.allClaimsInd = allClaimsInd;
	}

	public String getAllClaimsDInd() {
		return allClaimsDInd;
	}

	public void setAllClaimsDInd(String allClaimsDInd) {
		this.allClaimsDInd = allClaimsDInd;
	}

	public List<AsrGenericCode> getDiagnosises() {
		return diagnosises;
	}

	public void setDiagnosises(List<AsrGenericCode> diagnosises) {
		this.diagnosises = diagnosises;
	}

	public List<AsrGenericCode> getHcpcses() {
		return hcpcses;
	}

	public void setHcpcses(List<AsrGenericCode> hcpcses) {
		this.hcpcses = hcpcses;
	}

	public List<AsrGenericCode> getProcedures() {
		return procedures;
	}

	public void setProcedures(List<AsrGenericCode> procedures) {
		this.procedures = procedures;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getStartAt() {
		return startAt;
	}

	public void setStartAt(Integer startAt) {
		this.startAt = startAt;
	}

	public List<AsrGenericCode> getMdcdSvcCats() {
		return mdcdSvcCats;
	}

	public void setMdcdSvcCats(List<AsrGenericCode> mdcdSvcCats) {
		this.mdcdSvcCats = mdcdSvcCats;
	}

	public List<AsrGenericCode> getMdcdSvcSubcats() {
		return mdcdSvcSubcats;
	}

	public void setMdcdSvcSubcats(List<AsrGenericCode> mdcdSvcSubcats) {
		this.mdcdSvcSubcats = mdcdSvcSubcats;
	}

	public List<AsrGenericCode> getMdcdStates() {
		return mdcdStates;
	}

	public void setMdcdStates(List<AsrGenericCode> mdcdStates) {
		this.mdcdStates = mdcdStates;
	}

	public String getAsrCostInd() {
		return asrCostInd;
	}

	public void setAsrCostInd(String asrCostInd) {
		this.asrCostInd = asrCostInd;
	}
}
