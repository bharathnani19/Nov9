package gov.hhs.cms.fps.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.annotate.JsonProperty;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class ClaimsSolrStream {

	@JsonProperty("result-set")
	private ClaimsSolrStreamResult result;

	public ClaimsSolrStreamResult getResult() {
		return result;
	}
	public void setResult(ClaimsSolrStreamResult result) {
		this.result = result;
	}
	
}
