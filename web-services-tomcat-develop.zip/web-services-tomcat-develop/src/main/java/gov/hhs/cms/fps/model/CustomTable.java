package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class CustomTable implements Serializable {

	private String tableId;
	private String modelBusnsId;
	private String tabName;
	private String tabShortName;
	private String tabSummary;
	private List<CustomTableColumns> columns = new ArrayList<CustomTableColumns>();
	private List<CustomTableDataRow> dataRows = new ArrayList<CustomTableDataRow>();
	public String getTableId() {
		return tableId;
	}
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	public String getTabName() {
		return tabName;
	}
	public void setTabName(String tabName) {
		this.tabName = tabName;
	}
	public String getTabSummary() {
		return tabSummary;
	}
	public void setTabSummary(String tabSummary) {
		this.tabSummary = tabSummary;
	}
	public List<CustomTableColumns> getColumns() {
		return columns;
	}
	public void setColumns(List<CustomTableColumns> columns) {
		this.columns = columns;
	}
	
	public String getTabShortName() {
		return tabShortName;
	}
	public void setTabShortName(String tabShortName) {
		this.tabShortName = tabShortName;
	}
	public List<CustomTableDataRow> getDataRows() {
		return dataRows;
	}
	public void setDataRows(List<CustomTableDataRow> dataRows) {
		this.dataRows = dataRows;
	}
}
