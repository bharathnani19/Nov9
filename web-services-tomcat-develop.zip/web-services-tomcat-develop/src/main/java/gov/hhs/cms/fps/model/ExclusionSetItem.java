package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.hhs.cms.fps.util.NAStringSerializer;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class ExclusionSetItem implements Serializable{
	

	private Integer asrptId;
	private Integer itemId;
	private String userNm;
	private List<AsrGenericCode> exclusions;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String comments;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="America/New_York")
	private Date rollOffDt;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy/MM/dd", timezone="America/New_York")

	private Date addedDt;
	private String zone;
	private String ownerId;
	

	private String removedDt;
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public List<AsrGenericCode> getExclusions() {
		return exclusions;
	}
	public void setExclusions(List<AsrGenericCode> exclusions) {
		this.exclusions = exclusions;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Date getRollOffDt() {
		return rollOffDt;
	}
	public void setRollOffDt(Date rollOffDt) {
		this.rollOffDt = rollOffDt;
	}
	public Date getAddedDt() {
		return addedDt;
	}
	public void setAddedDt(Date addedDt) {
		this.addedDt = addedDt;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public String getRemovedDt() {
		return removedDt;
	}
	public void setRemovedDt(String removedDt) {
		this.removedDt = removedDt;
	}
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
}
