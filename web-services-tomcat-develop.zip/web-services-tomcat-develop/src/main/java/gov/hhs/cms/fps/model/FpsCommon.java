/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

// TODO: Auto-generated Javadoc
/**
 * The Class FpsCommon.
 */
 @JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
public class FpsCommon implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -142573620219026622L;
	
	/** The case ID. */
	private String caseID; // FPS_ALERT.ALERT_ID
	
	/** The external case ID. */
	private String externalCaseID;
	
	/** The status. */
	private String status;
	
	private String fullName;
	/** The first name. */
	private String firstName;
	
	/** The last name. */
	private String lastName;
	
	/** The middle initial. */
	private String middleInitial;
	
	/** The business name. */
	private String businessName;
	
	/** The priority. */
	private String priority;
	
	/** The subject ID. */
	private String subjectID;  //FPS_ALERT.SUBJ_ID
	
	/** The allegations. */
	private List<FpsCommonAllegation> allegations;
	
	/** The create date. */
	private String createDate; //FPS_ALERT.ALERT_CREAT_DT
	
	/** The update date. */
	private String updateDate;//FPS_ALERT.AUDT_UPDT_TS
	
	/** The source system. */
	private String sourceSystem;
	
	/** The organization. */
	private String organization;
	
	/** The owner jurisdiction. */
	private String ownerJurisdiction;
	
	/** The assigned user name. */
	private String assignedUserName; //FPS_USR_RFRNC.APLCTN_USER_ID
	
	/** The program type. */
	private String programType;
	
	/** The facility name. */
	private String facilityName;
	
	/** The display service URL. */
	private String displayServiceURL;
	
	/** The retrieval URL. */
	private String retrievalURL;
	
	/** The beneficiaries. */
	private List<FpsCommonBeneficiary> beneficiaries;
	
	/** The ptans. */
	private List<FpsCommonPtan> ptans;
	
	/** The status date. */
	private String statusDate;
	
	/** The work load date. */
	private String workLoadDate;
	
	/** The user details. */
	private List<FpsCommonUser> userDetails;

	/** The dollar amount. */
	private String dollarAmount;  //FPS_ALERT.ALERT_CST_AMT
	
	/** The claim type. */
	private String claimType; //FPS_ALERT.CLMT_TYPE_CD
	
	/** The received date time. */
	private String receivedDateTime;
	
	//SYS-4399
	private List<FpsCommonMac> macJurisdictions;
	
	/**
	 * Gets the case ID.
	 *
	 * @return the case ID
	 */
	public String getCaseID() {
		return caseID;
	}
	
	/**
	 * Sets the case ID.
	 *
	 * @param caseID the new case ID
	 */
	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	
	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	/**
	 * Gets the middle initial.
	 *
	 * @return the middle initial
	 */
	public String getMiddleInitial() {
		return middleInitial;
	}
	
	/**
	 * Sets the middle initial.
	 *
	 * @param middleInitial the new middle initial
	 */
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}
	
	/**
	 * Gets the business name.
	 *
	 * @return the business name
	 */
	public String getBusinessName() {
		return businessName;
	}
	
	/**
	 * Sets the business name.
	 *
	 * @param businessName the new business name
	 */
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	
	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}
	
	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	/**
	 * Gets the subject ID.
	 *
	 * @return the subject ID
	 */
	public String getSubjectID() {
		return subjectID;
	}
	
	/**
	 * Sets the subject ID.
	 *
	 * @param subjectID the new subject ID
	 */
	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}
	
	/**
	 * Gets the creates the date.
	 *
	 * @return the creates the date
	 */
	public String getCreateDate() {
		return createDate;
	}
	
	/**
	 * Sets the creates the date.
	 *
	 * @param createDate the new creates the date
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	
	/**
	 * Gets the update date.
	 *
	 * @return the update date
	 */
	public String getUpdateDate() {
		return updateDate;
	}
	
	/**
	 * Sets the update date.
	 *
	 * @param updateDate the new update date
	 */
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	
	/**
	 * Gets the source system.
	 *
	 * @return the source system
	 */
	public String getSourceSystem() {
		return sourceSystem;
	}
	
	/**
	 * Sets the source system.
	 *
	 * @param sourceSystem the new source system
	 */
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
	/**
	 * Gets the organization.
	 *
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}
	
	/**
	 * Sets the organization.
	 *
	 * @param organization the new organization
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	
	/**
	 * Gets the owner jurisdiction.
	 *
	 * @return the owner jurisdiction
	 */
	public String getOwnerJurisdiction() {
		return ownerJurisdiction;
	}
	
	/**
	 * Sets the owner jurisdiction.
	 *
	 * @param ownerJurisdiction the new owner jurisdiction
	 */
	public void setOwnerJurisdiction(String ownerJurisdiction) {
		this.ownerJurisdiction = ownerJurisdiction;
	}
	
	/**
	 * Gets the assigned user name.
	 *
	 * @return the assigned user name
	 */
	public String getAssignedUserName() {
		return assignedUserName;
	}
	
	/**
	 * Sets the assigned user name.
	 *
	 * @param assignedUserName the new assigned user name
	 */
	public void setAssignedUserName(String assignedUserName) {
		this.assignedUserName = assignedUserName;
	}
	
	/**
	 * Gets the program type.
	 *
	 * @return the program type
	 */
	public String getProgramType() {
		return programType;
	}
	
	/**
	 * Sets the program type.
	 *
	 * @param programType the new program type
	 */
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	
	/**
	 * Gets the facility name.
	 *
	 * @return the facility name
	 */
	public String getFacilityName() {
		return facilityName;
	}
	
	/**
	 * Sets the facility name.
	 *
	 * @param facilityName the new facility name
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	
	/**
	 * Gets the display service URL.
	 *
	 * @return the display service URL
	 */
	public String getDisplayServiceURL() {
		return displayServiceURL;
	}
	
	/**
	 * Sets the display service URL.
	 *
	 * @param displayServiceURL the new display service URL
	 */
	public void setDisplayServiceURL(String displayServiceURL) {
		this.displayServiceURL = displayServiceURL;
	}
	
	/**
	 * Gets the retrieval URL.
	 *
	 * @return the retrieval URL
	 */
	public String getRetrievalURL() {
		return retrievalURL;
	}
	
	/**
	 * Sets the retrieval URL.
	 *
	 * @param retrievalURL the new retrieval URL
	 */
	public void setRetrievalURL(String retrievalURL) {
		this.retrievalURL = retrievalURL;
	}

	/**
	 * Gets the status date.
	 *
	 * @return the statusDate
	 */
	public String getStatusDate() {
		return statusDate;
	}
	
	/**
	 * Sets the status date.
	 *
	 * @param statusDate the statusDate to set
	 */
	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}
	
	/**
	 * Gets the work load date.
	 *
	 * @return the workLoadDate
	 */
	public String getWorkLoadDate() {
		return workLoadDate;
	}
	
	/**
	 * Sets the work load date.
	 *
	 * @param workLoadDate the workLoadDate to set
	 */
	public void setWorkLoadDate(String workLoadDate) {
		this.workLoadDate = workLoadDate;
	}
	
	/**
	 * Gets the user details.
	 *
	 * @return the userDetails
	 */
	public List<FpsCommonUser> getUserDetails() {
		return userDetails;
	}
	
	/**
	 * Sets the user details.
	 *
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(List<FpsCommonUser> userDetails) {
		this.userDetails = userDetails;
	}
	
	/**
	 * Gets the beneficiaries.
	 *
	 * @return the beneficiaries
	 */
	public List<FpsCommonBeneficiary> getBeneficiaries() {
		return beneficiaries;
	}
	
	/**
	 * Sets the beneficiaries.
	 *
	 * @param beneficiaries the beneficiaries to set
	 */
	public void setBeneficiaries(List<FpsCommonBeneficiary> beneficiaries) {
		this.beneficiaries = beneficiaries;
	}
	
	/**
	 * Gets the ptans.
	 *
	 * @return the ptans
	 */
	public List<FpsCommonPtan> getPtans() {
		return ptans;
	}
	
	/**
	 * Sets the ptans.
	 *
	 * @param ptans the ptans to set
	 */
	public void setPtans(List<FpsCommonPtan> ptans) {
		this.ptans = ptans;
	}
	
	/**
	 * Gets the dollar amount.
	 *
	 * @return the dollarAmount
	 */
	public String getDollarAmount() {
		return dollarAmount;
	}
	
	/**
	 * Sets the dollar amount.
	 *
	 * @param dollarAmount the dollarAmount to set
	 */
	public void setDollarAmount(String dollarAmount) {
		this.dollarAmount = dollarAmount;
	}
	
	/**
	 * Gets the claim type.
	 *
	 * @return the claimType
	 */
	public String getClaimType() {
		return claimType;
	}
	
	/**
	 * Sets the claim type.
	 *
	 * @param claimType the claimType to set
	 */
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	
	/**
	 * Gets the allegations.
	 *
	 * @return the allegations
	 */
	public List<FpsCommonAllegation> getAllegations() {
		return allegations;
	}
	
	/**
	 * Sets the allegations.
	 *
	 * @param allegations the allegations to set
	 */
	public void setAllegations(List<FpsCommonAllegation> allegations) {
		this.allegations = allegations;
	}
	

	/**
	 * Gets the received date time.
	 *
	 * @return the receivedDateTime
	 */
	public String getReceivedDateTime() {
		return receivedDateTime;
	}
	
	/**
	 * Sets the received date time.
	 *
	 * @param receivedDateTime the receivedDateTime to set
	 */
	public void setReceivedDateTime(String receivedDateTime) {
		this.receivedDateTime = receivedDateTime;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the external case ID.
	 *
	 * @return the externalCaseID
	 */
	public String getExternalCaseID() {
		return externalCaseID;
	}
	
	/**
	 * Sets the external case ID.
	 *
	 * @param externalCaseID the externalCaseID to set
	 */
	public void setExternalCaseID(String externalCaseID) {
		this.externalCaseID = externalCaseID;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FpsCommon [caseID=" + caseID + ", externalCaseID=" + externalCaseID + ", status=" + status
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", middleInitial=" + middleInitial
				+ ", businessName=" + businessName + ", priority=" + priority + ", subjectID=" + subjectID
				+ ", allegations=" + allegations + ", createDate=" + createDate + ", updateDate=" + updateDate
				+ ", sourceSystem=" + sourceSystem + ", organization=" + organization + ", ownerJurisdiction="
				+ ownerJurisdiction + ", assignedUserName=" + assignedUserName + ", programType=" + programType
				+ ", facilityName=" + facilityName + ", displayServiceURL=" + displayServiceURL + ", retrievalURL="
				+ retrievalURL + ", beneficiaries=" + beneficiaries + ", ptans=" + ptans + ", statusDate=" + statusDate
				+ ", workLoadDate=" + workLoadDate + ", userDetails=" + userDetails + ", "
				+ ", dollarAmount=" + dollarAmount + ", claimType=" + claimType + ", receivedDateTime="
				+ receivedDateTime + "]";
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public List<FpsCommonMac> getMacJurisdictions() {
		return macJurisdictions;
	}

	public void setMacJurisdictions(List<FpsCommonMac> macJurisdictions) {
		this.macJurisdictions = macJurisdictions;
	}
	
}
