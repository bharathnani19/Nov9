/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class FpsCommonAllegation.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonAllegation implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8903477514492112968L;
	
	/** The allegation ID. */
	private String allegationID;
	
	/**
	 * Gets the allegation ID.
	 *
	 * @return the allegationID
	 */
	public String getAllegationID() {
		return allegationID;
	}
	
	/**
	 * Sets the allegation ID.
	 *
	 * @param allegationID the allegationID to set
	 */
	public void setAllegationID(String allegationID) {
		this.allegationID = allegationID;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FpsCommonAllegation [allegationID=" + allegationID + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((allegationID == null) ? 0 : allegationID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsCommonAllegation other = (FpsCommonAllegation) obj;
		if (allegationID == null) {
			if (other.allegationID != null)
				return false;
		} else if (!allegationID.equals(other.allegationID))
			return false;
		return true;
	}
}
