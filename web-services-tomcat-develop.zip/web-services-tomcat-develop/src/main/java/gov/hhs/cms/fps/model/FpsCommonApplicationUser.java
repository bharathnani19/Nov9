/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class FpsCommonApplicationUser.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonApplicationUser implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1488202326971525797L;
	
	/** The aplctn user id. */
	private String aplctnUserId;
	
	/** The user 1 st name. */
	private String user1stName;
	
	/** The user mdl initl name. */
	private String userMdlInitlName;
	
	/** The user last name. */
	private String userLastName;
	
	/** The user email adr. */
	private String userEmailAdr;
	
	/** The user phne num. */
	private String userPhneNum;
	
	/**
	 * Gets the aplctn user id.
	 *
	 * @return the aplctn user id
	 */
	public String getAplctnUserId() {
		return aplctnUserId;
	}
	
	/**
	 * Sets the aplctn user id.
	 *
	 * @param aplctnUserId the new aplctn user id
	 */
	public void setAplctnUserId(String aplctnUserId) {
		this.aplctnUserId = aplctnUserId;
	}
	
	/**
	 * Gets the user 1 st name.
	 *
	 * @return the user 1 st name
	 */
	public String getUser1stName() {
		return user1stName;
	}
	
	/**
	 * Sets the user 1 st name.
	 *
	 * @param user1stName the new user 1 st name
	 */
	public void setUser1stName(String user1stName) {
		this.user1stName = user1stName;
	}
	
	/**
	 * Gets the user mdl initl name.
	 *
	 * @return the user mdl initl name
	 */
	public String getUserMdlInitlName() {
		return userMdlInitlName;
	}
	
	/**
	 * Sets the user mdl initl name.
	 *
	 * @param userMdlInitlName the new user mdl initl name
	 */
	public void setUserMdlInitlName(String userMdlInitlName) {
		this.userMdlInitlName = userMdlInitlName;
	}
	
	/**
	 * Gets the user last name.
	 *
	 * @return the user last name
	 */
	public String getUserLastName() {
		return userLastName;
	}
	
	/**
	 * Sets the user last name.
	 *
	 * @param userLastName the new user last name
	 */
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	
	/**
	 * Gets the user email adr.
	 *
	 * @return the user email adr
	 */
	public String getUserEmailAdr() {
		return userEmailAdr;
	}
	
	/**
	 * Sets the user email adr.
	 *
	 * @param userEmailAdr the new user email adr
	 */
	public void setUserEmailAdr(String userEmailAdr) {
		this.userEmailAdr = userEmailAdr;
	}
	
	/**
	 * Gets the user phne num.
	 *
	 * @return the user phne num
	 */
	public String getUserPhneNum() {
		return userPhneNum;
	}
	
	/**
	 * Sets the user phne num.
	 *
	 * @param userPhneNum the new user phne num
	 */
	public void setUserPhneNum(String userPhneNum) {
		this.userPhneNum = userPhneNum;
	}

}
