/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import gov.hhs.cms.fps.model.generated.FpsAlert;
// TODO: Auto-generated Javadoc

/**
 * The Class FpsCommonInternal.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonInternal extends FpsCommon implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -4365163636123999674L;
	
	/** The group npi. */
	private String groupNpi;
	
	/** The asrpt types. */
	private List<String> asrptTypes;
	
	/** The system tags. */
	private List<String> systemTags;
	
	/** The claim types. */
	List<String> claimTypes;
	
	/** The claim lines cnt. */
	private int claimLinesCnt;
	
	/** The crossover lines cnt. */
	private int crossoverLinesCnt;
	
	/** The risk score. */
	private BigDecimal riskScore;
	
	/** The alert lines cnt. */
	private int alertLinesCnt;
	
	/** The alerts. */
	private List<FpsAlert> alerts;
	
	/** The bene prvdr cnt. */
	private int benePrvdrCnt;
	
	/** The dual bene cnt. */
	private int dualBeneCnt;
	
	/** The dual bene pct. */
	private BigDecimal dualBenePct;
	
	/** The procedures cnt. */
	private int proceduresCnt;
	
	/** The subject state cd. */
	private String subjectStateCd;
	
	/** The subject zone cd. */
	private String subjectZoneCd;
	
	/** The subject zone cost amt. */
	private BigDecimal subjectZoneCostAmt;
	
	/** The assigned zone cd. */
	private String assignedZoneCd;
	
	/** The open lead investigation ind. */
	private String openLeadInvestigationInd;
	
	/** The ptan cnt. */
	private int ptanCnt;
	
	/** The specialty cnt. */
	private int specialtyCnt;
	
	/** The specialties. */
	private List<String> specialties;
	
	/** The activities. */
	private List<FpsCommonUserActivity> activities;
	
	/** The actions. */
	private List<FpsCommonActionType> actions;
	
	/** The barrier to action cd. */
	private String barrierToActionCd;
	
	/** The ruling change reason cd. */
	private String rulingChangeReasonCd;
	
	/** The not subject change ind. */
	private String notSubjectChangeInd;
	
	/** The not suspect reasons. */
	private List<String> notSuspectReasons;
	
	/**
	 * Gets the group npi.
	 *
	 * @return the group npi
	 */
	public String getGroupNpi() {
		return groupNpi;
	}
	
	/**
	 * Sets the group npi.
	 *
	 * @param groupNpi the new group npi
	 */
	public void setGroupNpi(String groupNpi) {
		this.groupNpi = groupNpi;
	}
	
	/**
	 * Gets the asrpt types.
	 *
	 * @return the asrpt types
	 */
	public List<String> getAsrptTypes() {
		return asrptTypes;
	}
	
	/**
	 * Sets the asrpt types.
	 *
	 * @param asrptTypes the new asrpt types
	 */
	public void setAsrptTypes(List<String> asrptTypes) {
		this.asrptTypes = asrptTypes;
	}
	
	/**
	 * Gets the system tags.
	 *
	 * @return the system tags
	 */
	public List<String> getSystemTags() {
		return systemTags;
	}
	
	/**
	 * Sets the system tags.
	 *
	 * @param systemTags the new system tags
	 */
	public void setSystemTags(List<String> systemTags) {
		this.systemTags = systemTags;
	}
	
	/**
	 * Gets the claim types.
	 *
	 * @return the claim types
	 */
	public List<String> getClaimTypes() {
		return claimTypes;
	}
	
	/**
	 * Sets the claim types.
	 *
	 * @param claimTypes the new claim types
	 */
	public void setClaimTypes(List<String> claimTypes) {
		this.claimTypes = claimTypes;
	}
	
	/**
	 * Gets the claim lines cnt.
	 *
	 * @return the claim lines cnt
	 */
	public int getClaimLinesCnt() {
		return claimLinesCnt;
	}
	
	/**
	 * Sets the claim lines cnt.
	 *
	 * @param claimLinesCnt the new claim lines cnt
	 */
	public void setClaimLinesCnt(int claimLinesCnt) {
		this.claimLinesCnt = claimLinesCnt;
	}
	
	/**
	 * Gets the crossover lines cnt.
	 *
	 * @return the crossover lines cnt
	 */
	public int getCrossoverLinesCnt() {
		return crossoverLinesCnt;
	}
	
	/**
	 * Sets the crossover lines cnt.
	 *
	 * @param crossoverLinesCnt the new crossover lines cnt
	 */
	public void setCrossoverLinesCnt(int crossoverLinesCnt) {
		this.crossoverLinesCnt = crossoverLinesCnt;
	}
	
	/**
	 * Gets the risk score.
	 *
	 * @return the risk score
	 */
	public BigDecimal getRiskScore() {
		return riskScore;
	}
	
	/**
	 * Sets the risk score.
	 *
	 * @param riskScore the new risk score
	 */
	public void setRiskScore(BigDecimal riskScore) {
		this.riskScore = riskScore;
	}
	
	/**
	 * Gets the alert lines cnt.
	 *
	 * @return the alert lines cnt
	 */
	public int getAlertLinesCnt() {
		return alertLinesCnt;
	}
	
	/**
	 * Sets the alert lines cnt.
	 *
	 * @param alertLinesCnt the new alert lines cnt
	 */
	public void setAlertLinesCnt(int alertLinesCnt) {
		this.alertLinesCnt = alertLinesCnt;
	}
	
	/**
	 * Gets the alerts.
	 *
	 * @return the alerts
	 */
	public List<FpsAlert> getAlerts() {
		return alerts;
	}
	
	/**
	 * Sets the alerts.
	 *
	 * @param alerts the new alerts
	 */
	public void setAlerts(List<FpsAlert> alerts) {
		this.alerts = alerts;
	}
	
	/**
	 * Gets the bene prvdr cnt.
	 *
	 * @return the bene prvdr cnt
	 */
	public int getBenePrvdrCnt() {
		return benePrvdrCnt;
	}
	
	/**
	 * Sets the bene prvdr cnt.
	 *
	 * @param benePrvdrCnt the new bene prvdr cnt
	 */
	public void setBenePrvdrCnt(int benePrvdrCnt) {
		this.benePrvdrCnt = benePrvdrCnt;
	}
	
	/**
	 * Gets the dual bene cnt.
	 *
	 * @return the dual bene cnt
	 */
	public int getDualBeneCnt() {
		return dualBeneCnt;
	}
	
	/**
	 * Sets the dual bene cnt.
	 *
	 * @param dualBeneCnt the new dual bene cnt
	 */
	public void setDualBeneCnt(int dualBeneCnt) {
		this.dualBeneCnt = dualBeneCnt;
	}
	
	/**
	 * Gets the dual bene pct.
	 *
	 * @return the dual bene pct
	 */
	public BigDecimal getDualBenePct() {
		return dualBenePct;
	}
	
	/**
	 * Sets the dual bene pct.
	 *
	 * @param dualBenePct the new dual bene pct
	 */
	public void setDualBenePct(BigDecimal dualBenePct) {
		this.dualBenePct = dualBenePct;
	}
	
	/**
	 * Gets the procedures cnt.
	 *
	 * @return the procedures cnt
	 */
	public int getProceduresCnt() {
		return proceduresCnt;
	}
	
	/**
	 * Sets the procedures cnt.
	 *
	 * @param proceduresCnt the new procedures cnt
	 */
	public void setProceduresCnt(int proceduresCnt) {
		this.proceduresCnt = proceduresCnt;
	}
	
	/**
	 * Gets the subject state cd.
	 *
	 * @return the subject state cd
	 */
	public String getSubjectStateCd() {
		return subjectStateCd;
	}
	
	/**
	 * Sets the subject state cd.
	 *
	 * @param subjectStateCd the new subject state cd
	 */
	public void setSubjectStateCd(String subjectStateCd) {
		this.subjectStateCd = subjectStateCd;
	}
	
	/**
	 * Gets the subject zone cd.
	 *
	 * @return the subject zone cd
	 */
	public String getSubjectZoneCd() {
		return subjectZoneCd;
	}
	
	/**
	 * Sets the subject zone cd.
	 *
	 * @param subjectZoneCd the new subject zone cd
	 */
	public void setSubjectZoneCd(String subjectZoneCd) {
		this.subjectZoneCd = subjectZoneCd;
	}
	
	/**
	 * Gets the subject zone cost amt.
	 *
	 * @return the subject zone cost amt
	 */
	public BigDecimal getSubjectZoneCostAmt() {
		return subjectZoneCostAmt;
	}
	
	/**
	 * Sets the subject zone cost amt.
	 *
	 * @param subjectZoneCostAmt the new subject zone cost amt
	 */
	public void setSubjectZoneCostAmt(BigDecimal subjectZoneCostAmt) {
		this.subjectZoneCostAmt = subjectZoneCostAmt;
	}
	
	/**
	 * Gets the assigned zone cd.
	 *
	 * @return the assigned zone cd
	 */
	public String getAssignedZoneCd() {
		return assignedZoneCd;
	}
	
	/**
	 * Sets the assigned zone cd.
	 *
	 * @param assignedZoneCd the new assigned zone cd
	 */
	public void setAssignedZoneCd(String assignedZoneCd) {
		this.assignedZoneCd = assignedZoneCd;
	}
	
	/**
	 * Gets the open lead investigation ind.
	 *
	 * @return the open lead investigation ind
	 */
	public String getOpenLeadInvestigationInd() {
		return openLeadInvestigationInd;
	}
	
	/**
	 * Sets the open lead investigation ind.
	 *
	 * @param openLeadInvestigationInd the new open lead investigation ind
	 */
	public void setOpenLeadInvestigationInd(String openLeadInvestigationInd) {
		this.openLeadInvestigationInd = openLeadInvestigationInd;
	}
	
	/**
	 * Gets the ptan cnt.
	 *
	 * @return the ptan cnt
	 */
	public int getPtanCnt() {
		return ptanCnt;
	}
	
	/**
	 * Sets the ptan cnt.
	 *
	 * @param ptanCnt the new ptan cnt
	 */
	public void setPtanCnt(int ptanCnt) {
		this.ptanCnt = ptanCnt;
	}
	
	/**
	 * Gets the specialty cnt.
	 *
	 * @return the specialty cnt
	 */
	public int getSpecialtyCnt() {
		return specialtyCnt;
	}
	
	/**
	 * Sets the specialty cnt.
	 *
	 * @param specialtyCnt the new specialty cnt
	 */
	public void setSpecialtyCnt(int specialtyCnt) {
		this.specialtyCnt = specialtyCnt;
	}
	
	/**
	 * Gets the specialties.
	 *
	 * @return the specialties
	 */
	public List<String> getSpecialties() {
		return specialties;
	}
	
	/**
	 * Sets the specialties.
	 *
	 * @param specialties the new specialties
	 */
	public void setSpecialties(List<String> specialties) {
		this.specialties = specialties;
	}
	
	/**
	 * Gets the activities.
	 *
	 * @return the activities
	 */
	public List<FpsCommonUserActivity> getActivities() {
		return activities;
	}
	
	/**
	 * Sets the activities.
	 *
	 * @param activities the new activities
	 */
	public void setActivities(List<FpsCommonUserActivity> activities) {
		this.activities = activities;
	}
	
	/**
	 * Gets the actions.
	 *
	 * @return the actions
	 */
	public List<FpsCommonActionType> getActions() {
		return actions;
	}
	
	/**
	 * Sets the actions.
	 *
	 * @param actions the new actions
	 */
	public void setActions(List<FpsCommonActionType> actions) {
		this.actions = actions;
	}
	
	/**
	 * Gets the barrier to action cd.
	 *
	 * @return the barrier to action cd
	 */
	public String getBarrierToActionCd() {
		return barrierToActionCd;
	}
	
	/**
	 * Sets the barrier to action cd.
	 *
	 * @param barrierToActionCd the new barrier to action cd
	 */
	public void setBarrierToActionCd(String barrierToActionCd) {
		this.barrierToActionCd = barrierToActionCd;
	}
	
	/**
	 * Gets the ruling change reason cd.
	 *
	 * @return the ruling change reason cd
	 */
	public String getRulingChangeReasonCd() {
		return rulingChangeReasonCd;
	}
	
	/**
	 * Sets the ruling change reason cd.
	 *
	 * @param rulingChangeReasonCd the new ruling change reason cd
	 */
	public void setRulingChangeReasonCd(String rulingChangeReasonCd) {
		this.rulingChangeReasonCd = rulingChangeReasonCd;
	}
	
	/**
	 * Gets the not subject change ind.
	 *
	 * @return the not subject change ind
	 */
	public String getNotSubjectChangeInd() {
		return notSubjectChangeInd;
	}
	
	/**
	 * Sets the not subject change ind.
	 *
	 * @param notSubjectChangeInd the new not subject change ind
	 */
	public void setNotSubjectChangeInd(String notSubjectChangeInd) {
		this.notSubjectChangeInd = notSubjectChangeInd;
	}
	
	/**
	 * Gets the not suspect reasons.
	 *
	 * @return the not suspect reasons
	 */
	public List<String> getNotSuspectReasons() {
		return notSuspectReasons;
	}
	
	/**
	 * Sets the not suspect reasons.
	 *
	 * @param notSuspectReasons the new not suspect reasons
	 */
	public void setNotSuspectReasons(List<String> notSuspectReasons) {
		this.notSuspectReasons = notSuspectReasons;
	}
}
