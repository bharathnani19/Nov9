/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
// TODO: Auto-generated Javadoc
/**
 * The Class FpsCommonPtan.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonPtan  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 3036049900747481585L;
	
	/** The ptan. */
	private String ptan;
	private String type;
	
	/**
	 * Gets the ptan.
	 *
	 * @return the ptan
	 */
	public String getPtan() {
		return ptan;
	}
	
	/**
	 * Sets the ptan.
	 *
	 * @param ptan the new ptan
	 */
	public void setPtan(String ptan) {
		this.ptan = ptan;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ptan == null) ? 0 : ptan.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsCommonPtan other = (FpsCommonPtan) obj;
		if (ptan == null) {
			if (other.ptan != null)
				return false;
		} else if (!ptan.equals(other.ptan))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return (ptan != null ?  ptan : "") ;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
}
