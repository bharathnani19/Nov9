/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
// TODO: Auto-generated Javadoc

/**
 * The Class FpsCommonUserActivity.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsCommonUserActivity implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5713651718568277022L;
	
	/** The asrpt user actvty id. */
	private int asrptUserActvtyId;
	
	/** The fps actvty type rfrnc. */
	private FpsCommonActivityType fpsActvtyTypeRfrnc;
	
	/** The fps aplctn user. */
	private FpsCommonApplicationUser fpsAplctnUser;
	
	/** The fps asrpt invstgtn. */
	private FpsCommonInvestigation fpsAsrptInvstgtn;
	
	/** The user actvty dt. */
	private Date userActvtyDt;
	
	/** The user actvty cnt. */
	private Integer userActvtyCnt;
	
	/** The user actvty cmt txt. */
	private String userActvtyCmtTxt;
	
	/** The fps vrsn ind. */
	private String fpsVrsnInd;
	
	/**
	 * Gets the asrpt user actvty id.
	 *
	 * @return the asrpt user actvty id
	 */
	public int getAsrptUserActvtyId() {
		return asrptUserActvtyId;
	}
	
	/**
	 * Sets the asrpt user actvty id.
	 *
	 * @param asrptUserActvtyId the new asrpt user actvty id
	 */
	public void setAsrptUserActvtyId(int asrptUserActvtyId) {
		this.asrptUserActvtyId = asrptUserActvtyId;
	}
	
	/**
	 * Gets the fps actvty type rfrnc.
	 *
	 * @return the fps actvty type rfrnc
	 */
	public FpsCommonActivityType getFpsActvtyTypeRfrnc() {
		return fpsActvtyTypeRfrnc;
	}
	
	/**
	 * Sets the fps actvty type rfrnc.
	 *
	 * @param fpsActvtyTypeRfrnc the new fps actvty type rfrnc
	 */
	public void setFpsActvtyTypeRfrnc(FpsCommonActivityType fpsActvtyTypeRfrnc) {
		this.fpsActvtyTypeRfrnc = fpsActvtyTypeRfrnc;
	}
	
	/**
	 * Gets the fps aplctn user.
	 *
	 * @return the fps aplctn user
	 */
	public FpsCommonApplicationUser getFpsAplctnUser() {
		return fpsAplctnUser;
	}
	
	/**
	 * Sets the fps aplctn user.
	 *
	 * @param fpsAplctnUser the new fps aplctn user
	 */
	public void setFpsAplctnUser(FpsCommonApplicationUser fpsAplctnUser) {
		this.fpsAplctnUser = fpsAplctnUser;
	}
	
	/**
	 * Gets the fps asrpt invstgtn.
	 *
	 * @return the fps asrpt invstgtn
	 */
	public FpsCommonInvestigation getFpsAsrptInvstgtn() {
		return fpsAsrptInvstgtn;
	}
	
	/**
	 * Sets the fps asrpt invstgtn.
	 *
	 * @param fpsAsrptInvstgtn the new fps asrpt invstgtn
	 */
	public void setFpsAsrptInvstgtn(FpsCommonInvestigation fpsAsrptInvstgtn) {
		this.fpsAsrptInvstgtn = fpsAsrptInvstgtn;
	}
	
	/**
	 * Gets the user actvty dt.
	 *
	 * @return the user actvty dt
	 */
	public Date getUserActvtyDt() {
		return userActvtyDt;
	}
	
	/**
	 * Sets the user actvty dt.
	 *
	 * @param userActvtyDt the new user actvty dt
	 */
	public void setUserActvtyDt(Date userActvtyDt) {
		this.userActvtyDt = userActvtyDt;
	}
	
	/**
	 * Gets the user actvty cnt.
	 *
	 * @return the user actvty cnt
	 */
	public Integer getUserActvtyCnt() {
		return userActvtyCnt;
	}
	
	/**
	 * Sets the user actvty cnt.
	 *
	 * @param userActvtyCnt the new user actvty cnt
	 */
	public void setUserActvtyCnt(Integer userActvtyCnt) {
		this.userActvtyCnt = userActvtyCnt;
	}
	
	/**
	 * Gets the user actvty cmt txt.
	 *
	 * @return the user actvty cmt txt
	 */
	public String getUserActvtyCmtTxt() {
		return userActvtyCmtTxt;
	}
	
	/**
	 * Sets the user actvty cmt txt.
	 *
	 * @param userActvtyCmtTxt the new user actvty cmt txt
	 */
	public void setUserActvtyCmtTxt(String userActvtyCmtTxt) {
		this.userActvtyCmtTxt = userActvtyCmtTxt;
	}
	
	/**
	 * Gets the fps vrsn ind.
	 *
	 * @return the fps vrsn ind
	 */
	public String getFpsVrsnInd() {
		return fpsVrsnInd;
	}
	
	/**
	 * Sets the fps vrsn ind.
	 *
	 * @param fpsVrsnInd the new fps vrsn ind
	 */
	public void setFpsVrsnInd(String fpsVrsnInd) {
		this.fpsVrsnInd = fpsVrsnInd;
	}
}
