package gov.hhs.cms.fps.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.hhs.cms.fps.util.NAStringSerializer;

public class FpsEdit {
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String fpsEditNum;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String fpsEditName;
	
	
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String editDesc;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String editActnType;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String lineOfBusns;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String hstry;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String hstryLkbckPrd;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String echimpNum;
	
	public String getFpsEditNum() {
		return fpsEditNum;
	}
	public void setFpsEditNum(String fpsEditNum) {
		this.fpsEditNum = fpsEditNum;
	}
	public String getFpsEditName() {
		return fpsEditName;
	}
	public void setFpsEditName(String fpsEditName) {
		this.fpsEditName = fpsEditName;
	}
	public String getEditDesc() {
		return editDesc;
	}
	public void setEditDesc(String editDesc) {
		this.editDesc = editDesc;
	}
	public String getEditActnType() {
		return editActnType;
	}
	public void setEditActnType(String editActnType) {
		this.editActnType = editActnType;
	}
	public String getLineOfBusns() {
		return lineOfBusns;
	}
	public void setLineOfBusns(String lineOfBusns) {
		this.lineOfBusns = lineOfBusns;
	}
	public String getHstry() {
		return hstry;
	}
	public void setHstry(String hstry) {
		this.hstry = hstry;
	}
	public String getHstryLkbckPrd() {
		return hstryLkbckPrd;
	}
	public void setHstryLkbckPrd(String hstryLkbckPrd) {
		this.hstryLkbckPrd = hstryLkbckPrd;
	}
	public String getEchimpNum() {
		return echimpNum;
	}
	public void setEchimpNum(String echimpNum) {
		this.echimpNum = echimpNum;
	}
}
