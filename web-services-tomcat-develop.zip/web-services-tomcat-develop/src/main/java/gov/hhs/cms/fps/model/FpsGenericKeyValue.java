package gov.hhs.cms.fps.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsGenericKeyValue implements Serializable {

	private String key;
	private String value;
	private String desc;
	private String amt;
	private String filterCd;
	public FpsGenericKeyValue() {
		
	}
	public FpsGenericKeyValue(String key, String value) {
		this.key = key;
		this.value = value;
	}
	public FpsGenericKeyValue(String key, String value, String desc) {
		this.key = key;
		this.value = value;
		this.desc = desc;
	}
	public FpsGenericKeyValue(String key, String value, String desc, String filterCd) {
		this.key = key;
		this.value = value;
		this.desc = desc;
		this.filterCd = filterCd;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getAmt() {
		return amt;
	}
	public void setAmt(String amt) {
		this.amt = amt;
	}
	public String getFilterCd() {
		return filterCd;
	}
	public void setFilterCd(String filterCd) {
		this.filterCd = filterCd;
	}
	
}
