package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsGeoBase implements Serializable {

	private long id;
	private String lastName;
	private String firstName;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private Double latitude;
	private Double longitude;
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsGeoBase other = (FpsGeoBase) obj;
		if (id != other.id)
			return false;
		return true;
	}
	public String toAddress(){
		
		List<String> parts = new ArrayList<String>();
		if (StringUtils.isNotBlank(address1)){
			parts.add(address1);
		}
		if (StringUtils.isNotBlank(address2)){
			parts.add(address2);
		}
		if (StringUtils.isNotBlank(city)){
			parts.add(city);
		}
		if (StringUtils.isNotBlank(state)){
			parts.add(state);
		}
		if (StringUtils.isNotBlank(zip)){
			parts.add(zip);
		}
		
		return StringUtils.join(parts.toArray(), ", ");
	}
}
