package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)

public class FpsProvider implements Serializable{

	private FpsProviderInfo relatedInfo;
	private FpsProviderEnrollment enrollment;
	private FpsProviderPerforming performing;
	private FpsProviderOrderRefer orderRefer;
	private FpsProviderMedi medi;
	
	public FpsProviderInfo getRelatedInfo() {
		return relatedInfo;
	}
	public void setRelatedInfo(FpsProviderInfo relatedInfo) {
		this.relatedInfo = relatedInfo;
	}
	public FpsProviderEnrollment getEnrollment() {
		return enrollment;
	}
	public void setEnrollment(FpsProviderEnrollment enrollment) {
		this.enrollment = enrollment;
	}
	public FpsProviderPerforming getPerforming() {
		return performing;
	}
	public void setPerforming(FpsProviderPerforming performing) {
		this.performing = performing;
	}
	public FpsProviderOrderRefer getOrderRefer() {
		return orderRefer;
	}
	public void setOrderRefer(FpsProviderOrderRefer orderRefer) {
		this.orderRefer = orderRefer;
	}
	public FpsProviderMedi getMedi() {
		return medi;
	}
	public void setMedi(FpsProviderMedi medi) {
		this.medi = medi;
	}
	
	
	
}
