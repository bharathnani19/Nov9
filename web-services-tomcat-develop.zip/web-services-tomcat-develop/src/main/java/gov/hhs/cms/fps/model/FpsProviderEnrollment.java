package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class FpsProviderEnrollment implements Serializable {
	private Double apsRiskScore;
	private Double apsEfiRiskScore;
	private String apsLastDt;
	private String pacIdStatus;
	private String pacIdStatusDt;
	private String macId;
	private String ptan;
	private String ptanEffectiveDt;
	private String ptanTermDt;
	private String tin;
	private String stateCd;
	private String groupPin;
	private String renderingNpiNum;
	public Double getApsRiskScore() {
		return apsRiskScore;
	}
	public void setApsRiskScore(Double apsRiskScore) {
		this.apsRiskScore = apsRiskScore;
	}
	public Double getApsEfiRiskScore() {
		return apsEfiRiskScore;
	}
	public void setApsEfiRiskScore(Double apsEfiRiskScore) {
		this.apsEfiRiskScore = apsEfiRiskScore;
	}
	public String getApsLastDt() {
		return apsLastDt;
	}
	public void setApsLastDt(String apsLastDt) {
		this.apsLastDt = apsLastDt;
	}
	public String getPacIdStatus() {
		return pacIdStatus;
	}
	public void setPacIdStatus(String pacIdStatus) {
		this.pacIdStatus = pacIdStatus;
	}
	public String getPacIdStatusDt() {
		return pacIdStatusDt;
	}
	public void setPacIdStatusDt(String pacIdStatusDt) {
		this.pacIdStatusDt = pacIdStatusDt;
	}
	public String getMacId() {
		return macId;
	}
	public void setMacId(String macId) {
		this.macId = macId;
	}
	public String getPtan() {
		return ptan;
	}
	public void setPtan(String ptan) {
		this.ptan = ptan;
	}
	public String getPtanEffectiveDt() {
		return ptanEffectiveDt;
	}
	public void setPtanEffectiveDt(String ptanEffectiveDt) {
		this.ptanEffectiveDt = ptanEffectiveDt;
	}
	public String getPtanTermDt() {
		return ptanTermDt;
	}
	public void setPtanTermDt(String ptanTermDt) {
		this.ptanTermDt = ptanTermDt;
	}
	public String getTin() {
		return tin;
	}
	public void setTin(String tin) {
		this.tin = tin;
	}
	public String getStateCd() {
		return stateCd;
	}
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
	public String getGroupPin() {
		return groupPin;
	}
	public void setGroupPin(String groupPin) {
		this.groupPin = groupPin;
	}
	public String getRenderingNpiNum() {
		return renderingNpiNum;
	}
	public void setRenderingNpiNum(String renderingNpiNum) {
		this.renderingNpiNum = renderingNpiNum;
	}
}
