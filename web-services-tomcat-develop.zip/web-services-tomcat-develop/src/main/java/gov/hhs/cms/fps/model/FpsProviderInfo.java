package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)

public class FpsProviderInfo implements Serializable{

	private int providerId;
	private String lastUpdateDt;
	private String perfName;
	private String perfNpi;
	private String perfPtan;
	private String perfSpecialty;
	private String perfAddress;
	private String perfCity;
	private String perfState;
	private String perfZipCd;	
	private String perfCncInd;
	
	private String referName;
	private String referNpi;
	private String referPtan;
	private String referSpecialty;
	private String referAddress;
	private String referCity;
	private String referState;
	private String referZipCd;	
	private String referCncInd;
	
	private String attendName;
	private String attendNpi;
	private String attendPtan;
	private String attendSpecialty;
	private String attendAddress;
	private String attendCity;
	private String attendState;
	private String attendZipCd;	
	private String attendCncInd;
	
	private String billingName;
	private String billingNpi;
	private String billingPtan;
	private String billingSpecialty;
	private String billingAddress;
	private String billingCity;
	private String billingState;
	private String billingZipCd;	
	private String billingCncInd;
	
	private String perfHasAsrInd;
	private String referHasAsrInd;
	private String attendHasAsrInd;
	private String billingHasASrInd;
	
	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public String getPerfName() {
		return perfName;
	}

	public void setPerfName(String perfName) {
		this.perfName = perfName;
	}

	public String getPerfNpi() {
		return perfNpi;
	}

	public void setPerfNpi(String perfNpi) {
		this.perfNpi = perfNpi;
	}

	public String getPerfPtan() {
		return perfPtan;
	}

	public void setPerfPtan(String perfPtan) {
		this.perfPtan = perfPtan;
	}

	public String getPerfSpecialty() {
		return perfSpecialty;
	}

	public void setPerfSpecialty(String perfSpecialty) {
		this.perfSpecialty = perfSpecialty;
	}

	public String getPerfAddress() {
		return perfAddress;
	}

	public void setPerfAddress(String perfAddress) {
		this.perfAddress = perfAddress;
	}

	public String getPerfCity() {
		return perfCity;
	}

	public void setPerfCity(String perfCity) {
		this.perfCity = perfCity;
	}

	public String getPerfState() {
		return perfState;
	}

	public void setPerfState(String perfState) {
		this.perfState = perfState;
	}

	public String getPerfZipCd() {
		return perfZipCd;
	}

	public void setPerfZipCd(String perfZipCd) {
		this.perfZipCd = perfZipCd;
	}

	public String getPerfCncInd() {
		return perfCncInd;
	}

	public void setPerfCncInd(String perfCncInd) {
		this.perfCncInd = perfCncInd;
	}

	public String getReferName() {
		return referName;
	}

	public void setReferName(String referName) {
		this.referName = referName;
	}

	public String getReferNpi() {
		return referNpi;
	}

	public void setReferNpi(String referNpi) {
		this.referNpi = referNpi;
	}

	public String getReferPtan() {
		return referPtan;
	}

	public void setReferPtan(String referPtan) {
		this.referPtan = referPtan;
	}

	public String getReferSpecialty() {
		return referSpecialty;
	}

	public void setReferSpecialty(String referSpecialty) {
		this.referSpecialty = referSpecialty;
	}

	public String getReferAddress() {
		return referAddress;
	}

	public void setReferAddress(String referAddress) {
		this.referAddress = referAddress;
	}

	public String getReferCity() {
		return referCity;
	}

	public void setReferCity(String referCity) {
		this.referCity = referCity;
	}

	public String getReferState() {
		return referState;
	}

	public void setReferState(String referState) {
		this.referState = referState;
	}

	public String getReferZipCd() {
		return referZipCd;
	}

	public void setReferZipCd(String referZipCd) {
		this.referZipCd = referZipCd;
	}

	public String getReferCncInd() {
		return referCncInd;
	}

	public void setReferCncInd(String referCncInd) {
		this.referCncInd = referCncInd;
	}

	public String getAttendName() {
		return attendName;
	}

	public void setAttendName(String attendName) {
		this.attendName = attendName;
	}

	public String getAttendNpi() {
		return attendNpi;
	}

	public void setAttendNpi(String attendNpi) {
		this.attendNpi = attendNpi;
	}

	public String getAttendPtan() {
		return attendPtan;
	}

	public void setAttendPtan(String attendPtan) {
		this.attendPtan = attendPtan;
	}

	public String getAttendSpecialty() {
		return attendSpecialty;
	}

	public void setAttendSpecialty(String attendSpecialty) {
		this.attendSpecialty = attendSpecialty;
	}

	public String getAttendAddress() {
		return attendAddress;
	}

	public void setAttendAddress(String attendAddress) {
		this.attendAddress = attendAddress;
	}

	public String getAttendCity() {
		return attendCity;
	}

	public void setAttendCity(String attendCity) {
		this.attendCity = attendCity;
	}

	public String getAttendState() {
		return attendState;
	}

	public void setAttendState(String attendState) {
		this.attendState = attendState;
	}

	public String getAttendZipCd() {
		return attendZipCd;
	}

	public void setAttendZipCd(String attendZipCd) {
		this.attendZipCd = attendZipCd;
	}

	public String getAttendCncInd() {
		return attendCncInd;
	}

	public void setAttendCncInd(String attendCncInd) {
		this.attendCncInd = attendCncInd;
	}

	public String getBillingName() {
		return billingName;
	}

	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}

	public String getBillingNpi() {
		return billingNpi;
	}

	public void setBillingNpi(String billingNpi) {
		this.billingNpi = billingNpi;
	}

	public String getBillingPtan() {
		return billingPtan;
	}

	public void setBillingPtan(String billingPtan) {
		this.billingPtan = billingPtan;
	}

	public String getBillingSpecialty() {
		return billingSpecialty;
	}

	public void setBillingSpecialty(String billingSpecialty) {
		this.billingSpecialty = billingSpecialty;
	}

	public String getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getBillingCity() {
		return billingCity;
	}

	public void setBillingCity(String billingCity) {
		this.billingCity = billingCity;
	}

	public String getBillingState() {
		return billingState;
	}

	public void setBillingState(String billingState) {
		this.billingState = billingState;
	}

	public String getBillingZipCd() {
		return billingZipCd;
	}

	public void setBillingZipCd(String billingZipCd) {
		this.billingZipCd = billingZipCd;
	}

	public String getBillingCncInd() {
		return billingCncInd;
	}

	public void setBillingCncInd(String billingCncInd) {
		this.billingCncInd = billingCncInd;
	}

	public String getPerfHasAsrInd() {
		return perfHasAsrInd;
	}

	public void setPerfHasAsrInd(String perfHasAsrInd) {
		this.perfHasAsrInd = perfHasAsrInd;
	}

	public String getReferHasAsrInd() {
		return referHasAsrInd;
	}

	public void setReferHasAsrInd(String referHasAsrInd) {
		this.referHasAsrInd = referHasAsrInd;
	}

	public String getAttendHasAsrInd() {
		return attendHasAsrInd;
	}

	public void setAttendHasAsrInd(String attendHasAsrInd) {
		this.attendHasAsrInd = attendHasAsrInd;
	}

	public String getBillingHasASrInd() {
		return billingHasASrInd;
	}

	public void setBillingHasASrInd(String billingHasASrInd) {
		this.billingHasASrInd = billingHasASrInd;
	}

	public String getLastUpdateDt() {
		return lastUpdateDt;
	}

	public void setLastUpdateDt(String lastUpdateDt) {
		this.lastUpdateDt = lastUpdateDt;
	}

	
}
