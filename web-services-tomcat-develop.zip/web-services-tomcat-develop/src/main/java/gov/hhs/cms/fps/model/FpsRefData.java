package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.ANY, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsRefData implements Serializable {
	private List<FpsUser> users;
	private List<FpsZone> zones;
	private List<FpsZone> zoneNoMacs;
	private List<AsrAlertType> alerts;
	private List<AsrDetailModel> models;
	private List<AsrDetailModel> p1Models;
	private List<AsrModelScheme> modelSchemes;
	private List<AsrDetailModel> mdcdModels;
	private List<FpsCommonBarrierType> barriers;
	private List<AsrAction> actions;
	private List<AsrActivity> activities;
	private List<AsrState> states;
	private List<AsrRuling> rulings;
	private List<AsrGenericCode> cityStates;
	private List<FpsGenericKeyValue> exclusions;
	private List<FpsGenericKeyValue> exclusionsMdcd;
	private List<FpsGenericKeyValue> prioritizationTypes;
	private List<AsrGenericCode> edits;
	private List<AsrGenericCode> enrollments;
	private List<FpsGenericKeyValue> exclusionCategories;
	private List<FpsGenericKeyValue> specialties;
	private List<VmInitialModel> vmMedicaidModels;
	private List<AsrGenericCode> mdcdSvcCats;
	private List<AsrGenericCode> mdcdSvcSubCats;
	private List<FpsGenericKeyValue> mdcdSpecialties;
	private List<AsrGenericCode> mdcdSvcTypes;

	private List<AsrGenericCode> mdcdRoles;
	private String p1EnabledInd;

	private List<FpsGenericKeyValue> emlRoles;

	
	public List<FpsUser> getUsers() {
		return this.users;
	}

	public void setUsers(List<FpsUser> users) {
		this.users = users;
	}

	public List<FpsZone> getZones() {
		return this.zones;
	}

	public void setZones(List<FpsZone> zones) {
		this.zones = zones;
	}

	public List<AsrAlertType> getAlerts() {
		return this.alerts;
	}

	public void setAlerts(List<AsrAlertType> alerts) {
		this.alerts = alerts;
	}

	public List<AsrDetailModel> getModels() {
		return this.models;
	}

	public void setModels(List<AsrDetailModel> models) {
		this.models = models;
	}

	public List<FpsCommonBarrierType> getBarriers() {
		return this.barriers;
	}

	public void setBarriers(List<FpsCommonBarrierType> barriers) {
		this.barriers = barriers;
	}

	public List<AsrAction> getActions() {
		return this.actions;
	}

	public void setActions(List<AsrAction> actions) {
		this.actions = actions;
	}

	public List<AsrActivity> getActivities() {
		return this.activities;
	}

	public void setActivities(List<AsrActivity> activities) {
		this.activities = activities;
	}

	public List<AsrState> getStates() {
		return this.states;
	}

	public void setStates(List<AsrState> states) {
		this.states = states;
	}

	public List<AsrRuling> getRulings() {
		return this.rulings;
	}

	public void setRulings(List<AsrRuling> rulings) {
		this.rulings = rulings;
	}

	public List<FpsZone> getZoneNoMacs() {
		return zoneNoMacs;
	}

	public void setZoneNoMacs(List<FpsZone> zoneNoMacs) {
		this.zoneNoMacs = zoneNoMacs;
	}

	public List<AsrGenericCode> getCityStates() {
		return cityStates;
	}

	public void setCityStates(List<AsrGenericCode> cityStates) {
		this.cityStates = cityStates;
	}

	public List<FpsGenericKeyValue> getPrioritizationTypes() {
		return prioritizationTypes;
	}

	public void setPrioritizationTypes(List<FpsGenericKeyValue> prioritizationTypes) {
		this.prioritizationTypes = prioritizationTypes;
	}

	public List<FpsGenericKeyValue> getExclusions() {
		return exclusions;
	}

	public void setExclusions(List<FpsGenericKeyValue> exclusions) {
		this.exclusions = exclusions;
	}

	public List<AsrGenericCode> getEdits() {
		return edits;
	}

	public void setEdits(List<AsrGenericCode> edits) {
		this.edits = edits;
	}

	public List<AsrGenericCode> getEnrollments() {
		return enrollments;
	}

	public void setEnrollments(List<AsrGenericCode> enrollments) {
		this.enrollments = enrollments;
	}

	public List<FpsGenericKeyValue> getExclusionCategories() {
		return exclusionCategories;
	}

	public void setExclusionCategories(List<FpsGenericKeyValue> exclusionCategories) {
		this.exclusionCategories = exclusionCategories;
	}

	/**
	 * @return the specialties
	 */
	public List<FpsGenericKeyValue> getSpecialties() {
		return specialties;
	}

	/**
	 * @param specialties the specialties to set
	 */
	public void setSpecialties(List<FpsGenericKeyValue> specialties) {
		this.specialties = specialties;
	}



	public List<VmInitialModel> getVmMedicaidModels() {
		return vmMedicaidModels;
	}

	public void setVmMedicaidModels(List<VmInitialModel> vmMedicaidModels) {
		this.vmMedicaidModels = vmMedicaidModels;
	}

	public List<AsrGenericCode> getMdcdSvcCats() {
		return mdcdSvcCats;
	}

	public void setMdcdSvcCats(List<AsrGenericCode> mdcdSvcCats) {
		this.mdcdSvcCats = mdcdSvcCats;
	}

	public List<AsrGenericCode> getMdcdSvcSubCats() {
		return mdcdSvcSubCats;
	}

	public void setMdcdSvcSubCats(List<AsrGenericCode> mdcdSvcSubCats) {
		this.mdcdSvcSubCats = mdcdSvcSubCats;
	}

	public List<AsrGenericCode> getMdcdRoles() {
		return mdcdRoles;
	}

	public void setMdcdRoles(List<AsrGenericCode> mdcdRoles) {
		this.mdcdRoles = mdcdRoles;
	}

	public List<FpsGenericKeyValue> getMdcdSpecialties() {
		return mdcdSpecialties;
	}

	public void setMdcdSpecialties(List<FpsGenericKeyValue> mdcdSpecialties) {
		this.mdcdSpecialties = mdcdSpecialties;
	}

	public List<AsrDetailModel> getMdcdModels() {
		return mdcdModels;
	}

	public void setMdcdModels(List<AsrDetailModel> mdcdModels) {
		this.mdcdModels = mdcdModels;
	}

	public List<AsrGenericCode> getMdcdSvcTypes() {
		return mdcdSvcTypes;
	}

	public void setMdcdSvcTypes(List<AsrGenericCode> mdcdSvcTypes) {
		this.mdcdSvcTypes = mdcdSvcTypes;
	}

	public List<FpsGenericKeyValue> getExclusionsMdcd() {
		return exclusionsMdcd;
	}

	public void setExclusionsMdcd(List<FpsGenericKeyValue> exclusionsMdcd) {
		this.exclusionsMdcd = exclusionsMdcd;
	}

	public String getP1EnabledInd() {
		return p1EnabledInd;
	}

	public void setP1EnabledInd(String p1EnabledInd) {
		this.p1EnabledInd = p1EnabledInd;
	}

	public List<FpsGenericKeyValue> getEmlRoles() {
		return emlRoles;
	}

	public void setEmlRoles(List<FpsGenericKeyValue> emlRoles) {
		this.emlRoles = emlRoles;
	}

	public List<AsrDetailModel> getP1Models() {
		return p1Models;
	}

	public void setP1Models(List<AsrDetailModel> p1Models) {
		this.p1Models = p1Models;
	}

	public List<AsrModelScheme> getModelSchemes() {
		return modelSchemes;
	}

	public void setModelSchemes(List<AsrModelScheme> modelSchemes) {
		this.modelSchemes = modelSchemes;
	}

}
