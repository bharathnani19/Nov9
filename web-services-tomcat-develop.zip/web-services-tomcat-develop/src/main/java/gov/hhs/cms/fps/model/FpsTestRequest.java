/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

// TODO: Auto-generated Javadoc
/**
 * The Class FpsTestRequest.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
public class FpsTestRequest implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3842384601096446080L;
	
	/** The test id. */
	private String testId;
	
	/** The fps common. */
	private FpsCommon fpsCommon;
	
	/**
	 * Gets the test id.
	 *
	 * @return the test id
	 */
	public String getTestId() {
		return testId;
	}
	
	/**
	 * Sets the test id.
	 *
	 * @param testId the new test id
	 */
	public void setTestId(String testId) {
		this.testId = testId;
	}
	
	/**
	 * Gets the fps common.
	 *
	 * @return the fps common
	 */
	public FpsCommon getFpsCommon() {
		return fpsCommon;
	}
	
	/**
	 * Sets the fps common.
	 *
	 * @param fpsCommon the new fps common
	 */
	public void setFpsCommon(FpsCommon fpsCommon) {
		this.fpsCommon = fpsCommon;
	}
}
