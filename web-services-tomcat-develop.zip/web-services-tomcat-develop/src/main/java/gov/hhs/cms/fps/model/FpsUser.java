package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class FpsUser implements Serializable{

	private String userId;
	private String givenName;
	private String email;
	//role
	private String groupName;
	//zone
	private String businessCategory;
	private String firstName;
	private String lastName;
	private String masterApprover;
	private String inqOnlyApprover;
	private String macApprover;
	private String cmsPriorityAsr;
	private String phone;
	private String prioritizeSup;
	private String upic;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getGivenName() {
		return givenName;
	}
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getBusinessCategory() {
		return businessCategory;
	}
	public void setBusinessCategory(String businessCategory) {
		this.businessCategory = businessCategory;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsUser other = (FpsUser) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMasterApprover() {
		return masterApprover;
	}
	public void setMasterApprover(String masterApprover) {
		this.masterApprover = masterApprover;
	}
	public String getInqOnlyApprover() {
		return inqOnlyApprover;
	}
	public void setInqOnlyApprover(String inqOnlyApprover) {
		this.inqOnlyApprover = inqOnlyApprover;
	}
	public String getMacApprover() {
		return macApprover;
	}
	public void setMacApprover(String macApprover) {
		this.macApprover = macApprover;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCmsPriorityAsr() {
		return cmsPriorityAsr;
	}
	public void setCmsPriorityAsr(String cmsPriorityAsr) {
		this.cmsPriorityAsr = cmsPriorityAsr;
	}
	public String getPrioritizeSup() {
		return prioritizeSup;
	}
	public void setPrioritizeSup(String prioritizeSup) {
		this.prioritizeSup = prioritizeSup;
	}
	public String getUpic() {
		return upic;
	}
	public void setUpic(String upic) {
		this.upic = upic;
	}

	
}
