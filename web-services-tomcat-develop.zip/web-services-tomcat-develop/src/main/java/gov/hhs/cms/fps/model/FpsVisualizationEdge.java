package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)

public class FpsVisualizationEdge implements Serializable {

	//@Field(value="src")
	private String from;
	//@Field(value="dst")
	private String to;
	//@Field(value="label")
	@JsonIgnore
	private String label="";
	
	private String title;
	
	private String title2;

	private String title3;
	
	private String title4;
	
	private String title5;
	//@Field(value="attr_sqnc_num")
	private Integer attrSqncNum;
	//@Field(value="audt_insrt_ts")
	private Date audtInsrtTs;
	//@Field(value="clstr_size")
	private Integer clstrSize;
	////@Field(value="flag")
	private String flag;;
	////@Field(value="group")
	private String group;
	//@Field(value="model_busns_id")
	private String modelBusnsId;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy/MM/dd", timezone="America/New_York")
	//@Field(value="model_run_dt")
	private Date modelRunDt;

	//@Field(value="rpt_card_rsk_sna_oupt_stng_id")
	private Integer reportcardsnaId;
	//@Field(value="rltd_npi_name")
	private String rltdNpiName="";
	//@Field(value="rltd_prvdr_clstr_pct")
	private String rltdPrvdrClstrPct="";
	//@Field(value="rltd_prvdr_npi")
	private String rltdPrvdrNpi="";
	//@Field(value="rltd_prvdr_num_bene")
	private Integer rltdPrvdrNumBene;
	//@Field(value="rltd_prvdr_rsk_rsn_desc")
	private String rltdPrvdrRskRsnDesc="";
	
	private String rltdPrvdrType="";
	//@Field(value="stus_txt")
	private String stusTxt=""; 	
	//@Field(value="subj_npi_name")
	private String subjNpiName="";
	//@Field(value="subj_prvdr_clstr_pct")
	private String subjPrvdrClstrPct="";
	//@Field(value="subj_prvdr_npi")
	private String subjPrvdrNpi="";
	//@Field(value="subj_prvdr_num_bene")
	private Integer subjPrvdrNumBene;
	//@Field(value="id")
	private String id;
	//@Field(value="subj_prvdr_type")
	private String subjPrvdrRole="";
	//@Field(value="rltd_prvdr_type")
	private String rltdPrvdrRole="";
	//@Field(value="ranking")
	private Integer ranking;
	//@Field(value="weight")
	private Double weight;
	//@Field(value="percent_bene")
	private Float benePct;

	//@Field(value="bene_cnt")
	private Long beneCnt;
	private AsrSummary asr;
	//@Field(value="pecos_relationship")
	private String pecosRltnshp;
	//@Field(value="num_rltd_prvdr")
	private String rltdPrvdrNum;
	//@Field(value="num_bad_rltd_prvdr")
	private String badRltdPrvdrNum;
	//@Field(value="pct_bad_rltd_prvdr")
	private String badRltdPrvdrPct;	
	
	private List<AsrGenericCode> rltdPrvdrRskRsns;
	
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getTitle() {
		String retval = "";
		if (modelBusnsId != null){
			retval =  StringEscapeUtils.escapeJavaScript("# of Shared Benes: " + clstrSize + ", Reason:" + rltdPrvdrRskRsnDesc);
		}else{
			String roundedBenePct = "N/A";
			if (beneCnt != null) {
		     BigDecimal bd = new BigDecimal(benePct).setScale(2, RoundingMode.HALF_UP);
		     roundedBenePct = bd.toPlainString();
			}
			retval =  "# Shared Benes: " + (beneCnt != null ? beneCnt :"N/A") + "<br/> % Shared Benes:" + roundedBenePct;
		}
		
		return retval;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTitle2() {
		return title2;
	}
	public void setTitle2(String title2) {
		this.title2 = title2;
	}
	public String getTitle3() {
		return title3;
	}
	public void setTitle3(String title3) {
		this.title3 = title3;
	}
	public String getTitle4() {
		return title4;
	}
	public void setTitle4(String title4) {
		this.title4 = title4;
	}
	public String getTitle5() {
		return title5;
	}
	public void setTitle5(String title5) {
		this.title5 = title5;
	}
	public Integer getClstrSize() {
		if (beneCnt != null) {
			return beneCnt.intValue();
		}
		return clstrSize;
	}
	public void setClstrSize(Integer clstrSize) {
		this.clstrSize = clstrSize;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	public String getRltdNpiName() {
		return rltdNpiName;
	}
	public void setRltdNpiName(String rltdNpiName) {
		this.rltdNpiName = rltdNpiName;
	}
	public String getRltdPrvdrClstrPct() {
		return rltdPrvdrClstrPct;
	}
	public void setRltdPrvdrClstrPct(String rltdPrvdrClstrPct) {
		this.rltdPrvdrClstrPct = rltdPrvdrClstrPct;
	}
	public String getRltdPrvdrNpi() {
		return rltdPrvdrNpi;
	}
	public void setRltdPrvdrNpi(String rltdPrvdrNpi) {
		this.rltdPrvdrNpi = rltdPrvdrNpi;
	}
	public Integer getRltdPrvdrNumBene() {
		return rltdPrvdrNumBene;
	}
	public void setRltdPrvdrNumBene(Integer rltdPrvdrNumBene) {
		this.rltdPrvdrNumBene = rltdPrvdrNumBene;
	}
	public String getRltdPrvdrRskRsnDesc() {
		return rltdPrvdrRskRsnDesc;
	}
	public void setRltdPrvdrRskRsnDesc(String rltdPrvdrRskRsnDesc) {
		this.rltdPrvdrRskRsnDesc = rltdPrvdrRskRsnDesc;
	}
	public String getRltdPrvdrType() {
		return rltdPrvdrType;
	}
	public void setRltdPrvdrType(String rltdPrvdrType) {
		this.rltdPrvdrType = rltdPrvdrType;
	}
	public String getSubjNpiName() {
		return subjNpiName;
	}
	public void setSubjNpiName(String subjNpiName) {
		this.subjNpiName = subjNpiName;
	}
	public String getSubjPrvdrClstrPct() {
		if (benePct != null) {
			return benePct.toString();
		}
		return subjPrvdrClstrPct;
	}
	public void setSubjPrvdrClstrPct(String subjPrvdrClstrPct) {
		this.subjPrvdrClstrPct = subjPrvdrClstrPct;
	}
	public String getSubjPrvdrNpi() {
		return subjPrvdrNpi;
	}
	public void setSubjPrvdrNpi(String subjPrvdrNpi) {
		this.subjPrvdrNpi = subjPrvdrNpi;
	}
	public Integer getSubjPrvdrNumBene() {
		
		return subjPrvdrNumBene;
	}
	public void setSubjPrvdrNumBene(Integer subjPrvdrNumBene) {
		this.subjPrvdrNumBene = subjPrvdrNumBene;
	}
	public AsrSummary getAsr() {
		return asr;
	}
	public void setAsr(AsrSummary asr) {
		this.asr = asr;
	}
	public Date getModelRunDt() {
		return modelRunDt;
	}
	public void setModelRunDt(Date modelRunDt) {
		this.modelRunDt = modelRunDt;
	}
	public List<AsrGenericCode> getRltdPrvdrRskRsns() {
		if (rltdPrvdrRskRsns == null && rltdPrvdrRskRsnDesc != null){
			rltdPrvdrRskRsns = new ArrayList<AsrGenericCode>();
			String[] rsns = rltdPrvdrRskRsnDesc.split(",");
			for (int i= 0;i < rsns.length;i++){
				AsrGenericCode code = new AsrGenericCode();
				code.setCode(rsns[i]);
				rltdPrvdrRskRsns.add(code);
			}
		}
		return rltdPrvdrRskRsns;
	}
	public void setRltdPrvdrRskRsns(List<AsrGenericCode> rltdPrvdrRskRsns) {
		this.rltdPrvdrRskRsns = rltdPrvdrRskRsns;
	}
	public String getSubjPrvdrRole() {
		return subjPrvdrRole;
	}
	public void setSubjPrvdrRole(String subjPrvdrRole) {
		this.subjPrvdrRole = subjPrvdrRole;
	}
	public String getRltdPrvdrRole() {
		return rltdPrvdrRole;
	}
	public void setRltdPrvdrRole(String rltdPrvdrRole) {
		this.rltdPrvdrRole = rltdPrvdrRole;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public Integer getRanking() {
		return ranking;
	}
	public void setRanking(Integer ranking) {
		this.ranking = ranking;
	}
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((from == null) ? 0 : from.hashCode());
		result = prime * result + ((to == null) ? 0 : to.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsVisualizationEdge other = (FpsVisualizationEdge) obj;
		if (from == null) {
			if (other.from != null)
				return false;
		} else if (!from.equals(other.from))
			return false;
		if (to == null) {
			if (other.to != null)
				return false;
		} else if (!to.equals(other.to))
			return false;
		return true;
	}
	public String getPecosRltnshp() {
		return pecosRltnshp;
	}
	public void setPecosRltnshp(String pecosRltnshp) {
		this.pecosRltnshp = pecosRltnshp;
	}
	public String getRltdPrvdrNum() {
		return rltdPrvdrNum;
	}
	public void setRltdPrvdrNum(String rltdPrvdrNum) {
		this.rltdPrvdrNum = rltdPrvdrNum;
	}
	public String getBadRltdPrvdrNum() {
		return badRltdPrvdrNum;
	}
	public void setBadRltdPrvdrNum(String badRltdPrvdrNum) {
		this.badRltdPrvdrNum = badRltdPrvdrNum;
	}
	public String getBadRltdPrvdrPct() {
		return badRltdPrvdrPct;
	}
	public void setBadRltdPrvdrPct(String badRltdPrvdrPct) {
		this.badRltdPrvdrPct = badRltdPrvdrPct;
	}
	@JsonIgnore
	public Float getBenePct() {
		return benePct;
	}
	public void setBenePct(Float benePct) {
		this.benePct = benePct;
	}
	public Long getBeneCnt() {
		return beneCnt;
	}
	public void setBeneCnt(Long beneCnt) {
		this.beneCnt = beneCnt;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "FpsVisualizationEdge [from=" + from + ", to=" + to + ", subjPrvdrClstrPct=" + subjPrvdrClstrPct
				+ ", id=" + id + ", benePct=" + benePct + "]";
	}
}
