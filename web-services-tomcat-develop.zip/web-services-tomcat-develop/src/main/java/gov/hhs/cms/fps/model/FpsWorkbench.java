package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class FpsWorkbench implements Serializable {

	private List<FpsWorkbenchList> workbenchLists;
	private List<FpsWorkbenchList> workbenchMdcdLists;

	public List<FpsWorkbenchList> getWorkbenchLists() {
		return workbenchLists;
	}

	public void setWorkbenchLists(List<FpsWorkbenchList> workbenchLists) {
		this.workbenchLists = workbenchLists;
	}

	public List<FpsWorkbenchList> getWorkbenchMdcdLists() {
		return workbenchMdcdLists;
	}

	public void setWorkbenchMdcdLists(List<FpsWorkbenchList> workbenchMdcdLists) {
		this.workbenchMdcdLists = workbenchMdcdLists;
	}

}
