package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class FpsWorkbenchAction implements Serializable {

	private List<Integer> asrptIds;

	public List<Integer> getAsrptIds() {
		return asrptIds;
	}

	public void setAsrptIds(List<Integer> asrptIds) {
		this.asrptIds = asrptIds;
	}
	

}
