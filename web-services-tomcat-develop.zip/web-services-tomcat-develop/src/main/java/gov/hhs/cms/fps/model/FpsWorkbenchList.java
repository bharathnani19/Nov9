package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class FpsWorkbenchList implements Serializable, Comparable<FpsWorkbenchList> {

	private Integer listId;
	private String listType;
	private String listNm;
	private String ownerNm;
	private String ownerId;
	private String sharedInd;
	private Integer grpId;
	private String grpNm;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	private Date createDt;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")

	private Date updateDt;
	private String listCnt;
	private String prioritizedCnt;
	private String publicInd;
	private String removedInd;
	private String asrType;

	public Integer getListId() {
		return listId;
	}

	public void setListId(Integer listId) {
		this.listId = listId;
	}

	public String getListType() {
		return listType;
	}

	public void setListType(String listType) {
		this.listType = listType;
	}

	public String getListNm() {
		return listNm;
	}

	public void setListNm(String listNm) {
		this.listNm = listNm;
	}

	public String getOwnerNm() {
		return ownerNm;
	}

	public void setOwnerNm(String ownerNm) {
		this.ownerNm = ownerNm;
	}

	public String getSharedInd() {
		return sharedInd;
	}

	public void setSharedInd(String sharedInd) {
		this.sharedInd = sharedInd;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public Date getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getListCnt() {
		return listCnt;
	}

	public void setListCnt(String listCnt) {
		this.listCnt = listCnt;
	}

	public String getPrioritizedCnt() {
		return prioritizedCnt;
	}

	public void setPrioritizedCnt(String prioritizedCnt) {
		this.prioritizedCnt = prioritizedCnt;
	}

	public int compareTo(FpsWorkbenchList m) {
		if (this.createDt != null) {
			return m.createDt.compareTo(this.createDt);
		} else if (this.listNm != null) {
			return this.listNm.toLowerCase().compareTo(m.listNm.toLowerCase());
		} else {
			return 0;
		}
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public Integer getGrpId() {
		return grpId;
	}

	public void setGrpId(Integer grpId) {
		this.grpId = grpId;
	}

	public String getGrpNm() {
		return grpNm;
	}

	public void setGrpNm(String grpNm) {
		this.grpNm = grpNm;
	}

	public String getPublicInd() {
		return publicInd;
	}

	public void setPublicInd(String publicInd) {
		this.publicInd = publicInd;
	}

	public String getRemovedInd() {
		return removedInd;
	}

	public void setRemovedInd(String removedInd) {
		this.removedInd = removedInd;
	}

	public String getAsrType() {
		return asrType;
	}

	public void setAsrType(String asrType) {
		this.asrType = asrType;
	}
}
