package gov.hhs.cms.fps.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class HdfsFileStoreException {

	private String exception;
	private String javaClassName;
	private String message;
	public String getException() {
		return exception;
	}
	public void setException(String exception) {
		this.exception = exception;
	}
	public String getJavaClassName() {
		return javaClassName;
	}
	public void setJavaClassName(String javaClassName) {
		this.javaClassName = javaClassName;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "HdfsFileStoreException [" + (exception != null ? "exception=" + exception + ", " : "")
				+ (javaClassName != null ? "javaClassName=" + javaClassName + ", " : "")
				+ (message != null ? "message=" + message : "") + "]";
	}
}
