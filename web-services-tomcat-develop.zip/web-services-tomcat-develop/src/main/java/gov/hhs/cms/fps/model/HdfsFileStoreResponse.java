package gov.hhs.cms.fps.model;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;


@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonIgnoreProperties(ignoreUnknown=true)
public class HdfsFileStoreResponse {
    @JsonProperty("RemoteException")
	private HdfsFileStoreException remoteException;
    @JsonProperty("FileStatuses")

	private HdfsFileStoreStatuses fileStatuses;
	public HdfsFileStoreException getRemoteException() {
		return remoteException;
	}
	public void setRemoteException(HdfsFileStoreException remoteException) {
		this.remoteException = remoteException;
	}

}
