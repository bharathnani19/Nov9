package gov.hhs.cms.fps.model;

import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonIgnoreProperties(ignoreUnknown=true)
public class HdfsFileStoreStatuses {
    @JsonProperty("FileStatus")

	private List<HdfsFileStoreStatus> fileStatus;

	public List<HdfsFileStoreStatus> getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(List<HdfsFileStoreStatus> fileStatus) {
		this.fileStatus = fileStatus;
	}
}
