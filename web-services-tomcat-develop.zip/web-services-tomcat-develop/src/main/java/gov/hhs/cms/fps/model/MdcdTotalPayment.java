package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class MdcdTotalPayment implements Serializable {
	
	private String modelNm;
	private String role;
	private String billingNpi;
	private String svcCat;
	private String states;
	private String svcSubCat;
	private String mcoSubmitAmt;
	private String mcoTotalPmt;
	private String mcoPlan;
	private String submitAmt;
	private String totalPmt;
	private String plan;
	private String ffsSubmitAmt;
	private String ffsTotalPmt;
	private String ffsPlan;
	private Integer recipCnt;
	private Integer mcoRecipCnt;
	private Integer ffsRecipCnt;
	public String getModelNm() {
		return modelNm;
	}
	public void setModelNm(String modelNm) {
		this.modelNm = modelNm;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getBillingNpi() {
		return billingNpi;
	}
	public void setBillingNpi(String billingNpi) {
		this.billingNpi = billingNpi;
	}
	public String getSvcCat() {
		return svcCat;
	}
	public void setSvcCat(String svcCat) {
		this.svcCat = svcCat;
	}
	public String getStates() {
		return states;
	}
	public void setStates(String states) {
		this.states = states;
	}
	public String getSvcSubCat() {
		return svcSubCat;
	}
	public void setSvcSubCat(String svcSubCat) {
		this.svcSubCat = svcSubCat;
	}
	public String getMcoSubmitAmt() {
		return mcoSubmitAmt;
	}
	public void setMcoSubmitAmt(String mcoSubmitAmt) {
		this.mcoSubmitAmt = mcoSubmitAmt;
	}
	public String getMcoTotalPmt() {
		return mcoTotalPmt;
	}
	public void setMcoTotalPmt(String mcoTotalPmt) {
		this.mcoTotalPmt = mcoTotalPmt;
	}
	public String getMcoPlan() {
		return mcoPlan;
	}
	public void setMcoPlan(String mcoPlan) {
		this.mcoPlan = mcoPlan;
	}
	public String getSubmitAmt() {
		return submitAmt;
	}
	public void setSubmitAmt(String submitAmt) {
		this.submitAmt = submitAmt;
	}
	public String getTotalPmt() {
		return totalPmt;
	}
	public void setTotalPmt(String totalPmt) {
		this.totalPmt = totalPmt;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getFfsSubmitAmt() {
		return ffsSubmitAmt;
	}
	public void setFfsSubmitAmt(String ffsSubmitAmt) {
		this.ffsSubmitAmt = ffsSubmitAmt;
	}
	public String getFfsTotalPmt() {
		return ffsTotalPmt;
	}
	public void setFfsTotalPmt(String ffsTotalPmt) {
		this.ffsTotalPmt = ffsTotalPmt;
	}
	public String getFfsPlan() {
		return ffsPlan;
	}
	public void setFfsPlan(String ffsPlan) {
		this.ffsPlan = ffsPlan;
	}
	public Integer getRecipCnt() {
		return recipCnt;
	}
	public void setRecipCnt(Integer recipCnt) {
		this.recipCnt = recipCnt;
	}
	public Integer getMcoRecipCnt() {
		return mcoRecipCnt;
	}
	public void setMcoRecipCnt(Integer mcoRecipCnt) {
		this.mcoRecipCnt = mcoRecipCnt;
	}
	public Integer getFfsRecipCnt() {
		return ffsRecipCnt;
	}
	public void setFfsRecipCnt(Integer ffsRecipCnt) {
		this.ffsRecipCnt = ffsRecipCnt;
	}

}
