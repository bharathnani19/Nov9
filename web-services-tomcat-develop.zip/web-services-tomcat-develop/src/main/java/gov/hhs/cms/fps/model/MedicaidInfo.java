package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class MedicaidInfo implements Serializable {
	
	private String state;
	private String npi;
	private String prvdrName;
	private String reason;
	private String asOfDate;
	private String claimCnt;
	private String dollars;
	private String number;
	private List<MedicaidInfoData> data;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
	public String getClaimCnt() {
		return claimCnt;
	}
	public void setClaimCnt(String claimCnt) {
		this.claimCnt = claimCnt;
	}
	public String getDollars() {
		return dollars;
	}
	public void setDollars(String dollars) {
		this.dollars = dollars;
	}
	public List<MedicaidInfoData> getData() {
		return data;
	}
	public void setData(List<MedicaidInfoData> data) {
		this.data = data;
	}
	public String getPrvdrName() {
		return prvdrName;
	}
	public void setPrvdrName(String prvdrName) {
		this.prvdrName = prvdrName;
	}
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	

}
