package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class MedicaidInfoData implements Serializable {
	
	private String attrDef;
	private String threshold;
	private String prvdrVal;
	private String attrThresh;
	private String stateMedian;
	private String statePct;

	public String getAttrDef() {
		return attrDef;
	}
	public void setAttrDef(String attrDef) {
		this.attrDef = attrDef;
	}
	public String getThreshold() {
		return threshold;
	}
	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}
	public String getPrvdrVal() {
		return prvdrVal;
	}
	public void setPrvdrVal(String prvdrVal) {
		this.prvdrVal = prvdrVal;
	}
	public String getAttrThresh() {
		return attrThresh;
	}
	public void setAttrThresh(String attrThresh) {
		this.attrThresh = attrThresh;
	}
	public String getStateMedian() {
		return stateMedian;
	}
	public void setStateMedian(String stateMedian) {
		this.stateMedian = stateMedian;
	}
	public String getStatePct() {
		return statePct;
	}
	public void setStatePct(String statePct) {
		this.statePct = statePct;
	}
	

}
