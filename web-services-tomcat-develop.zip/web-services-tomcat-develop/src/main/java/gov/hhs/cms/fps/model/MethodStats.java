package gov.hhs.cms.fps.model;

public class MethodStats {


	private String methodName;
	private long count;
	private long totalTime;
	private long lastTotalTime;
	private long maxTime;
	private String methodArgs;
	
	 public MethodStats(String methodName, String methodArgs) {
         this.methodName = methodName;
         this.methodArgs = methodArgs;
     }

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public long getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(long totalTime) {
		this.totalTime = totalTime;
	}

	public long getLastTotalTime() {
		return lastTotalTime;
	}

	public void setLastTotalTime(long lastTotalTime) {
		this.lastTotalTime = lastTotalTime;
	}

	public long getMaxTime() {
		return maxTime;
	}

	public void setMaxTime(long maxTime) {
		this.maxTime = maxTime;
	}

	public String getMethodArgs() {
		return methodArgs;
	}

	public void setMethodArgs(String methodArgs) {
		this.methodArgs = methodArgs;
	}

}
