package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProviderAnalysisZoneData implements Serializable {
	
	private String cntrctrCd;
	private String prioritizeInd = "N";

	private String ucmCaseStatusesTxt;
	private Date ucmLastClosedDt;
	private String leadInd = "N";
	
	private List<String> exclusions = new ArrayList<String>();
	

	private List<String> ucmCaseStatuses = new ArrayList<String>();
	private List<Date> ucmLastClosedDts = new ArrayList<Date>();
	public String getCntrctrCd() {
		return cntrctrCd;
	}
	public void setCntrctrCd(String cntrctrCd) {
		this.cntrctrCd = cntrctrCd;
	}
	public String getPrioritizeInd() {
		return prioritizeInd;
	}
	public void setPrioritizeInd(String prioritizeInd) {
		this.prioritizeInd = prioritizeInd;
	}
	
	public String getUcmCaseStatusesTxt() {
		return ucmCaseStatusesTxt;
	}
	public void setUcmCaseStatusesTxt(String ucmCaseStatusesTxt) {
		this.ucmCaseStatusesTxt = ucmCaseStatusesTxt;
	}
	public Date getUcmLastClosedDt() {
		return ucmLastClosedDt;
	}
	public void setUcmLastClosedDt(Date ucmLastClosedDt) {
		this.ucmLastClosedDt = ucmLastClosedDt;
	}
	public String getLeadInd() {
		return leadInd;
	}
	public void setLeadInd(String leadInd) {
		this.leadInd = leadInd;
	}


	public List<String> getUcmCaseStatuses() {
		return ucmCaseStatuses;
	}
	public void setUcmCaseStatuses(List<String> ucmCaseStatuses) {
		this.ucmCaseStatuses = ucmCaseStatuses;
	}
	public List<Date> getUcmLastClosedDts() {
		return ucmLastClosedDts;
	}
	public void setUcmLastClosedDts(List<Date> ucmLastClosedDts) {
		this.ucmLastClosedDts = ucmLastClosedDts;
	}
	public Date getMostRecentUcmClosedDt() {
		return ucmLastClosedDts.size() > 0 ? Collections.max(ucmLastClosedDts): null;
	}
	public List<String> getExclusions() {
		return exclusions;
	}
	public void setExclusions(List<String> exclusions) {
		this.exclusions = exclusions;
	}
	
	
	
}
