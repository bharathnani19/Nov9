package gov.hhs.cms.fps.model;

import java.io.Serializable;

public class RelatedAsr implements Serializable {

	private String npi;
	private Integer asrptId;
	private String name;
	private String relationships;
	private String riskScore;
	private String priorityScore;
	private String asrCost;
	private String newModels;
	private String agedModels;
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRelationships() {
		return relationships;
	}
	public void setRelationships(String relationships) {
		this.relationships = relationships;
	}
	public String getRiskScore() {
		return riskScore;
	}
	public void setRiskScore(String riskScore) {
		this.riskScore = riskScore;
	}
	public String getPriorityScore() {
		return priorityScore;
	}
	public void setPriorityScore(String priorityScore) {
		this.priorityScore = priorityScore;
	}
	public String getAsrCost() {
		return asrCost;
	}
	public void setAsrCost(String asrCost) {
		this.asrCost = asrCost;
	}
	public String getNewModels() {
		return newModels;
	}
	public void setNewModels(String newModels) {
		this.newModels = newModels;
	}
	public String getAgedModels() {
		return agedModels;
	}
	public void setAgedModels(String agedModels) {
		this.agedModels = agedModels;
	}
}
