package gov.hhs.cms.fps.model;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.annotate.JsonProperty;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)
@JsonInclude(Include.NON_NULL)
public class SolrStreamAsrDetailClaimLineItem extends AsrDetailClaimLineItem {

	@JsonProperty("EOF")
	private String eof;
	@JsonProperty("RESPONSE_TIME")
	private String responseTime;
	@JsonProperty("EXCEPTION")
	private String exeption;
	
}
