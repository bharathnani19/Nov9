/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

// TODO: Auto-generated Javadoc
/**
 * The Class UcmCaseDiscoveryParameter.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)

public class UcmCaseDiscoveryParameter  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5680814436894391521L;
	
	/** The start time. */
	private String startTime;
	
	/** The end time. */
	private String endTime;
	
	/** The asr. */
	private List<String> asr = new ArrayList<String>();
	
	/** The npi. */
	private List<String> npi = new ArrayList<String>();
	
	
	public void addAsr(String newAsr){
		asr.add(newAsr);
	}
	
	public void addNpi(String newNpi){
		npi.add(newNpi);
	}
	/**
	 * Gets the asr.
	 *
	 * @return the asr
	 */
	public List<String> getAsr() {
		return asr;
	}
	
	/**
	 * Sets the asr.
	 *
	 * @param asr the new asr
	 */
	public void setAsr(List<String> asr) {
		this.asr = asr;
	}
	
	/**
	 * Gets the npi.
	 *
	 * @return the npi
	 */
	public List<String> getNpi() {
		return npi;
	}
	
	/**
	 * Sets the npi.
	 *
	 * @param npi the new npi
	 */
	public void setNpi(List<String> npi) {
		this.npi = npi;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UcmCaseDiscoveryParameter [asr=" + asr + ", npi=" + npi + "]";
	}
	
	/**
	 * Gets the start time.
	 *
	 * @return the start time
	 */
	public String getStartTime() {
		return startTime;
	}
	
	/**
	 * Sets the start time.
	 *
	 * @param startTime the new start time
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	
	/**
	 * Gets the end time.
	 *
	 * @return the end time
	 */
	public String getEndTime() {
		return endTime;
	}
	
	/**
	 * Sets the end time.
	 *
	 * @param endTime the new end time
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	
}
