/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

// TODO: Auto-generated Javadoc
/**
 * The Class UcmCaseDiscoveryRequest.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.NONE)

public class UcmCaseDiscoveryRequest implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9115744605609812948L;
	
	/** The system name. */
	private String systemName = "FPS";
	
	/** The request type. */
	private String requestType = "Data";
	
	/** The request sub type. */
	private String requestSubType = "UCMCases";
	
	/** The parameters. */
	private UcmCaseDiscoveryParameter parameters;
	
	/** The transaction ID. */
	//key:value
	private String transactionID;
	
	/**
	 * Gets the system name.
	 *
	 * @return the systemName
	 */
	public String getSystemName() {
		return systemName;
	}
	
	/**
	 * Sets the system name.
	 *
	 * @param systemName the systemName to set
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	
	/**
	 * Gets the request type.
	 *
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	
	/**
	 * Sets the request type.
	 *
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	/**
	 * Gets the request sub type.
	 *
	 * @return the requestSubType
	 */
	public String getRequestSubType() {
		return requestSubType;
	}
	
	/**
	 * Sets the request sub type.
	 *
	 * @param requestSubType the requestSubType to set
	 */
	public void setRequestSubType(String requestSubType) {
		this.requestSubType = requestSubType;
	}
	
	/**
	 * Gets the transaction ID.
	 *
	 * @return the transactionID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	
	/**
	 * Sets the transaction ID.
	 *
	 * @param transactionID the transactionID to set
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	/**
	 * Gets the parameters.
	 *
	 * @return the parameters
	 */
	public UcmCaseDiscoveryParameter getParameters() {
		return parameters;
	}
	
	/**
	 * Sets the parameters.
	 *
	 * @param parameters the parameters to set
	 */
	public void setParameters(UcmCaseDiscoveryParameter parameters) {
		this.parameters = parameters;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UcmCaseDiscoveryRequest [systemName=" + systemName
				+ ", requestType=" + requestType + ", requestSubType="
				+ requestSubType + ", parameters=" + parameters
				+ ", transactionID=" + transactionID + "]";
	}
}
