/*
 * 
 */
package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
// TODO: Auto-generated Javadoc

/**
 * The Class UcmCaseDiscoveryResponse.
 */
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)

public class UcmCaseDiscoveryResponse  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1766391575720920055L;
	
	/** The transaction ID. */
	private String transactionID;
	
	/** The status. */
	private String status;
	
	private String statusDescription;
	
	/** The response data. */
	private List<UcmCaseData> responseData;
	
	/**
	 * Gets the transaction ID.
	 *
	 * @return the transaction ID
	 */
	public String getTransactionID() {
		return transactionID;
	}
	
	/**
	 * Sets the transaction ID.
	 *
	 * @param transactionID the new transaction ID
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the response data.
	 *
	 * @return the responseData
	 */
	public List<UcmCaseData> getResponseData() {
		return responseData;
	}
	
	/**
	 * Sets the response data.
	 *
	 * @param responseData the responseData to set
	 */
	public void setResponseData(List<UcmCaseData> responseData) {
		this.responseData = responseData;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
}
