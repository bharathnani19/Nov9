package gov.hhs.cms.fps.model;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonDeserialize;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonFormat;

import gov.hhs.cms.fps.controller.JsonDateDeserializer;
@JsonIgnoreProperties(ignoreUnknown = true)
@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@org.codehaus.jackson.annotate.JsonAutoDetect(fieldVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.ANY, getterVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.NONE, setterVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.NONE)

public class UcmModelContribution implements Serializable{
	private String ucmAsrRecordId;
	private String npi;
	private String subject;
//	@JsonDeserialize(using = JsonDateDeserializer.class)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd hh:mm:ss.SSSX", timezone="America/New_York")
	private String ratingDate;
	private String eventType;
	private List<UcmModelContributionModel> model;
	public String getUcmAsrRecordId() {
		return ucmAsrRecordId;
	}
	public void setUcmAsrRecordId(String ucmAsrRecordId) {
		this.ucmAsrRecordId = ucmAsrRecordId;
	}
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getRatingDate() {
		return ratingDate;
	}
	public void setRatingDate(String ratingDate) {
		this.ratingDate = ratingDate;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public List<UcmModelContributionModel> getModel() {
		return model;
	}
	public void setModel(List<UcmModelContributionModel> model) {
		this.model = model;
	}
	@Override
	public String toString() {
		return "UcmModelContribution [" + (ucmAsrRecordId != null ? "ucmAsrRecordId=" + ucmAsrRecordId + ", " : "")
				+ (npi != null ? "npi=" + npi + ", " : "") + (subject != null ? "subject=" + subject + ", " : "")
				+ (ratingDate != null ? "ratingDate=" + ratingDate + ", " : "")
				+ (eventType != null ? "eventType=" + eventType + ", " : "") + (model != null ? "model=" + model : "")
				+ "]";
	}
	
}
