package gov.hhs.cms.fps.model;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

@JsonIgnoreProperties(ignoreUnknown = true)
@com.fasterxml.jackson.annotation.JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@org.codehaus.jackson.annotate.JsonAutoDetect(fieldVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.ANY, getterVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.NONE, setterVisibility = org.codehaus.jackson.annotate.JsonAutoDetect.Visibility.NONE)

public class UcmModelContributionModel implements Serializable {

	private String modelName;
	private String contribution;

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getContribution() {
		return contribution;
	}

	public void setContribution(String contribution) {
		this.contribution = contribution;
	}

	@Override
	public String toString() {
		return "UcmModelContributionModel [" + (modelName != null ? "modelName=" + modelName + ", " : "")
				+ (contribution != null ? "contribution=" + contribution : "") + "]";
	}
}
