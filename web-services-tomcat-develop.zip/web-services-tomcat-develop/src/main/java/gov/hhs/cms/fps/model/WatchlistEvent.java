package gov.hhs.cms.fps.model;

import java.util.ArrayList;
import java.util.List;

public class WatchlistEvent {

	private String userEmail;
	private List<String> models = new ArrayList<String>();
	private Double asrptRiskScreNum;
	private Integer asrptId;
	private String subjId;
	private List<AsrSummary> asrs;
	private String userId;

	private List<String> oldModels;
	
	
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public List<String> getModels() {
		return models;
	}
	public void setModels(List<String> models) {
		this.models = models;
	}
	public Double getAsrptRiskScreNum() {
		return asrptRiskScreNum;
	}
	public void setAsrptRiskScreNum(Double asrptRiskScreNum) {
		this.asrptRiskScreNum = asrptRiskScreNum;
	}
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	public List<AsrSummary> getAsrs() {
		return asrs;
	}
	public void setAsrs(List<AsrSummary> asrs) {
		this.asrs = asrs;
	}
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}

	public List<String> getOldModels() {
		return oldModels;
	}
	public void setOldModels(List<String> oldModels) {
		this.oldModels = oldModels;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

}
