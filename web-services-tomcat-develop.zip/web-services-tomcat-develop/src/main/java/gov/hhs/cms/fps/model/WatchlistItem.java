package gov.hhs.cms.fps.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import gov.hhs.cms.fps.util.FpsEnums.EntityType;
import gov.hhs.cms.fps.util.FpsEnums.EventType;

public abstract class WatchlistItem {

	@JsonIgnore
	public abstract EntityType getType();

	public abstract String getUserId();

	public abstract String getUserEmail();

	public abstract EventType getEventType();

	public abstract String getEventName();

	@JsonIgnore
	public abstract String getEmailSubject();

	public String id;
	public FpsEventNotification event;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd", timezone = "America/New_York")
	public Date createDt;
	@JsonIgnore
	private Integer subscriptionId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public static WatchlistItem parseInstance(WatchlistItem event) {
		switch (event.getEventType()) {
		case FOLLOWUP:
			return (FollowUpItem) event;
		case APS:
			return (ApsItem) event;
		case CUSTOMASR:
			return (CustomASRItem) event;
		default:
			return event;
		}
	}

	public static WatchlistItem getInstance(String event, String userId) {
		EventType type = EventType.valueOf(event);
		switch (type) {
		case FOLLOWUP:
			return new FollowUpItem(userId);
		case APS:
			return new ApsItem(userId);
		case CUSTOMASR:
			return new CustomASRItem(userId);
		default:
			return null;
		}
	}

	public static WatchlistItem getInstance(String event) {
		EventType type = EventType.valueOf(event);
		switch (type) {
		case FOLLOWUP:
			return new FollowUpItem();
		case APS:
			return new ApsItem();
		default:
			return null;
		}
	}

	public FpsEventNotification getEvent() {
		return event;
	}

	public void setEvent(FpsEventNotification event) {
		this.event = event;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public Integer getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(Integer subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

}
