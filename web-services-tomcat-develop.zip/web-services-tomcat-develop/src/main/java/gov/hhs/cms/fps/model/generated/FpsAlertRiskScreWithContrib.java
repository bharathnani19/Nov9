package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Subselect;
import org.hibernate.annotations.Where;
@Entity
//@Table(name="FPS_ALERT_RISK_SCRE_WITH_CONTRIB_MQT")
@Subselect(value = "select ASRPT_RISK_SCRE_UPDT_TS,asrpt_id, subj_id,asrpt_risk_scre_num, asr_risk_mthd_txt, model_id, model_busns_id, alert_id, alert_Creat_dt, ML_MODEL_ALERT_RISK_MTHD_TXT, ALERT_RISK_SCRE_NUM,ALERT_CONTRIBUTING_FACTOR_PCT " +
		"from fps2.FPS_ALERT_RISK_SCRE_WITH_CONTRIB_MQT a " +
		"where ASRPT_RISK_SCRE_UPDT_TS = ( " +
		"select max(ASRPT_RISK_SCRE_UPDT_TS) ASRPT_RISK_SCRE_UPDT_TS " +
		"from fps2.FPS_ALERT_RISK_SCRE_WITH_CONTRIB_MQT b where a.asrpt_id = b.asrpt_id and a.model_busns_id = b.model_busns_id ) ")
@Where(clause = " ML_MODEL_ALERT_RISK_MTHD_TXT = 'ENHANCED' ")
public class FpsAlertRiskScreWithContrib implements Serializable {

	private Integer asrptId;
	private String subjId;
	private BigDecimal riskScreNum;
	private Date riskScoreUpdateDt;
	private String riskScoreMthd;
	private Integer modelId;
	private String modelBusnsId;
	private Integer alertId;
	private Date alertCreatDt;
	private String alertRiskScoreMthd;
	private BigDecimal alertRiskScreNum;
	private BigDecimal alertContribPct;
	private FpsModel fpsModel;

	
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="SUBJ_ID")
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	@Column(name="ASRPT_RISK_SCRE_NUM")
	public BigDecimal getRiskScreNum() {
		return riskScreNum;
	}
	public void setRiskScreNum(BigDecimal riskScreNum) {
		this.riskScreNum = riskScreNum;
	}
	@Id
	@Column(name="ASRPT_RISK_SCRE_UPDT_TS")
	@Temporal(TemporalType.TIMESTAMP)

	public Date getRiskScoreUpdateDt() {
		return riskScoreUpdateDt;
	}
	public void setRiskScoreUpdateDt(Date riskScoreUpdateDt) {
		this.riskScoreUpdateDt = riskScoreUpdateDt;
	}
	@Column(name="ASR_RISK_MTHD_TXT")
	public String getRiskScoreMthd() {
		return riskScoreMthd;
	}
	public void setRiskScoreMthd(String riskScoreMthd) {
		this.riskScoreMthd = riskScoreMthd;
	}
	
	@Column(name="MODEL_ID")
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}
	@Id
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Column(name="ALERT_ID")
	public Integer getAlertId() {
		return alertId;
	}
	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}
	@Column(name="ALERT_CREAT_DT")
	@Temporal(TemporalType.DATE)

	public Date getAlertCreatDt() {
		return alertCreatDt;
	}
	public void setAlertCreatDt(Date alertCreatDt) {
		this.alertCreatDt = alertCreatDt;
	}
	@Column(name="ML_MODEL_ALERT_RISK_MTHD_TXT")
	public String getAlertRiskScoreMthd() {
		return alertRiskScoreMthd;
	}
	public void setAlertRiskScoreMthd(String alertRiskScoreMthd) {
		this.alertRiskScoreMthd = alertRiskScoreMthd;
	}
	@Column(name="ALERT_RISK_SCRE_NUM")
	public BigDecimal getAlertRiskScreNum() {
		return alertRiskScreNum;
	}
	public void setAlertRiskScreNum(BigDecimal alertRiskScreNum) {
		this.alertRiskScreNum = alertRiskScreNum;
	}
	@Column(name="ALERT_CONTRIBUTING_FACTOR_PCT")
	public BigDecimal getAlertContribPct() {
		return alertContribPct;
	}
	public void setAlertContribPct(BigDecimal alertContribPct) {
		this.alertContribPct = alertContribPct;
	}
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "MODEL_ID", updatable=false, insertable=false)
	public FpsModel getFpsModel() {
		return this.fpsModel;
	}

	public void setFpsModel(FpsModel fpsModel) {
		this.fpsModel = fpsModel;
	}
}
