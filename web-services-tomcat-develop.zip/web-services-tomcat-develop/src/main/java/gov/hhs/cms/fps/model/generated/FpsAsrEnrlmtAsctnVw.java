package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "FPS_ASR_ENRLMT_ASCTN_VW")
public class FpsAsrEnrlmtAsctnVw implements Serializable {

	private Integer asrptId;
	private String prvdrNpiNum;
	private String enrlmtId;
	private FpsAsrpt fpsAsrpt;

	@Id
	@Column(name = "ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}

	@Column(name = "PRVDR_NPI_NUM")
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}

	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}

	@Id
	@Column(name = "ENRLMT_ID")
	public String getEnrlmtId() {
		return enrlmtId;
	}

	public void setEnrlmtId(String enrlmtId) {
		this.enrlmtId = enrlmtId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable = false, insertable = false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}

	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
}
