package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
@Entity
@Table(name="FPS_ASRPT_APS_VW")
public class FpsAsrptApsVw implements Serializable {

	private Integer asrptId;
	private Integer identityId;
	private String subjId;
	private String businessName = "N/A";
	private String firstName = "N/A";
	private String lastName = "N/A";
	private String charge = "N/A";
	private Date chargeDate;
	private String chargeType = "N/A";
	private String county = "N/A";
	private String courtName = "N/A";
	private String courtJurisdiction = "N/A";
	private String crimSource = "N/A";
	private String disposition = "N/A";
	private Date dispositionDate;
	private Date incarcerationDate;
	private String sentence = "N/A";
	private Date sentenceDate;
	private String state = "N/A";
	private String ein = "N/A";
	private String offenseId;
	private Date updateDt;
	
	private FpsAsrpt fpsAsrpt;
	private FpsAsrptMdcd fpsAsrptMdcd;
	@Column(name="SUBJ_ID")

	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	@Column(name="BUSINESS_NAME")

	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	@Column(name="FIRST_NAME")

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Column(name="LAST_NAME")

	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Id
	@Column(name="CHARGE_DATE")

	public Date getChargeDate() {
		return chargeDate;
	}
	public void setChargeDate(Date chargeDate) {
		this.chargeDate = chargeDate;
	}
	@Column(name="CHARGE_TYPE")

	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	@Column(name="COUNTY")

	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	@Column(name="COURT_NAME")

	public String getCourtName() {
		return courtName;
	}
	public void setCourtName(String courtName) {
		this.courtName = courtName;
	}
	@Column(name="CRIM_SOURCE")

	public String getCrimSource() {
		return crimSource;
	}
	public void setCrimSource(String crimSource) {
		this.crimSource = crimSource;
	}
	@Column(name="DISPOSITION")

	public String getDisposition() {
		return disposition;
	}
	public void setDisposition(String disposition) {
		this.disposition = disposition;
	}
	@Column(name="DISPOSITION_DATE")

	public Date getDispositionDate() {
		return dispositionDate;
	}
	public void setDispositionDate(Date dispositionDate) {
		this.dispositionDate = dispositionDate;
	}
	@Column(name="INCARCERATION_DATE")

	public Date getIncarcerationDate() {
		return incarcerationDate;
	}
	public void setIncarcerationDate(Date incarcerationDate) {
		this.incarcerationDate = incarcerationDate;
	}
	@Column(name="SENTENCE")

	public String getSentence() {
		return sentence;
	}
	public void setSentence(String sentence) {
		this.sentence = sentence;
	}
	@Column(name="SENTENCE_DATE")

	public Date getSentenceDate() {
		return sentenceDate;
	}
	public void setSentenceDate(Date sentenceDate) {
		this.sentenceDate = sentenceDate;
	}
	@Column(name="STATE")
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Id
	@Column(name="IDENTITY_ID")
	public Integer getIdentityId() {
		return identityId;
	}
	public void setIdentityId(Integer identityId) {
		this.identityId = identityId;
	}
	@Column(name="ASRPT_ID")

	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Id
	@Column(name="CHARGE")

	public String getCharge() {
		return charge;
	}
	public void setCharge(String charge) {
		this.charge = charge;
	}
	@Column(name="COURT_JURISDICTION")

	public String getCourtJurisdiction() {
		return courtJurisdiction;
	}
	public void setCourtJurisdiction(String courtJurisdiction) {
		this.courtJurisdiction = courtJurisdiction;
	}
	@Column(name="EIN")

	public String getEin() {
		return ein;
	}
	public void setEin(String ein) {
		this.ein = ein;
	}
	@Fetch(FetchMode.JOIN)	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable = false, insertable = false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asrptId == null) ? 0 : asrptId.hashCode());
		result = prime * result + ((charge == null) ? 0 : charge.hashCode());
		result = prime * result + ((chargeDate == null) ? 0 : chargeDate.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsAsrptApsVw other = (FpsAsrptApsVw) obj;
		if (asrptId == null) {
			if (other.asrptId != null)
				return false;
		} else if (!asrptId.equals(other.asrptId))
			return false;
		if (charge == null) {
			if (other.charge != null)
				return false;
		} else if (!charge.equals(other.charge))
			return false;
		if (chargeDate == null) {
			if (other.chargeDate != null)
				return false;
		} else if (!chargeDate.equals(other.chargeDate))
			return false;
		return true;
	}
	@Column(name="OFFENSE_UNIQUE_ID")
	public String getOffenseId() {
		return offenseId;
	}
	public void setOffenseId(String offenseId) {
		this.offenseId = offenseId;
	}
	@Column(name="UPDATED_DATE")
	public Date getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", insertable=false, updatable=false)
	public FpsAsrptMdcd getFpsAsrptMdcd() {
		return fpsAsrptMdcd;
	}

	public void setFpsAsrptMdcd(FpsAsrptMdcd fpsAsrptMdcd) {
		this.fpsAsrptMdcd = fpsAsrptMdcd;
	}
}
