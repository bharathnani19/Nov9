package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "FPS_ASRPT_CLM_ENRLMT_ID_VW")
public class FpsAsrptClmEnrlmtIdVw implements Serializable {

	private Integer asrptId;
	private String prvdrNpiNum;
	private String enrlmtId;
	private String stusCd;
	private String stusDesc;
	private String role;
	private FpsAsrpt fpsAsrpt;

	@Id
	@Column(name = "ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}

	@Column(name = "PRVDR_NPI_NUM")
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}

	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}

	@Id
	@Column(name = "ENRLMT_ID")
	public String getEnrlmtId() {
		return enrlmtId;
	}

	public void setEnrlmtId(String enrlmtId) {
		this.enrlmtId = enrlmtId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable = false, insertable = false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}

	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}

	@Column(name = "STUS_CD")
	public String getStusCd() {
		return stusCd;
	}

	public void setStusCd(String stusCd) {
		this.stusCd = stusCd;
	}

	@Column(name = "STUS_DESC")
	public String getStusDesc() {
		return stusDesc;
	}

	public void setStusDesc(String stusDesc) {
		this.stusDesc = stusDesc;
	}

	@Column(name = "ROLE")
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
