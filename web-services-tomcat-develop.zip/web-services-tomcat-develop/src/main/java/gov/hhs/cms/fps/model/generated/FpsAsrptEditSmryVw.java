package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "fps_asrpt_edit_smry_vw")
public class FpsAsrptEditSmryVw implements Serializable {

	private int asrptId;
	private String modelName;
	private String npiNum;
	private Integer editId;
	private FpsAsrpt fpsAsrpt;

	@Column(name = "ASRPT_ID")
	@Id
	public int getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}

	@Column(name = "MODEL_NAME")
	@Id
	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	@Column(name = "NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}

	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable = false, insertable = false)
	public FpsAsrpt getFpsAsrpt() {
		return this.fpsAsrpt;
	}

	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}

	@Column(name="FPS_PRE_PYMT_DNL_ID")
	public Integer getEditId() {
		return editId;
	}

	public void setEditId(Integer editId) {
		this.editId = editId;
	}

}
