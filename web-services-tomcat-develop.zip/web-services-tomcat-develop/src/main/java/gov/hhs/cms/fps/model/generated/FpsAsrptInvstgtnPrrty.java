package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="FPS_ASRPT_INVSTGTN_PRRTY")
public class FpsAsrptInvstgtnPrrty implements Serializable {
	private FpsAsrptInvstgtn fpsAsrptInvstgtn;
	private Integer asrptInvstgtnPrrtyId;
	private Integer asrptInvstgtnId;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String extrnlPrrtyId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_INVSTGTN_ID", updatable = false, insertable = false)
	public FpsAsrptInvstgtn getFpsAsrptInvstgtn() {
		return fpsAsrptInvstgtn;
	}
	public void setFpsAsrptInvstgtn(FpsAsrptInvstgtn fpsAsrptInvstgtn) {
		this.fpsAsrptInvstgtn = fpsAsrptInvstgtn;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ASRPT_INVSTGTN_PRRTY_ID")
	public Integer getAsrptInvstgtnPrrtyId() {
		return asrptInvstgtnPrrtyId;
	}
	public void setAsrptInvstgtnPrrtyId(Integer asrptInvstgtnPrrtyId) {
		this.asrptInvstgtnPrrtyId = asrptInvstgtnPrrtyId;
	}
	@Column(name="ASRPT_INVSTGTN_ID")
	public Integer getAsrptInvstgtnId() {
		return asrptInvstgtnId;
	}
	public void setAsrptInvstgtnId(Integer asrptInvstgtnId) {
		this.asrptInvstgtnId = asrptInvstgtnId;
	}
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="EXTRNL_PRRTY_ID")
//	@Transient
	public String getExtrnlPrrtyId() {
		return extrnlPrrtyId;
	}
	public void setExtrnlPrrtyId(String extrnlPrrtyId) {
		this.extrnlPrrtyId = extrnlPrrtyId;
	}
	
}
