package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vw_fps_asrpt_list_user_jrsdctn_dtl")
public class FpsAsrptListUserJrsdctnDtlVw implements Serializable {

	private Integer asrptId;
	private String wsUserId;
	private String wsMyJrsdctn;
	private String exUserId;
	private String exMyJrsdctn;
	private String publicInd;
	private String exItemActvInd;
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Id
	@Column(name="WS_USER_ID")
	public String getWsUserId() {
		return wsUserId;
	}
	public void setWsUserId(String wsUserId) {
		this.wsUserId = wsUserId;
	}
	@Id
	@Column(name="WS_MY_JRSDCTN")
	public String getWsMyJrsdctn() {
		return wsMyJrsdctn;
	}
	public void setWsMyJrsdctn(String wsMyJrsdctn) {
		this.wsMyJrsdctn = wsMyJrsdctn;
	}
	@Id
	@Column(name="EX_USER_ID")
	public String getExUserId() {
		return exUserId;
	}
	public void setExUserId(String exUserId) {
		this.exUserId = exUserId;
	}
	@Id
	@Column(name="EX_MY_JRSDCTN")
	public String getExMyJrsdctn() {
		return exMyJrsdctn;
	}
	public void setExMyJrsdctn(String exMyJrsdctn) {
		this.exMyJrsdctn = exMyJrsdctn;
	}
	@Id
	@Column(name="EXCLSN_PUBLIC_IND")
	public String getPublicInd() {
		return publicInd;
	}
	public void setPublicInd(String publicInd) {
		this.publicInd = publicInd;
	}
	@Id
	@Column(name="EX_ITEM_ACTV_IND")
	public String getExItemActvInd() {
		return exItemActvInd;
	}
	public void setExItemActvInd(String exItemActvInd) {
		this.exItemActvInd = exItemActvInd;
	}
}
