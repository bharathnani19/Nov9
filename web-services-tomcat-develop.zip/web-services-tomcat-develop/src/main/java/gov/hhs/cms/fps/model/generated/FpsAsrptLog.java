package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "FPS_ASRPT_LOG")
@BatchSize(size = 100)
public class FpsAsrptLog implements Serializable {
	private int asrptLogId;
	private Double asrptRiskScre;
	private Date asrptLogDt;
	private String asrptDesc;
	private String actvtyActnInd;
	private BigDecimal actvtyActnCnt;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private Integer asrptInvstgtnId;
	private String asrptCmt;
	private String fpsVrsnInd;
	private String lgcyAsrptLoid;
	private String aplctnUserId;
	private FpsAsrpt fpsAsrpt;
	private int asrptId;

	public FpsAsrptLog() {
	}

	public FpsAsrptLog(int asrptLogId, String audtInsrtId, Date audtInsrtTs) {
		this.asrptLogId = asrptLogId;
		this.audtInsrtId = audtInsrtId;
		this.audtInsrtTs = audtInsrtTs;
	}

	public FpsAsrptLog(int asrptLogId, Integer asrptId, Double asrptRiskScre, Date asrptLogDt, String asrptDesc,
			String actvtyActnInd, BigDecimal actvtyActnCnt, String audtInsrtId, Date audtInsrtTs,
			Integer asrptInvstgtnId, String asrptCmt, String fpsVrsnInd) {
		this.asrptLogId = asrptLogId;
		this.asrptRiskScre = asrptRiskScre;
		this.asrptLogDt = asrptLogDt;
		this.asrptDesc = asrptDesc;
		this.actvtyActnInd = actvtyActnInd;
		this.actvtyActnCnt = actvtyActnCnt;
		this.audtInsrtId = audtInsrtId;
		this.audtInsrtTs = audtInsrtTs;
		this.asrptInvstgtnId = asrptInvstgtnId;
		this.asrptCmt = asrptCmt;
		this.fpsVrsnInd = fpsVrsnInd;
	}

	@Id
//  @GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(generator = "FpsAsrptLog_SEQ")
	@SequenceGenerator(name = "FpsAsrptLog_SEQ", sequenceName = "fps2.fps_asrpt_log_asrpt_log_id_seq", allocationSize = 20)

	@Column(name = "ASRPT_LOG_ID", unique = true, nullable = false)
	public int getAsrptLogId() {
		return this.asrptLogId;
	}

	public void setAsrptLogId(int asrptLogId) {
		this.asrptLogId = asrptLogId;
	}

	@Column(name = "ASRPT_RISK_SCRE", precision = 53, scale = 0)
	public Double getAsrptRiskScre() {
		return this.asrptRiskScre;
	}

	public void setAsrptRiskScre(Double asrptRiskScre) {
		this.asrptRiskScre = asrptRiskScre;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ASRPT_LOG_TS", length = 10)
	public Date getAsrptLogDt() {
		return this.asrptLogDt;
	}

	public void setAsrptLogDt(Date asrptLogDt) {
		this.asrptLogDt = asrptLogDt;
	}

	@Column(name = "ASRPT_DESC", length = 2000)
	public String getAsrptDesc() {
		return this.asrptDesc;
	}

	public void setAsrptDesc(String asrptDesc) {
		this.asrptDesc = asrptDesc;
	}

	@Column(name = "ACTVTY_ACTN_IND", length = 1)
	public String getActvtyActnInd() {
		return this.actvtyActnInd;
	}

	public void setActvtyActnInd(String actvtyActnInd) {
		this.actvtyActnInd = actvtyActnInd;
	}

	@Column(name = "ACTVTY_ACTN_CNT", precision = 10, scale = 0)
	public BigDecimal getActvtyActnCnt() {
		return this.actvtyActnCnt;
	}

	public void setActvtyActnCnt(BigDecimal actvtyActnCnt) {
		this.actvtyActnCnt = actvtyActnCnt;
	}

	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "ASRPT_INVSTGTN_ID")
	public Integer getAsrptInvstgtnId() {
		return this.asrptInvstgtnId;
	}

	public void setAsrptInvstgtnId(Integer asrptInvstgtnId) {
		this.asrptInvstgtnId = asrptInvstgtnId;
	}

	@Column(name = "ASRPT_CMT")
	@Lob
	@Type(type = "org.hibernate.type.TextType")
	public String getAsrptCmt() {
		return this.asrptCmt;
	}

	public void setAsrptCmt(String asrptCmt) {
		this.asrptCmt = asrptCmt;
	}

	@Column(name = "FPS_VRSN_IND", length = 1)
	public String getFpsVrsnInd() {
		return this.fpsVrsnInd;
	}

	public void setFpsVrsnInd(String fpsVrsnInd) {
		this.fpsVrsnInd = fpsVrsnInd;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable = false, insertable = false)
	public FpsAsrpt getFpsAsrpt() {
		return this.fpsAsrpt;
	}

	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}

	@Column(name = "LGCY_ASRPT_LOID")
	public String getLgcyAsrptLoid() {
		return this.lgcyAsrptLoid;
	}

	public void setLgcyAsrptLoid(String lgcyAsrptLoid) {
		this.lgcyAsrptLoid = lgcyAsrptLoid;
	}

	@Column(name = "APLCTN_USER_ID")
	public String getAplctnUserId() {
		return this.aplctnUserId;
	}

	public void setAplctnUserId(String aplctnUserId) {
		this.aplctnUserId = aplctnUserId;
	}

	@Column(name = "ASRPT_ID")
	public int getAsrptId() {
		return this.asrptId;
	}

	public void setAsrptId(int asrptId) {
		this.asrptId = asrptId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(aplctnUserId, asrptCmt, asrptId, asrptLogDt, asrptRiskScre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsAsrptLog other = (FpsAsrptLog) obj;
		return Objects.equals(aplctnUserId, other.aplctnUserId) && Objects.equals(asrptCmt, other.asrptCmt)
				&& asrptId == other.asrptId && Objects.equals(asrptLogDt, other.asrptLogDt)
				&& Objects.equals(asrptRiskScre, other.asrptRiskScre);
	}
}
