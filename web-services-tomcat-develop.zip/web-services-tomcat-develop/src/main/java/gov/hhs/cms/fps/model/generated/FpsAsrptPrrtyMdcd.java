package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name="FPS_ASRPT_PRRTY_MDCD")
public class FpsAsrptPrrtyMdcd implements Serializable {

	private Integer asrptPrrtyId;
	private Integer asrptId;
	private FpsAsrptMdcd fpsAsrpt;
	private String cntrctrCd;
	private String userId;
	private Date prrtyDfndDt;
	private Date audtInsrtTs;
	private Date audtUpdtTs;
	private String audtInsrtId;
	private String audtUpdtId;
	private String asrptPrrtyRsnDesc;
	private FpsCntrctrRfrnc fpsCntrctrRfrnc;
	private String cmsPriorityAsrInd;
	private String extrnlPrrtyId;
	private String stateCd;
	private Set<FpsAsrptPrrtyModelMdcd> fpsAsrptPrrtyModels;
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ASRPT_PRRTY_MDCD_ID")
	public Integer getAsrptPrrtyId() {
		return asrptPrrtyId;
	}
	public void setAsrptPrrtyId(Integer asrptPrrtyId) {
		this.asrptPrrtyId = asrptPrrtyId;
	}
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID", updatable=false, insertable=false)
	
	public FpsAsrptMdcd getFpsAsrpt() {
		return fpsAsrpt;
	}
	public void setFpsAsrpt(FpsAsrptMdcd fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}
	@Column(name="CNTRCTR_CD")
	public String getCntrctrCd() {
		return cntrctrCd;
	}
	public void setCntrctrCd(String cntrctrCd) {
		this.cntrctrCd = cntrctrCd;
	}
	@Column(name="USER_ID")
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	@Column(name="PRRTY_DFND_TS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getPrrtyDfndDt() {
		return prrtyDfndDt;
	}
	public void setPrrtyDfndDt(Date prrtyDfndDt) {
		this.prrtyDfndDt = prrtyDfndDt;
	}
	@Column(name="AUDT_INSRT_TS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="AUDT_UPDT_TS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name="AUDT_UPDT_ID")
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Column(name="ASRPT_PRRTY_RSN_DESC", length=3000)
	public String getAsrptPrrtyRsnDesc() {
		return asrptPrrtyRsnDesc;
	}
	public void setAsrptPrrtyRsnDesc(String asrptPrrtyRsnDesc) {
		this.asrptPrrtyRsnDesc = asrptPrrtyRsnDesc;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRCTR_CD", referencedColumnName="CNTRCTR_CD", updatable=false, insertable=false)
	@NotFound(action=NotFoundAction.IGNORE)
	@BatchSize(size=500)
	public FpsCntrctrRfrnc getFpsCntrctrRfrnc() {
		return this.fpsCntrctrRfrnc;
	}

	public void setFpsCntrctrRfrnc(FpsCntrctrRfrnc fpsCntrctrRfrnc) {
		this.fpsCntrctrRfrnc = fpsCntrctrRfrnc;
	}
	@Column(name="CMS_PRRTY_ASR_IND")
//	@Transient
	public String getCmsPriorityAsrInd() {
		return cmsPriorityAsrInd;
	}
	public void setCmsPriorityAsrInd(String cmsPriorityAsrInd) {
		this.cmsPriorityAsrInd = cmsPriorityAsrInd;
	}
	
	@Column(name="EXTRNL_PRRTY_ID")
//	@Transient
	public String getExtrnlPrrtyId() {
		return extrnlPrrtyId;
	}
	public void setExtrnlPrrtyId(String extrnlPrrtyId) {
		this.extrnlPrrtyId = extrnlPrrtyId;
	}
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsAsrptPrrty")
	@BatchSize(size = 500)
	public Set<FpsAsrptPrrtyModelMdcd> getFpsAsrptPrrtyModels() {
		return fpsAsrptPrrtyModels;
	}
	public void setFpsAsrptPrrtyModels(Set<FpsAsrptPrrtyModelMdcd> fpsAsrptPrrtyModels) {
		this.fpsAsrptPrrtyModels = fpsAsrptPrrtyModels;
	}
	@Column(name="STATE_CD")
	public String getStateCd() {
		return stateCd;
	}
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
}
