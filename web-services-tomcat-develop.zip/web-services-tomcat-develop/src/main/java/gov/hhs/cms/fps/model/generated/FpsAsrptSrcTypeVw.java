package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="FPS_ASRPT_SMRY_VSBLTY_VW")
public class FpsAsrptSrcTypeVw implements Serializable {

	private Integer asrptId;
	private String summaryVisibleInd;
	
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="ASR_TYPE")
	public String getSummaryVisibleInd() {
		return summaryVisibleInd;
	}
	public void setSummaryVisibleInd(String summaryVisibleInd) {
		this.summaryVisibleInd = summaryVisibleInd;
	}
}
