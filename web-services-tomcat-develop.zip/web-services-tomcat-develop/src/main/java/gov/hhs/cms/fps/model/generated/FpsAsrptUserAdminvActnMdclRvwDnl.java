package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="FPS_ASRPT_USER_ADMINV_ACTN_MDCL_RVW_DNL")
public class FpsAsrptUserAdminvActnMdclRvwDnl implements Serializable {
	private Integer asrptUserAdminvActnMdclRvwDnlId;
	private FpsAsrptUserAdminvActnMdclRvw fpsAsrptUserAdminvActnMdclRvw;
	private String denialType;
	private String denialDesc;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private String recChgInd;
	
	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_mdcl_rvw_dnl_id_seq",  sequenceName = "asrpt_user_adminv_actn_mdcl_rvw_dnl_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_mdcl_rvw_dnl_id_seq")	
	@Column(name = "ASRPT_USER_ADMINV_ACTN_MDCL_RVW_DNL_ID", unique = true, nullable = false)
	public Integer getAsrptUserAdminvActnMdclRvwDnlId() {
		return asrptUserAdminvActnMdclRvwDnlId;
	}
	public void setAsrptUserAdminvActnMdclRvwDnlId(Integer asrptUserAdminvActnMdclRvwDnlId) {
		this.asrptUserAdminvActnMdclRvwDnlId = asrptUserAdminvActnMdclRvwDnlId;
	}
	

	@Column(name="DNL_TYPE")
	public String getDenialType() {
		return denialType;
	}
	public void setDenialType(String denialType) {
		this.denialType = denialType;
	}
	@Column(name="DNL_DESC")
	public String getDenialDesc() {
		return denialDesc;
	}
	public void setDenialDesc(String denialDesc) {
		this.denialDesc = denialDesc;
	}
	
	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	@Column(name = "REC_CHG_IND", length = 1)
	public String getRecChgInd() {
		return this.recChgInd;
	}

	public void setRecChgInd(String recChgInd) {
		this.recChgInd = recChgInd;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_MDCL_RVW_ID")
	public FpsAsrptUserAdminvActnMdclRvw getFpsAsrptUserAdminvActnMdclRvw() {
		return fpsAsrptUserAdminvActnMdclRvw;
	}
	public void setFpsAsrptUserAdminvActnMdclRvw(FpsAsrptUserAdminvActnMdclRvw fpsAsrptUserAdminvActnMdclRvw) {
		this.fpsAsrptUserAdminvActnMdclRvw = fpsAsrptUserAdminvActnMdclRvw;
	}
}
