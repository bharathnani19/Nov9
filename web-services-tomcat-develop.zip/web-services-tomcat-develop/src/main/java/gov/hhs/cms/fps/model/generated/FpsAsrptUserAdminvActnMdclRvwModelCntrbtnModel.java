package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="FPS_ASRPT_USER_ADMINV_ACTN_MDCL_RVW_MODEL_CNTRBTN_MODEL")
public class FpsAsrptUserAdminvActnMdclRvwModelCntrbtnModel implements Serializable {

	private Integer asrptUserAdminvActnMdclRvwModelCntrbtnModelId;
	private FpsAsrptUserAdminvActnMdclRvwModelCntrbtn fpsAsrptUserAdminvActnMdclRvwModelCntrbtn;
	private String modelBusnsId;
	private String cntrbtnDesc;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private String recChgInd;
	
	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_mdcl_rvw_model_cntrbtn_model_id_seq",  sequenceName = "asrpt_user_adminv_actn_mdcl_rvw_model_cntrbtn_model_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_mdcl_rvw_model_cntrbtn_model_id_seq")
	@Column(name = "ASRPT_USER_ADMINV_ACTN_MDCL_RVW_MODEL_CNTRBTN_MODEL_ID", unique = true, nullable = false)
	public Integer getAsrptUserAdminvActnMdclRvwModelCntrbtnModelId() {
		return asrptUserAdminvActnMdclRvwModelCntrbtnModelId;
	}
	public void setAsrptUserAdminvActnMdclRvwModelCntrbtnModelId(Integer asrptUserAdminvActnMdclRvwModelCntrbtnModelId) {
		this.asrptUserAdminvActnMdclRvwModelCntrbtnModelId = asrptUserAdminvActnMdclRvwModelCntrbtnModelId;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_MDCL_RVW_MODEL_CNTRBTN_ID")
	public FpsAsrptUserAdminvActnMdclRvwModelCntrbtn getFpsAsrptUserAdminvActnMdclRvwModelCntrbtn() {
		return fpsAsrptUserAdminvActnMdclRvwModelCntrbtn;
	}
	public void setFpsAsrptUserAdminvActnMdclRvwModelCntrbtn(
			FpsAsrptUserAdminvActnMdclRvwModelCntrbtn fpsAsrptUserAdminvActnMdclRvwModelCntrbtn) {
		this.fpsAsrptUserAdminvActnMdclRvwModelCntrbtn = fpsAsrptUserAdminvActnMdclRvwModelCntrbtn;
	}
	@Column(name = "MODEL_BUSNS_ID", nullable = false, length = 128)

	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Column(name = "CNTRBTN_DESC", nullable = false, length = 128)

	public String getCntrbtnDesc() {
		return cntrbtnDesc;
	}
	public void setCntrbtnDesc(String cntrbtnDesc) {
		this.cntrbtnDesc = cntrbtnDesc;
	}


	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	@Column(name = "REC_CHG_IND", length = 1)
	public String getRecChgInd() {
		return this.recChgInd;
	}

	public void setRecChgInd(String recChgInd) {
		this.recChgInd = recChgInd;
	}
	
	
}
