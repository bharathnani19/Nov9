package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "FPS_ASRPT_USER_ADMINV_ACTN_OVRPYMT_DTL")
@BatchSize(size = 100)
public class FpsAsrptUserAdminvActnOvrPmnt implements Serializable {
	private Integer asrptUserAdminvActnOvrpmntId;
	// overpayment
	private String financeType;
	private Date determinationDate;
	private BigDecimal originalOverpaymentAmount;
	private BigDecimal revisedOverpaymentAmount;
	private BigDecimal federalShareAmount;
	private BigDecimal revisedFederalShare;
	private BigDecimal demandedAmount;
	private BigDecimal recoveredAmount;
	private BigDecimal nonCollectibleAmount;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private Date claimPaidFromDate;
	private Date claimPaidEndDate;

	private FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn;
	private Set<FpsAsrptUserAdminvActnOvrPmntClm> fpsAsrptUserAdminvActnOvrPmntClms;


	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_ID")
	public FpsAsrptUserAdminvActn getFpsAsrptUserAdminvActn() {
		return fpsAsrptUserAdminvActn;
	}

	public void setFpsAsrptUserAdminvActn(FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn) {
		this.fpsAsrptUserAdminvActn = fpsAsrptUserAdminvActn;
	}

	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_ovrpymt_dtl_id_seq",  sequenceName = "asrpt_user_adminv_actn_ovrpymt_dtl_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_ovrpymt_dtl_id_seq")
	@Column(name = "ASRPT_USER_ADMINV_ACTN_OVRPYMT_DTL_ID")

	public Integer getAsrptUserAdminvActnOvrpmntId() {
		return asrptUserAdminvActnOvrpmntId;
	}

	public void setAsrptUserAdminvActnOvrpmntId(Integer asrptUserAdminvActnOvrpmntId) {
		this.asrptUserAdminvActnOvrpmntId = asrptUserAdminvActnOvrpmntId;
	}

	@Column(name = "FIN_TYPE")

	public String getFinanceType() {
		return financeType;
	}

	public void setFinanceType(String financeType) {
		this.financeType = financeType;
	}

	@Column(name = "DTRMNTN_DT")

	public Date getDeterminationDate() {
		return determinationDate;
	}

	public void setDeterminationDate(Date determinationDate) {
		this.determinationDate = determinationDate;
	}

	@Column(name = "ORGNL_OVRPMT_AMT")

	public BigDecimal getOriginalOverpaymentAmount() {
		return originalOverpaymentAmount;
	}

	public void setOriginalOverpaymentAmount(BigDecimal originalOverpaymentAmount) {
		this.originalOverpaymentAmount = originalOverpaymentAmount;
	}

	@Column(name = "RVSD_OVRPMT_AMT")

	public BigDecimal getRevisedOverpaymentAmount() {
		return revisedOverpaymentAmount;
	}

	public void setRevisedOverpaymentAmount(BigDecimal revisedOverpaymentAmount) {
		this.revisedOverpaymentAmount = revisedOverpaymentAmount;
	}

	@Column(name = "FED_SHR_AMT")

	public BigDecimal getFederalShareAmount() {
		return federalShareAmount;
	}

	public void setFederalShareAmount(BigDecimal federalShareAmount) {
		this.federalShareAmount = federalShareAmount;
	}

	@Column(name = "RVSD_FED_SHR_AMT")

	public BigDecimal getRevisedFederalShare() {
		return revisedFederalShare;
	}

	public void setRevisedFederalShare(BigDecimal revisedFederalShare) {
		this.revisedFederalShare = revisedFederalShare;
	}

	@Column(name = "DMNDD_AMT")

	public BigDecimal getDemandedAmount() {
		return demandedAmount;
	}

	public void setDemandedAmount(BigDecimal demandedAmount) {
		this.demandedAmount = demandedAmount;
	}

	@Column(name = "RCVRD_AMT")

	public BigDecimal getRecoveredAmount() {
		return recoveredAmount;
	}

	public void setRecoveredAmount(BigDecimal recoveredAmount) {
		this.recoveredAmount = recoveredAmount;
	}

	@Column(name = "UNCLCLTBL_AMT")

	public BigDecimal getNonCollectibleAmount() {
		return nonCollectibleAmount;
	}

	public void setNonCollectibleAmount(BigDecimal nonCollectibleAmount) {
		this.nonCollectibleAmount = nonCollectibleAmount;
	}
	@Fetch(FetchMode.SELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsAsrptUserAdminvActnOvrPmnt", cascade = CascadeType.ALL)
	@BatchSize(size=1000)
	@NotFound(action = NotFoundAction.IGNORE)
	public Set<FpsAsrptUserAdminvActnOvrPmntClm> getFpsAsrptUserAdminvActnOvrPmntClms() {
		return fpsAsrptUserAdminvActnOvrPmntClms;
	}

	public void setFpsAsrptUserAdminvActnOvrPmntClms(Set<FpsAsrptUserAdminvActnOvrPmntClm> fpsAsrptUserAdminvActnOvrPmntClms) {
		this.fpsAsrptUserAdminvActnOvrPmntClms = fpsAsrptUserAdminvActnOvrPmntClms;
	}
	@Column(name="CLM_PD_FROM_DT")
	public Date getClaimPaidFromDate() {
		return claimPaidFromDate;
	}

	public void setClaimPaidFromDate(Date claimPaidFromDate) {
		this.claimPaidFromDate = claimPaidFromDate;
	}
	@Column(name="CLM_PD_END_DT")

	public Date getClaimPaidEndDate() {
		return claimPaidEndDate;
	}

	public void setClaimPaidEndDate(Date claimPaidEndDate) {
		this.claimPaidEndDate = claimPaidEndDate;
	}
}
