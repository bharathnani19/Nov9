package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="FPS_ASRPT_USER_ADMINV_ACTN_PRRTY")
public class FpsAsrptUserAdminvActnPrrty implements Serializable {

	private FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn;
	private Integer asrptUserAdminvActnId;
	private Integer asrptUserAdminvActnPrrtyId;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String extrnlPrrtyId;
	
	
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="EXTRNL_PRRTY_ID")
//	@Transient
	public String getExtrnlPrrtyId() {
		return extrnlPrrtyId;
	}
	public void setExtrnlPrrtyId(String extrnlPrrtyId) {
		this.extrnlPrrtyId = extrnlPrrtyId;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_ID", updatable = false, insertable = false)
	public FpsAsrptUserAdminvActn getFpsAsrptUserAdminvActn() {
		return fpsAsrptUserAdminvActn;
	}
	public void setFpsAsrptUserAdminvActn(FpsAsrptUserAdminvActn fpsAsrptUserAdminvActn) {
		this.fpsAsrptUserAdminvActn = fpsAsrptUserAdminvActn;
	}
	@Column(name="ASRPT_USER_ADMINV_ACTN_ID")
	public Integer getAsrptUserAdminvActnId() {
		return asrptUserAdminvActnId;
	}
	public void setAsrptUserAdminvActnId(Integer asrptUserAdminvActnId) {
		this.asrptUserAdminvActnId = asrptUserAdminvActnId;
	}
	@Id
	@Column(name="ASRPT_USER_ADMINV_ACTN_PRRTY_ID")
	@SequenceGenerator(name="asrpt_user_adminv_actn_prrty_id_seq",  sequenceName = "asrpt_user_adminv_actn_prrty_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_prrty_id_seq")
	public Integer getAsrptUserAdminvActnPrrtyId() {
		return asrptUserAdminvActnPrrtyId;
	}
	public void setAsrptUserAdminvActnPrrtyId(Integer asrptUserAdminvActnPrrtyId) {
		this.asrptUserAdminvActnPrrtyId = asrptUserAdminvActnPrrtyId;
	}
}