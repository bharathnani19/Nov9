package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="FPS_ASRPT_USER_ADMINV_ACTN_RFI_SUBJ")
public class FpsAsrptUserAdminvActnRfiSubj implements Serializable {

	private Integer asrptUserAdminvActnRfiSubjId;
	private FpsAsrptUserAdminvActnRfiDtl fpsAsrptUserAdminvActnRfiDtl;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private String recChgInd;
	private String orderNum;
	private String subjType;
	private String prvdrDataUpdtdInd;
	private String npiNum;
	private String tinNum;
	private String mdclId;
	private String enrlmntStus;
	private String enrlmntId;
	private String enrlmntType;
	private String oscarNum;
	private String suplrNum;
	private String rrlAreaDrInd;
	private String vctmInd;
	private String subjChainAfltnInd;
	private String spcltyCds;
	private String mbiNum;
	private String dualElgblInd;
	private String cncInd;
	private String cncRiskCd;
	private Date cncRiskDt;
	
	@Id
	@SequenceGenerator(name="asrpt_user_adminv_actn_rfi_subj_id_seq",  sequenceName = "asrpt_user_adminv_actn_rfi_subj_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "asrpt_user_adminv_actn_rfi_subj_id_seq")	
	@Column(name="ASRPT_USER_ADMINV_ACTN_RFI_SUBJ_ID")
	public Integer getAsrptUserAdminvActnRfiSubjId() {
		return asrptUserAdminvActnRfiSubjId;
	}
	public void setAsrptUserAdminvActnRfiSubjId(Integer asrptUserAdminvActnRfiSubjId) {
		this.asrptUserAdminvActnRfiSubjId = asrptUserAdminvActnRfiSubjId;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_USER_ADMINV_ACTN_RFI_DTL_ID")
	public FpsAsrptUserAdminvActnRfiDtl getFpsAsrptUserAdminvActnRfiDtl() {
		return fpsAsrptUserAdminvActnRfiDtl;
	}
	public void setFpsAsrptUserAdminvActnRfiDtl(FpsAsrptUserAdminvActnRfiDtl fpsAsrptUserAdminvActnRfiDtl) {
		this.fpsAsrptUserAdminvActnRfiDtl = fpsAsrptUserAdminvActnRfiDtl;
	}
	@Column(name="AUDT_INSRT_ID")
	public String getAudtInsrtId() {
		return audtInsrtId;
	}
	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="AUDT_INSRT_TS")
	public Date getAudtInsrtTs() {
		return audtInsrtTs;
	}
	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}
	@Column(name="AUDT_UPDT_ID")
	public String getAudtUpdtId() {
		return audtUpdtId;
	}
	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="AUDT_UPDT_TS")
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	@Column(name="REC_CHG_IND")
	public String getRecChgInd() {
		return recChgInd;
	}
	public void setRecChgInd(String recChgInd) {
		this.recChgInd = recChgInd;
	}
	@Column(name="ORDR_NUM")
	public String getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	@Column(name="SUBJ_TYPE")
	public String getSubjType() {
		return subjType;
	}
	public void setSubjType(String subjType) {
		this.subjType = subjType;
	}
	@Column(name="PRVDR_DATA_UPDTD_IND")
	public String getPrvdrDataUpdtdInd() {
		return prvdrDataUpdtdInd;
	}
	public void setPrvdrDataUpdtdInd(String prvdrDataUpdtdInd) {
		this.prvdrDataUpdtdInd = prvdrDataUpdtdInd;
	}
	@Column(name="NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	@Column(name="TIN_NUM")
	public String getTinNum() {
		return tinNum;
	}
	public void setTinNum(String tinNum) {
		this.tinNum = tinNum;
	}
	@Column(name="MDCL_ID")
	public String getMdclId() {
		return mdclId;
	}
	public void setMdclId(String mdclId) {
		this.mdclId = mdclId;
	}
	@Column(name="ENRLMNT_STUS")
	public String getEnrlmntStus() {
		return enrlmntStus;
	}
	public void setEnrlmntStus(String enrlmntStus) {
		this.enrlmntStus = enrlmntStus;
	}
	@Column(name="ENRLMNT_ID")
	public String getEnrlmntId() {
		return enrlmntId;
	}
	public void setEnrlmntId(String enrlmntId) {
		this.enrlmntId = enrlmntId;
	}
	@Column(name="ENRLMNT_TYPE")
	public String getEnrlmntType() {
		return enrlmntType;
	}
	public void setEnrlmntType(String enrlmntType) {
		this.enrlmntType = enrlmntType;
	}
	@Column(name="OSCAR_NUM")
	public String getOscarNum() {
		return oscarNum;
	}
	public void setOscarNum(String oscarNum) {
		this.oscarNum = oscarNum;
	}
	@Column(name="SUPLR_NUM")
	public String getSuplrNum() {
		return suplrNum;
	}
	public void setSuplrNum(String suplrNum) {
		this.suplrNum = suplrNum;
	}
	@Column(name="RRL_AREA_DR_IND")
	public String getRrlAreaDrInd() {
		return rrlAreaDrInd;
	}
	public void setRrlAreaDrInd(String rrlAreaDrInd) {
		this.rrlAreaDrInd = rrlAreaDrInd;
	}
	@Column(name="VCTM_IND")
	public String getVctmInd() {
		return vctmInd;
	}
	public void setVctmInd(String vctmInd) {
		this.vctmInd = vctmInd;
	}
	@Column(name="SUBJ_CHAIN_AFLTN_IND")
	public String getSubjChainAfltnInd() {
		return subjChainAfltnInd;
	}
	public void setSubjChainAfltnInd(String subjChainAfltnInd) {
		this.subjChainAfltnInd = subjChainAfltnInd;
	}
	@Column(name="SPCLTY_CDS")
	public String getSpcltyCds() {
		return spcltyCds;
	}
	public void setSpcltyCds(String spcltyCds) {
		this.spcltyCds = spcltyCds;
	}
	@Column(name="MBI_NUM")
	public String getMbiNum() {
		return mbiNum;
	}
	public void setMbiNum(String mbiNum) {
		this.mbiNum = mbiNum;
	}
	@Column(name="DUAL_ELGBL_IND")
	public String getDualElgblInd() {
		return dualElgblInd;
	}
	public void setDualElgblInd(String dualElgblInd) {
		this.dualElgblInd = dualElgblInd;
	}
	@Column(name="CNC_IND")
	public String getCncInd() {
		return cncInd;
	}
	public void setCncInd(String cncInd) {
		this.cncInd = cncInd;
	}
	@Column(name="CNC_RISK_CD")
	public String getCncRiskCd() {
		return cncRiskCd;
	}
	public void setCncRiskCd(String cncRiskCd) {
		this.cncRiskCd = cncRiskCd;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="CNC_RISK_DT")
	public Date getCncRiskDt() {
		return cncRiskDt;
	}
	public void setCncRiskDt(Date cncRiskDt) {
		this.cncRiskDt = cncRiskDt;
	}
}
