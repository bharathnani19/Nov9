package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.sql.Clob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Where;
@Entity
@Table(name = "FPS_ASRPT_USER_LINK_EVNT")
@BatchSize(size=100)
@Where(clause=" REC_CHG_IND != 'D' AND REC_CHG_IND != 'R' ")
public class FpsAsrptUserLinkEvnt implements Serializable {
	private int asrptUserLinkEvntId;
	private FpsAsrptInvstgtn fpsAsrptInvstgtn;
	private String aplctnSuprUserId;
	private Date userLinkEvntDt;
	private String audtInsrtId;
	private Date audtInsrtTs;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private String recChgInd;
	private String extrnlCaseId;
	private String linkEventTypeDesc;
	private String ucmEvntId;

	public FpsAsrptUserLinkEvnt() {
	}



	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(generator = "FpsAsrptUserLinkEvnt_SEQ")
	@SequenceGenerator(name="FpsAsrptUserLinkEvnt_SEQ",sequenceName="fps2.fps_asrpt_user_link_evnt_asrpt_user_link_evnt_id_seq", allocationSize=20)

	@Column(name = "ASRPT_USER_LINK_EVNT_ID", unique = true, nullable = false)
	public int getAsrptUserLinkEvntId() {
		return this.asrptUserLinkEvntId;
	}

	public void setAsrptUserLinkEvntId(int asrptUserLinkEvntId) {
		this.asrptUserLinkEvntId = asrptUserLinkEvntId;
	}

//	@ManyToOne(fetch = FetchType.EAGER)
//	@JoinColumn(name = "LINK_EVENT_TYPE_CD", updatable=false, insertable=false)
//	public FpsLinkEvntTypeRfrnc getFpsLinkEvntTypeRfrnc() {
//		return this.fpsLinkEvntTypeRfrnc;
//	}
//
//	public void setFpsLinkEvntTypeRfrnc(FpsLinkEvntTypeRfrnc fpsLinkEvntTypeRfrnc) {
//		this.fpsLinkEvntTypeRfrnc = fpsLinkEvntTypeRfrnc;
//	}

	@ManyToOne(fetch = FetchType.LAZY, optional=false)
	@JoinColumn(name = "ASRPT_INVSTGTN_ID")
	public FpsAsrptInvstgtn getFpsAsrptInvstgtn() {
		return this.fpsAsrptInvstgtn;
	}

	public void setFpsAsrptInvstgtn(FpsAsrptInvstgtn fpsAsrptInvstgtn) {
		this.fpsAsrptInvstgtn = fpsAsrptInvstgtn;
	}

	@Column(name = "LINK_EVNT_USER_ID", length = 20)
	public String getAplctnSuprUserId() {
		return this.aplctnSuprUserId;
	}

	public void setAplctnSuprUserId(String aplctnSuprUserId) {
		this.aplctnSuprUserId = aplctnSuprUserId;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "LINK_EVNT_DT", nullable = false, length = 10)
	public Date getUserLinkEvntDt() {
		return this.userLinkEvntDt;
	}

	public void setUserLinkEvntDt(Date userLinkEvntDt) {
		this.userLinkEvntDt = userLinkEvntDt;
	}



	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}


	@Column(name = "REC_CHG_IND", length = 1)
	public String getRecChgInd() {
		return this.recChgInd;
	}

	public void setRecChgInd(String recChgInd) {
		this.recChgInd = recChgInd;
	}
	@Column(name="EXTRNL_CASE_ID")
	public String getExtrnlCaseId() {
		return extrnlCaseId;
	}

	public void setExtrnlCaseId(String extrnlCaseId) {
		this.extrnlCaseId = extrnlCaseId;
	}
	@Column(name="LINK_EVNT_TYPE_DESC")
	public String getLinkEventTypeDesc() {
		return linkEventTypeDesc;
	}

	public void setLinkEventTypeDesc(String linkEventTypeDesc) {
		this.linkEventTypeDesc = linkEventTypeDesc;
	}
	@Column(name="UCM_EVNT_ID")

	public String getUcmEvntId() {
		return ucmEvntId;
	}

	public void setUcmEvntId(String ucmEvntId) {
		this.ucmEvntId = ucmEvntId;
	}
}
