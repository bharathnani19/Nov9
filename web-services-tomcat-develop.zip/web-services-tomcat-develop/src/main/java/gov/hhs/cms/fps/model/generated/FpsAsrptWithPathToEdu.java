package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.Subselect;
@Entity
@Subselect("select a.asrpt_id, sum(case when d.PATH_TO_EDCTN_IND = 'Y' then 1 else 0 end) as path_to_edu_y_ct from fps2.fps_asrpt a " +
		"left join fps2.fps_asrpt_alert_asctn b on a.asrpt_id = b.asrpt_id " +
		"left join fps2.fps_alert c on b.alert_id = c.alert_id " +
		"left join fps2.fps_model d on c.model_id = d.model_id " +
		"where c.alert_Creat_dt > current_date - interval '180 days'  "
		+ "group by a.asrpt_id "
		
			)
public class FpsAsrptWithPathToEdu implements Serializable {
	private Integer asrptId;
	private Integer eduCt;
	
	@Id
	@Column(name = "ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name = "path_to_edu_y_ct")
	public Integer getEduCt() {
		return eduCt;
	}
	public void setEduCt(Integer eduCt) {
		this.eduCt = eduCt;
	}

}
