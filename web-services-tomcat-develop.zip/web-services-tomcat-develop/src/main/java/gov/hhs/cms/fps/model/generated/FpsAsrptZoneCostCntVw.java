package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FPS_ASRPT_ZONE_COST_CNT_VW", schema="fps2")
public class FpsAsrptZoneCostCntVw implements Serializable{
	private Integer asrptId;
	private String cntrctrNm;
	private String cntrctrDesc;
	private BigDecimal clmCost;
	private Integer clmCnt;
	
	@Id
	@Column(name="asrpt_id")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Id
	@Column(name="cntrctr_name")
	public String getCntrctrNm() {
		return cntrctrNm;
	}
	public void setCntrctrNm(String cntrctrNm) {
		this.cntrctrNm = cntrctrNm;
	}
	@Column(name="cntrctr_desc")
	public String getCntrctrDesc() {
		return cntrctrDesc;
	}
	public void setCntrctrDesc(String cntrctrDesc) {
		this.cntrctrDesc = cntrctrDesc;
	}
	@Column(name="clm_cost")

	public BigDecimal getClmCost() {
		return clmCost;
	}
	public void setClmCost(BigDecimal clmCost) {
		this.clmCost = clmCost;
	}
	@Column(name="clm_cnt")

	public Integer getClmCnt() {
		return clmCnt;
	}
	public void setClmCnt(Integer clmCnt) {
		this.clmCnt = clmCnt;
	}
	
	

}
