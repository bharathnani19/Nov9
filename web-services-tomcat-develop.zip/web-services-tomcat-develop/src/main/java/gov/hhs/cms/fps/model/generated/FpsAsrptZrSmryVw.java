package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;
@Entity
@Table(name="FPS_ASRPT_ZR_SMRY_VW")
@BatchSize(size = 500)
public class FpsAsrptZrSmryVw implements Serializable {

	private Integer asrptId;
	private String npiNum;
	private String ucmProcName;
	private String srcSysName;
	private FpsAsrpt fpsAsrpt;
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	@Column(name="UCM_PROC_NAME")
	public String getUcmProcName() {
		return ucmProcName;
	}
	public void setUcmProcName(String ucmProcName) {
		this.ucmProcName = ucmProcName;
	}
	@Column(name="SRC_SYS_NAME")
	public String getSrcSysName() {
		return srcSysName;
	}
	public void setSrcSysName(String srcSysName) {
		this.srcSysName = srcSysName;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "ASRPT_ID",insertable=false, updatable=false)
	public FpsAsrpt getFpsAsrpt() {
		return fpsAsrpt;
	}


	public void setFpsAsrpt(FpsAsrpt fpsAsrpt) {
		this.fpsAsrpt = fpsAsrpt;
	}

}
