package gov.hhs.cms.fps.model.generated;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.cache.annotation.Cacheable;

@Entity
@Table(name = "FPS_ALERTED_SSF_ASR_KEY")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "claim")
@BatchSize(size = 1000)

public class FpsClmAsrpt implements java.io.Serializable {

	private Integer clmId;
	private Integer asrptId;
	private Integer clmRvwInd;
	private String modelString;
	private FpsClm fpsClm;

	@Id
	@Column(name = "CLM_ID")
	public Integer getClmId() {
		return clmId;
	}

	public void setClmId(Integer clmId) {
		this.clmId = clmId;
	}

	@Id
	@Column(name = "ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}

	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}


	@Column(name = "CLM_RVW_IND")
	public Integer getClmRvwInd() {
		return clmRvwInd;
	}

	public void setClmRvwInd(Integer clmRvwInd) {
		this.clmRvwInd = clmRvwInd;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CLM_ID", updatable = false, insertable = false)
	public FpsClm getFpsClm() {
		return fpsClm;
	}

	public void setFpsClm(FpsClm fpsClm) {
		this.fpsClm = fpsClm;
	}
	//@Id
	@Column(name = "MODEL_BUSNS_IDS")
	public String getModelString() {
		return modelString;
	}

	public void setModelString(String modelString) {
		this.modelString = modelString;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asrptId == null) ? 0 : asrptId.hashCode());
		result = prime * result + ((clmId == null) ? 0 : clmId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FpsClmAsrpt other = (FpsClmAsrpt) obj;
		if (asrptId == null) {
			if (other.asrptId != null)
				return false;
		} else if (!asrptId.equals(other.asrptId))
			return false;
		if (clmId == null) {
			if (other.clmId != null)
				return false;
		} else if (!clmId.equals(other.clmId))
			return false;
		return true;
	}

}
