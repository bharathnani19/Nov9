package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="FPS_ALERTED_CLM_LINE_ATTR_KEY_VW_MDCD")
public class FpsClmAttrMdcd implements Serializable {

	private Integer asrptId;
	
	private String subjId;
	
	private Integer alertId;
		 
	private Date alertCreatDt;
	
	private Integer modelId;
	
	private String modelBusnsId;
	
	private String submtgMdcdLclStateCd;
	
	private String geoMdcdUspsStateCd;
	 
	private Integer fpsClmId;
	
	private Integer fpsClmLineId;
	private String clmRvwInd;
	private Integer attrSqncNum;
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	@Column(name="SUBJ_ID")	
	public String getSubjId() {
		return subjId;
	}
	public void setSubjId(String subjId) {
		this.subjId = subjId;
	}
	@Column(name="ALERT_ID")
	@Id
	public Integer getAlertId() {
		return alertId;
	}
	public void setAlertId(Integer alertId) {
		this.alertId = alertId;
	}
	@Column(name="ALERT_CREAT_DT")
	public Date getAlertCreatDt() {
		return alertCreatDt;
	}
	
	public void setAlertCreatDt(Date alertCreatDt) {
		this.alertCreatDt = alertCreatDt;
	}
	@Column(name="MODEL_ID")
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}
	@Column(name="MODEL_BUSNS_ID")	
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Column(name="SUBMTG_MDCD_LCL_STATE_CD")
	public String getSubmtgMdcdLclStateCd() {
		return submtgMdcdLclStateCd;
	}
	public void setSubmtgMdcdLclStateCd(String submtgMdcdLclStateCd) {
		this.submtgMdcdLclStateCd = submtgMdcdLclStateCd;
	}
	@Column(name="GEO_MDCD_USPS_STATE_CD")	 
	public String getGeoMdcdUspsStateCd() {
		return geoMdcdUspsStateCd;
	}
	public void setGeoMdcdUspsStateCd(String geoMdcdUspsStateCd) {
		this.geoMdcdUspsStateCd = geoMdcdUspsStateCd;
	}
	@Id
	@Column(name="FPS_CLM_ID")	
	public Integer getFpsClmId() {
		return fpsClmId;
	}
	public void setFpsClmId(Integer fpsClmId) {
		this.fpsClmId = fpsClmId;
	}
	@Id
	@Column(name="FPS_CLM_LINE_ID")
	public Integer getFpsClmLineId() {
		return fpsClmLineId;
	}
	public void setFpsClmLineId(Integer fpsClmLineId) {
		this.fpsClmLineId = fpsClmLineId;
	}
	@Id
	@Column(name="CLM_RVW_IND")
	public String getClmRvwInd() {
		return clmRvwInd;
	}
	public void setClmRvwInd(String clmRvwInd) {
		this.clmRvwInd = clmRvwInd;
	}
	@Id
	@Column(name="ATTR_SQNC_NUM")
	public Integer getAttrSqncNum() {
		return attrSqncNum;
	}
	public void setAttrSqncNum(Integer attrSqncNum) {
		this.attrSqncNum = attrSqncNum;
	}
	

}
