package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;

@Entity()
@Table(name="FPS_CLM_DGNS_RFRNC")
@BatchSize(size=200)
public class FpsClmDgnsRfrnc implements Serializable {


	private String clmDgnsCd;
	
	private String clmDgnsShrtDesc;
	
	@Id
	@Column(name="CLM_DGNS_CD")
	public String getClmDgnsCd() {
		return clmDgnsCd;
	}
	public void setClmDgnsCd(String clmDgnsCd) {
		this.clmDgnsCd = clmDgnsCd;
	}
	
	@Column(name="CLM_DGNS_SHRT_DESC")
	public String getClmDgnsShrtDesc() {
		return clmDgnsShrtDesc;
	}
	public void setClmDgnsShrtDesc(String clmDgnsShrtDesc) {
		this.clmDgnsShrtDesc = clmDgnsShrtDesc;
	}

}
