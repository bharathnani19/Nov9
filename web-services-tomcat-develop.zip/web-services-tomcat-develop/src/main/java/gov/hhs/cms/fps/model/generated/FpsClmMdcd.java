package gov.hhs.cms.fps.model.generated;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;

import gov.hhs.cms.fps.util.CsvHelper;
import gov.hhs.cms.fps.util.FpsDomainObjectConverter;
import gov.hhs.cms.fps.util.FpsEnums.SolrClaimType;
@Entity
@Table(name="fps_clm_mdcd_smry_vw")
public class FpsClmMdcd extends MdcdBaseClaim {

	private MdcdClmTypeCd mdcdClmTypeCd;
	private MdcdGeoLclStateCd mdcdGeoLclStateCd;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CLM_TYPE_CD", insertable = false, updatable = false)
	@BatchSize(size = 1000)
	public MdcdClmTypeCd getMdcdClmTypeCd() {
		return mdcdClmTypeCd;
	}

	public void setMdcdClmTypeCd(MdcdClmTypeCd mdcdClmTypeCd) {
		this.mdcdClmTypeCd = mdcdClmTypeCd;
	}
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SUBMTG_MDCD_LCL_STATE_CD", insertable = false, updatable = false)
	@BatchSize(size = 1000)
//	@Transient
	public MdcdGeoLclStateCd getMdcdGeoLclStateCd() {
		return mdcdGeoLclStateCd;
	}

	public void setMdcdGeoLclStateCd(MdcdGeoLclStateCd mdcdGeoLclStateCd) {
		this.mdcdGeoLclStateCd = mdcdGeoLclStateCd;
	}

	@Override
	public String toCsv() {
		CsvHelper sb = new CsvHelper();

			FpsDomainObjectConverter.convertFpsAsrptToDetailMdcdClaimLinesCsv(this, sb, SolrClaimType.ALERTED,
					this.getAsrptId());
	
		return sb.toString();
	}
	@Override
	public void toCsv(CsvHelper sb) {
//		long start = System.currentTimeMillis();
//		BaosHelper sb = new BaosHelper(baos);

			FpsDomainObjectConverter.convertFpsAsrptToDetailMdcdClaimLinesCsv(this, sb, SolrClaimType.ALERTED,
					this.getAsrptId());
		

	}
}
