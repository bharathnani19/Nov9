package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="FPS_CSTM_TBL")
public class FpsCstmTbl implements Serializable {
	
	private Integer fpsCstmTblId;
	private String modelBusnsId;
	private String cstmTblId;
	private String cstmTblName;
	private String cstmTblDesc;
	private String cstmTblShrtName;
	private List<FpsCstmTblClmnName> fpsCstmTblClmnNames = new ArrayList<FpsCstmTblClmnName>();
	private List<FpsCstmTblData> fpsCstmTblDatas = new ArrayList<FpsCstmTblData>();
	private FpsModel fpsModel;
	
	public FpsCstmTbl(  ) {
		
	}
	
	public FpsCstmTbl(String cstmTblId, String cstmTblName, String cstmTblDesc, String cstmTblShrtName  ) {
		this.cstmTblId = cstmTblId;
		this.cstmTblName = cstmTblName;
		this.cstmTblShrtName = cstmTblShrtName;
		this.cstmTblDesc = cstmTblDesc;
	}
	
	@Id
	@Column(name="FPS_CSTM_TBL_ID")
	public Integer getFpsCstmTblId(){
		return this.fpsCstmTblId;
	}
	
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId(){
		return this.modelBusnsId;
	}

	
	@Column(name="CSTM_TBL_ID")
	public String getCstmTblId(){
		return this.cstmTblId;
	}
	
	@Column(name="CSTM_TBL_NAME")
	public String getCstmTblName(){
		return this.cstmTblName;
	}

	@Column(name="CSTM_TBL_DESC")
	public String getCstmTblDesc(){
		return this.cstmTblDesc;
	}
	@Column(name="CSTM_TBL_SHRT_NAME")
	public String getCstmTblShrtName(){
		return this.cstmTblShrtName;
	}

	public void setFpsCstmTblId(Integer fpsCstmTblId) {
		this.fpsCstmTblId = fpsCstmTblId;
	}

	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	public void setCstmTblId(String cstmTblId) {
		this.cstmTblId = cstmTblId;
	}

	public void setCstmTblName(String cstmTblName) {
		this.cstmTblName = cstmTblName;
	}

	public void setCstmTblDesc(String cstmTblDesc) {
		this.cstmTblDesc = cstmTblDesc;
	}

	public void setCstmTblShrtName(String cstmTblShrtName) {
		this.cstmTblShrtName = cstmTblShrtName;
	}
//	@OneToMany(fetch = FetchType.LAZY, mappedBy="fpsCstmTbl")
//	@BatchSize(size = 500)
//	@NotFound(action = NotFoundAction.IGNORE)
	@Transient
	public List<FpsCstmTblClmnName> getFpsCstmTblClmnNames() {
		return fpsCstmTblClmnNames;
	}
	
	public void setFpsCstmTblClmnNames(List<FpsCstmTblClmnName> fpsCstmTblClmnNames) {
		this.fpsCstmTblClmnNames = fpsCstmTblClmnNames;
	}
//	@OneToMany(fetch = FetchType.LAZY, mappedBy="fpsCstmTbl")
//	@BatchSize(size = 500)
//	@NotFound(action = NotFoundAction.IGNORE)
	@Transient
	public List<FpsCstmTblData> getFpsCstmTblDatas() {
		return fpsCstmTblDatas;
	}

	public void setFpsCstmTblDatas(List<FpsCstmTblData> fpsCstmTblDatas) {
		this.fpsCstmTblDatas = fpsCstmTblDatas;
	}
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "MODEL_BUSNS_ID", referencedColumnName = "MODEL_BUSNS_ID", updatable = false, insertable = false)
//	public FpsModel getFpsModel() {
//		return this.fpsModel;
//	}
//
//	public void setFpsModel(FpsModel fpsModel) {
//		this.fpsModel = fpsModel;
//	}
}
