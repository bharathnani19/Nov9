package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
@Entity
@Table(name="FPS_CSTM_TBL_CLMN_NAME")
@BatchSize(size=500)
public class FpsCstmTblClmnName implements Serializable {
	
	private Integer fpsCstmTblClmNameId; 
	private String modelBusnsId;
	private String cstmTblId;
	private String cstmTblClmnNum;
	private String cstmTblClmnLabel;
	private FpsCstmTbl fpsCstmTbl;
	private Set<FpsCstmTblData> fpsCstmTblDatas;
	
	@Id
	@Column(name="FPS_CSTM_TBL_CLMN_NAME_ID")
	public Integer getFpsCstmTblClmNameId(){
		return fpsCstmTblClmNameId;
	}
	
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId(){
		return modelBusnsId;
	}
	
	@Column(name="CSTM_TBL_ID")
	public String getCstmTblId(){
		return cstmTblId;
	}
	
	@Column(name="CSTM_TBL_CLMN_NUM")
	public String getCstmTblClmnNum(){
		return cstmTblClmnNum;
	}
	
	@Column(name="CSTM_TBL_CLMN_LABEL")
	public String getCstmTblClmnLabel(){
		return cstmTblClmnLabel;
		
	}

	public void setFpsCstmTblClmNameId(Integer fpsCstmTblClmNameId) {
		this.fpsCstmTblClmNameId = fpsCstmTblClmNameId;
	}

	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	public void setCstmTblId(String cstmTblId) {
		this.cstmTblId = cstmTblId;
	}

	public void setCstmTblClmnNum(String cstmTblClmnNum) {
		this.cstmTblClmnNum = cstmTblClmnNum;
	}

	public void setCstmTblClmnLabel(String cstmTblClmnLabel) {
		this.cstmTblClmnLabel = cstmTblClmnLabel;
	}

	


}
