package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
@Entity
//table name changed in SysR12.0
@Table(name="FPS_CSTM_TBL_DTL")
@BatchSize(size=500)
public class FpsCstmTblData implements Serializable {

	private Integer cstmTblDataId;
	private String modelBusnsId;
	private String modelRunDtStr;
	private String npiNum;
	private String cstmTblId; 
	private String cstmTblRowNum;
	private String cstmTblClmnNum;
	private String cstmTblPrvdrVal;	
	private Date modelRunDt;
	private FpsCstmTblScndryNpiRfrnc fpsCstmTblScndryNpiRfrnc;
	private Integer linkAsrptId;

	
	@Id
	@Column(name="FPS_CSTM_TBL_DTL_ID")
	public Integer getCstmTblDataId() {
		return cstmTblDataId;
	}
	public void setCstmTblDataId(Integer cstmTblDataId) {
		this.cstmTblDataId = cstmTblDataId;
	}
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Column(name="MODEL_RUN_DT_STR")
	public String getModelRunDtStr() {
		return modelRunDtStr;
	}
	public void setModelRunDtStr(String modelRunDtStr) {
		this.modelRunDtStr = modelRunDtStr;
	}
	@Column(name="NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	@Column(name="CSTM_TBL_ID")
	public String getCstmTblId() {
		return cstmTblId;
	}
	public void setCstmTblId(String cstmTblId) {
		this.cstmTblId = cstmTblId;
	}
	@Column(name="CSTM_TBL_ROW_NUM")
	public String getCstmTblRowNum() {
		return cstmTblRowNum;
	}
	public void setCstmTblRowNum(String cstmTblRowNum) {
		this.cstmTblRowNum = cstmTblRowNum;
	}
	@Column(name="CSTM_TBL_CLMN_NUM")
	public String getCstmTblClmnNum() {
		return cstmTblClmnNum;
	}
	public void setCstmTblClmnNum(String cstmTblClmnNum) {
		this.cstmTblClmnNum = cstmTblClmnNum;
	}
	@Column(name="CSTM_TBL_PRVDR_VAL")
	public String getCstmTblPrvdrVal() {
		return cstmTblPrvdrVal;
	}
	public void setCstmTblPrvdrVal(String cstmTblPrvdrVal) {
		this.cstmTblPrvdrVal = cstmTblPrvdrVal;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumns({
	    @JoinColumn(name="CSTM_TBL_ID", referencedColumnName="CSTM_TBL_ID", updatable=false, insertable=false),
	    @JoinColumn(name="MODEL_BUSNS_ID", referencedColumnName="MODEL_BUSNS_ID", updatable=false, insertable=false),
	    @JoinColumn(name="CSTM_TBL_CLMN_NUM", referencedColumnName="CSTM_TBL_CLMN_NUM", updatable=false, insertable=false)
	})
	@BatchSize(size=500)
	
	public FpsCstmTblScndryNpiRfrnc getFpsCstmTblScndryNpiRfrnc() {
		return fpsCstmTblScndryNpiRfrnc;
	}

	public void setFpsCstmTblScndryNpiRfrnc(FpsCstmTblScndryNpiRfrnc fpsCstmTblScndryNpiRfrnc) {
		this.fpsCstmTblScndryNpiRfrnc = fpsCstmTblScndryNpiRfrnc;
	}
	@Temporal(TemporalType.DATE)
	@Column(name="MODEL_RUN_DT")
	public Date getModelRunDt() {
		return modelRunDt;
	}
	public void setModelRunDt(Date modelRunDt) {
		this.modelRunDt = modelRunDt;
	}

	@Formula(value = "(select a.asrpt_id from fps2.fps_cstm_tbl_asr_link_mqt a where a.CSTM_TBL_ID = CSTM_TBL_ID and a.MODEL_BUSNS_ID = MODEL_BUSNS_ID and a.CSTM_TBL_CLMN_NUM = CSTM_TBL_CLMN_NUM and a.CSTM_TBL_ROW_NUM = CSTM_TBL_ROW_NUM and a.NPI_NUM = NPI_NUM and a.MODEL_RUN_DT = MODEL_RUN_DT)")


	public Integer getLinkAsrptId() {
		return linkAsrptId;
	}
	public void setLinkAsrptId(Integer linkAsrptId) {
		this.linkAsrptId = linkAsrptId;
	}
	
	
//	@ManyToOne(fetch = FetchType.LAZY)
//	@BatchSize(size=500)
//
//	@JoinColumns({
//	    @JoinColumn(name="CSTM_TBL_ID", referencedColumnName="CSTM_TBL_ID", updatable=false, insertable=false),
//	    @JoinColumn(name="CSTM_TBL_CLMN_NUM", referencedColumnName="CSTM_TBL_CLMN_NUM", updatable=false, insertable=false)
//	})
//	public FpsCstmTblClmnName getFpsCstmTblClmnName() {
//		return fpsCstmTblClmnName;
//	}
//
//	public void setFpsCstmTblClmnName(FpsCstmTblClmnName fpsCstmTblClmnName) {
//		this.fpsCstmTblClmnName = fpsCstmTblClmnName;
//	}

}
