package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="FPS_CSTM_TBL_SCNDRY_NPI_HSTRY")
public class FpsCstmTblScndryNpiHstry implements Serializable {

	private String modelBusnsId;
	private String scndryNpiNum;
	private String newAsrInd;
	private Date modelRunDt;
	private String npiNum;
	
	@Id
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Id
	@Column(name="SCNDRY_NPI_NUM")
	public String getScndryNpiNum() {
		return scndryNpiNum;
	}
	public void setScndryNpiNum(String scndryNpiNum) {
		this.scndryNpiNum = scndryNpiNum;
	}
	@Column(name="NEW_ASR_IND")
	public String getNewAsrInd() {
		return newAsrInd;
	}
	public void setNewAsrInd(String newAsrInd) {
		this.newAsrInd = newAsrInd;
	}
	@Id
	@Column(name="MODEL_RUN_DT")
	public Date getModelRunDt() {
		return modelRunDt;
	}
	public void setModelRunDt(Date modelRunDt) {
		this.modelRunDt = modelRunDt;
	}
	@Id
	@Column(name="NPI_NUM")
	public String getNpiNum() {
		return npiNum;
	}
	public void setNpiNum(String npiNum) {
		this.npiNum = npiNum;
	}
	
}
