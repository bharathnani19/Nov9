package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Formula;
import org.hibernate.annotations.Where;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.hhs.cms.fps.util.NAStringSerializer;
@Entity
@Table(name="FPS_EDIT_NUM_RFRNC")
@Where(clause="actv_ind != 'D' ")
public class FpsEditNumRfrnc implements Serializable {

	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String fpsEditNum;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String fpsEditName;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String modelCntrctr;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String editOwner;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String audtInsrtId;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String echimpName;
	private Date audtInsrtTs;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String audtUpdtId;
	private Date audtUpdtTs;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String actvInd;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String macInfo;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String editDesc;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String editActnType;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String lineOfBusns;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String hstry;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String hstryLkbckPrd;
	@JsonSerialize(nullsUsing = NAStringSerializer.class)
	private String echimpNum;
	public FpsEditNumRfrnc() {
	}

	public FpsEditNumRfrnc(String fpsEditNum, String fpsEditName, String modelCntrctr, String editOwner,
			String audtInsrtId, Date audtInsrtTs, String audtUpdtId, Date audtUpdtTs) {
		this.fpsEditNum = fpsEditNum;
		this.fpsEditName = fpsEditName;
		this.modelCntrctr = modelCntrctr;
		this.editOwner = editOwner;
		this.audtInsrtId = audtInsrtId;
		this.audtInsrtTs = audtInsrtTs;
		this.audtUpdtId = audtUpdtId;
		this.audtUpdtTs = audtUpdtTs;
	}

	@Id

	@Column(name = "FPS_EDIT_NUM", unique = true, nullable = false, length = 30)
	public String getFpsEditNum() {
		return this.fpsEditNum;
	}

	public void setFpsEditNum(String fpsEditNum) {
		this.fpsEditNum = fpsEditNum;
	}

	@Column(name = "FPS_EDIT_NAME", nullable = false, length = 200)
	public String getFpsEditName() {
		return this.fpsEditName;
	}

	public void setFpsEditName(String fpsEditName) {
		this.fpsEditName = fpsEditName;
	}

	@Column(name = "MODEL_CNTRCTR", nullable = false, length = 100)
	public String getModelCntrctr() {
		return this.modelCntrctr;
	}

	public void setModelCntrctr(String modelCntrctr) {
		this.modelCntrctr = modelCntrctr;
	}

	@Column(name = "EDIT_OWNER", nullable = false, length = 100)
	public String getEditOwner() {
		return this.editOwner;
	}

	public void setEditOwner(String editOwner) {
		this.editOwner = editOwner;
	}

	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", nullable = false, length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", nullable = false, length = 26)
	public Date getAudtUpdtTs() {
		return this.audtUpdtTs;
	}

	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}

	@Column(name="ECHIMP_NAME")
	public String getEchimpName() {
		return echimpName;
	}

	public void setEchimpName(String echimpName) {
		this.echimpName = echimpName;
	}
	@Column(name = "ACTV_IND", length = 1)
	public String getActvInd() {
		return this.actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

	@Formula(value="(select string_agg(b.poc_email_Adr, ',') from fps2.fps_prodn_prblm_rpt_org_poc b where b.poc_org = model_cntrctr)")
	public String getMacInfo() {
		return macInfo;
	}

	public void setMacInfo(String macInfo) {
		this.macInfo = macInfo;
	}
	@Column(name = "EDIT_DESC")

	public String getEditDesc() {
		return editDesc;
	}

	public void setEditDesc(String editDesc) {
		this.editDesc = editDesc;
	}
	@Column(name = "EDIT_ACTN_TYPE")

	public String getEditActnType() {
		return editActnType;
	}

	public void setEditActnType(String editActnType) {
		this.editActnType = editActnType;
	}
	@Column(name = "LINE_OF_BUSNS")

	public String getLineOfBusns() {
		return lineOfBusns;
	}

	public void setLineOfBusns(String lineOfBusns) {
		this.lineOfBusns = lineOfBusns;
	}
	@Column(name = "HSTRY")

	public String getHstry() {
		return hstry;
	}

	public void setHstry(String hstry) {
		this.hstry = hstry;
	}
	@Column(name = "HSTRY_LKBCK_PRD")

	public String getHstryLkbckPrd() {
		return hstryLkbckPrd;
	}

	public void setHstryLkbckPrd(String hstryLkbckPrd) {
		this.hstryLkbckPrd = hstryLkbckPrd;
	}
	@Column(name = "ECHIMP_CR_NUM")

	public String getEchimpNum() {
		return echimpNum;
	}

	public void setEchimpNum(String echimpNum) {
		this.echimpNum = echimpNum;
	}

	@Override
	public String toString() {
		return "{\"" + (fpsEditNum != null ? "fpsEditNum\":\"" + fpsEditNum + "\", \"" : "")
				+ (fpsEditName != null ? "fpsEditName\":\"" + fpsEditName : "") + "\"}";
	}

}
