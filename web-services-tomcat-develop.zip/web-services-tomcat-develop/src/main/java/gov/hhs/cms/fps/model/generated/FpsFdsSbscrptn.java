package gov.hhs.cms.fps.model.generated;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="FPS_FDS_SBSCRPTN")
public class FpsFdsSbscrptn implements Serializable{
	private Integer sbscrptnId;
	private String sbscrptnActnCd;
	private String sysCd;
	private String eventTypeCd;
	private String objTypeCd;
	private String objSrchId;
	private String ntfctnUrlTxt;
	private Date efctvDt;
	private Date trmntnDt;
	private String urlUpdtInd;
	private Date audtInsrtTs;
	private String audtInsrtId;
	private String audtUpdtId;
	private Date audtUpdtTs;
	private FpsFdsSysRfrnc fpsFdsSysRfrnc;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SBSCRPTN_ID")
	public Integer getSbscrptnId() {
		return sbscrptnId;
	}
	public void setSbscrptnId(Integer sbscrptnId) {
		this.sbscrptnId = sbscrptnId;
	}
	@Column(name="SBSCRPTN_ACTN_CD")
	public String getSbscrptnActnCd() {
		return sbscrptnActnCd;
	}
	public void setSbscrptnActnCd(String sbscrptnActnCd) {
		this.sbscrptnActnCd = sbscrptnActnCd;
	}
	@Column(name="SYS_ID")
	public String getSysCd() {
		return sysCd;
	}
	public void setSysCd(String sysCd) {
		this.sysCd = sysCd;
	}
	@Column(name="EVNT_TYPE_CD")
	public String getEventTypeCd() {
		return eventTypeCd;
	}
	public void setEventTypeCd(String eventTypeCd) {
		this.eventTypeCd = eventTypeCd;
	}
	@Column(name="OBJ_TYPE_CD")
	public String getObjTypeCd() {
		return objTypeCd;
	}
	public void setObjTypeCd(String objTypeCd) {
		this.objTypeCd = objTypeCd;
	}
	
	@Column(name="OBJ_SRCH_ID")
	public String getObjSrchId() {
		return objSrchId;
	}
	public void setObjSrchId(String objSrchId) {
		this.objSrchId = objSrchId;
	}
	@Column(name="NTFCTN_URL_TXT")
	public String getNtfctnUrlTxt() {
		return ntfctnUrlTxt;
	}
	public void setNtfctnUrlTxt(String ntfctnUrlTxt) {
		this.ntfctnUrlTxt = ntfctnUrlTxt;
	}
	@Column(name="EFCTV_DT")
	public Date getEfctvDt() {
		return efctvDt;
	}
	public void setEfctvDt(Date efctvDt) {
		this.efctvDt = efctvDt;
	}
	@Column(name="TRMNTN_DT")
	public Date getTrmntnDt() {
		return trmntnDt;
	}
	public void setTrmntnDt(Date trmntnDt) {
		this.trmntnDt = trmntnDt;
	}
	@Column(name="URL_UPDT_IND")
	public String getUrlUpdtInd() {
		return urlUpdtInd;
	}
	public void setUrlUpdtInd(String urlUpdtInd) {
		this.urlUpdtInd = urlUpdtInd;
	}
	@Column(name = "AUDT_INSRT_ID", nullable = false, length = 128)
	public String getAudtInsrtId() {
		return this.audtInsrtId;
	}

	public void setAudtInsrtId(String audtInsrtId) {
		this.audtInsrtId = audtInsrtId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_INSRT_TS", nullable = false, length = 26)
	public Date getAudtInsrtTs() {
		return this.audtInsrtTs;
	}

	public void setAudtInsrtTs(Date audtInsrtTs) {
		this.audtInsrtTs = audtInsrtTs;
	}

	@Column(name = "AUDT_UPDT_ID", length = 128)
	public String getAudtUpdtId() {
		return this.audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "AUDT_UPDT_TS", nullable = false, length = 26)
	public Date getAudtUpdtTs() {
		return audtUpdtTs;
	}
	public void setAudtUpdtTs(Date audtUpdtTs) {
		this.audtUpdtTs = audtUpdtTs;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SYS_ID", updatable = false, insertable = false)
	public FpsFdsSysRfrnc getFpsFdsSysRfrnc() {
		return fpsFdsSysRfrnc;
	}
	public void setFpsFdsSysRfrnc(FpsFdsSysRfrnc fpsFdsSysRfrnc) {
		this.fpsFdsSysRfrnc = fpsFdsSysRfrnc;
	}
	
}
