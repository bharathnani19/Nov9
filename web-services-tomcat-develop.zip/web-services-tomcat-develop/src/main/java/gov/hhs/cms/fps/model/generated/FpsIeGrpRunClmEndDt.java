package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;
@Table(name="FPS_IE_GRP_RUN_CLM_END_DT")
@BatchSize(size=500)
@Entity
public class FpsIeGrpRunClmEndDt implements Serializable {

	private String modelBusnsId;
	private Date modelRunDt;
	private Integer modelId;
	private Date modelWindowStartDt;
	private Date modelWindowEndDt;
	private String modelWindowClmDtFld;
//	@Id
	@Column(name="MODEL_BUSNS_ID")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Id
	@Column(name="MODEL_RUN_DT")
	public Date getModelRunDt() {
		return modelRunDt;
	}
	public void setModelRunDt(Date modelRunDt) {
		this.modelRunDt = modelRunDt;
	}
	@Column(name="MODEL_WINDOW_START_DT")
	public Date getModelWindowStartDt() {
		return modelWindowStartDt;
	}
	public void setModelWindowStartDt(Date modelWindowStartDt) {
		this.modelWindowStartDt = modelWindowStartDt;
	}
	@Column(name="MODEL_WINDOW_END_DT")
	public Date getModelWindowEndDt() {
		return modelWindowEndDt;
	}
	public void setModelWindowEndDt(Date modelWindowEndDt) {
		this.modelWindowEndDt = modelWindowEndDt;
	}
	@Column(name="MODEL_WINDOW_CLM_DT_FLD")
	public String getModelWindowClmDtFld() {
		return modelWindowClmDtFld;
	}
	public void setModelWindowClmDtFld(String modelWindowClmDtFld) {
		this.modelWindowClmDtFld = modelWindowClmDtFld;
	}
	@Id
	@Column(name="MODEL_ID")
	public Integer getModelId() {
		return modelId;
	}
	public void setModelId(Integer modelId) {
		this.modelId = modelId;
	}
	
}
