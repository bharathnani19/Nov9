package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.BatchSize;

@Entity
@Table(name="FPS_MAX_MODEL_RUN_DT_MDCD")
@BatchSize(size=500)
public class FpsMaxModelRunDtMdcd implements Serializable {
	
	private String modelBusnsId;
	private Date maxRunDt;
	
	@Id
	@Column(name="model_busns_id")
	public String getModelBusnsId() {
		return modelBusnsId;
	}
	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}
	@Id
	@Column(name="MAX_RUN_DT")
	public Date getMaxRunDt() {
		return maxRunDt;
	}
	public void setMaxRunDt(Date maxRunDt) {
		this.maxRunDt = maxRunDt;
	}
	
	
	
	

}
