package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name="FPS_PRIORITIZATION_WKLY_DATASET_EXCLUSION_SRCH_VW_MDCD")
public class FpsMdcdExclusionSearch  implements Serializable{

	private Date extractDt;
	private Integer asrptId;
	
	private String prvdrNpiNum;
	private String exclusionCd;
	private FpsPrvdrAnlys fpsPrvdrAnlys;
	private String cntrctrCd;
	private FpsPrvdrAnlysExclusionRfrnc fpsPrvdrAnlysExclusionRfrnc;
	private String publicInd;
	private String ownerId;
	
//	@Column(name="EXTRACT_DT")
	@Transient
	public Date getExtractDt() {
		return extractDt;
	}
	public void setExtractDt(Date extractDt) {
		this.extractDt = extractDt;
	}
	@Id
	@Column(name="ASRPT_ID")
	public Integer getAsrptId() {
		return asrptId;
	}
	public void setAsrptId(Integer asrptId) {
		this.asrptId = asrptId;
	}
	
	@Column(name="PRVDR_NPI_NUM")
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}
	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}
	@Id
	@Column(name="EXCLUSION_CD")
	
	public String getExclusionCd() {
		return exclusionCd;
	}
	public void setExclusionCd(String exclusionCd) {
		this.exclusionCd = exclusionCd;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ASRPT_ID",updatable = false, insertable = false)
	public FpsPrvdrAnlys getFpsPrvdrAnlys() {
		return fpsPrvdrAnlys;
	}
	public void setFpsPrvdrAnlys(FpsPrvdrAnlys fpsPrvdrAnlys) {
		this.fpsPrvdrAnlys = fpsPrvdrAnlys;
	}
	@Column(name="CNTRCTR_CD")
	@Id
	public String getCntrctrCd() {
		return cntrctrCd;
	}
	public void setCntrctrCd(String cntrctrCd) {
		this.cntrctrCd = cntrctrCd;
	}
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "EXCLUSION_CD", updatable = false, insertable = false)
	public FpsPrvdrAnlysExclusionRfrnc getFpsPrvdrAnlysExclusionRfrnc() {
		return fpsPrvdrAnlysExclusionRfrnc;
	}
	public void setFpsPrvdrAnlysExclusionRfrnc(FpsPrvdrAnlysExclusionRfrnc fpsPrvdrAnlysExclusionRfrnc) {
		this.fpsPrvdrAnlysExclusionRfrnc = fpsPrvdrAnlysExclusionRfrnc;
	}
	@Column(name="PUBLIC_IND")

	public String getPublicInd() {
		return publicInd;
	}
	public void setPublicInd(String publicInd) {
		this.publicInd = publicInd;
	}
	@Column(name="OWNER_ID")

	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
}
