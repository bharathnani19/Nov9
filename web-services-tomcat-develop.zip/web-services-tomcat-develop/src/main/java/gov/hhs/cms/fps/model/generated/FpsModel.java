package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Formula;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "FPS_MODEL")
@BatchSize(size = 100)
public class FpsModel implements Serializable {
	private int modelId;
	private FpsModelTypeRfrnc fpsModelTypeRfrnc;
	private String modelBusnsId;
	private String modelBusnsIdExtrnl;
	private String modelName;
	private String modelDesc;
	private Date modelCreatDt;
	private String fpsVrsnInd;
	private Double modelThrshldRiskScreNum;
	private Double modelCmpstScreNum;
	private String updtFreqDesc;
	private Date modelImpltnDt;
	private Date modelMdfctnDt;
	private String clmTypeCd;
	private String modelVrsnNum;
	private String modelTypeCd;
	private String modelImpltnDtStr;
	private String audtUpdtId;
	private Set<FpsAlert> fpsAlerts = new HashSet<FpsAlert>(0);
	private Set<FpsModelVrsn> fpsModelVrsns = new HashSet<FpsModelVrsn>(0);
	private Set<FpsRptCardDtl> fpsRptCardDtls = new HashSet<FpsRptCardDtl>(0);
	private String rptCardTypeDesc;
	private String ownrCntctPhneNum;
	private String ownrCntctEmailTxt;
	private String modelCmsOwnrName;
	private String modelActvtyStus;
	private String modelGuidanceDocFilePath;
	private String priorityInd;
	private String hstryLookbackPeriod;
	private Set<FpsMaxModelRunDtVw> fpsMaxModelRunDtVws;
	private Set<VwFpsModelLastStatusChg> vwFpsModelLastStatusChgs;
	private Set<FpsIeGrpRunClmEndDt> fpsIeGrpRunClmEndDts;
	private Date statusDt;
	private Date priorityDt;
	private String statusChangeUser;
	private Date maxModelRunDt;
	private String visTypeCd;
	private String lookbackDates;
	private Integer cadence = 30;
	private String pathToEduInd = "N";

	@Column(name = "OWNR_CNTCT_PHNE_NUM", length=20)
	public String getOwnrCntctPhneNum() {
		return this.ownrCntctPhneNum;
	}

	public void setOwnrCntctPhneNum(String ownrCntctPhneNum) {
		this.ownrCntctPhneNum = ownrCntctPhneNum;
	}

	@Column(name = "OWNR_CNTCT_EMAIL_TXT", length=50)
	public String getOwnrCntctEmailTxt() {
		return this.ownrCntctEmailTxt;
	}

	public void setOwnrCntctEmailTxt(String ownrCntctEmailTxt) {
		this.ownrCntctEmailTxt = ownrCntctEmailTxt;
	}

	@Column(name = "MODEL_CMS_OWNR_NAME", length=50)
	public String getModelCmsOwnrName() {
		return this.modelCmsOwnrName;
	}

	public void setModelCmsOwnrName(String modelCmsOwnrName) {
		this.modelCmsOwnrName = modelCmsOwnrName;
	}

	@Id
	@Column(name = "MODEL_ID", unique = true, nullable = false)
	public int getModelId() {
		return this.modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "MODEL_TYPE_CD", updatable = false, insertable = false)
	@BatchSize(size=100)
	public FpsModelTypeRfrnc getFpsModelTypeRfrnc() {
		return this.fpsModelTypeRfrnc;
	}

	public void setFpsModelTypeRfrnc(FpsModelTypeRfrnc fpsModelTypeRfrnc) {
		this.fpsModelTypeRfrnc = fpsModelTypeRfrnc;
	}

	@Column(name = "MODEL_BUSNS_ID", length = 30)
	public String getModelBusnsId() {
		return this.modelBusnsId;
	}

	public void setModelBusnsId(String modelBusnsId) {
		this.modelBusnsId = modelBusnsId;
	}

	@Column(name = "MODEL_NAME", length = 200)
	public String getModelName() {
		return this.modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	@Column(name = "MODEL_DESC", length = 1000)
	public String getModelDesc() {
		return this.modelDesc;
	}

	public void setModelDesc(String modelDesc) {
		this.modelDesc = modelDesc;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "MODEL_CREAT_DT", length = 10)
	public Date getModelCreatDt() {
		return this.modelCreatDt;
	}

	public void setModelCreatDt(Date modelCreatDt) {
		this.modelCreatDt = modelCreatDt;
	}

	@Column(name = "FPS_VRSN_IND", nullable = false, length = 1)
	public String getFpsVrsnInd() {
		return this.fpsVrsnInd;
	}

	public void setFpsVrsnInd(String fpsVrsnInd) {
		this.fpsVrsnInd = fpsVrsnInd;
	}

	@Column(name = "MODEL_THRSHLD_RISK_SCRE_NUM", precision = 53, scale = 0)
	public Double getModelThrshldRiskScreNum() {
		return this.modelThrshldRiskScreNum;
	}

	public void setModelThrshldRiskScreNum(Double modelThrshldRiskScreNum) {
		this.modelThrshldRiskScreNum = modelThrshldRiskScreNum;
	}

	@Column(name = "UPDT_FREQ_DESC", length = 30)
	public String getUpdtFreqDesc() {
		return this.updtFreqDesc;
	}

	public void setUpdtFreqDesc(String updtFreqDesc) {
		this.updtFreqDesc = updtFreqDesc;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "MODEL_IMPLTN_DT", length = 10)
	public Date getModelImpltnDt() {
		return this.modelImpltnDt;
	}

	public void setModelImpltnDt(Date modelImpltnDt) {
		this.modelImpltnDt = modelImpltnDt;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "MODEL_MDFCTN_DT", length = 10)
	public Date getModelMdfctnDt() {
		return this.modelMdfctnDt;
	}

	public void setModelMdfctnDt(Date modelMdfctnDt) {
		this.modelMdfctnDt = modelMdfctnDt;
	}

	@Column(name = "CLM_TYPE_CD", length = 50)
	public String getClmTypeCd() {
		return this.clmTypeCd;
	}

	public void setClmTypeCd(String clmTypeCd) {
		this.clmTypeCd = clmTypeCd;
	}

	@Column(name = "MODEL_VRSN_NUM", length = 50)
	public String getModelVrsnNum() {
		return this.modelVrsnNum;
	}

	public void setModelVrsnNum(String modelVrsnNum) {
		this.modelVrsnNum = modelVrsnNum;
	}



	@Column(name = "MODEL_IMPLTN_DT_STR", length = 50)
	public String getModelImpltnDtStr() {
		return this.modelImpltnDtStr;
	}

	public void setModelImpltnDtStr(String modelImpltnDtStr) {
		this.modelImpltnDtStr = modelImpltnDtStr;
	}

	

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsModel")
	@BatchSize(size = 50)
	public Set<FpsAlert> getFpsAlerts() {
		return this.fpsAlerts;
	}

	public void setFpsAlerts(Set<FpsAlert> fpsAlerts) {
		this.fpsAlerts = fpsAlerts;
	}

	

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsModel")
	public Set<FpsModelVrsn> getFpsModelVrsns() {
		return this.fpsModelVrsns;
	}

	public void setFpsModelVrsns(Set<FpsModelVrsn> fpsModelVrsns) {
		this.fpsModelVrsns = fpsModelVrsns;
	}

	

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fpsModel")
	@NotFound(action = NotFoundAction.IGNORE)
	public Set<FpsRptCardDtl> getFpsRptCardDtls() {
		return this.fpsRptCardDtls;
	}

	public void setFpsRptCardDtls(Set<FpsRptCardDtl> fpsRptCardDtls) {
		this.fpsRptCardDtls = fpsRptCardDtls;
	}

	@Column(name = "MODEL_TYPE_CD", length = 20)
	public String getModelTypeCd() {
		return this.modelTypeCd;
	}

	public void setModelTypeCd(String modelTypeCd) {
		this.modelTypeCd = modelTypeCd;
	}

	@Column(name = "RPT_CARD_TYPE_DESC")
	public String getRptCardTypeDesc() {
		return this.rptCardTypeDesc;
	}

	public void setRptCardTypeDesc(String rptCardTypeDesc) {
		this.rptCardTypeDesc = rptCardTypeDesc;
	}

	@Column(name = "MODEL_CMPST_SCRE_NUM")
	public Double getModelCmpstScreNum() {
		return this.modelCmpstScreNum;
	}

	public void setModelCmpstScreNum(Double modelCmpstScreNum) {
		this.modelCmpstScreNum = modelCmpstScreNum;
	}

	@Column(name = "MODEL_ACTVTY_STUS")
	public String getModelActvtyStus() {
		return modelActvtyStus;
	}

	public void setModelActvtyStus(String modelActvtyStus) {
		this.modelActvtyStus = modelActvtyStus;
	}
	@Column(name = "AUDT_UPDT_ID")
	public String getAudtUpdtId() {
		return audtUpdtId;
	}

	public void setAudtUpdtId(String audtUpdtId) {
		this.audtUpdtId = audtUpdtId;
	}
	@Column(name = "MODEL_GUIDANCE_DOC_FILE_PATH")
	public String getModelGuidanceDocFilePath() {
		return modelGuidanceDocFilePath;
	}

	public void setModelGuidanceDocFilePath(String modelGuidanceDocFilePath) {
		this.modelGuidanceDocFilePath = modelGuidanceDocFilePath;
	}
	@Column(name="PRIORITY_ALERT_IND")
	public String getPriorityInd() {
		return priorityInd;
	}

	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}
	@Column(name="HSTRY_LOOKBACK_PERIOD")
	public String getHstryLookbackPeriod() {
		return hstryLookbackPeriod;
	}

	public void setHstryLookbackPeriod(String hstryLookbackPeriod) {
		this.hstryLookbackPeriod = hstryLookbackPeriod;
	}
	
	
	//@Formula(value = "( select stusChg.last_status_chg_dt from fps2.vw_fps_model_last_status_chg stusChg "
	//		 + "where stusChg.model_id = model_id )")
	@Transient
	public Date getStatusDt() {
		return statusDt;
	}

	public void setStatusDt(Date statusDt) {
		this.statusDt = statusDt;
	}
	
	//@Formula(value = "(select date(max(b.change_ts))  from fps2.vw_fps_model_hstry b  where b.field = 'Priority Alert Indicator' and b.change_type = 'Update' and b.model_id = model_id)")
	@Transient
	public Date getPriorityDt() {
		return priorityDt;
	}

	public void setPriorityDt(Date priorityDt) {
		this.priorityDt = priorityDt;
	}
	//@Formula(value = "( select stusChg.changed_by from fps2.vw_fps_model_last_status_chg stusChg "
	//		 + "where stusChg.model_id = model_id )")
	@Transient
	public String getStatusChangeUser() {
		return statusChangeUser;
	}

	public void setStatusChangeUser(String statusChangeUser) {
		this.statusChangeUser = statusChangeUser;
	}
	//@Formula(value = "( select maxRun.MAX_RUN_DT from fps2.FPS_MAX_MODEL_RUN_DT_VW maxRun "
	//		 + "where maxRun.model_busns_id = model_busns_id )")
	@Transient
	public Date getMaxModelRunDt() {
		return maxModelRunDt;
	}

	public void setMaxModelRunDt(Date maxModelRunDt) {
		this.maxModelRunDt = maxModelRunDt;
	}

	@Column(name="VIS_TYPE_CD")
	public String getVisTypeCd() {
		return visTypeCd;
	}

	public void setVisTypeCd(String visTypeCd) {
		this.visTypeCd = visTypeCd;
	}
	@Formula(value = "( select dates.MODEL_WINDOW_CLM_DT_FLD||', '|| to_char(dates.MODEL_WINDOW_START_DT, 'YYYY/MM/DD')||'-'||to_char( dates.MODEL_WINDOW_END_DT,'YYYY/MM/DD') from fps2.FPS_MAX_MODEL_RUN_DT_VW maxRun\r\n" + 
			"inner join fps2.FPS_IE_GRP_RUN_CLM_END_DT dates on maxRun.max_run_dt = dates.model_run_dt and dates.model_busns_id = maxRun.model_busns_id\r\n" + 
			"			where maxRun.model_busns_id = model_busns_id )")
	public String getLookbackDates() {
		return lookbackDates;
	}

	public void setLookbackDates(String lookbackDates) {
		this.lookbackDates = lookbackDates;
	}
	@OneToMany(fetch = FetchType.LAZY) 
	@JoinColumn(name = "MODEL_ID", referencedColumnName="MODEL_ID",updatable = false, insertable = false)
	@NotFound(action = NotFoundAction.IGNORE)
	@BatchSize(size=500)
	public Set<VwFpsModelLastStatusChg> getVwFpsModelLastStatusChgs() {
		return vwFpsModelLastStatusChgs;
	}

	public void setVwFpsModelLastStatusChgs(Set<VwFpsModelLastStatusChg> vwFpsModelLastStatusChgs) {
		this.vwFpsModelLastStatusChgs = vwFpsModelLastStatusChgs;
	}
	@OneToMany(fetch = FetchType.LAZY) 
	@JoinColumn(name = "MODEL_BUSNS_ID", referencedColumnName="MODEL_BUSNS_ID",updatable = false, insertable = false)
	@NotFound(action = NotFoundAction.IGNORE)
	@BatchSize(size=500)
	public Set<FpsMaxModelRunDtVw> getFpsMaxModelRunDtVws() {
		return fpsMaxModelRunDtVws;
	}

	public void setFpsMaxModelRunDtVws(Set<FpsMaxModelRunDtVw> fpsMaxModelRunDtVws) {
		this.fpsMaxModelRunDtVws = fpsMaxModelRunDtVws;
	}
	
//	@OneToMany(fetch = FetchType.LAZY) 
//	@JoinColumn(name = "MODEL_ID", referencedColumnName="MODEL_ID",updatable = false, insertable = false)
//	@NotFound(action = NotFoundAction.IGNORE)
//	@BatchSize(size=500)
//	@OrderBy(value="MODEL_RUN_DT desc")
//	public Set<FpsIeGrpRunClmEndDt> getFpsIeGrpRunClmEndDts() {
//		return fpsIeGrpRunClmEndDts;
//	}
//
//	public void setFpsIeGrpRunClmEndDts(Set<FpsIeGrpRunClmEndDt> fpsIeGrpRunClmEndDts) {
//		this.fpsIeGrpRunClmEndDts = fpsIeGrpRunClmEndDts;
//	}

	@Column(name="model_alert_stus_age_days")
	public Integer getCadence() {
		return cadence;
	}

	public void setCadence(Integer cadence) {
		this.cadence = cadence;
	}
	@Column(name="PATH_TO_EDCTN_IND")
	public String getPathToEduInd() {
		return pathToEduInd;
	}

	public void setPathToEduInd(String pathToEduInd) {
		this.pathToEduInd = pathToEduInd;
	}
	
	//@Column(name = "MODEL_BUSNS_ID_EXTRNL", length = 30)
	@Transient
	public String getModelBusnsIdExtrnl() {
		return modelBusnsIdExtrnl;
	}

	public void setModelBusnsIdExtrnl(String modelBusnsIdExtrnl) {
		this.modelBusnsIdExtrnl = modelBusnsIdExtrnl;
	}
	@Transient
	public String getUiModelBusnsId() {
		return getModelBusnsIdExtrnl() != null ? getModelBusnsIdExtrnl() : getModelBusnsId();
	}
	@Transient
	public boolean isP1Model() {
		return this.getClmTypeCd() != null && this.getClmTypeCd().startsWith("P1");
	}
}
