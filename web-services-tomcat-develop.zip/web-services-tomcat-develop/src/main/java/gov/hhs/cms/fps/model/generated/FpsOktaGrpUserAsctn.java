package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FPS_OKTA_GROUP_USER_ASCTN")
public class FpsOktaGrpUserAsctn implements Serializable{

	private String groupNm;
	private String userNm;
	@Id
	@Column(name="GROUP_NAME")
	public String getGroupNm() {
		return groupNm;
	}
	public void setGroupNm(String groupNm) {
		this.groupNm = groupNm;
	}
	@Id
	@Column(name="USERNAME")
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
}
