package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FPS_OKTA_USERS")
public class FpsOktaUser  implements Serializable{

	private String userNm;
	private String friendlyNm;
	private String email;
	
	@Id
	@Column(name="USERNAME")
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	@Column(name="FRIENDLY_NAME")
	public String getFriendlyNm() {
		return friendlyNm;
	}
	public void setFriendlyNm(String friendlyNm) {
		this.friendlyNm = friendlyNm;
	}
	@Column(name="EMAIL")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
