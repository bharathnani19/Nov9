package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="FPS_PLND_SYS_OUTGE")
public class FpsPlndSysOutge
  implements Serializable
{
  private int plndSysOutgeId;
  private String outgeTitleTxt;
  private Date outgeStrtDt;
  private Date outgeEndDt;
  private String outgeAfctdZnTxt;
  private String audtInsrtId;
  private Date audtInsrtTs;
  private String audtUpdtId;
  private Date audtUpdtTs;
  private String fpsVrsnInd;
  
  public FpsPlndSysOutge() {}
  
  public FpsPlndSysOutge(int plndSysOutgeId, String audtInsrtId, Date audtInsrtTs)
  {
    this.plndSysOutgeId = plndSysOutgeId;
    this.audtInsrtId = audtInsrtId;
    this.audtInsrtTs = audtInsrtTs;
  }
  
  public FpsPlndSysOutge(int plndSysOutgeId, String outgeTitleTxt, Date outgeStrtDt, Date outgeEndDt, String outgeAfctdZnTxt, String audtInsrtId, Date audtInsrtTs, String audtUpdtId, Date audtUpdtTs, String fpsVrsnInd)
  {
    this.plndSysOutgeId = plndSysOutgeId;
    this.outgeTitleTxt = outgeTitleTxt;
    this.outgeStrtDt = outgeStrtDt;
    this.outgeEndDt = outgeEndDt;
    this.outgeAfctdZnTxt = outgeAfctdZnTxt;
    this.audtInsrtId = audtInsrtId;
    this.audtInsrtTs = audtInsrtTs;
    this.audtUpdtId = audtUpdtId;
    this.audtUpdtTs = audtUpdtTs;
    this.fpsVrsnInd = fpsVrsnInd;
  }
  
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  @Column(name="PLND_SYS_OUTGE_ID", unique=true, nullable=false)
  public int getPlndSysOutgeId()
  {
    return this.plndSysOutgeId;
  }
  
  public void setPlndSysOutgeId(int plndSysOutgeId)
  {
    this.plndSysOutgeId = plndSysOutgeId;
  }
  
  @Column(name="OUTGE_TITLE_TXT", length=200)
  public String getOutgeTitleTxt()
  {
    return this.outgeTitleTxt;
  }
  
  public void setOutgeTitleTxt(String outgeTitleTxt)
  {
    this.outgeTitleTxt = outgeTitleTxt;
  }
  
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="OUTGE_STRT_TS", length=10)
  public Date getOutgeStrtDt()
  {
    return this.outgeStrtDt;
  }
  
  public void setOutgeStrtDt(Date outgeStrtDt)
  {
    this.outgeStrtDt = outgeStrtDt;
  }
  
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="OUTGE_END_TS", length=10)
  public Date getOutgeEndDt()
  {
    return this.outgeEndDt;
  }
  
  public void setOutgeEndDt(Date outgeEndDt)
  {
    this.outgeEndDt = outgeEndDt;
  }
  
  @Column(name="OUTGE_AFCTD_ZN_TXT", length=100)
  public String getOutgeAfctdZnTxt()
  {
    return this.outgeAfctdZnTxt;
  }
  
  public void setOutgeAfctdZnTxt(String outgeAfctdZnTxt)
  {
    this.outgeAfctdZnTxt = outgeAfctdZnTxt;
  }
  
  @Column(name="AUDT_INSRT_ID", nullable=false, length=128)
  public String getAudtInsrtId()
  {
    return this.audtInsrtId;
  }
  
  public void setAudtInsrtId(String audtInsrtId)
  {
    this.audtInsrtId = audtInsrtId;
  }
  
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="AUDT_INSRT_TS", nullable=false, length=26)
  public Date getAudtInsrtTs()
  {
    return this.audtInsrtTs;
  }
  
  public void setAudtInsrtTs(Date audtInsrtTs)
  {
    this.audtInsrtTs = audtInsrtTs;
  }
  
  @Column(name="AUDT_UPDT_ID", length=128)
  public String getAudtUpdtId()
  {
    return this.audtUpdtId;
  }
  
  public void setAudtUpdtId(String audtUpdtId)
  {
    this.audtUpdtId = audtUpdtId;
  }
  
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="AUDT_UPDT_TS", length=26)
  public Date getAudtUpdtTs()
  {
    return this.audtUpdtTs;
  }
  
  public void setAudtUpdtTs(Date audtUpdtTs)
  {
    this.audtUpdtTs = audtUpdtTs;
  }
  
  @Column(name="FPS_VRSN_IND", length=1)
  public String getFpsVrsnInd()
  {
    return this.fpsVrsnInd;
  }
  
  public void setFpsVrsnInd(String fpsVrsnInd)
  {
    this.fpsVrsnInd = fpsVrsnInd;
  }
}
