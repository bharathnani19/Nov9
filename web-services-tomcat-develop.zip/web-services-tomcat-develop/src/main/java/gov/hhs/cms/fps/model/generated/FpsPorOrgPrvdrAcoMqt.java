package gov.hhs.cms.fps.model.generated;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="FPS_POR_ORG_PRVDR_ACO_MQT")
//@Subselect("select distinct a.PRVDR_NPI_NUM  from FPS_POR_ORG_PRVDR_DTL a where a.PRVDR_AFLTN_END_DT > current date and a.PGM_ORG_TYPE_CD = 'ACO' and length(trim(a.PRVDR_NPI_NUM)) > 0  "
//			)
public class FpsPorOrgPrvdrAcoMqt implements Serializable {

	private String prvdrNpiNum;
	@Id
	@Column(name="PRVDR_NPI_NUM")
	public String getPrvdrNpiNum() {
		return prvdrNpiNum;
	}

	public void setPrvdrNpiNum(String prvdrNpiNum) {
		this.prvdrNpiNum = prvdrNpiNum;
	}
	
}
